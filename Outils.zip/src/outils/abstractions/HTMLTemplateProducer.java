package outils.abstractions;

import java.io.InputStream;
import java.util.List;

import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.DefaultTestFilename;
import outils.tests.automated.annotations.DefaultTestValue;
import outils.tests.automated.annotations.NoParentMethodsTesting;
import outils.types.FilesCharsetsTypes;

/**
 * Modèle pour un fichier html
 * @author Claude Toupin - 5 janv. 2022
 */
@NoParentMethodsTesting
@DefaultParameterTestValue(type = String.class, name = "templateFile", value = "tests\\files\\abstractions\\HTMLTemplateProducer.txt")
@DefaultParameterTestValue(type = String[].class, name = "templateFiles", value = "tests\\files\\abstractions\\HTMLTemplateProducer.txt")
@DefaultParameterTestValue(type = String.class, name = "baseDir", value = "JunitHelper.getCurrentDirectory()", process = false)
@DefaultTestFilename("HTMLTemplateProducer.txt")
@DefaultTestValue(type = FilesCharsetsTypes.class, value = "FilesCharsetsTypes.UTF_8")
public class HTMLTemplateProducer extends TemplateProducer {
	/** Tag de début **/
	final private static String START_TAG = "{$";

	/** Tag de fin **/
	final private static String END_TAG = "}";

	/**
	 * Constructeur de base
	 */
	public HTMLTemplateProducer() {
		super();
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

	/**
	 * Constructeur de base
	 * @param template Contenu du modèle
	 */
	public HTMLTemplateProducer(List<String> template) {
		super(template);
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

	/**
	 * Constructeur de base
	 * @param baseDir Répertoire de base
	 * @param templateFiles Liste de noms complets de fichiers modèles
	 * @throws Exception en cas d'erreur...
	 */
	public HTMLTemplateProducer(String baseDir, String... templateFiles) throws Exception {
		super(baseDir, templateFiles);
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

	/**
	 * Constructeur de base
	 * @param baseDir Répertoire de base
	 * @param templateFile Nom complet du fichier modèle
	 * @param charsetType Type de jeu de caractères
	 * @throws Exception en cas d'erreur...
	 */
	public HTMLTemplateProducer(String baseDir, String templateFile, FilesCharsetsTypes charsetType) throws Exception {
		super(baseDir, templateFile, charsetType);
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

	/**
	 * Constructeur de base
	 * @param baseDir Répertoire de base
	 * @param templateFiles Liste de noms complets de fichiers modèles
	 * @param charsetType Type de jeu de caractères
	 * @throws Exception en cas d'erreur...
	 */
	public HTMLTemplateProducer(String baseDir, FilesCharsetsTypes charsetType, String... templateFiles) throws Exception {
		super(baseDir, charsetType, templateFiles);
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

	/**
	 * Constructeur de base
	 * @param inputStreams Liste de flux de données de fichiers modèles
	 * @throws Exception en cas d'erreur...
	 */
	public HTMLTemplateProducer(InputStream... inputStreams) throws Exception {
		super(inputStreams);
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données du fichier modèle
	 * @param charsetType Type de jeu de caractères
	 * @throws Exception en cas d'erreur...
	 */
	public HTMLTemplateProducer(InputStream inputStream, FilesCharsetsTypes charsetType) throws Exception {
		super(inputStream, charsetType);
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

	/**
	 * Constructeur de base
	 * @param charsetType Type de jeu de caractères
	 * @param inputStreams Liste de flux de données de fichiers modèles
	 * @throws Exception en cas d'erreur...
	 */
	public HTMLTemplateProducer(FilesCharsetsTypes charsetType, InputStream... inputStreams) throws Exception {
		super(charsetType, inputStreams);
		setStartTag(START_TAG);
		setEndTag(END_TAG);
	}

}