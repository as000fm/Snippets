package outils.abstractions;

import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Interface d'itération d'une liste avec plus de méthodes
 * @author Claude Toupin - 20 juill. 2022
 */
public interface IListIterator<E> extends ListIterator<E> {

	/**
	 * Extrait l'élément courant
	 * @return l'élément courant
	 * @throws NoSuchElementException s'il n'y a pas d'élément courant
	 */
	E get();

	/**
	 * Extrait l'index du curseur de l'itération
	 * @return l'index du curseur de l'itération
	 */
	int getCursor();

	/**
	 * Extrait l'index courant
	 * @return l'index courant
	 */
	int getIndex();

	/**
	 * Indicateur d'itération au début de la liste
	 * @return vrais si l'itération est au début de la liste
	 */
	boolean atFirst();

	/**
	 * Indicateur d'itération à la fin de la liste
	 * @return vrais si l'itération est à la fin de la liste
	 */
	boolean atLast();

	/**
	 * Extrait la liste courante
	 * @return la liste courante
	 */
	List<E> getList();

	/**
	 * Indicateur de liste vide
	 * @return vrai si la liste est vide
	 */
	boolean isEmpty();

	/**
	 * Extrait la taille de la liste courante
	 * @return la taille de la liste courante
	 */
	int size();
	
	/**
	 * Indicateur que la liste contient l'item spécifié
	 * @param item L'item à vérifier
	 * @return vari si la liste contient l'item spécifié
	 */
	boolean contains(E item);

	/**
	 * Modifie la liste courante à itérer et réinitialise l'itération
	 * @param list La nouvelle liste
	 * @throws NullPointerException si pas de liste à itérer de spécifiée
	 */
	void setList(List<E> list);

	/**
	 * Modifie la liste courante à itérer et réinitialise l'itération
	 * @param list La nouvelle liste
	 * @param cursor Index initiale du curseur de l'itération
	 * @throws NullPointerException si pas de liste à itérer de spécifiée
	 */
	void setList(List<E> list, int cursor);

	/**
	 * Réinitialise l'itération
	 */
	void reset();

	/**
	 * Réinitialise l'itération
	 * @param cursor Index initiale du curseur de l'itération
	 */
	void reset(int cursor);
}
