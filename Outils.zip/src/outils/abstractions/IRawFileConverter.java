package outils.abstractions;

import java.util.List;

/**
 * Interface de conversion de données brute selon le type du fichier
 * @author Claude Toupin - 1 mai 2019
 */
public interface IRawFileConverter {
	
	/**
	 * Extrait la liste des extensions de fichiers de type texte
	 * @return la liste des extensions de fichiers de type texte
	 */
	List<String> getTextExtensionsList();
	
	/**
	 * Conversion de données brute selon le type du fichier
	 * @param filename Nom du fichier
	 * @param raw Données brute 
	 * @return un objet selon le type de données du fichier
	 * @throws Exception en cas d'erreur...
	 */
	Object convert(String filename, byte[] raw) throws Exception;
	
	/**
	 * Indique si le fichier est de type texte ou non
	 * @param filename Nom du fichier
	 * @return vrai si le fichier est de type texte
	 * @throws Exception en cas d'erreur...
	 */
	boolean isTextType(String filename) throws Exception;
}
