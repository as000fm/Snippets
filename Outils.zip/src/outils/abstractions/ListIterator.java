package outils.abstractions;

import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Implémentation de l'interface d'itération d'une liste avec plus de méthodes
 * @author Claude Toupin - 20 juill. 2022
 */
public class ListIterator<E> implements IListIterator<E> {
	/** Liste à itérer **/
	private List<E> list;

	/** Taille attendu de la liste à itérer **/
	private transient int expectedSize;

	/** Index du curseur de l'itération **/
	private transient int cursor;

	/**
	 * Constructeur de base
	 * @param list Liste à itérer
	 * @throws NullPointerException si pas de liste à itérer de spécifiée
	 */
	public ListIterator(List<E> list) {
		setList(list);
	}

	/**
	 * Constructeur de base
	 * @param list Liste à itérer
	 * @param cursor Index initiale du curseur de l'itération
	 * @throws NullPointerException si pas de liste à itérer de spécifiée
	 */
	@AutomatedTests({ "a,b", "1" })
	public ListIterator(List<E> list, int cursor) {
		setList(list, cursor);
	}

	/**
	 * Vérifie si la liste a été modifiée de façon externe
	 * @throws ConcurrentModificationException si la liste a été modifiée de façon externe
	 */
	protected void checkForConcurrentModification() {
		if (expectedSize != list.size()) {
			throw new ConcurrentModificationException();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ListIterator [list=" + list + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof IListIterator) {
				IListIterator<?> iListIterator = (IListIterator<?>) obj;

				return OutilsBase.areEquals(list, iListIterator.getList());
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(list);
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#hasNext()
	 */
	@Override
	public boolean hasNext() {
		return cursor != list.size();
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#next()
	 */
	@Override
	public E next() {
		checkForConcurrentModification();

		try {
			E item = list.get(cursor++);
			return item;
		} catch (IndexOutOfBoundsException e) {
			checkForConcurrentModification();
			throw new NoSuchElementException();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#hasPrevious()
	 */
	@Override
	public boolean hasPrevious() {
		return cursor != 0;
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#previous()
	 */
	@Override
	public E previous() {
		checkForConcurrentModification();

		try {
			E item = list.get(--cursor);
			return item;
		} catch (IndexOutOfBoundsException e) {
			checkForConcurrentModification();
			throw new NoSuchElementException();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#nextIndex()
	 */
	@Override
	public int nextIndex() {
		return cursor;
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#previousIndex()
	 */
	@Override
	public int previousIndex() {
		return cursor - 1;
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#remove()
	 */
	@Override
	public void remove() {
		if (cursor < 1) {
			throw new IllegalStateException();
		}

		checkForConcurrentModification();

		try {
			list.remove(--cursor);
			expectedSize = list.size();
		} catch (IndexOutOfBoundsException e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#set(java.lang.Object)
	 */
	@Override
	public void set(E item) {
		checkForConcurrentModification();

		if (cursor < 1) {
			throw new IllegalStateException();
		}

		try {
			list.set(cursor - 1, item);
		} catch (IndexOutOfBoundsException e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.util.ListIterator#add(java.lang.Object)
	 */
	@Override
	public void add(E item) {
		checkForConcurrentModification();

		try {
			list.add(cursor++, item);
			expectedSize = list.size();
		} catch (IndexOutOfBoundsException e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#get()
	 */
	@Override
	public E get() {
		checkForConcurrentModification();

		if (cursor < 1) {
			throw new IllegalStateException();
		}

		try {
			return list.get(cursor - 1);
		} catch (IndexOutOfBoundsException e) {
			throw new NoSuchElementException();
		}
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#getCursor()
	 */
	@Override
	public int getCursor() {
		return cursor;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#getIndex()
	 */
	@Override
	public int getIndex() {
		return cursor - 1;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#atFirst()
	 */
	@Override
	public boolean atFirst() {
		return cursor <= 1;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#atLast()
	 */
	@Override
	public boolean atLast() {
		return cursor == list.size();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#getList()
	 */
	@Override
	public List<E> getList() {
		return list;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#isEmpty()
	 */
	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#size()
	 */
	@Override
	public int size() {
		return list.size();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#contains(java.lang.Object)
	 */
	@Override
	public boolean contains(E item) {
		return list.contains(item);
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#setList(java.util.List)
	 */
	@Override
	public void setList(List<E> list) {
		setList(list, 0);
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#setList(java.util.List, int)
	 */
	@Override
	public void setList(List<E> list, int cursor) {
		if (list == null) {
			throw new NullPointerException("Pas de liste à itérer de spécifiée");
		}

		this.list = list;
		this.expectedSize = list.size();

		reset(cursor);
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#reset()
	 */
	@Override
	public void reset() {
		reset(0);
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IListIterator#reset(int)
	 */
	@Override
	public void reset(int cursor) {
		this.cursor = (cursor <= list.size()) ? cursor : 0;
	}

}
