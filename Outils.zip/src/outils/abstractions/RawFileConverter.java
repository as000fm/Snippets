package outils.abstractions;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Convertisseur de base de données brute selon le type du fichier
 * @author Claude Toupin - 1 mai 2019
 */
public class RawFileConverter implements IRawFileConverter {
	/** Liste des extensions de fichiers de type texte **/
	final private List<String> textExtensionsList;

	/**
	 * Constructeur de base
	 */
	@TestMethodsInstance
	public RawFileConverter() {
		this.textExtensionsList = new ArrayList<String>();
		this.textExtensionsList.add(OutilsCommun.TEXT_EXTENSION);
		this.textExtensionsList.add(".text");
		this.textExtensionsList.add(OutilsCommun.LOG_EXTENSION);
		this.textExtensionsList.add(".htm");
		this.textExtensionsList.add(OutilsCommun.HTML_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.CSV_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.XML_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.JSON_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.INI_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.PROPERTIES_EXTENSION);
		this.textExtensionsList.add(".bat");
		this.textExtensionsList.add(".cmd");
		this.textExtensionsList.add(".sh");
		this.textExtensionsList.add(".csh");
		this.textExtensionsList.add(".bash");
		this.textExtensionsList.add(OutilsCommun.JAVA_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.GROOVY_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.POWERSHELL_EXTENSION);
		this.textExtensionsList.add(OutilsCommun.SQL_EXTENSION);
	}

	/**
	 * Constructeur de base
	 * @param extraTextExtensions Énumération des extensions supplémentaires de fichiers de type texte
	 */
	@AutomatedTests("null,.text")
	public RawFileConverter(String... extraTextExtensions) {
		this();

		if (extraTextExtensions != null) {
			for (String extra : extraTextExtensions) {
				if (!OutilsBase.isEmpty(extra)) {
					String extension = extra.toLowerCase().trim();

					if (!this.textExtensionsList.contains(extension)) {
						this.textExtensionsList.add(extension);
					}
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IRawFileConverter#getTextExtensionsList()
	 */
	@Override
	public List<String> getTextExtensionsList() {
		return textExtensionsList;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.RawFileConverter#convert(java.lang.String, byte[])
	 */
	@Override
	@AutomatedTests(value = { "RawFileConverter.css", "65", "RawFileConverter.txt", "66", "RawFileConverter.zip", "67" }, filenames = 0)
	public Object convert(String filename, byte[] raw) throws Exception {
		if (raw != null) {
			if (isTextType(filename)) {
				return new String(raw);
			}
		}

		return raw;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.IRawFileConverter#isTextType(java.lang.String)
	 */
	@Override
	@AutomatedTests(value = { "RawFileConverter.css", "RawFileConverter.txt", "RawFileConverter.zip" }, filenames = 0)
	public boolean isTextType(String filename) throws Exception {
		if (!OutilsBase.isEmpty(filename)) {
			String fn = filename.toLowerCase().trim();

			for (String extension : getTextExtensionsList()) {
				if (fn.endsWith(extension)) {
					return true;
				}
			}

			String type = Files.probeContentType(new File(filename).toPath());

			if (!OutilsBase.isEmpty(type)) {
				if (type.startsWith("text/")) {
					return true;
				}
			}
		}

		return false;
	}

}
