package outils.abstractions;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.DefaultTestValue;
import outils.tests.automated.annotations.SkipAllExceptions;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.FilesCharsetsTypes;

/**
 * Produit un List<String> basé sur un fichier modèle
 */
@SkipAllExceptions
@DefaultParameterTestValue(type = String.class, name = "basedir", value = "")
@DefaultParameterTestValue(type = String[].class, name = "templateFiles", value = "TemplateProducer.txt", filename = true)
@DefaultParameterTestValue(type = String.class, name = "templateFile", value = "TemplateProducer.txt", filename = true)
@DefaultParameterTestValue(type = InputStream.class, name = "inputStreams", value = "TemplateProducer.txt", filename = true)
@DefaultParameterTestValue(type = InputStream[].class, name = "inputStream", value = "TemplateProducer.txt", filename = true)
@DefaultTestValue(type = FilesCharsetsTypes.class, value = "FilesCharsetsTypes.UTF_8")
@CoverageTestsCases(TemplateProducer.CoverageTestsCases.class)
public class TemplateProducer extends TemplateProducerBase {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			TemplateProducer templateProducer = new TemplateProducer(OutilsCommun.getCurrentDirectory(), OutilsCommun.getFullname("tests", "files", "abstractions", "TemplateProducerCasesTest1.txt"), FilesCharsetsTypes.UTF_8);
			templateProducer.getTagsDictionary().put("Hello", "Hello");
			templateProducer.getTagsDictionary().put("Allo", null);
			templateProducer.getTagsDictionary().put("Toto", "Hello");
			templateProducer.getTagsDictionary().put("1", "Coco");

			templateProducer.produce();

			TemplateProducer templateProducerCase = new TemplateProducer() {

				@Override
				protected String onTag(String tag) throws Exception {
					return null;
				}
			};

			templateProducerCase.produce(OutilsCommun.getFullname("tests", "files", "abstractions", "TemplateProducerCasesTest2.txt"));
			templateProducerCase.produce(OutilsCommun.getFullname("tests", "files", "abstractions", "TemplateProducerCasesTest2.txt"), FilesCharsetsTypes.UTF_8);
			templateProducerCase.getTag();
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}
	}

	/** Dictionnaire des valeurs des balises à subsituter **/
	final private Map<String, Object> tagsDictionary;

	/**
	 * Constructeur de base
	 */
	@TestMethodsInstance
	public TemplateProducer() {
		super();
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/**
	 * Constructeur de base
	 * @param template Contenu du modèle
	 */
	public TemplateProducer(List<String> template) {
		super(template);
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/**
	 * Constructeur de base
	 * @param baseDir Répertoire de base
	 * @param templateFiles Liste de noms complets de fichiers modèles
	 * @throws Exception en cas d'erreur...
	 */
	public TemplateProducer(String baseDir, String... templateFiles) throws Exception {
		super(baseDir, templateFiles);
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/**
	 * Constructeur de base
	 * @param baseDir Répertoire de base
	 * @param templateFile Nom complet du fichier modèle
	 * @param charsetType Type de jeu de caractères
	 * @throws Exception en cas d'erreur...
	 */
	public TemplateProducer(String baseDir, String templateFile, FilesCharsetsTypes charsetType) throws Exception {
		super(baseDir, templateFile, charsetType);
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/**
	 * Constructeur de base
	 * @param baseDir Répertoire de base
	 * @param charsetType Type de jeu de caractères
	 * @param templateFiles Liste de noms complets de fichiers modèles
	 * @throws Exception en cas d'erreur...
	 */
	public TemplateProducer(String baseDir, FilesCharsetsTypes charsetType, String... templateFiles) throws Exception {
		super(baseDir, charsetType, templateFiles);
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/**
	 * Constructeur de base
	 * @param inputStreams Liste de flux de données de fichiers modèles
	 * @throws Exception en cas d'erreur...
	 */
	public TemplateProducer(InputStream... inputStreams) throws Exception {
		super(inputStreams);
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données du fichier modèle
	 * @param charsetType Type de jeu de caractères
	 * @throws Exception en cas d'erreur...
	 */
	public TemplateProducer(InputStream inputStream, FilesCharsetsTypes charsetType) throws Exception {
		super(inputStream, charsetType);
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/**
	 * Constructeur de base
	 * @param charsetType Type de jeu de caractères
	 * @param inputStreams Liste de flux de données de fichiers modèles
	 * @throws Exception en cas d'erreur...
	 */
	public TemplateProducer(FilesCharsetsTypes charsetType, InputStream... inputStreams) throws Exception {
		super(charsetType, inputStreams);
		this.tagsDictionary = new HashMap<String, Object>();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.TemplateProducerBase#beforeProduceLine(java.lang.String)
	 */
	@Override
	protected String beforeProduceLine(String line) throws Exception {
		return line;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.TemplateProducerBase#afterProduceLine(java.lang.String)
	 */
	@Override
	protected String afterProduceLine(String line) throws Exception {
		return line;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.TemplateProducerBase#onTag(java.lang.String)
	 */
	@Override
	protected String onTag(String tag) throws Exception {
		if (tagsDictionary.containsKey(tag)) {
			return OutilsBase.asString(tagsDictionary.get(tag));
		}

		return getStartTag() + tag + getEndTag();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.TemplateProducerBase#beforeProduce()
	 */
	@Override
	protected List<String> beforeProduce() throws Exception {
		return new ArrayList<String>();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.abstractions.TemplateProducerBase#afterProduce()
	 */
	@Override
	protected List<String> afterProduce() throws Exception {
		return new ArrayList<String>();
	}

	/**
	 * Extrait le champ tagsDictionary
	 * @return un Map<String,Object>
	 */
	public Map<String, Object> getTagsDictionary() {
		return tagsDictionary;
	}

}
