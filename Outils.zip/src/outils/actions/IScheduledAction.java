package outils.actions;

/**
 * Interface d'une action cédulée
 * @author Claude Toupin - 2012-07-23
 */
public interface IScheduledAction {
	/**
	 * Exécution de l'action
	 */
	void execute();
}
