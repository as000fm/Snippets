package outils.actions;

import java.util.Calendar;

import outils.commun.OutilsCommun;

/**
 * Classe  de base d'une action cédulée
 * @author Claude Toupin - 2012-07-23
 */
public abstract class ScheduledAction implements IScheduledAction {
	/** Date et heure de la prochaine action **/
	private Calendar nextScheduledAction;

	/** Date et heure en millisecondes de la prochaine action **/
	private long nextScheduledActionTime;

	/** Indicateur d'exécution immédiate de l'action **/
	private boolean executeNow;

	/**
	 * Constructeur de base
	 */
	public ScheduledAction() {
		this(false);
	}

	/**
	 * Constructeur de base
	 * @param executeNow Indicateur d'exécution immédiate de l'action
	 */
	public ScheduledAction(boolean executeNow) {
		this.nextScheduledAction = null;
		this.nextScheduledActionTime = 0;
		this.executeNow = executeNow;

		OutilsCommun.log(verbose());

		if (!executeNow) {
			nextTime();
		}
	}
	/**
	 * Extrait le champ executeNow
	 * @return un boolean
	 */
	protected boolean isExecuteNow() {
		return executeNow;
	}

	/**
	 * Modifie le champ executeNow
	 * @param executeNow La valeur du champ executeNow
	 */
	protected void setExecuteNow(boolean executeNow) {
		this.executeNow = executeNow;
	}

	/**
	 * Vérification si c'est le temps d'effectuer l'action ou non
	 * @return vrai si c'est le cas
	 */
	protected boolean isActionTime() {
		if (executeNow) {
			executeNow = false;
			nextScheduledAction = null;
			nextScheduledActionTime = 0;
			return true;
		}
		
		return (System.currentTimeMillis() >= nextScheduledActionTime);
	}

	/**
	 * Calcul de la date et heure de la prochaine action qui exécute une période précise a toutes les x minutes
	 */
	protected void nextPeriod(int minute) {
		assert (minute > 0) : "minute < 0";
		assert (minute < 60) : "minute > 60";

		if (isNextScheduledActionNull()) {
			Calendar initialAction = Calendar.getInstance();
			initialAction.set(Calendar.MINUTE, 0);
			initialAction.set(Calendar.SECOND, 0);
			initialAction.set(Calendar.MILLISECOND, 0);

			while (initialAction.getTimeInMillis() <= System.currentTimeMillis()) {
				initialAction.add(Calendar.MINUTE, minute);
			}

			setNextScheduledAction(initialAction);
		} else {
			addNextScheduledAction(Calendar.MINUTE, minute);
		}
	}

	/**
	 * Calcul de la date et heure de la prochaine action qui exécute sur l'heure
	 */
	protected void nextHour() {
		nextHourlyPeriod(0);
	}

	/**
	 * Calcul de la date et heure de la prochaine action qui exécute une période précise a toutes les heures
	 */
	protected void nextHourlyPeriod(int minute) {
		if (isNextScheduledActionNull()) {
			Calendar initialAction = Calendar.getInstance();
			initialAction.set(Calendar.MINUTE, minute % 60);
			initialAction.set(Calendar.SECOND, 0);
			initialAction.set(Calendar.MILLISECOND, 0);

			if (initialAction.getTimeInMillis() <= System.currentTimeMillis()) {
				initialAction.add(Calendar.HOUR, 1);
			}

			setNextScheduledAction(initialAction);
		} else {
			addNextScheduledAction(Calendar.HOUR, 1);
		}
	}

	/**
	 * Calcul de la date et heure de la prochaine action qui exécute une période précise a tous les jours
	 */
	protected void nextDailyPeriod(int hour, int minute) {
		if (isNextScheduledActionNull()) {
			Calendar initialAction = Calendar.getInstance();
			initialAction.set(Calendar.HOUR, hour % 24);
			initialAction.set(Calendar.HOUR_OF_DAY, hour % 24);
			initialAction.set(Calendar.MINUTE, minute % 60);
			initialAction.set(Calendar.SECOND, 0);
			initialAction.set(Calendar.MILLISECOND, 0);

			if (initialAction.getTimeInMillis() <= System.currentTimeMillis()) {
				initialAction.add(Calendar.DAY_OF_MONTH, 1);
			}

			setNextScheduledAction(initialAction);
		} else {
			addNextScheduledAction(Calendar.DAY_OF_MONTH, 1);
		}
	}

	/**
	 * Modifie le champ nextScheduledAction
	 * @param nextScheduledAction La valeur du champ nextScheduledAction
	 */
	protected void setNextScheduledAction(Calendar nextScheduledAction) {
		this.nextScheduledAction = nextScheduledAction;
		this.nextScheduledActionTime = (nextScheduledAction != null) ? nextScheduledAction.getTimeInMillis() : 0;
	}

	/**
	 * Ajout d'une période de temps à la date et heure de la prochaine action
	 * @param field the calendar field.
	 * @param amount the amount of date or time to be added to the field.
	 * @param field Le champ de type Calendar
	 * @param amount La valeur à ajouter
	 */
	protected void addNextScheduledAction(int field, int amount) {
		assert (nextScheduledAction != null) : "nextScheduledAction == null";

		nextScheduledAction.add(field, amount);
		nextScheduledActionTime = nextScheduledAction.getTimeInMillis();
	}

	/**
	 * Indique si la date et heure de la prochaine action est nulle
	 * @return vrai si nulle
	 */
	protected boolean isNextScheduledActionNull() {
		return nextScheduledAction == null;
	}

	/**
	 * Extrait le champ nextScheduledActionTime
	 * @return un long
	 */
	protected long getNextScheduledActionTime() {
		return nextScheduledActionTime;
	}


	/**
	 * Calcul de la date et heure de la prochaine action
	 */
	abstract protected void nextTime();

	/**
	 * Identifiaction de l'action
	 * @return un String
	 */
	abstract protected String verbose();

}
