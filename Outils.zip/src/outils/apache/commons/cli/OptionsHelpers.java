package outils.apache.commons.cli;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;

import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultTestValue;
import outils.tests.automated.annotations.SkipAllExceptions;

/**
 * Classe java des méthodes utilitaires statiques publiques pour l'aide et les options de la ligne de commande
 * @author Claude Toupin - 31 mars 2019
 */
@SkipAllExceptions
@DefaultTestValue(type = Class.class, value = "OptionsHelpers.class")
@DefaultTestValue(type = Options.class, value = "new Options()")
public class OptionsHelpers {

	/**
	 * Affichage de l'aide
	 * @param cls Classe de l'exécution
	 * @param options Paramètres de l'application
	 * @param french Indicateur de textes en français
	 */
	public static void displayHelp(Class<?> cls, Options options, boolean french) {
		displayHelp(cls, options, french, null);
	}

	/**
	 * Affichage de l'aide
	 * @param cls Classe de l'exécution
	 * @param options Paramètres de l'application
	 * @param french Indicateur de textes en français
	 * @param note Note de fin de page de l'aide
	 */
	public static void displayHelp(Class<?> cls, Options options, boolean french, String note) {
		String text = french ? "Options disponibles" : "Available options";

		HelpFormatter formatter = new HelpFormatter();
		formatter.setOptionComparator(null);
		formatter.printHelp(OutilsCommun.getConsole(), formatter.getWidth(), cls.getSimpleName(), "\n" + text + " :", options, formatter.getLeftPadding(), formatter.getDescPadding(), note, true);
		OutilsCommun.getConsole().flush();
	}

	/**
	 * Construction d'une option à la ligne de commande
	 * @param option L'option
	 * @return l'option à la ligne de commande
	 */
	public static String asOption(String option) {
		if (option == null) {
			return null;
		}

		return "-" + option;
	}

	/**
	 * Construction d'une option à la ligne de commande
	 * @param option L'option
	 * @param value Valeur du paramètre
	 * @return l'option à la ligne de commande
	 */
	@AutomatedTests({ "Hello", "World" })
	public static String asOption(String option, String value) {
		if (value == null) {
			return asOption(option);
		}

		if (value.indexOf(' ') != -1) {
			value = "\"" + value + "\"";
		}

		return "-" + option + " " + value;
	}

}
