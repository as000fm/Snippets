package outils.apache.commons.cli.console;

import outils.apache.commons.cli.console.base.ConsoleApplicationBase;
import outils.apache.commons.cli.types.OptionsTypes;

/**
 * Classe minimale pour l'exécution d'une application de type console (i.e. ligne de commande) en anglais
 * @author Claude Toupin - 1 oct. 2021
 */
public abstract class EnglishConsoleApplication extends ConsoleApplicationBase {

	/**
	 * Constructeur de base
	 * @param applicationTitle Titre de l'application
	 * @param applicationVersion Version de l'application
	 */
	public EnglishConsoleApplication(String applicationTitle, String applicationVersion) {
		this(applicationTitle, applicationVersion, false, false);
	}

	/**
	 * Constructeur de base
	 * @param applicationTitle Titre de l'application
	 * @param applicationVersion Version de l'application
	 * @param quietApplication Indicateur d'application sans affichage (i.e silencieuse)
	 */
	public EnglishConsoleApplication(String applicationTitle, String applicationVersion, boolean quietApplication) {
		this(applicationTitle, applicationVersion, quietApplication, false);
	}

	/**
	 * Constructeur de base
	 * @param applicationTitle Titre de l'application
	 * @param applicationVersion Version de l'application
	 * @param quietApplication Indicateur d'application sans affichage (i.e silencieuse)
	 * @param allowNoArguments Autorise ou non que la ligne de commande n'aie aucun argument
	 */
	public EnglishConsoleApplication(String applicationTitle, String applicationVersion, boolean quietApplication, boolean allowNoArguments) {
		super(applicationTitle, applicationVersion, quietApplication, allowNoArguments, false);

		addOptionData(OptionsTypes.HELP, "Displays help.");
	}

}
