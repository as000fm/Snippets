package outils.apache.commons.cli.console.base;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import outils.apache.commons.cli.OptionsHelpers;
import outils.apache.commons.cli.console.data.ConsoleApplicationOptionData;
import outils.apache.commons.cli.types.OptionsTypes;
import outils.base.OutilsBase;
import outils.commun.OutilsCommun;

/**
 * Classe de base pour l'exécution d'une application de type console (i.e. ligne de commande)
 * @author Claude Toupin - 8 nov. 2019
 */
public abstract class ConsoleApplicationBase {
	/** Titre de l'application **/
	final private String applicationTitle;

	/** Version de l'application **/
	final private String applicationVersion;

	/** Indicateur d'application sans affichage (i.e silencieuse) **/
	private boolean quietApplication;

	/** Autorise ou non que la ligne de commande n'aie aucun argument **/
	private boolean allowNoArguments;

	/** Liste des options **/
	final private List<ConsoleApplicationOptionData> optionsList;

	/** Indicateur de textes en français **/
	private boolean french;
	
	/** Arguments de la méthode execute **/
	private String[] executeArguments;

	/**
	 * Constructeur de base
	 * @param applicationTitle Titre de l'application
	 * @param applicationVersion Version de l'application
	 */
	public ConsoleApplicationBase(String applicationTitle, String applicationVersion) {
		this(applicationTitle, applicationVersion, false, false, true);
	}

	/**
	 * Constructeur de base
	 * @param applicationTitle Titre de l'application
	 * @param applicationVersion Version de l'application
	 * @param quietApplication Indicateur d'application sans affichage (i.e silencieuse)
	 */
	public ConsoleApplicationBase(String applicationTitle, String applicationVersion, boolean quietApplication) {
		this(applicationTitle, applicationVersion, quietApplication, false, true);
	}

	/**
	 * Constructeur de base
	 * @param applicationTitle Titre de l'application
	 * @param applicationVersion Version de l'application
	 * @param quietApplication Indicateur d'application sans affichage (i.e silencieuse)
	 * @param allowNoArguments Autorise ou non que la ligne de commande n'aie aucun argument
	 */
	public ConsoleApplicationBase(String applicationTitle, String applicationVersion, boolean quietApplication, boolean allowNoArguments) {
		this(applicationTitle, applicationVersion, quietApplication, allowNoArguments, true);
	}

	/**
	 * Constructeur de base
	 * @param applicationTitle Titre de l'application
	 * @param applicationVersion Version de l'application
	 * @param quietApplication Indicateur d'application sans affichage (i.e silencieuse)
	 * @param allowNoArguments Autorise ou non que la ligne de commande n'aie aucun argument
	 * @param french Indicateur de textes en français
	 */
	public ConsoleApplicationBase(String applicationTitle, String applicationVersion, boolean quietApplication, boolean allowNoArguments, boolean french) {
		this.applicationTitle = applicationTitle;
		this.applicationVersion = applicationVersion;
		this.quietApplication = quietApplication;
		this.allowNoArguments = allowNoArguments;
		this.optionsList = new ArrayList<ConsoleApplicationOptionData>();
		this.french = french;
		this.executeArguments = null;
	}

	/**
	 * Exécution de la ligne de commande par l'application console
	 * @param commandLine La ligne de commande à exécuter
	 * @return le code de retour de l'exécution
	 * @throws Exception en cas d'erreur...
	 */
	protected abstract int execute(CommandLine commandLine) throws Exception;

	/**
	 * Traitement d'une exception
	 * @param throwable L'exception à traiter
	 * @return vrai si pas de message à afficher
	 */
	protected boolean onException(Throwable throwable) {
		return false;
	}

	/**
	 * Indique si l'option d'aide est présente ou non
	 * @param argumentsList Liste des arguments
	 * @return vrai si l'option d'aide est présente
	 */
	protected boolean hasHelpOption(List<String> argumentsList) {
		return OptionsTypes.HELP.hasOption(french, argumentsList);
	}

	/**
	 * Effectue l'affichage de l'aide à la console
	 * @param options Options de la ligne de commande
	 * @param args Argumenets de la ligne de commande
	 */
	protected void doHelpOption(Options options, String[] args) {
		OptionsHelpers.displayHelp(getClass(), options, french);
	}

	/**
	 * Extrait la liste des options de base (i.e. toutes les options possibles)
	 * @return la liste des options de base
	 */
	protected List<ConsoleApplicationOptionData> getOptionsList() {
		return this.optionsList;
	}

	/**
	 * Extrait la liste des options pour un ictionnaire des options donné
	 * @param optionsList Liste des options à extraire la liste des options
	 * @return la liste des options
	 */
	protected List<ConsoleApplicationOptionData> getOptionsList(List<ConsoleApplicationOptionData> optionsList) {
		return this.optionsList;
	}

	/**
	 * Affichage de l'erreur à la console
	 * @param message Le message d'erreur à afficher
	 */
	protected void errorConsole(String message) {
		String separator = OutilsBase.padString("", '+', message.length());

		OutilsCommun.console(separator);
		OutilsCommun.console(message);
		OutilsCommun.console(separator);
	}

	/**
	 * Affichage de l'aide à la console
	 * @param message Message à afficher
	 * @param options Options de la ligne de commande
	 * @param args Argumenets de la ligne de commande
	 */
	protected void showHelpOption(String message, Options options, String[] args) {
		if (quietApplication) {
			showApplicationBanner(message);
		}

		doHelpOption(buildOptions(getOptionsList()), args);
	}

	/**
	 * Construction d'une option à la ligne de commande
	 * @param optionType Type de l'option
	 * @return l'option à la ligne de commande
	 */
	public String asOption(OptionsTypes optionType) {
		return optionType.asOption(french);
	}

	/**
	 * Construction d'une option à la ligne de commande
	 * @param optionType Type de l'option
	 * @param value Valeur du paramètre
	 * @return l'option à la ligne de commande
	 */
	public String asOption(OptionsTypes optionType, String value) {
		return optionType.asOption(french, value);
	}

	/**
	 * Construction d'une option au long (ex: -help) à la ligne de commande
	 * @param optionType Type de l'option
	 * @return l'option à la ligne de commande
	 */
	public String asLongOption(OptionsTypes optionType) {
		return optionType.asLongOption(french);
	}

	/**
	 * Construction d'une option au long (ex: -help) à la ligne de commande
	 * @param optionType Type de l'option
	 * @param value Valeur du paramètre
	 * @return l'option à la ligne de commande
	 */
	public String asLongOption(OptionsTypes optionType, String value) {
		return optionType.asLongOption(french, value);
	}

	/**
	 * Construction d'une option au long en double (ex: --help) à la ligne de commande
	 * @param optionType Type de l'option
	 * @return l'option à la ligne de commande
	 */
	public String asLongLongOption(OptionsTypes optionType) {
		return optionType.asLongLongOption(french);
	}

	/**
	 * Construction d'une option au long en double (ex: --help) à la ligne de commande
	 * @param optionType Type de l'option
	 * @param value Valeur du paramètre
	 * @return l'option à la ligne de commande
	 */
	public String asLongLongOption(OptionsTypes optionType, String value) {
		return optionType.asLongLongOption(french, value);
	}

	/**
	 * Extrait la valeur de l'option à la ligne de commande
	 * @param optionType Type de l'option
	 * @param commandLine La ligne de commande
	 * @return la valeur de l'option
	 */
	public String getOptionValue(OptionsTypes optionType, CommandLine commandLine) {
		if (commandLine != null) {
			return commandLine.getOptionValue(optionType.getOption(french));
		}

		return null;
	}

	/**
	 * Indique si l'option est présente ou non à la ligne de commande
	 * @param optionType Type de l'option
	 * @param commandLine La ligne de commande
	 * @return vrai si l'option est présente
	 */
	public boolean hasOption(OptionsTypes optionType, CommandLine commandLine) {
		if (commandLine != null) {
			return commandLine.hasOption(optionType.getOption(french));
		}

		return false;
	}

	/**
	 * Indique si l'option est présente ou non dans la liste des arguments
	 * @param optionType Type de l'option
	 * @param argumentsList La liste des arguments
	 * @return vrai si l'option est présente
	 */
	public boolean hasOption(OptionsTypes optionType, List<String> argumentsList) {
		if (!OutilsBase.isEmpty(argumentsList)) {
			return argumentsList.contains(optionType.asOption(french)) || argumentsList.contains(optionType.asLongOption(french)) || argumentsList.contains(optionType.asLongLongOption(french));
		}

		return false;
	}

	/**
	 * Indique si le texte de l'option au long existe ou non
	 * @param optionType Type de l'option
	 * @return vrai si le texte de l'option au long existe
	 */
	public boolean hasLongOption(OptionsTypes optionType) {
		return optionType.hasLongOption(french);
	}

	/**
	 * Extrait les données pour l'option
	 * @param optionType Type de l'option
	 * @param description Description de l'option
	 * @return les données pour l'option
	 */
	public ConsoleApplicationOptionData getOptionData(OptionsTypes optionType, String description) {
		return optionType.getOptionData(french, description);
	}

	/**
	 * Extrait les données pour l'option
	 * @param optionType Type de l'option
	 * @param arg Indicateur d'argument
	 * @param description Description de l'option
	 * @return les données pour l'option
	 */
	public ConsoleApplicationOptionData getOptionData(OptionsTypes optionType, boolean arg, String description) {
		return optionType.getOptionData(arg, arg, description);
	}

	/**
	 * Extrait les données pour l'option
	 * @param optionType Type de l'option
	 * @param arg Indicateur d'argument
	 * @param required Indicateur d'option requise
	 * @param description Description de l'option
	 * @return les données pour l'option
	 */
	public ConsoleApplicationOptionData getOptionData(OptionsTypes optionType, boolean arg, boolean required, String description) {
		return optionType.getOptionData(french, arg, required, description);
	}

	/**
	 * Ajout d'une option à la liste des options
	 * @param optionType Type de l'option
	 * @param description Description de l'option
	 * @return vrai si réussi
	 */
	public boolean addOptionData(OptionsTypes optionType, String description) {
		return optionsList.add(getOptionData(optionType, description));
	}

	/**
	 * Ajout d'une option à la liste des options
	 * @param optionType Type de l'option
	 * @param arg Indicateur d'argument
	 * @param description Description de l'option
	 * @return vrai si réussi
	 */
	public boolean addOptionData(OptionsTypes optionType, boolean arg, String description) {
		return optionsList.add(getOptionData(optionType, arg, arg, description));
	}

	/**
	 * Ajout d'une option à la liste des options
	 * @param optionType Type de l'option
	 * @param arg Indicateur d'argument
	 * @param required Indicateur d'option requise
	 * @param description Description de l'option
	 * @return vrai si réussi
	 */
	public boolean addOptionData(OptionsTypes optionType, boolean arg, boolean required, String description) {
		return optionsList.add(getOptionData(optionType, arg, required, description));
	}

	/**
	 * Validation des arguments
	 * @param args Arguments
	 * @return vrai si valide
	 */
	public boolean validate(String[] args) {
		return validate(OutilsBase.asList(args));
	}

	/**
	 * Validation des arguments
	 * @param args Arguments
	 * @return vrai si valide
	 */
	public boolean validate(List<String> argumentsList) {
		if (argumentsList.isEmpty() && !allowNoArguments) {
			return false;
		}

		List<ConsoleApplicationOptionData> optionsList = new ArrayList<ConsoleApplicationOptionData>();

		for (ConsoleApplicationOptionData optionData : getOptionsList()) {
			if (optionData.hasOption(argumentsList)) {
				optionsList.add(optionData);
			}
		}

		optionsList = getOptionsList(optionsList);

		if (hasHelpOption(argumentsList)) {
			return true;
		}

		Options options = buildOptions(optionsList);

		CommandLineParser parser = new DefaultParser();

		try {
			parser.parse(options, argumentsList.toArray(new String[argumentsList.size()]), false);
		} catch (ParseException parseException) {
			return false;
		}

		return true;
	}

	/**
	 * Exécution d'une application de type console
	 * @param args Arguments
	 * @return le code de retour de l'exécution
	 */
	public int execute(String[] args) {
		return execute(args, null);
	}

	/**
	 * Exécution d'une application de type console
	 * @param args Arguments
	 * @param message Message à afficher
	 * @return le code de retour de l'exécution
	 */
	public int execute(String[] args, String message) {
		executeArguments = args;
		
		int returnCode = 0;

		long start = System.currentTimeMillis();

		try {
			if (!quietApplication) {
				showApplicationBanner(message);
			}

			List<String> argumentsList = OutilsBase.asList(args);

			if (argumentsList.isEmpty() && !allowNoArguments) {
				showHelpOption(message, buildOptions(getOptionsList()), args);
			} else {
				List<ConsoleApplicationOptionData> optionsList = new ArrayList<ConsoleApplicationOptionData>();

				for (ConsoleApplicationOptionData optionData : getOptionsList()) {
					if (optionData.hasOption(argumentsList)) {
						optionsList.add(optionData);
					}
				}

				optionsList = getOptionsList(optionsList);

				if (hasHelpOption(argumentsList)) {
					showHelpOption(message, buildOptions(getOptionsList()), args);
				} else {
					Options options = buildOptions(optionsList);

					CommandLineParser parser = new DefaultParser();

					CommandLine commandLine;

					try {
						commandLine = parser.parse(options, args, false);
					} catch (ParseException parseException) {
						displayHelp(parseException, options);
						commandLine = null;
						returnCode = 99;
					}

					if (commandLine != null) {
						returnCode = execute(commandLine);
					}
				}
			}
		} catch (Throwable throwable) {
			if (!onException(throwable)) {
				OutilsCommun.console(throwable);
			}

			returnCode = 99;
		} finally {
			if (!quietApplication) {
				String status = french ? "Fin de l'exécution" : "End of execution";

				if (returnCode != 0) {
					status += (french ? " avec code de retour " : " with return code ") + returnCode;
				}

				String duration;

				if (french) {
					duration = "Temps total de l'exécution de l'application: " + OutilsBase.topChrono(start, "jour", "heure", "minute", "seconde", "milliseconde", true);
				} else {
					duration = "Total runtime of application: " + OutilsBase.topChrono(start, "day", "hour", "minute", "second", "millisecond", true);
				}

				String separator = OutilsBase.padString("", '=', duration.length());

				OutilsCommun.console(separator);
				OutilsCommun.console(duration);
				OutilsCommun.console(separator);
				OutilsCommun.console(status);
			}
		}

		return returnCode;
	}

	/**
	 * Constuction des options pour une liste des options donnée
	 * @param optionsDataList La liste des options à construire
	 * @return les options de l'application
	 */
	public Options buildOptions(List<ConsoleApplicationOptionData> optionsDataList) {
		Options options = new Options();

		if (optionsDataList != null) {
			for (ConsoleApplicationOptionData optionData : optionsDataList) {
				options.addOption(optionData.buildOption());
			}
		}

		return options;
	}

	/**
	 * Affichage de l'aide
	 */
	public void displayHelp() {
		displayHelp(null, buildOptions(getOptionsList()));
	}

	/**
	 * Affichage de l'aide
	 * @param Options Les options de l'application
	 */
	public void displayHelp(Options options) {
		displayHelp(null, options);
	}

	/**
	 * Affichage de l'aide
	 */
	public void displayHelp(ParseException parseException) {
		displayHelp(parseException, buildOptions(getOptionsList()));
	}

	/**
	 * Affichage de l'aide
	 * @param parseException Erreur lors de l'analyse des argumenets de la ligne de commande
	 * @param Options Les options de l'application
	 */
	public void displayHelp(ParseException parseException, Options options) {
		if (parseException != null) {
			OutilsCommun.console((french ? "Erreur: " : " Error: ") + parseException.getLocalizedMessage());
		}

		OptionsHelpers.displayHelp(this.getClass(), options, french);
	}

	/**
	 * Extrait la liste des textes de la banière de l'application
	 * @return la liste des textes de la banière de l'application
	 */
	public List<String> getApplicationBanner() {
		return getApplicationBanner(null);
	}

	/**
	 * Extrait la liste des textes de la banière de l'application
	 * @param message Message à afficher
	 * @return la liste des textes de la banière de l'application
	 */
	public List<String> getApplicationBanner(String message) {
		List<String> list = new ArrayList<String>();

		String banner = (getApplicationTitle() + " " + getApplicationVersion()).trim();

		list.add(banner);
		list.add(OutilsBase.padString("", '=', banner.length()));

		if (!OutilsBase.isEmpty(message)) {
			list.add(message);
			list.add(OutilsBase.padString("", '*', message.length()));
		}

		return list;
	}

	/**
	 * Affiche la banière de l'application
	 */
	public void showApplicationBanner() {
		showApplicationBanner(null);
	}

	/**
	 * Affiche la banière de l'application
	 * @param message Message à afficher
	 */
	public void showApplicationBanner(String message) {
		List<String> list = getApplicationBanner(message);

		for (String text : list) {
			OutilsCommun.console(text);
		}
	}

	/**
	 * Extrait le champ applicationTitle
	 * @return un String
	 */
	public String getApplicationTitle() {
		return applicationTitle;
	}

	/**
	 * Extrait le champ applicationVersion
	 * @return un String
	 */
	public String getApplicationVersion() {
		return applicationVersion;
	}

	/**
	 * Extrait le champ quietApplication
	 * @return un boolean
	 */
	public boolean isQuietApplication() {
		return quietApplication;
	}

	/**
	 * Modifie le champ quietApplication
	 * @param quietApplication La valeur du champ quietApplication
	 */
	public void setQuietApplication(boolean quietApplication) {
		this.quietApplication = quietApplication;
	}

	/**
	 * Extrait le champ french
	 * @return un boolean
	 */
	public boolean isFrench() {
		return french;
	}

	/**
	 * Extrait le champ executeArguments
	 * @return un String[]
	 */
	public String[] getExecuteArguments() {
		return executeArguments;
	}
}
