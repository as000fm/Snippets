package outils.apache.commons.cli.console.data;

import java.util.List;
import java.util.Objects;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Option.Builder;

import outils.apache.commons.cli.OptionsHelpers;
import outils.base.OutilsBase;
import outils.gson.OutilsGson;
import outils.tests.automated.annotations.AddImportsForTesting;
import outils.tests.automated.annotations.AllowRuntimeExceptions;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Classe de données d'une option pour une application de type console (i.e. ligne de commande)
 * @author Claude Toupin - 8 nov. 2019
 */
@AddImportsForTesting(ConsoleApplicationOptionData.class)
@DefaultParameterTestValue(type = String.class, name = "option", value = "h", strict = false)
@DefaultParameterTestValue(type = String.class, name = "longOption", value = "help", strict = false)
@DefaultParameterTestValue(type = String.class, name = "description", value = "Aide", strict = false)
public class ConsoleApplicationOptionData {
	/** Texte de l'option (ex: h) **/
	private String option;

	/** Texte de l'option au long (ex: help) **/
	private String longOption;

	/** Indicateur d'argument **/
	private boolean arg;

	/** Indicateur d'option requise **/
	private boolean required;

	/** Description de l'option **/
	private String description;

	/**
	 * Constructeur de base
	 * @param option Texte de l'option (ex: h)
	 * @param description Description de l'option
	 */
	@AllowRuntimeExceptions
	public ConsoleApplicationOptionData(String option, String description) {
		this(option, null, false, false, description);
	}

	/**
	 * Constructeur de base
	 * @param option Texte de l'option (ex: h)
	 * @param longOption Texte de l'option au long (ex: help)
	 * @param description Description de l'option
	 */
	public ConsoleApplicationOptionData(String option, String longOption, String description) {
		this(option, longOption, false, false, description);
	}

	/**
	 * Constructeur de base
	 * @param option Texte de l'option (ex: h)
	 * @param arg Indicateur d'argument
	 * @param description Description de l'option
	 */
	public ConsoleApplicationOptionData(String option, boolean arg, String description) {
		this(option, null, arg, false, description);
	}

	/**
	 * Constructeur de base
	 * @param option Texte de l'option (ex: h)
	 * @param longOption Texte de l'option au long (ex: help)
	 * @param arg Indicateur d'argument
	 * @param description Description de l'option
	 */
	public ConsoleApplicationOptionData(String option, String longOption, boolean arg, String description) {
		this(option, longOption, arg, false, description);
	}

	/**
	 * Constructeur de base
	 * @param option Texte de l'option (ex: h)
	 * @param arg Indicateur d'argument
	 * @param required Indicateur d'option requise
	 * @param description Description de l'option
	 */
	public ConsoleApplicationOptionData(String option, boolean arg, boolean required, String description) {
		this(option, null, arg, required, description);
	}

	/**
	 * Constructeur de base
	 * @param option Texte de l'option (ex: h)
	 * @param longOption Texte de l'option au long (ex: help)
	 * @param arg Indicateur d'argument
	 * @param required Indicateur d'option requise
	 * @param description Description de l'option
	 */
	@TestMethodsInstance
	public ConsoleApplicationOptionData(String option, String longOption, boolean arg, boolean required, String description) {
		if (OutilsBase.isEmpty(option)) {
			throw new RuntimeException("Valeur requise pour option !!!");
		}

		// longOption est facultatif (optionnel)

		if (OutilsBase.isEmpty(description)) {
			throw new RuntimeException("Valeur requise pour description !!!");
		}

		this.option = option;
		this.longOption = longOption;
		this.arg = arg;
		this.required = required;
		this.description = description;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return OutilsGson.toJson(this);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	@AutomatedTests("new ConsoleApplicationOptionData(\"t\", \"toto\", true, true, \"Toto\")")
	@AutomatedTests("new ConsoleApplicationOptionData(\"h\", \"toto\", true, true, \"Toto\")")
	@AutomatedTests("new ConsoleApplicationOptionData(\"h\", \"help\", true, true, \"Toto\")")
	@AutomatedTests("new ConsoleApplicationOptionData(\"h\", \"help\", true, true, \"Aide\")")
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof ConsoleApplicationOptionData) {
				ConsoleApplicationOptionData consoleApplicationOptionData = (ConsoleApplicationOptionData) obj;

				return OutilsBase.areEquals(option, consoleApplicationOptionData.getOption()) //
						&& OutilsBase.areEquals(longOption, consoleApplicationOptionData.getLongOption()) //
						&& (arg == consoleApplicationOptionData.hasArg()) //
						&& (required == consoleApplicationOptionData.isRequired()) //
						&& OutilsBase.areEquals(description, consoleApplicationOptionData.getDescription()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(arg, description, longOption, option, required);
	}

	/**
	 * construction de l'option selon les valeurs des champs
	 * @return un Builder
	 */
	public Option buildOption() {
		Builder build = Option.builder(option).required(required).hasArg(arg).desc(description);

		if (!OutilsBase.isEmpty(longOption)) {
			build.longOpt(longOption);
		}

		return build.build();
	}

	/**
	 * Indique si l'option est présente ou non dans la liste des arguments
	 * @param argumentsList Liste des arguments
	 * @return vrai si l'option est présente dans la liste des arguments
	 */
	@AutomatedTests({ "-h,-help,--help", "-help,--help", "--help" })
	public boolean hasOption(List<String> argumentsList) {
		boolean found = false;

		if (argumentsList != null) {
			found = argumentsList.contains(OptionsHelpers.asOption(option));

			if (!found) {
				if (!OutilsBase.isEmpty(longOption)) {
					found = argumentsList.contains(OptionsHelpers.asOption(longOption)) || argumentsList.contains(OptionsHelpers.asOption(OptionsHelpers.asOption(longOption)));
				}
			}
		}

		return found;
	}

	/**
	 * Extrait le champ option
	 * @return un String
	 */
	public String getOption() {
		return option;
	}

	/**
	 * Modifie le champ option
	 * @param option La valeur du champ option
	 * @return un ConsoleApplicationOptionData
	 */
	public ConsoleApplicationOptionData setOption(String option) {
		this.option = option;
		return this;
	}

	/**
	 * Extrait le champ longOption
	 * @return un String
	 */
	public String getLongOption() {
		return longOption;
	}

	/**
	 * Modifie le champ longOption
	 * @param longOption La valeur du champ longOption
	 * @return un ConsoleApplicationOptionData
	 */
	public ConsoleApplicationOptionData setLongOption(String longOption) {
		this.longOption = longOption;
		return this;
	}

	/**
	 * Extrait le champ arg
	 * @return un boolean
	 */
	public boolean hasArg() {
		return arg;
	}

	/**
	 * Modifie le champ arg
	 * @param arg La valeur du champ arg
	 * @return un ConsoleApplicationOptionData
	 */
	public ConsoleApplicationOptionData setArg(boolean arg) {
		this.arg = arg;
		return this;
	}

	/**
	 * Extrait le champ required
	 * @return un boolean
	 */
	public boolean isRequired() {
		return required;
	}

	/**
	 * Modifie le champ required
	 * @param required La valeur du champ required
	 * @return un ConsoleApplicationOptionData
	 */
	public ConsoleApplicationOptionData setRequired(boolean required) {
		this.required = required;
		return this;
	}

	/**
	 * Extrait le champ description
	 * @return un String
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Modifie le champ description
	 * @param description La valeur du champ description
	 * @return un ConsoleApplicationOptionData
	 */
	public ConsoleApplicationOptionData setDescription(String description) {
		this.description = description;
		return this;
	}
}
