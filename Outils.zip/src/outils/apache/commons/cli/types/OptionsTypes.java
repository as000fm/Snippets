package outils.apache.commons.cli.types;

import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;

import outils.apache.commons.cli.OptionsHelpers;
import outils.apache.commons.cli.console.data.ConsoleApplicationOptionData;
import outils.base.OutilsBase;
import outils.tests.automated.annotations.AddImportsForTesting;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types des options dispnibles
 * @author Claude Toupin - 1 oct. 2021
 */
@AddImportsForTesting({ Option.class, OptionsTypes.class })
public enum OptionsTypes {
	ADMINISTRATOR("adm", "administrator", "adm", "administrateur"), //
	AFTER("after", null, "apres", null), //
	API("api", null, "api", null), //
	ASYNCHRONOUS("async", "asynchronous", "async", "asynchrone"), //
	BANNER("ban", "banner", "ban", "banniere"), //
	BEFORE("before", null, "avant", null), //
	CATEGORY("cat", "category", "cat", "categorie"), //
	COMMAND("cmd", "command", "cmd", "commande"), //
	COMPLETE("complete", null, "complet", null), //
	CONFIGURATION("conf", "configuration", "conf", "configuration"), //
	CSV("csv", null, "csv", null), //
	CURRENT("current", null, "actuel", null), //
	DATE("date", "date"), //
	DEBUG("debug", null, "debug", "deboguage"), //
	DELAY("delay", null, "delai", null), //
	DELEGATE("delegate", null, "delegation", null), //
	DELETE("del", "delete", "sup", "suppression"), //
	DESTINATION("dest", "destination", "dest", "destination"), //
	DIRECT("direct", null, "direct", null), //
	DIRECTORY("dir", "directory", "rep", "repertoire"), //
	ENVIRONMENT("env", "environment", "env", "environnement"), //
	EMAIL("email", null, "courriel", null), //
	EXCEL("excel", null, "excel", null), //
	EXECUTE("exec", "execute", "exec", "execution"), //
	EXPORT("export", null, "export", "exportation"), //
	FILE("file", "fichier"), //
	FILTER("filter", null, "filtre", null), //
	FORCE("force", null, "force", null), //
	FULL("full", null, "complet", null), //
	HELP("help", "aide"), //
	HOSTNAME("host", "hostname", "hote", null), //
	ID("id", null, "id", null), //
	IMPORT("import", null, "import", "importation"), //
	ITEM("item", "item"), //
	JSON("json", null, "json", null), //
	KEY("k", "key", "cle", null), //
	LIST("list", "liste"), //
	LOG("log", null, "jrnl", "journal"), //
	NAME("name", "name"), //
	OCTOPRINT("octo", "octoprint", "octo", "octoprint"), //
	OPTION("option", null, "option", null), //
	OPTIONS("options", null, "options", null), //
	OUTPUT("o", "output", "sortie", null), //
	PACKAGE("pkg", "package", "pkg", "package"), //
	PARAMETERS("params", "parameters", "params", "parametres"), //
	PASSWORD("p", "password", "mdp", null), //
	PERMISSIONS("perms", "permissions", "perms", "permissions"), //
	PI("pi", "raspberrypi", "pi", "raspberrypi"), //
	PLAN("plan", null, "plan", null), //
	PLANNING("planning", null, "planif", "planification"), //
	PROFILES("profs", "profiles", "profs", "profiles"), //
	RATE("rate", null, "taux", null), //
	REBOOT("reboot", null, "redem", "redemarrage"), //
	REPORT("rpt", "report", "rpt", "rapport"), //
	RESET("reset", null, "raz", "reinitialise"), //
	RESTART("restart", null, "rep", "repartir"), //
	RECOVERY("recovery", null, "recupere", null), //
	RUN("run", null, "exec", "execution"), //
	SCRIPT("script", null, "script", null), //
	SEQUENCE("seq", "sequence", "seq", "sequence"), //
	SERVICE("service", null, "service", null), //
	SHUTDOWN("shutdown", null, "ferme", "fermeture"), //
	SIMULATION("sim", "simulation", "sim", "simulation"), //
	SOURCE("src", "source", "src", "source"), //
	STATUS("status", "statut"), //
	START("start", null, "depart", null), //
	STOP("stop", null, "arret", null), //
	TIME("time", "heure"), //
	TOMCAT("tc", "tomcat", "tc", "tomcat"), //
	TYPE("type", null, "type", null), //
	USER("user", "usager"), //
	VALUE("value", "valeur"), //
	VERSION("ver", "version", "ver", "version"), //
	ZIP("zip", null, "zip", null), //
	;

	/** Texte de l'option en anglais (ex: h) **/
	final private String optionEnglish;

	/** Texte de l'option au long en anglais (ex: help) **/
	final private String longOptionEnglish;

	/** Texte de l'option en français (ex: a) **/
	final private String optionFrench;

	/** Texte de l'option au long en français (ex: aide) **/
	final private String longOptionFrench;

	/**
	 * Constructeur de base
	 * @param longOptionEnglish Texte de l'option au long en anglais
	 * @param longOptionFrench Texte de l'option au long en français
	 */
	private OptionsTypes(String longOptionEnglish, String longOptionFrench) {
		this(longOptionEnglish.substring(0, 1), longOptionEnglish, longOptionFrench.substring(0, 1), longOptionFrench);
	}

	/**
	 * Constructeur de base
	 * @param optionEnglish Texte de l'option en anglais
	 * @param longOptionEnglish Texte de l'option au long en anglais
	 * @param optionFrench Texte de l'option en français
	 * @param longOptionFrench Texte de l'option au long en français
	 */
	private OptionsTypes(String optionEnglish, String longOptionEnglish, String optionFrench, String longOptionFrench) {
		this.optionEnglish = optionEnglish;
		this.longOptionEnglish = longOptionEnglish;
		this.optionFrench = optionFrench;
		this.longOptionFrench = longOptionFrench;
	}

	/**
	 * Construction d'une option à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @return l'option à la ligne de commande
	 */
	public String asOption(boolean french) {
		return OptionsHelpers.asOption(french ? optionFrench : optionEnglish);
	}

	/**
	 * Construction d'une option à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @param value Valeur du paramètre
	 * @return l'option à la ligne de commande
	 */
	public String asOption(boolean french, String value) {
		return OptionsHelpers.asOption(french ? optionFrench : optionEnglish, value);
	}

	/**
	 * Construction d'une option au long (ex: -help) à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @return l'option à la ligne de commande
	 */
	public String asLongOption(boolean french) {
		return OptionsHelpers.asOption(french ? longOptionFrench : longOptionEnglish);
	}

	/**
	 * Construction d'une option au long (ex: -help) à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @param value Valeur du paramètre
	 * @return l'option à la ligne de commande
	 */
	public String asLongOption(boolean french, String value) {
		return OptionsHelpers.asOption(french ? longOptionFrench : longOptionEnglish, value);
	}

	/**
	 * Construction d'une option au long en double (ex: --help) à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @return l'option à la ligne de commande
	 */
	public String asLongLongOption(boolean french) {
		return OptionsHelpers.asOption(OptionsHelpers.asOption(french ? longOptionFrench : longOptionEnglish));
	}

	/**
	 * Construction d'une option au long en double (ex: --help) à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @param value Valeur du paramètre
	 * @return l'option à la ligne de commande
	 */
	public String asLongLongOption(boolean french, String value) {
		return OptionsHelpers.asOption(OptionsHelpers.asOption(french ? longOptionFrench : longOptionEnglish, value));
	}

	/**
	 * Extrait la valeur de l'option à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @param commandLine La ligne de commande
	 * @return la valeur de l'option
	 */
	@AutomatedTests({ "false", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(false), \"Help !!!\")).build()" })
	@AutomatedTests({ "true", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(false), \"Help !!!\")).build()" })
	@AutomatedTests({ "false", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(true), \"Help !!!\")).build()" })
	@AutomatedTests({ "true", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(true), \"Help !!!\")).build()" })
	public String getOptionValue(boolean french, CommandLine commandLine) {
		if (commandLine != null) {
			return commandLine.getOptionValue(french ? optionFrench : optionEnglish);
		}

		return null;
	}

	/**
	 * Indique si l'option est présente ou non à la ligne de commande
	 * @param french Indicateur d'option en français
	 * @param commandLine La ligne de commande
	 * @return vrai si l'option est présente
	 */
	@AutomatedTests({ "false", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(false), \"Help !!!\")).build()" })
	@AutomatedTests({ "true", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(false), \"Help !!!\")).build()" })
	@AutomatedTests({ "false", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(true), \"Help !!!\")).build()" })
	@AutomatedTests({ "true", "new CommandLine.Builder().addOption(new Option(OptionsTypes.HELP.getOption(true), \"Help !!!\")).build()" })
	public boolean hasOption(boolean french, CommandLine commandLine) {
		if (commandLine != null) {
			return commandLine.hasOption(french ? optionFrench : optionEnglish);
		}

		return false;
	}

	/**
	 * Indique si l'option est présente ou non dans la liste des arguments
	 * @param french Indicateur d'option en français
	 * @param argumentsList La liste des arguments
	 * @return vrai si l'option est présente
	 */
	@AutomatedTests(value = { "false", "junit.JunitHelper.asList(OptionsTypes.HELP.asOption(false))" }, process = false)
	@AutomatedTests(value = { "false", "junit.JunitHelper.asList(OptionsTypes.HELP.asLongOption(false))" }, process = false)
	@AutomatedTests(value = { "false", "junit.JunitHelper.asList(OptionsTypes.HELP.asLongLongOption(false))" }, process = false)
	@AutomatedTests(value = { "true", "junit.JunitHelper.asList(OptionsTypes.HELP.asOption(true))" }, process = false)
	@AutomatedTests(value = { "true", "junit.JunitHelper.asList(OptionsTypes.HELP.asLongOption(true))" }, process = false)
	@AutomatedTests(value = { "true", "junit.JunitHelper.asList(OptionsTypes.HELP.asLongLongOption(true))" }, process = false)
	public boolean hasOption(boolean french, List<String> argumentsList) {
		if (!OutilsBase.isEmpty(argumentsList)) {
			return argumentsList.contains(asOption(french)) || argumentsList.contains(asLongOption(french)) || argumentsList.contains(asLongLongOption(french));
		}

		return false;
	}

	/**
	 * Indique si le texte de l'option au long existe ou non
	 * @param french Indicateur d'option en français
	 * @return vrai si le texte de l'option au long existe
	 */
	public boolean hasLongOption(boolean french) {
		return !OutilsBase.isEmpty(french ? longOptionFrench : longOptionEnglish);
	}

	/**
	 * Extrait les données pour l'option
	 * @param french Indicateur d'option en français
	 * @param description Description de l'option
	 * @return les données pour l'option
	 */
	public ConsoleApplicationOptionData getOptionData(boolean french, String description) {
		return new ConsoleApplicationOptionData(french ? optionFrench : optionEnglish, french ? longOptionFrench : longOptionEnglish, description);
	}

	/**
	 * Extrait les données pour l'option
	 * @param french Indicateur d'option en français
	 * @param arg Indicateur d'argument
	 * @param description Description de l'option
	 * @return les données pour l'option
	 */
	public ConsoleApplicationOptionData getOptionData(boolean french, boolean arg, String description) {
		return new ConsoleApplicationOptionData(french ? optionFrench : optionEnglish, french ? longOptionFrench : longOptionEnglish, arg, description);
	}

	/**
	 * Extrait les données pour l'option
	 * @param french Indicateur d'option en français
	 * @param arg Indicateur d'argument
	 * @param required Indicateur d'option requise
	 * @param description Description de l'option
	 * @return les données pour l'option
	 */
	public ConsoleApplicationOptionData getOptionData(boolean french, boolean arg, boolean required, String description) {
		return new ConsoleApplicationOptionData(french ? optionFrench : optionEnglish, french ? longOptionFrench : longOptionEnglish, arg, required, description);
	}

	/**
	 * Extrait le champ option
	 * @param french Indicateur d'option en français
	 * @return un String
	 */
	public String getOption(boolean french) {
		return french ? optionFrench : optionEnglish;
	}

	/**
	 * Extrait le champ longOption
	 * @param french Indicateur d'option en français
	 * @return un String
	 */
	public String getLongOption(boolean french) {
		return french ? longOptionFrench : longOptionEnglish;
	}
}
