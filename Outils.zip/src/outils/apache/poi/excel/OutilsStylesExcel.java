package outils.apache.poi.excel;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.IndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import outils.apache.poi.excel.types.ColorsStylesTypes;
import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultTestValue;

/**
 * Classe des méthodes statiques des outils et styles pour Excel
 * @author Claude Toupin - 13 mars 2019
 */
@DefaultTestValue(type = XSSFWorkbook.class, value = "new XSSFWorkbook()")
public class OutilsStylesExcel {
	/** Taille maximale d'une colonne **/
	final public static int MAX_COLUMNS_SIZE = 255 * 256;

	/** Extension d'un fichier Excel **/
	final public static String EXCEL_EXTENSION = ".xlsx";

	/**
	 * Extrait le nom de la colonne pour un index donné
	 * @param index L'index à extraire (0 => A)
	 * @return le nom de la colonne pour un index donné
	 */
	@AutomatedTests("-100")
	final public static String getExcelColumnName(int index) {
		if (index < 0) {
			index = -index;
		}

		String name = "";

		do {
			name = OutilsBase.asString((char) ('A' + (index % 26)));
			index /= 26;
		} while (index != 0);

		return name;
	}

	/**
	 * Formattage d'une date AAAA-MM-JJ HHhMM pour les noms de feuilles
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String formatDateTimeSheet(Date date) {
		return (date != null) ? OutilsCommun.asFrenchDateTimeString(date) : "";
	}

	/**
	 * Formattage d'une heure HHhMM pour les noms de feuilles
	 * @param date L'heure à formatter
	 * @return un String ("" si null)
	 */
	final public static String formatTimeSheet(Date date) {
		return (date != null) ? OutilsCommun.asFrenchTimeString(date) : "";
	}

	/**
	 * Formattage d'un pourcentage à une décimale arrondie
	 * @param value La valeur à formatter
	 * @return le poucentage à une décimale arrondie
	 */
	final public static double formatPercentage(double value) {
		return Math.round(1000.0 * value) / 1000.0;
	}

	/**
	 * Formattage d'un pourcentage à une décimale arrondie
	 * @param value La valeur à formatter
	 * @return le poucentage à une décimale arrondie en String
	 */
	@AutomatedTests("(Double) null")
	final public static String formatPercentageAsString(Double value) {
		return OutilsBase.isEmpty(value) ? "" : OutilsBase.asString(formatPercentage(value));
	}

	/**
	 * Calcul d'un pourcentage à une décimale arrondie
	 * @param count Le nombre
	 * @param total Le total
	 * @return le poucentage à une décimale arrondie
	 */
	final public static double computePercentage(int count, int total) {
		return Math.round((1000.0 * (double) count) / (double) total) / 1000.0;
	}

	/**
	 * Calcul d'un pourcentage à une décimale arrondie
	 * @param count Le nombre
	 * @param total Le total
	 * @return le poucentage à une décimale arrondie
	 */
	final public static double computePercentage(long count, long total) {
		return Math.round((1000.0 * (double) count) / (double) total) / 1000.0;
	}

	/**
	 * Calcul d'un pourcentage à une décimale arrondie
	 * @param count Le nombre
	 * @param total Le total
	 * @return le poucentage à une décimale arrondie en String
	 */
	final public static String computePercentageAsString(int count, int total) {
		return OutilsBase.asString(computePercentage(count, total));
	}

	/**
	 * Calcul d'un pourcentage à une décimale arrondie
	 * @param count Le nombre
	 * @param total Le total
	 * @return le poucentage à une décimale arrondie en String
	 */
	final public static String computePercentageAsString(long count, long total) {
		return OutilsBase.asString(computePercentage(count, total));
	}

	/**
	 * Ajout d'une feuille au tableur
	 * @param workbook Le tableur
	 * @param sheetName Nom de la feuille
	 * @return la nouvelle feuille
	 */
	@AutomatedTests({ "null", "null" })
	final public static XSSFSheet addSheet(XSSFWorkbook workbook, String sheetName) {
		if (workbook == null) {
			return null;
		}

		XSSFSheet sheet = workbook.createSheet(OutilsBase.asString(sheetName).trim());

		sheet.setPrintGridlines(false);
		sheet.setFitToPage(true);
		sheet.setAutobreaks(true);

		PrintSetup printSetup = sheet.getPrintSetup();
		printSetup.setLandscape(false);
		printSetup.setFitHeight((short) 1);
		printSetup.setFitWidth((short) 1);

		return sheet;
	}

	/**
	 * Calcul de la largueur d'un texte en unités de 1/256ièmes
	 * @param text Le texte
	 * @return la largeur en unités de 1/256ièmes
	 */
	final public static int computeTextWidthExtra(String text) {
		return computeTextWidthExtra(OutilsBase.asString(text).length());
	}

	/**
	 * Calcul de la largueur d'un texte en unités de 1/256ièmes
	 * @param length La taille du texte
	 * @return la largeur en unités de 1/256ièmes
	 */
	final public static int computeTextWidthExtra(int length) {
		return OutilsBase.min(MAX_COLUMNS_SIZE, (length + 1) * 256);
	}

	/**
	 * Calcul de la largueur d'un texte en unités de 1/256ièmes
	 * @param text Le texte
	 * @return la largeur en unités de 1/256ièmes
	 */
	final public static int computeTextWidth(String text) {
		return computeTextWidth(OutilsBase.asString(text).length());
	}

	/**
	 * Calcul de la largueur d'un texte en unités de 1/256ièmes
	 * @param length La taille du texte
	 * @return la largeur en unités de 1/256ièmes
	 */
	final public static int computeTextWidth(int length) {
		return OutilsBase.min(MAX_COLUMNS_SIZE, length * 256);
	}

	/**
	 * Extrait la rangée d'une cellule donnée
	 * @param cell La cellule
	 * @return une rangée
	 */
	final public static XSSFRow getRow(XSSFCell cell) {
		if (cell == null) {
			return null;
		}

		return cell.getRow();
	}

	/**
	 * Extrait la feuille d'une cellule donnée
	 * @param cell La cellule
	 * @return une feuille
	 */
	final public static XSSFSheet getSheet(XSSFCell cell) {
		return getSheet(getRow(cell));
	}

	/**
	 * Extrait la feuille d'une rangée donnée
	 * @param row La rangée
	 * @return une feuille
	 */
	final public static XSSFSheet getSheet(XSSFRow row) {
		if (row == null) {
			return null;
		}

		return row.getSheet();
	}

	/**
	 * Extrait le tableur d'une cellule donnée
	 * @param cell La cellule
	 * @return un tableur
	 */
	final public static XSSFWorkbook getWorkbook(XSSFCell cell) {
		return getWorkbook(getSheet(getRow(cell)));
	}

	/**
	 * Extrait le tableur d'une rangée donnée
	 * @param row La rangée
	 * @return un tableur
	 */
	final public static XSSFWorkbook getWorkbook(XSSFRow row) {
		return getWorkbook(getSheet(row));
	}

	/**
	 * Extrait le tableur d'une feuille donnée
	 * @param sheet La feuille
	 * @return un tableur
	 */
	final public static XSSFWorkbook getWorkbook(XSSFSheet sheet) {
		if (sheet == null) {
			return null;
		}

		return sheet.getWorkbook();
	}

	/**
	 * Initialise un style aux couleurs données
	 * @param workbook Le tableur
	 * @param colorsStyle Couleurs du style
	 * @return le style initialisé
	 */
	final public static XSSFCellStyle getCellColorsStyle(XSSFWorkbook workbook, ColorsStylesTypes colorsStyle) {
		return getCellColorsStyle(workbook, colorsStyle, null);
	}

	/**
	 * Initialise un style aux couleurs données
	 * @param workbook Le tableur
	 * @param colorsStyle Couleurs du style
	 * @param horizontalAlignment Alignement horizontale
	 * @return le style initialisé
	 */
	@AutomatedTests({ "null", "null", "null" })
	final public static XSSFCellStyle getCellColorsStyle(XSSFWorkbook workbook, ColorsStylesTypes colorsStyle, HorizontalAlignment horizontalAlignment) {
		if (workbook == null) {
			return null;
		}

		if (colorsStyle == null) {
			return workbook.createCellStyle();
		}

		return getCellColorsStyle(workbook, colorsStyle.isBold(), colorsStyle.getText(), horizontalAlignment, colorsStyle.getBackground(), colorsStyle.getBorders());
	}

	/**
	 * Initialise un style aux valeurs données
	 * @param workbook Le tableur
	 * @param bold Indicateur de texte en gras
	 * @param text Couleur du texte
	 * @param horizontalAlignment Alignement horizontale
	 * @param background Couleur de fond
	 * @param borders Couleur des bordures
	 * @return le style initialisé
	 */
	@AutomatedTests({ "null", "false", "null", "null", "null", "null" })
	final public static XSSFCellStyle getCellColorsStyle(XSSFWorkbook workbook, boolean bold, Color text, HorizontalAlignment horizontalAlignment, Color background, Color borders) {
		if (workbook == null) {
			return null;
		}

		IndexedColorMap icm = workbook.getStylesSource().getIndexedColors();

		XSSFCellStyle style = workbook.createCellStyle();

		if ((text != null) || bold) {
			XSSFFont font = workbook.createFont();
			font.setBold(bold);

			if (text != null) {
				font.setColor(new XSSFColor(text, icm));
			}

			style.setFont(font);
		}

		if (horizontalAlignment != null) {
			style.setAlignment(horizontalAlignment);
		}

		if (background != null) {
			style.setFillForegroundColor(new XSSFColor(background, icm));
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}

		if (borders != null) {
			XSSFColor color = new XSSFColor(borders, icm);

			style.setBorderLeft(BorderStyle.THIN);
			style.setLeftBorderColor(color);

			style.setBorderRight(BorderStyle.THIN);
			style.setRightBorderColor(color);

			style.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(color);

			style.setBorderBottom(BorderStyle.THIN);
			style.setBottomBorderColor(color);
		}

		return style;
	}

	/**
	 * Extrait en objet java la valeur d'une cellule
	 * @param cell La cellule à extraire
	 * @return la valeur en objet java
	 * @throws Exception en cas d'erreur...
	 */
	final public static Object getCellValue(Cell cell) throws Exception {
		if (cell == null) {
			return null;
		}

		switch (cell.getCellType()) {
			case STRING:
				return cell.getStringCellValue();
			case BOOLEAN:
				return Boolean.valueOf(cell.getBooleanCellValue());
			case NUMERIC:
				switch (cell.getCellStyle().getDataFormat()) {
					// Voir org.apache.poi.ss.usermodel.BuiltinFormats
					case 0x00: // "General"
					case 0x01: // "0"
					case 0x02: // "0.00"
					case 0x03: // "#,##0"
					case 0x04: // "#,##0.00"
					case 0x05: // "$#,##0_);($#,##0)"
					case 0x06: // "$#,##0_);[Red]($#,##0)"
					case 0x07: // "$#,##0.00);($#,##0.00)"
					case 0x08: // "$#,##0.00_);[Red]($#,##0.00)"
					case 0x09: // "0%"
					case 0x0A: // "0.00%"
					case 0x0B: // "0.00E+00"
					case 0x0C: // "# ?/?"
					case 0x0D: // "# ??/??"
					case 0x25: // "#,##0_);(#,##0)"
					case 0x26: // "#,##0_);[Red](#,##0)"
					case 0x27: // "#,##0.00_);(#,##0.00)"
					case 0x28: // "#,##0.00_);[Red](#,##0.00)"
					case 0x29: // "_(* #,##0_);_(* (#,##0);_(* \"-\"_);_(@_)"
					case 0x2A: // "_($* #,##0_);_($* (#,##0);_($* \"-\"_);_(@_)"
					case 0x2B: // "_(* #,##0.00_);_(* (#,##0.00);_(* \"-\"??_);_(@_)"
					case 0x2C: // "_($* #,##0.00_);_($* (#,##0.00);_($* \"-\"??_);_(@_)"
					case 0x30: // "##0.0E+0"
					case 0x31: // "@" - This is text format.
						return Double.valueOf(cell.getNumericCellValue());
					case 0x0E: // "m/d/yy"
					case 0x0F: // "d-mmm-yy"
					case 0x10: // "d-mmm"
					case 0x11: // "mmm-yy"
					case 0x12: // "h:mm AM/PM"
					case 0x14: // "h:mm"
					case 0x13: // "h:mm:ss AM/PM"
					case 0x15: // "h:mm:ss"
					case 0x16: // "m/d/yy h:mm"
					case 0x2D: // "mm:ss"
					case 0x2E: // "[h]:mm:ss"
					case 0x2F: // "mm:ss.0"
					case 0xA5: // "[$-F800]dddd\,\ mmmm\ dd\,\ yyyy"
						return cell.getDateCellValue();
					default:
						throw new Exception("Pas de traitement pour: " + cell.getCellStyle().getDataFormat() + " " + cell.getCellStyle().getDataFormatString());
				}
			case BLANK:
				return null;
			default:
				throw new Exception("Pas de traitement pour: " + cell.getCellType());
		}
	}

	/**
	 * Extrait en format texte la valeur d'une cellule
	 * @param cell La cellule à extraire
	 * @return la valeur en format texte
	 * @throws Exception en cas d'erreur...
	 */
	final public static String getCellValueAsString(Cell cell) throws Exception {
		if (cell == null) {
			return null;
		}

		switch (cell.getCellType()) {
			case STRING:
				return cell.getStringCellValue();
			case BOOLEAN:
				return OutilsBase.asString(cell.getBooleanCellValue());
			case NUMERIC:
				switch (cell.getCellStyle().getDataFormat()) {
					// Voir org.apache.poi.ss.usermodel.BuiltinFormats
					case 0x00: // "General"
					case 0x01: // "0"
					case 0x02: // "0.00"
					case 0x03: // "#,##0"
					case 0x04: // "#,##0.00"
					case 0x05: // "$#,##0_);($#,##0)"
					case 0x06: // "$#,##0_);[Red]($#,##0)"
					case 0x07: // "$#,##0.00);($#,##0.00)"
					case 0x08: // "$#,##0.00_);[Red]($#,##0.00)"
					case 0x09: // "0%"
					case 0x0A: // "0.00%"
					case 0x0B: // "0.00E+00"
					case 0x0C: // "# ?/?"
					case 0x0D: // "# ??/??"
					case 0x25: // "#,##0_);(#,##0)"
					case 0x26: // "#,##0_);[Red](#,##0)"
					case 0x27: // "#,##0.00_);(#,##0.00)"
					case 0x28: // "#,##0.00_);[Red](#,##0.00)"
					case 0x29: // "_(* #,##0_);_(* (#,##0);_(* \"-\"_);_(@_)"
					case 0x2A: // "_($* #,##0_);_($* (#,##0);_($* \"-\"_);_(@_)"
					case 0x2B: // "_(* #,##0.00_);_(* (#,##0.00);_(* \"-\"??_);_(@_)"
					case 0x2C: // "_($* #,##0.00_);_($* (#,##0.00);_($* \"-\"??_);_(@_)"
					case 0x30: // "##0.0E+0"
					case 0x31: // "@" - This is text format.
						return OutilsCommun.asNumericString(cell.getNumericCellValue());
					case 0x12: // "h:mm AM/PM"
					case 0x14: // "h:mm"
						return OutilsCommun.asTimeString(cell.getDateCellValue(), false);
					case 0x13: // "h:mm:ss AM/PM"
					case 0x15: // "h:mm:ss"
					case 0x2D: // "mm:ss"
					case 0x2E: // "[h]:mm:ss"
					case 0x2F: // "mm:ss.0"
						return OutilsCommun.asTimeString(cell.getDateCellValue());
					case 0x0E: // "m/d/yy"
					case 0x0F: // "d-mmm-yy"
					case 0x10: // "d-mmm"
					case 0x11: // "mmm-yy"
					case 0xA5: // "[$-F800]dddd\,\ mmmm\ dd\,\ yyyy"
						return OutilsCommun.asDateString(cell.getDateCellValue());
					case 0x16: // "m/d/yy h:mm"
						return OutilsCommun.asDateTimeString(cell.getDateCellValue(), false);
					default:
						throw new Exception("Pas de traitement pour: " + cell.getCellStyle().getDataFormat() + " " + cell.getCellStyle().getDataFormatString());
				}
			case BLANK:
				return null;
			default:
				throw new Exception("Pas de traitement pour: " + cell.getCellType());
		}
	}

	/**
	 * Lecture d'un fichier Excel au premier onglet
	 * @param filename Nom du fichier Excel
	 * @return un tableau dynamique
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = "OutilsStylesExcel.xlsx", filenames = 0)
	final public static List<List<Object>> readExcelFile(String filename) throws Exception {
		return readExcelFile(filename, 0);
	}

	/**
	 * Lecture d'un fichier Excel à un onglet donné
	 * @param filename Nom du fichier Excel
	 * @param sheetAt Index de l'onglet à lire
	 * @return un tableau dynamique
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = { "OutilsStylesExcel.xlsx", "1" }, filenames = 0)
	final public static List<List<Object>> readExcelFile(String filename, int sheetAt) throws Exception {
		List<List<Object>> table = new ArrayList<List<Object>>();

		FileInputStream inputStream = null;

		try {
			inputStream = new FileInputStream(new File(filename));

			XSSFWorkbook workbook = null;

			try {
				workbook = new XSSFWorkbook(inputStream);

				XSSFSheet sheet = workbook.getSheetAt(sheetAt);
				Iterator<Row> rowsIterator = sheet.iterator();

				while (rowsIterator.hasNext()) {
					Row row = rowsIterator.next();
					Iterator<Cell> cellsIterator = row.cellIterator();

					List<Object> itemsList = new ArrayList<Object>();
					table.add(itemsList);

					while (cellsIterator.hasNext()) {
						Cell cell = cellsIterator.next();

						itemsList.add(getCellValue(cell));
					}
				}
			} finally {
				if (workbook != null) {
					workbook.close();
				}
			}
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
		}

		return table;
	}

	/**
	 * Lecture d'un fichier Excel au premier onglet
	 * @param filename Nom du fichier Excel
	 * @return un tableau dynamique
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = "OutilsStylesExcel.xlsx", filenames = 0)
	final public static List<List<String>> readExcelFileAsString(String filename) throws Exception {
		return readExcelFileAsString(filename, 0);
	}

	/**
	 * Lecture d'un fichier Excel à un onglet donné
	 * @param filename Nom du fichier Excel
	 * @param sheetAt Index de l'onglet à lire
	 * @return un tableau dynamique
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = { "OutilsStylesExcel.xlsx", "1" }, filenames = 0)
	final public static List<List<String>> readExcelFileAsString(String filename, int sheetAt) throws Exception {
		List<List<String>> table = new ArrayList<List<String>>();

		FileInputStream inputStream = null;

		try {
			inputStream = new FileInputStream(new File(filename));

			XSSFWorkbook workbook = null;

			try {
				workbook = new XSSFWorkbook(inputStream);

				XSSFSheet sheet = workbook.getSheetAt(sheetAt);
				Iterator<Row> rowsIterator = sheet.iterator();

				while (rowsIterator.hasNext()) {
					Row row = rowsIterator.next();
					Iterator<Cell> cellsIterator = row.cellIterator();

					List<String> itemsList = new ArrayList<String>();
					table.add(itemsList);

					while (cellsIterator.hasNext()) {
						Cell cell = cellsIterator.next();

						itemsList.add(getCellValueAsString(cell));
					}
				}
			} finally {
				if (workbook != null) {
					workbook.close();
				}
			}
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
		}

		return table;
	}
}
