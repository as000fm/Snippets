package outils.apache.poi.excel.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import outils.apache.poi.excel.OutilsStylesExcel;
import outils.apache.poi.excel.types.ExcelSheetSectionsTypes;
import outils.base.OutilsBase;
import outils.gson.OutilsGson;

/**
 * Classe de base d'une feuille Excel
 * @author Claude Toupin - 13 mars 2019
 */
public abstract class ExcelSheetBase {
	/** Texte pour le nom "Total" **/
	final public static String TOTAL = "Total";

	/** Liste des données (lignes de la feuille Excel) **/
	final private List<IExeclSheetData> list;

	/**
	 * Constructeur de base
	 */
	public ExcelSheetBase() {
		this.list = new ArrayList<IExeclSheetData>();
	}

	/**
	 * Initialisation des styles pour le tableur
	 * @param workbook Le tableur
	 */
	protected abstract void initStyles(XSSFWorkbook workbook);

	/**
	 * Extrait le type d'une cellule selon sa valeur
	 * @param value La valeur de la cellule
	 * @return le type d'une cellule selon sa valeur
	 */
	protected CellType extractCellType(String value) {
		CellType type = CellType.STRING;

		if (!OutilsBase.isEmpty(value)) {
			try {
				Double.parseDouble(value);
				type = CellType.NUMERIC;
			} catch (NumberFormatException e) {
				type = (Boolean.valueOf(value).toString().equalsIgnoreCase(value)) ? CellType.BOOLEAN : CellType.STRING;
			}
		}

		return type;
	}

	/**
	 * Extrait le type d'une cellule selon sa valeur
	 * @param value La valeur de la cellule
	 * @param integerOnly Indicateur de traitement des entiers seulement
	 * @return le type d'une cellule selon sa valeur
	 */
	protected CellType extractCellType(String value, boolean integerOnly) {
		if (!integerOnly) {
			return extractCellType(value);
		}

		CellType type = CellType.STRING;

		if (!OutilsBase.isEmpty(value)) {
			if (!value.contains(".")) {
				try {
					Double.parseDouble(value);
					type = CellType.NUMERIC;
				} catch (NumberFormatException e) {
					type = (Boolean.valueOf(value).toString().equalsIgnoreCase(value)) ? CellType.BOOLEAN : CellType.STRING;
				}
			}
		}

		return type;
	}

	/**
	 * Assignation de la valeur d'une cellule selon son type
	 * @param cell La cellule à assigner
	 * @param style Le style de la cellule
	 * @param value La valeur de la cellule
	 */
	protected void assignCell(XSSFCell cell, XSSFCellStyle style, String value) {
		CellType type = CellType.STRING;

		if (!OutilsBase.isEmpty(value)) {
			try {
				Double.parseDouble(value);
				type = CellType.NUMERIC;
			} catch (NumberFormatException e) {
				type = (Boolean.valueOf(value).toString().equalsIgnoreCase(value)) ? CellType.BOOLEAN : CellType.STRING;
			}
		}

		assignCell(cell, style, type, value);
	}

	/**
	 * Assignation de la valeur d'une cellule selon son type
	 * @param cell La cellule à assigner
	 * @param style Le style de la cellule
	 * @param type Le type de la cellule
	 * @param value La valeur de la cellule
	 */
	protected void assignCell(XSSFCell cell, XSSFCellStyle style, CellType type, String value) {
		if (OutilsBase.isEmpty(value)) {
			type = CellType.STRING;
		}

		switch (type) {
			case STRING:
				cell.setCellValue(value);
				cell.setCellType(type);
				break;
			case NUMERIC:
				try {
					cell.setCellValue(Double.valueOf(value).doubleValue());
					cell.setCellType(type);
				} catch (Exception e) {
					cell.setCellValue(value);
					cell.setCellType(CellType.STRING);
				}
				break;
			case BOOLEAN:
				cell.setCellValue(Boolean.valueOf(value).booleanValue());
				cell.setCellType(type);
				break;
			default:
				throw new RuntimeException("Pas de traitement pour " + type);
		}

		if (style != null) {
			cell.setCellStyle(style);
		}
	}

	/**
	 * Assignation d'une cellule
	 * @param cell La cellule à assigner
	 * @param sectionType Le type de la section de la feuille Excel
	 * @param index Index courant de la section de la feuille Excel (et non sa rangée)
	 * @param column Colonne de la rangée courante
	 * @param value La valeur de la cellule
	 */
	protected abstract void assignCell(XSSFCell cell, ExcelSheetSectionsTypes sectionType, int index, int column, String value);

	/**
	 * Extrait une liste des largeurs maximales des textes des colonnes d'une liste de données
	 * @param dataList La liste de données
	 * @return la liste des tailles maximales des textes
	 */
	protected int[] extractColumnWidths(List<String[]> dataList) {
		int size = 0;

		if (dataList != null) {
			for (String[] items : dataList) {
				if (items != null) {
					size = Math.max(size, items.length);
				}
			}
		}

		int[] maximumSizes = new int[size];

		if (dataList != null) {
			if (size > 0) {
				for (int i = 0; i < maximumSizes.length; i++) {
					maximumSizes[i] = 0;
				}

				for (String[] items : dataList) {
					if (items != null) {
						for (int i = 0; i < size; i++) {
							if (i < items.length) {
								maximumSizes[i] = Math.max(maximumSizes[i], OutilsBase.asString(items[i]).length());
							}
						}
					}
				}
			}
		}

		return maximumSizes;
	}

	/**
	 * Extraire le tableau complet en une liste de données
	 * @param header Ligne de l'entête du tableau
	 * @param dataList Liste des données
	 * @param summary Ligne du sommaire du tableau
	 * @return le tableau complet en une liste de données
	 */
	protected List<String[]> extractTableDataList(String[] header, List<String[]> dataList, String[] summary) {
		List<String[]> tableDataList = new ArrayList<String[]>();

		if (header == null) {
			header = getHeader();
		}

		tableDataList.add(header);

		if (dataList != null) {
			tableDataList.addAll(dataList);
		}

		if (summary != null) {
			tableDataList.add(summary);
		}

		return tableDataList;
	}

	/**
	 * Indicateur de largeur de colonnes fixe
	 * @return vrai si largeur de colonnes fixe
	 */
	protected abstract boolean isColumnWidthsFix();

	/**
	 * Indicateur de filtre automatique sur les données
	 * @return vrai si on doit appliquer filtre automatique sur les données
	 */
	protected abstract boolean isAutoFilterData();

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return OutilsGson.toJson(this);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof ExcelSheetBase) {
				ExcelSheetBase excelSheetBase = (ExcelSheetBase) obj;

				return OutilsBase.areEquals(list, excelSheetBase.getList());
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(list);
	}

	/**
	 * Ajout d'une donnée à la liste
	 * @param data La donnée à ajouter
	 */
	public void add(IExeclSheetData data) {
		list.add(data);
	}

	/**
	 * Ajout d'une feuille au tableur
	 * @param workbook Le tableur
	 * @return la nouvelle feuille produite
	 */
	public XSSFSheet addSheet(XSSFWorkbook workbook) {
		return addSheet(workbook, null, (String[]) null);
	}

	/**
	 * Ajout d'une feuille au tableur
	 * @param workbook Le tableur
	 * @param sheetName Nom de la feuille
	 * @return la nouvelle feuille produite
	 */
	public XSSFSheet addSheet(XSSFWorkbook workbook, String sheetName) {
		return addSheet(workbook, sheetName, (String[]) null);
	}

	/**
	 * Ajout d'une feuille au tableur
	 * @param workbook Le tableur
	 * @param sheetName Nom de la feuille
	 * @param header Items de l'entête de la feuille
	 * @return la nouvelle feuille produite
	 */
	public XSSFSheet addSheet(XSSFWorkbook workbook, String sheetName, String... header) {
		if (workbook == null) {
			throw new RuntimeException("Erreur interne: Pas de tableur pour " + this.getClass().getSimpleName());
		}

		initStyles(workbook);

		if (OutilsBase.isEmpty(sheetName)) {
			sheetName = getSheetName();
		}

		if (header == null) {
			header = getHeader();
		}

		List<String[]> dataList = getDataList();
		String[] summary = getSummary();
		List<String[]> tableDataList = extractTableDataList(header, dataList, summary);
		int[] columnWidths = extractColumnWidths(tableDataList);
		int columnWidthsFix = OutilsBase.max(columnWidths);
		int extraColumnWidths = isAutoFilterData() ? 2 : 0;

		XSSFSheet sheet = OutilsStylesExcel.addSheet(workbook, sheetName);

		XSSFRow row;

		// Entête
		row = sheet.createRow(0);

		for (int col = 0; col < header.length; col++) {
			sheet.setColumnWidth(col, OutilsStylesExcel.computeTextWidthExtra(extraColumnWidths + (isColumnWidthsFix() ? columnWidthsFix : columnWidths[col])));
			assignCell(row.createCell(col), ExcelSheetSectionsTypes.HEADER, 0, col, header[col]);
		}

		// Données
		for (int i = 0; i < dataList.size(); i++) {
			String[] items = dataList.get(i);

			row = sheet.createRow(1 + i);

			for (int col = 0; col < items.length; col++) {
				assignCell(row.createCell(col), ExcelSheetSectionsTypes.DATA, i, col, items[col]);
			}
		}

		if (isAutoFilterData()) {
			sheet.setAutoFilter(new CellRangeAddress(0, dataList.size(), 0, header.length - 1));
		}

		// Sommaire
		if (summary != null) {
			row = sheet.createRow(1 + dataList.size());

			for (int col = 0; col < summary.length; col++) {
				assignCell(row.createCell(col), ExcelSheetSectionsTypes.SUMMARY, 0, col, summary[col]);
			}
		}

		return sheet;
	}

	/**
	 * Extrait un item de la liste
	 * @param index Index de l'item dans la liste
	 * @return un IExeclSheetData
	 */
	public IExeclSheetData getAtList(int index) {
		if ((index >= 0) && (index < list.size())) {
			return list.get(index);
		}

		return null;
	}

	/**
	 * Extrait le champ list
	 * @return un List<IExeclSheetData>
	 */
	public List<IExeclSheetData> getList() {
		return list;
	}

	/**
	 * Extrait le nom de la feuille Excel
	 * @return un String
	 */
	public abstract String getSheetName();

	/**
	 * Extrait la ligne d'entête de la feuille Excel
	 * @return un liste de texte pour l'entête
	 */
	public abstract String[] getHeader();

	/**
	 * Extrait les donnes depuis la liste des données (lignes de la feuille Excel)
	 * @return une liste de données
	 */
	public List<String[]> getDataList() {
		List<String[]> dataList = new ArrayList<String[]>();

		for (IExeclSheetData item : list) {
			dataList.add(item.extract());
		}

		return dataList;
	}

	/**
	 * Extrait les données de la ligne de sommaire
	 * @return un String[] qui devrait avoir au minimum getEntete().length
	 */
	public abstract String[] getSummary();
}
