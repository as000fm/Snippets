package outils.apache.poi.excel.base;

/**
 * Interface des données pour une feuille Excel
 * @author Claude Toupin - 13 mars 2019
 */
public interface IExeclSheetData {

	/**
	 * Extrait les données sous forme d'un tableau de String
	 * @return les données sous forme d'un tableau de String
	 */
	String[] extract();
}
