package outils.apache.poi.excel.styles;

import java.util.Objects;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import outils.apache.poi.excel.types.ColorsGroupsStylesTypes;
import outils.apache.poi.excel.types.ColorsStylesTypes;
import outils.apache.poi.excel.types.StylesTypes;
import outils.base.OutilsBase;
import outils.tests.automated.annotations.DefaultTestValue;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Classe des données d'un groupe de couleur de style des cellules
 * @author Claude Toupin - 15 mars 2019
 */
@DefaultTestValue(type = XSSFWorkbook.class, value = "new XSSFWorkbook()")
@DefaultTestValue(type = ColorsGroupsStylesTypes.class, value = "ColorsGroupsStylesTypes.GREEN")
@DefaultTestValue(type = ColorsStylesTypes.class, value = "ColorsStylesTypes.GREEN")
@DefaultTestValue(type = HorizontalAlignment.class, value = "HorizontalAlignment.CENTER")
public class ColorGroupStyleData {
	/** Groupe de couleur pour l'entête **/
	final public ColorStyleData header;

	/** Groupe de couleur pour les données pairs **/
	final public ColorStyleData evenData;

	/** Groupe de couleur pour les données impairs **/
	final public ColorStyleData oddData;

	/** Groupe de couleur pour le sommaire **/
	final public ColorStyleData summary;

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param colorGroupStyleType Groupe de couleur du style
	 */
	public ColorGroupStyleData(XSSFWorkbook workbook, ColorsGroupsStylesTypes colorGroupStyleType) {
		this(workbook, colorGroupStyleType, ColorsStylesTypes.BLACK_HEADER, HorizontalAlignment.CENTER);
	}

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param colorGroupStyleType Groupe de couleur du style
	 * @param horizontalAlignment Alignement horizontale du style des cellules en format décimale
	 */
	public ColorGroupStyleData(XSSFWorkbook workbook, ColorsGroupsStylesTypes colorGroupStyleType, HorizontalAlignment horizontalAlignment) {
		this(workbook, colorGroupStyleType, ColorsStylesTypes.BLACK_HEADER, horizontalAlignment);
	}

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param colorGroupStyleType Groupe de couleur du style
	 * @param colorSummaryStyleType Couleur du sommaire
	 */
	public ColorGroupStyleData(XSSFWorkbook workbook, ColorsGroupsStylesTypes colorGroupStyleType, ColorsStylesTypes colorSummaryStyleType) {
		this(workbook, colorGroupStyleType, colorSummaryStyleType, HorizontalAlignment.CENTER);
	}

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param colorGroupStyleType Groupe de couleur du style
	 * @param colorSummaryStyleType Couleur du sommaire
	 * @param horizontalAlignment Alignement horizontale du style des cellules en format décimale
	 */
	@TestMethodsInstance
	public ColorGroupStyleData(XSSFWorkbook workbook, ColorsGroupsStylesTypes colorGroupStyleType, ColorsStylesTypes colorSummaryStyleType, HorizontalAlignment horizontalAlignment) {
		if (colorGroupStyleType == null) {
			throw new RuntimeException("Erreur interne: colorGroupStyleType == null");
		}

		this.header = new ColorStyleData(workbook, colorGroupStyleType.getDark(), horizontalAlignment);
		this.evenData = new ColorStyleData(workbook, colorGroupStyleType.getEven(), horizontalAlignment);
		this.oddData = new ColorStyleData(workbook, colorGroupStyleType.getOdd(), horizontalAlignment);
		this.summary = new ColorStyleData(workbook, colorSummaryStyleType, horizontalAlignment);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColorGroupStyleData [header=" + header + ", evenData=" + evenData + ", oddData=" + oddData + ", summary=" + summary + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ColorGroupStyleData other = (ColorGroupStyleData) obj;
		return Objects.equals(evenData, other.evenData) && Objects.equals(header, other.header) && Objects.equals(oddData, other.oddData) && Objects.equals(summary, other.summary);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(evenData, header, oddData, summary);
	}

	/**
	 * Extrait le style de la cellule pour un type style donné
	 * @param color La couleur ayant le style désiré
	 * @param style Le type de style à extraire
	 * @return un XSSFCellStyle
	 */
	protected XSSFCellStyle getXSSFCellStyle(ColorStyleData color, StylesTypes style) {
		switch (style) {
			case CENTER:
				return color.getCenterStyle();
			case TEXT:
				return color.getTextStyle();
			case NUMBER:
				return color.getNumberStyle();
			case PERCENTAGE:
				return color.getPercentageStyle();
			default:
				throw new RuntimeException("Pas de traitement pour " + style.name());
		}
	}

	/**
	 * Extrait le champ header
	 * @return un ColorStyleData
	 */
	public ColorStyleData getHeader() {
		return header;
	}

	/**
	 * Extrait le style pour entete
	 * @param text Indicateur de style des cellules en format texte
	 * @param center Indicateur de style des cellules en format centré
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getHeader(boolean text, boolean center) {
		return getHeader(StylesTypes.getStyleType(text, center));
	}

	/**
	 * Extrait le style pour entete
	 * @param style Le type de style à extraire
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getHeader(StylesTypes style) {
		return getXSSFCellStyle(header, style);
	}

	/**
	 * Extrait le champ evenData
	 * @return un ColorStyleData
	 */
	public ColorStyleData getEvenData() {
		return evenData;
	}

	/**
	 * Extrait le style pour evenData
	 * @param text Indicateur de style des cellules en format texte
	 * @param center Indicateur de style des cellules en format centré
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getEvenData(boolean text, boolean center) {
		return getEvenData(StylesTypes.getStyleType(text, center));
	}

	/**
	 * Extrait le style pour evenData
	 * @param style Le type de style à extraire
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getEvenData(StylesTypes style) {
		return getXSSFCellStyle(evenData, style);
	}

	/**
	 * Extrait le champ oddData
	 * @return un ColorStyleData
	 */
	public ColorStyleData getOddData() {
		return oddData;
	}

	/**
	 * Extrait le style pour oddData
	 * @param text Indicateur de style des cellules en format texte
	 * @param center Indicateur de style des cellules en format centré
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getOddData(boolean text, boolean center) {
		return getOddData(StylesTypes.getStyleType(text, center));
	}

	/**
	 * Extrait le style pour oddData
	 * @param style Le type de style à extraire
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getOddData(StylesTypes style) {
		return getXSSFCellStyle(oddData, style);
	}

	/**
	 * Extrait le style pour donnees
	 * @param text Indicateur de style des cellules en format texte
	 * @param center Indicateur de style des cellules en format centré
	 * @param even Indicateur de rangée de données pair
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getData(boolean text, boolean center, boolean even) {
		return even ? getEvenData(text, center) : getOddData(text, center);
	}

	/**
	 * Extrait le style pour donnees
	 * @param style Le type de style à extraire
	 * @param even Indicateur de rangée de données pair
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getData(CellType style, boolean even) {
		return getData(CellType.STRING.equals(style), false, even);
	}

	/**
	 * Extrait le style pour donnees
	 * @param style Le type de style à extraire
	 * @param even Indicateur de rangée de données pair
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getData(StylesTypes style, boolean even) {
		return even ? getEvenData(style) : getOddData(style);
	}

	/**
	 * Extrait le style pour donnees
	 * @param text Indicateur de style des cellules en format texte
	 * @param center Indicateur de style des cellules en format centré
	 * @param index Index de la rangée de données
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getData(boolean text, boolean center, int index) {
		return getData(text, center, OutilsBase.isEven(index));
	}

	/**
	 * Extrait le style pour donnees
	 * @param style Le type de style à extraire
	 * @param index Index de la rangée de données
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getData(CellType style, int index) {
		return getData(style, false, index);
	}

	/**
	 * Extrait le style pour donnees
	 * @param style Le type de style à extraire
	 * @param center Indicateur de style des cellules en format centré
	 * @param index Index de la rangée de données
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getData(CellType style, boolean center, int index) {
		return getData(CellType.STRING.equals(style), center, OutilsBase.isEven(index));
	}

	/**
	 * Extrait le style pour donnees
	 * @param style Le type de style à extraire
	 * @param index Index de la rangée de données
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getData(StylesTypes style, int index) {
		return getData(style, OutilsBase.isEven(index));
	}

	/**
	 * Extrait le champ summary
	 * @return un ColorStyleData
	 */
	public ColorStyleData getSummary() {
		return summary;
	}

	/**
	 * Extrait le style pour summary
	 * @param text Indicateur de style des cellules en format texte
	 * @param center Indicateur de style des cellules en format centré
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getSummary(boolean text, boolean center) {
		return getSummary(StylesTypes.getStyleType(text, center));
	}

	/**
	 * Extrait le style pour summary
	 * @param style Le type de style à extraire
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getSummary(CellType style) {
		return getSummary(CellType.STRING.equals(style), false);
	}

	/**
	 * Extrait le style pour sommaire
	 * @param style Le type de style à extraire
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getSummary(StylesTypes style) {
		return getXSSFCellStyle(summary, style);
	}
}
