package outils.apache.poi.excel.styles;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import outils.apache.poi.excel.types.ColorsGroupsStylesTypes;
import outils.base.OutilsBase;
import outils.gson.OutilsGson;
import outils.tests.automated.annotations.AddImportsForTesting;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Classe des données d'une liste de groupes de couleurs de style des cellules
 * @author Claude Toupin - 15 mars 2019
 */
@AddImportsForTesting({ ColorsGroupsStylesTypes.class, XSSFWorkbook.class })
public class ColorGroupStyleList {
	/** Liste des groupes de couleurs **/
	final public List<ColorGroupStyleData> list;

	/**
	 * Constructeur de base
	 */
	@TestMethodsInstance
	public ColorGroupStyleList() {
		this.list = new ArrayList<ColorGroupStyleData>();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des groupes de couleurs
	 */
	public ColorGroupStyleList(List<ColorGroupStyleData> list) {
		this.list = list;
	}

	/**
	 * Constructeur de base
	 * @param list Liste des groupes de couleurs
	 */
	@AutomatedTests("new ColorGroupStyleData[] { new ColorGroupStyleData(new XSSFWorkbook(), ColorsGroupsStylesTypes.RED) }")
	public ColorGroupStyleList(ColorGroupStyleData... list) {
		this();

		if (list != null) {
			for (ColorGroupStyleData item : list) {
				this.list.add(item);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return OutilsGson.toJson(this);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof ColorGroupStyleList) {
				ColorGroupStyleList colorGroupStyleList = (ColorGroupStyleList) obj;

				return OutilsBase.areEquals(list, colorGroupStyleList.getList());
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(list);
	}

	/**
	 * Extrait le champ list
	 * @return un List<ColorGroupStyleData>
	 */
	public List<ColorGroupStyleData> getList() {
		return list;
	}

}
