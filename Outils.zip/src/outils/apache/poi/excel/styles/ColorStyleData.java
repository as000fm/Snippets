package outils.apache.poi.excel.styles;

import java.util.Objects;

import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import outils.apache.poi.excel.OutilsStylesExcel;
import outils.apache.poi.excel.types.ColorsStylesTypes;
import outils.base.OutilsBase;
import outils.tests.automated.annotations.DefaultTestValue;

/**
 * Classe des données pour une couleur de style des cellules
 * @author Claude Toupin - 15 mars 2019
 */
@DefaultTestValue(type = XSSFWorkbook.class, value = "new XSSFWorkbook()")
@DefaultTestValue(type = ColorsStylesTypes.class, value = "ColorsStylesTypes.GREEN")
@DefaultTestValue(type = HorizontalAlignment.class, value = "HorizontalAlignment.LEFT")
public class ColorStyleData {
	/** Style des cellules en format centré **/
	final private XSSFCellStyle centerStyle;

	/** Style des cellules en format texte **/
	final private XSSFCellStyle textStyle;

	/** Style des cellules en format décimale **/
	final private XSSFCellStyle numberStyle;

	/** Style des cellules en pourcentage **/
	final private XSSFCellStyle percentageStyle;

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param colorStyle Couleur du style
	 */
	public ColorStyleData(XSSFWorkbook workbook, ColorsStylesTypes colorStyle) {
		this(workbook, colorStyle, HorizontalAlignment.CENTER);
	}

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param colorStyle Couleur du style
	 * @param horizontalAlignment Alignement horizontale du style des cellules en format décimale
	 */
	public ColorStyleData(XSSFWorkbook workbook, ColorsStylesTypes colorStyle, HorizontalAlignment horizontalAlignment) {
		this.centerStyle = OutilsStylesExcel.getCellColorsStyle(workbook, colorStyle, HorizontalAlignment.CENTER);

		this.textStyle = OutilsStylesExcel.getCellColorsStyle(workbook, colorStyle);
		this.numberStyle = OutilsStylesExcel.getCellColorsStyle(workbook, colorStyle, horizontalAlignment);

		this.percentageStyle = OutilsStylesExcel.getCellColorsStyle(workbook, colorStyle, horizontalAlignment);
		this.percentageStyle.setDataFormat(workbook.createDataFormat().getFormat("#0.0%"));
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColorStyleData [centerStyle=" + centerStyle + ", textStyle=" + textStyle + ", numberStyle=" + numberStyle + ", percentageStyle=" + percentageStyle + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof ColorStyleData) {
				ColorStyleData colorStyleData = (ColorStyleData) obj;

				return OutilsBase.areEquals(centerStyle, colorStyleData.getCenterStyle()) //
						&& OutilsBase.areEquals(textStyle, colorStyleData.getTextStyle()) //
						&& OutilsBase.areEquals(numberStyle, colorStyleData.getTextStyle()) //
						&& OutilsBase.areEquals(percentageStyle, colorStyleData.getPercentageStyle()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(centerStyle, numberStyle, percentageStyle, textStyle);
	}

	/**
	 * Extrait le champ centerStyle
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getCenterStyle() {
		return centerStyle;
	}

	/**
	 * Extrait le champ textStyle
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getTextStyle() {
		return textStyle;
	}

	/**
	 * Extrait le champ numberStyle
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getNumberStyle() {
		return numberStyle;
	}

	/**
	 * Extrait le champ percentageStyle
	 * @return un XSSFCellStyle
	 */
	public XSSFCellStyle getPercentageStyle() {
		return percentageStyle;
	}

}
