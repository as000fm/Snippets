package outils.apache.poi.excel.styles;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import outils.apache.poi.excel.types.ColorsStylesTypes;
import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultTestValue;

/**
 * Classe des données d'une liste de couleurs de style des cellules
 * @author Claude Toupin - 15 mars 2019
 */
@DefaultTestValue(type = XSSFWorkbook.class, value = "new XSSFWorkbook()")
@DefaultTestValue(type = ColorsStylesTypes[].class, value = "ColorsStylesTypes.GREEN, ColorsStylesTypes.RED")
@DefaultTestValue(type = HorizontalAlignment.class, value = "HorizontalAlignment.CENTER")
public class ColorStyleList {
	/** Liste de couleurs de style des cellules **/
	final private List<ColorStyleData> list;

	/**
	 * Constructeur de base
	 */
	public ColorStyleList() {
		this.list = new ArrayList<ColorStyleData>();
	}

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param colorStylesList Liste de couleurs de style des cellules
	 */
	@AutomatedTests({ "new XSSFWorkbook()", "ColorsStylesTypes.BLUE" })
	public ColorStyleList(XSSFWorkbook workbook, ColorsStylesTypes... colorStylesList) {
		this();

		if (colorStylesList != null) {
			for (ColorsStylesTypes colorStyle : colorStylesList) {
				this.list.add(new ColorStyleData(workbook, colorStyle));
			}
		}
	}

	/**
	 * Constructeur de base
	 * @param workbook Le tableur
	 * @param horizontale Alignement horizontale du style des cellules en format décimale
	 * @param couleurStyle Liste de couleurs de style des cellules
	 */
	@AutomatedTests({ "new XSSFWorkbook()", "HorizontalAlignment.CENTER", "ColorsStylesTypes.BLUE" })
	public ColorStyleList(XSSFWorkbook workbook, HorizontalAlignment horizontale, ColorsStylesTypes... couleursStyleListe) {
		this.list = new ArrayList<ColorStyleData>();

		if (couleursStyleListe != null) {
			for (ColorsStylesTypes couleurStyle : couleursStyleListe) {
				this.list.add(new ColorStyleData(workbook, couleurStyle, horizontale));
			}
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColorStyleList [list=" + list + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof ColorStyleList) {
				ColorStyleList couleursStyleListe = (ColorStyleList) obj;

				return OutilsBase.areEquals(list, couleursStyleListe.getListe());
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(list);
	}

	/**
	 * Extrait le champ liste
	 * @return un List<CouleurStyleData>
	 */
	public List<ColorStyleData> getListe() {
		return list;
	}

}
