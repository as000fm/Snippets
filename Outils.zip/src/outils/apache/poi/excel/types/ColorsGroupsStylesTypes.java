package outils.apache.poi.excel.types;

/**
 * Énumération des types des groupes des couleurs des styles
 * @author Claude Toupin - 15 mars 2019
 */
public enum ColorsGroupsStylesTypes {
	BLUE(ColorsStylesTypes.BLUE_HEADER, ColorsStylesTypes.BLUE_EVEN, ColorsStylesTypes.BLUE_ODD), //
	LIGHT_BLUE(ColorsStylesTypes.LIGHT_BLUE_HEADER, ColorsStylesTypes.LIGHT_BLUE_EVEN, ColorsStylesTypes.LIGHT_BLUE_ODD), //
	DARK_BLUE(ColorsStylesTypes.DARK_BLUE_HEADER, ColorsStylesTypes.DARK_BLUE_EVEN, ColorsStylesTypes.DARK_BLUE_ODD), //
	CYAN(ColorsStylesTypes.CYAN_HEADER, ColorsStylesTypes.CYAN_EVEN, ColorsStylesTypes.CYAN_ODD), //
	GREY(ColorsStylesTypes.GREY_HEADER, ColorsStylesTypes.GREY_EVEN, ColorsStylesTypes.GREY_ODD), //
	LIGHT_GREY(ColorsStylesTypes.LIGHT_GREY_HEADER, ColorsStylesTypes.LIGHT_GREY_EVEN, ColorsStylesTypes.LIGHT_GREY_ODD), //
	DARK_GREY(ColorsStylesTypes.DARK_GREY_HEADER, ColorsStylesTypes.DARK_GREY_EVEN, ColorsStylesTypes.DARK_GREY_ODD), //
	YELLOW(ColorsStylesTypes.YELLOW_HEADER, ColorsStylesTypes.YELLOW_EVEN, ColorsStylesTypes.YELLOW_ODD), //
	MAGENTA(ColorsStylesTypes.MAGENTA_HEADER, ColorsStylesTypes.MAGENTA_EVEN, ColorsStylesTypes.MAGENTA_ODD), //
	BLACK(ColorsStylesTypes.BLACK_HEADER, ColorsStylesTypes.BLACK_EVEN, ColorsStylesTypes.BLACK_ODD), //
	GOLD(ColorsStylesTypes.GOLD_HEADER, ColorsStylesTypes.GOLD_EVEN, ColorsStylesTypes.GOLD_ODD), //
	ORANGE(ColorsStylesTypes.ORANGE_HEADER, ColorsStylesTypes.ORANGE_EVEN, ColorsStylesTypes.ORANGE_ODD), //
	RED(ColorsStylesTypes.RED_HEADER, ColorsStylesTypes.RED_EVEN, ColorsStylesTypes.RED_ODD), //
	GREEN(ColorsStylesTypes.GREEN_HEADER, ColorsStylesTypes.GREEN_EVEN, ColorsStylesTypes.GREEN_ODD), //
	LIGHT_GREEN(ColorsStylesTypes.LIGHT_GREEN_HEADER, ColorsStylesTypes.LIGHT_GREEN_EVEN, ColorsStylesTypes.LIGHT_GREEN_ODD), //
	DARK_GREEN(ColorsStylesTypes.DARK_GREEN_HEADER, ColorsStylesTypes.DARK_GREEN_EVEN, ColorsStylesTypes.DARK_GREEN_ODD), //
	;

	/** Couleur foncé **/
	final private ColorsStylesTypes dark;

	/** Couleur pair **/
	final private ColorsStylesTypes even;

	/** Couleur impair **/
	final private ColorsStylesTypes odd;

	/**
	 * Constructeur de base
	 * @param dark Couleur foncé
	 * @param even Couleur pair
	 * @param odd Couleur impair
	 */
	private ColorsGroupsStylesTypes(ColorsStylesTypes dark, ColorsStylesTypes even, ColorsStylesTypes odd) {
		this.dark = dark;
		this.even = even;
		this.odd = odd;
	}

	/**
	 * Extrait le champ dark
	 * @return un ColorStylesTypes
	 */
	public ColorsStylesTypes getDark() {
		return dark;
	}

	/**
	 * Extrait le champ even
	 * @return un ColorStylesTypes
	 */
	public ColorsStylesTypes getEven() {
		return even;
	}

	/**
	 * Extrait le champ odd
	 * @return un ColorStylesTypes
	 */
	public ColorsStylesTypes getOdd() {
		return odd;
	}
}
