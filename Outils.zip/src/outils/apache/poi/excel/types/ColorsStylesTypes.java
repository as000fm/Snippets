package outils.apache.poi.excel.types;

import java.awt.Color;

/**
 * Énumération des types des couleurs des styles
 * @author Claude Toupin - 14 mars 2019
 */
public enum ColorsStylesTypes {
	// Blanc
	WHITE(false, Color.BLACK, Color.WHITE, Color.LIGHT_GRAY), //
	WHITE_HEADER(true, Color.BLACK, Color.WHITE, Color.WHITE), //
	WHITE_EVEN(null, ExcelColorsTypes.WHITE_EVEN_DATA.getColor(), Color.WHITE), //
	WHITE_ODD(null, ExcelColorsTypes.WHITE_ODD_DATA.getColor(), Color.WHITE), //
	// Bleu (Excel)
	BLUE(false, Color.WHITE, ExcelColorsTypes.BLUE_EVEN_DATA.getColor(), ExcelColorsTypes.BLUE_HEADER.getColor()), //
	BLUE_HEADER(true, Color.WHITE, ExcelColorsTypes.BLUE_HEADER.getColor(), Color.WHITE), //
	BLUE_EVEN(null, ExcelColorsTypes.BLUE_EVEN_DATA.getColor(), Color.WHITE), //
	BLUE_ODD(null, ExcelColorsTypes.BLUE_ODD_DATA.getColor(), Color.WHITE), //
	// Bleu pâle (Excel)
	LIGHT_BLUE(false, Color.WHITE, ExcelColorsTypes.LIGHT_BLUE_EVEN_DATA.getColor(), ExcelColorsTypes.LIGHT_BLUE_HEADER.getColor()), //
	LIGHT_BLUE_HEADER(true, Color.WHITE, ExcelColorsTypes.LIGHT_BLUE_HEADER.getColor(), Color.WHITE), //
	LIGHT_BLUE_EVEN(null, ExcelColorsTypes.LIGHT_BLUE_EVEN_DATA.getColor(), Color.WHITE), //
	LIGHT_BLUE_ODD(null, ExcelColorsTypes.LIGHT_BLUE_ODD_DATA.getColor(), Color.WHITE), //
	// Bleu foncé
	DARK_BLUE(false, Color.WHITE, ExcelColorsTypes.DARK_BLUE_EVEN_DATA.getColor(), ExcelColorsTypes.DARK_BLUE_HEADER.getColor()), //
	DARK_BLUE_HEADER(true, Color.WHITE, ExcelColorsTypes.DARK_BLUE_HEADER.getColor(), Color.WHITE), //
	DARK_BLUE_EVEN(null, ExcelColorsTypes.DARK_BLUE_EVEN_DATA.getColor(), Color.WHITE), //
	DARK_BLUE_ODD(null, ExcelColorsTypes.DARK_BLUE_ODD_DATA.getColor(), Color.WHITE), //
	// Cyan
	CYAN(false, null, ExcelColorsTypes.CYAN_EVEN_DATA.getColor(), Color.CYAN), //
	CYAN_HEADER(true, null, Color.CYAN, Color.WHITE), //
	CYAN_EVEN(null, ExcelColorsTypes.CYAN_EVEN_DATA.getColor(), Color.WHITE), //
	CYAN_ODD(null, ExcelColorsTypes.CYAN_ODD_DATA.getColor(), Color.WHITE), //
	// Gris
	GREY(false, Color.WHITE, ExcelColorsTypes.GREY_EVEN_DATA.getColor(), ExcelColorsTypes.GREY_HEADER.getColor()), //
	GREY_HEADER(true, Color.WHITE, ExcelColorsTypes.GREY_HEADER.getColor(), Color.WHITE), //
	GREY_EVEN(null, ExcelColorsTypes.GREY_EVEN_DATA.getColor(), Color.WHITE), //
	GREY_ODD(null, ExcelColorsTypes.GREY_ODD_DATA.getColor(), Color.WHITE), //
	// Gris pâle
	LIGHT_GREY(false, Color.WHITE, ExcelColorsTypes.LIGHT_GREY_EVEN_DATA.getColor(), ExcelColorsTypes.LIGHT_GREY_HEADER.getColor()), //
	LIGHT_GREY_HEADER(true, Color.WHITE, ExcelColorsTypes.LIGHT_GREY_HEADER.getColor(), Color.WHITE), //
	LIGHT_GREY_EVEN(null, ExcelColorsTypes.LIGHT_GREY_EVEN_DATA.getColor(), Color.WHITE), //
	LIGHT_GREY_ODD(null, ExcelColorsTypes.LIGHT_GREY_ODD_DATA.getColor(), Color.WHITE), //
	// Gris foncé
	DARK_GREY(false, Color.WHITE, ExcelColorsTypes.DARK_GREY_EVEN_DATA.getColor(), ExcelColorsTypes.DARK_GREY_HEADER.getColor()), //
	DARK_GREY_HEADER(true, Color.WHITE, ExcelColorsTypes.DARK_GREY_HEADER.getColor(), Color.WHITE), //
	DARK_GREY_EVEN(Color.WHITE, ExcelColorsTypes.DARK_GREY_EVEN_DATA.getColor(), Color.WHITE), //
	DARK_GREY_ODD(null, ExcelColorsTypes.DARK_GREY_ODD_DATA.getColor(), Color.WHITE), //
	// Jaune
	YELLOW(false, null, ExcelColorsTypes.YELLOW_EVEN_DATA.getColor(), Color.YELLOW), //
	YELLOW_HEADER(true, null, Color.YELLOW, Color.WHITE), //
	YELLOW_EVEN(null, ExcelColorsTypes.YELLOW_EVEN_DATA.getColor(), Color.WHITE), //
	YELLOW_ODD(null, ExcelColorsTypes.YELLOW_ODD_DATA.getColor(), Color.WHITE), //
	// Magenta
	MAGENTA(false, Color.WHITE, ExcelColorsTypes.MAGENTA_EVEN_DATA.getColor(), Color.MAGENTA), //
	MAGENTA_HEADER(true, Color.WHITE, Color.MAGENTA, Color.WHITE), //
	MAGENTA_EVEN(null, ExcelColorsTypes.MAGENTA_EVEN_DATA.getColor(), Color.WHITE), //
	MAGENTA_ODD(null, ExcelColorsTypes.MAGENTA_ODD_DATA.getColor(), Color.WHITE), //
	// Noir
	BLACK(false, Color.WHITE, Color.BLACK, Color.LIGHT_GRAY), //
	BLACK_HEADER(true, Color.WHITE, Color.BLACK, Color.WHITE), //
	BLACK_EVEN(null, Color.LIGHT_GRAY, Color.WHITE), //
	BLACK_ODD(null, Color.WHITE, Color.WHITE), //
	// Or (Excel)
	GOLD(false, null, ExcelColorsTypes.GOLD_EVEN_DATA.getColor(), ExcelColorsTypes.GOLD_HEADER.getColor()), //
	GOLD_HEADER(true, Color.WHITE, ExcelColorsTypes.GOLD_HEADER.getColor(), Color.WHITE), //
	GOLD_EVEN(null, ExcelColorsTypes.GOLD_EVEN_DATA.getColor(), Color.WHITE), //
	GOLD_ODD(null, ExcelColorsTypes.GOLD_ODD_DATA.getColor(), Color.WHITE), //
	// Orange (Excel)
	ORANGE(false, Color.WHITE, ExcelColorsTypes.ORANGE_EVEN_DATA.getColor(), ExcelColorsTypes.ORANGE_HEADER.getColor()), //
	ORANGE_HEADER(true, Color.WHITE, ExcelColorsTypes.ORANGE_HEADER.getColor(), Color.WHITE), //
	ORANGE_EVEN(null, ExcelColorsTypes.ORANGE_EVEN_DATA.getColor(), Color.WHITE), //
	ORANGE_ODD(null, ExcelColorsTypes.ORANGE_ODD_DATA.getColor(), Color.WHITE), //
	// Rouge
	RED(false, Color.WHITE, ExcelColorsTypes.RED_EVEN_DATA.getColor(), Color.RED), //
	RED_HEADER(true, Color.WHITE, Color.RED, Color.WHITE), //
	RED_EVEN(null, ExcelColorsTypes.RED_EVEN_DATA.getColor(), Color.WHITE), //
	RED_ODD(null, ExcelColorsTypes.RED_ODD_DATA.getColor(), Color.WHITE), //
	// Vert (Excel)
	GREEN(false, null, ExcelColorsTypes.GREEN_EVEN_DATA.getColor(), ExcelColorsTypes.GREEN_HEADER.getColor()), //
	GREEN_HEADER(true, Color.WHITE, ExcelColorsTypes.GREEN_HEADER.getColor(), Color.WHITE), //
	GREEN_EVEN(null, ExcelColorsTypes.GREEN_EVEN_DATA.getColor(), Color.WHITE), //
	GREEN_ODD(null, ExcelColorsTypes.GREEN_ODD_DATA.getColor(), Color.WHITE), //
	// Vert pâle
	LIGHT_GREEN(false, null, ExcelColorsTypes.LIGHT_GREEN_EVEN_DATA.getColor(), ExcelColorsTypes.LIGHT_GREEN_HEADER.getColor()), //
	LIGHT_GREEN_HEADER(true, Color.WHITE, ExcelColorsTypes.LIGHT_GREEN_HEADER.getColor(), Color.WHITE), //
	LIGHT_GREEN_EVEN(null, ExcelColorsTypes.LIGHT_GREEN_EVEN_DATA.getColor(), Color.WHITE), //
	LIGHT_GREEN_ODD(null, ExcelColorsTypes.LIGHT_GREEN_ODD_DATA.getColor(), Color.WHITE), //
	// Vert foncé
	DARK_GREEN(false, Color.WHITE, ExcelColorsTypes.DARK_GREEN_EVEN_DATA.getColor(), ExcelColorsTypes.DARK_GREEN_HEADER.getColor()), //
	DARK_GREEN_HEADER(true, Color.WHITE, ExcelColorsTypes.DARK_GREEN_HEADER.getColor(), Color.WHITE), //
	DARK_GREEN_EVEN(null, ExcelColorsTypes.DARK_GREEN_EVEN_DATA.getColor(), Color.WHITE), //
	DARK_GREEN_ODD(null, ExcelColorsTypes.DARK_GREEN_ODD_DATA.getColor(), Color.WHITE), //
	;

	/** Indicateur de texte en gras **/
	final private boolean bold;

	/** Couleur du texte **/
	final private Color text;

	/** Couleur de fond **/
	final private Color background;

	/** Couleur des bordures **/
	final private Color borders;

	/**
	 * Constructeur de base
	 * @param text Couleur du texte
	 * @param horizontale Alignement horizontale
	 * @param background Couleur de fond
	 * @param borders Couleur des bordures
	 */
	private ColorsStylesTypes(Color text, Color background, Color borders) {
		this(false, text, background, borders);
	}

	/**
	 * Constructeur de base
	 * @param bold Indicateur de texte en gras
	 * @param text Couleur du texte
	 * @param horizontale Alignement horizontale
	 * @param background Couleur de fond
	 * @param borders Couleur des bordures
	 */
	private ColorsStylesTypes(boolean bold, Color text, Color background, Color borders) {
		this.bold = bold;
		this.text = text;
		this.background = background;
		this.borders = borders;
	}

	/**
	 * Extrait le champ bold
	 * @return un boolean
	 */
	public boolean isBold() {
		return bold;
	}

	/**
	 * Extrait le champ text
	 * @return un Color
	 */
	public Color getText() {
		return text;
	}

	/**
	 * Extrait le champ background
	 * @return un Color
	 */
	public Color getBackground() {
		return background;
	}

	/**
	 * Extrait le champ borders
	 * @return un Color
	 */
	public Color getBorders() {
		return borders;
	}
}
