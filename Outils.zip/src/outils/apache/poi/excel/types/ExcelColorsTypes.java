package outils.apache.poi.excel.types;

import java.awt.Color;

/**
 * Énumération des couleurs de cellules Excel extraites depuis les couleurs des styles de tableaux dans Excel
 * @author Claude Toupin - 15 mars 2019
 */
public enum ExcelColorsTypes {
	// Blanc
	WHITE_EVEN_DATA(166, 166, 166), //
	WHITE_ODD_DATA(217, 217, 217), //
	// Bleu
	BLUE_HEADER(68, 114, 196), //
	BLUE_EVEN_DATA(180, 198, 231), //
	BLUE_ODD_DATA(217, 225, 242), //
	BLUE_BORDERS(142, 169, 219), //
	// Bleu pâle
	LIGHT_BLUE_HEADER(91, 155, 213), //
	LIGHT_BLUE_EVEN_DATA(189, 215, 238), //
	LIGHT_BLUE_ODD_DATA(221, 235, 247), //
	LIGHT_BLUE_BORDERS(155, 194, 230), //
	// Bleu foncé
	DARK_BLUE_HEADER(45, 73, 179), //
	DARK_BLUE_EVEN_DATA(171, 181, 224), //
	DARK_BLUE_ODD_DATA(213, 215, 237), //
	DARK_BLUE_BORDERS(129, 144, 208), //
	// Cyan
	CYAN_EVEN_DATA(166, 255, 255), //
	CYAN_ODD_DATA(217, 255, 255), //
	// Gris
	GREY_HEADER(112, 112, 112), //
	GREY_EVEN_DATA(166, 166, 166), //
	GREY_ODD_DATA(217, 217, 217), //
	GREY_BORDERS(148, 148, 148), //
	// Gris pâle
	LIGHT_GREY_HEADER(165, 165, 165), //
	LIGHT_GREY_EVEN_DATA(219, 219, 219), //
	LIGHT_GREY_ODD_DATA(237, 237, 237), //
	LIGHT_GREY_BORDERS(201, 201, 201), //
	// Gris foncé
	DARK_GREY_HEADER(59, 59, 59), //
	DARK_GREY_EVEN_DATA(113, 113, 113), //
	DARK_GREY_ODD_DATA(197, 197, 197), //
	DARK_GREY_BORDERS(95, 95, 95), //
	// Jaune
	YELLOW_EVEN_DATA(255, 255, 166), //
	YELLOW_ODD_DATA(255, 255, 217), //
	// Magenta
	MAGENTA_EVEN_DATA(255, 166, 255), //
	MAGENTA_ODD_DATA(255, 217, 255), //
	// Or (jaune)
	GOLD_HEADER(255, 192, 0), //
	GOLD_EVEN_DATA(255, 230, 153), //
	GOLD_ODD_DATA(255, 242, 204), //
	GOLD_BORDERS(255, 217, 102), //
	// Jaune
	ORANGE_HEADER(237, 125, 49), //
	ORANGE_EVEN_DATA(248, 203, 173), //
	ORANGE_ODD_DATA(252, 228, 214), //
	ORANGE_BORDERS(244, 176, 132), //
	// Rouge
	RED_EVEN_DATA(255, 166, 166), //
	RED_ODD_DATA(255, 217, 217), //
	// Vert
	GREEN_HEADER(112, 173, 71), //
	GREEN_EVEN_DATA(198, 224, 180), //
	GREEN_ODD_DATA(226, 239, 218), //
	GREEN_BORDERS(169, 208, 142), //
	// Vert pâle
	LIGHT_GREEN_HEADER(139, 193, 103), //
	LIGHT_GREEN_EVEN_DATA(205, 227, 189), //
	LIGHT_GREEN_ODD_DATA(236, 254, 232), //
	LIGHT_GREEN_BORDERS(196, 228, 174), //
	// Vert foncé
	DARK_GREEN_HEADER(85, 153, 39), //
	DARK_GREEN_EVEN_DATA(191, 221, 171), //
	DARK_GREEN_ODD_DATA(216, 224, 204), //
	DARK_GREEN_BORDERS(142, 188, 110), //
	;

	/** Couleur RGB **/
	final private Color color;

	/**
	 * Constructeur de base
	 * @param color Couleur RGB
	 */
	private ExcelColorsTypes(Color color) {
		this.color = color;
	}

	/**
	 * Constructeur de base
	 * @param red Rouge 0-255
	 * @param green Vert 0-255
	 * @param blue Bleu 0-255
	 */
	private ExcelColorsTypes(int red, int green, int blue) {
		this(new Color(red, green, blue));
	}

	/**
	 * Extrait le champ couleur
	 * @return un Color
	 */
	public Color getColor() {
		return color;
	}
}
