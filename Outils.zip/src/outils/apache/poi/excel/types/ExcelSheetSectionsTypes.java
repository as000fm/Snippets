package outils.apache.poi.excel.types;

/**
 * Énumération des types de sections d'une feuille Excel
 * @author Claude Toupin - 15 mars 2019
 */
public enum ExcelSheetSectionsTypes {
	HEADER, //
	DATA, //
	SUMMARY, //
	;
}
