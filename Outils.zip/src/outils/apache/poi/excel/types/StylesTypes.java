package outils.apache.poi.excel.types;

/**
 * Énumération des types de styles
 * @author Claude Toupin - 18 mars 2019
 */
public enum StylesTypes {
	CENTER, //
	TEXT, //
	NUMBER, //
	PERCENTAGE, //
	;
	
	/**
	 * Extrait le type de style selon les paramètres donnés
	 * @param text Indicateur de style des cellules en format texte
	 * @param center Indicateur de style des cellules en format centré
	 * @return le type de style (CENTER, TEXT ou NUMBER)
	 */
	final public static StylesTypes getStyleType(boolean text, boolean center) {
		return text ? (center ? StylesTypes.CENTER : StylesTypes.TEXT) : StylesTypes.NUMBER;
	}
}
