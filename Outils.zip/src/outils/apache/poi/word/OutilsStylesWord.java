package outils.apache.poi.word;

/**
 * Classe des méthodes statiques des outils et styles pour Word
 * @author Claude Toupin - 6 nov. 2019
 */
public class OutilsStylesWord {
	/** Extension d'un fichier Word **/
	final public static String WORD_EXTENSION = ".docx";

}
