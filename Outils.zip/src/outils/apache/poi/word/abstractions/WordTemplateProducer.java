package outils.apache.poi.word.abstractions;

import java.io.File;
import java.io.InputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;

/**
 * Modification d'un fichier Word en substituant des balises
 * @author Claude Toupin - 7 nov. 2019
 */
public abstract class WordTemplateProducer extends WordTemplateProducerBase {

	/**
	 * Constructeur de base
	 * @param document Document Word à modifier
	 */
	public WordTemplateProducer(XWPFDocument document) {
		super(document);
	}
	
	/**
	 * Constructeur de base
	 * @param filename Nom du fichier du document Word à modifier
	 * @throws Exception en cas d'erreur...
	 */
	public WordTemplateProducer(String filename) throws Exception {
		super(filename);
	}
	
	/**
	 * Constructeur de base
	 * @param filename Fichier du document Word à modifier
	 * @throws Exception en cas d'erreur...
	 */
	public WordTemplateProducer(File file) throws Exception {
		super(file);
	}
	
	/**
	 * Constructeur de base
	 * @param stream Flux de données du document Word à modifier
	 * @throws Exception en cas d'erreur...
	 */
	public WordTemplateProducer(InputStream stream) throws Exception {
		super(stream);
	}

	/*
	 * (non-Javadoc)
	 * @see outils.word.abstractions.WordTemplateProducer#beforeFindTag(java.lang.String)
	 */
	@Override
	protected String beforeFindTag(String text) throws Exception {
		return text;
	}

}
