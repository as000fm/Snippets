package outils.apache.poi.word.abstractions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.xmlbeans.XmlCursor;

import outils.listes.StringData;

/**
 * Modification d'un fichier Word en substituant des balises
 * @author Claude Toupin - 7 nov. 2019
 */
public abstract class WordTemplateProducerBase {
	/** Début de balise à substituer **/
	private String startTag;
	
	/** Fin de balise à substituer **/
	private String endTag;
	
	/** Balise à substituer **/
	private String tag;

	/** Document Word à modifier **/
	final private XWPFDocument document;

	/**
	 * Constructeur de base
	 * @param document Document Word à modifier
	 */
	public WordTemplateProducerBase(XWPFDocument document) {
		this.startTag = "<#";
		this.endTag = ">";
		this.tag = "$TAG_";
		this.document = document;
	}
	
	/**
	 * Constructeur de base
	 * @param filename Nom du fichier du document Word à modifier
	 * @throws Exception en cas d'erreur...
	 */
	public WordTemplateProducerBase(String filename) throws Exception {
		this(new XWPFDocument(new FileInputStream(filename)));
	}
	
	/**
	 * Constructeur de base
	 * @param filename Fichier du document Word à modifier
	 * @throws Exception en cas d'erreur...
	 */
	public WordTemplateProducerBase(File file) throws Exception {
		this(new XWPFDocument(new FileInputStream(file)));
	}
	
	/**
	 * Constructeur de base
	 * @param stream Flux de données du document Word à modifier
	 * @throws Exception en cas d'erreur...
	 */
	public WordTemplateProducerBase(InputStream stream) throws Exception {
		this(new XWPFDocument(stream));
	}
	
	/**
	 * Pré-traitement avant le traitement de la ligne de texte du paragraphe
	 * @param text Ligne du modèle
	 * @return un String
	 * @throws Exception en cas d'erreur...
	 */
	abstract protected String beforeFindTag(String text) throws Exception;

	/**
	 * Traitement d'un tag
	 * @param tag Le nom du tag
	 * @param paragraph Le paragraphe à remplacer
	 * @return un XmlCursor de la nouvelle position
	 * @throws Exception en cas d'erreur...
	 */
	abstract protected XmlCursor onTag(String tag, XWPFParagraph paragraph) throws Exception;
	
	public void produce() throws Exception {
		List<StringData> tagsParagraphesList = new ArrayList<StringData>();
		
		for (XWPFParagraph paragraph : document.getParagraphs()) {
			String tagname = null;
			
			String text = beforeFindTag(paragraph.getText());
			
			int p = text.indexOf(startTag);

			if (p != -1) {
				int e = text.indexOf(endTag, p + startTag.length());

				if (e != -1) {
					tagname = text.substring(p + startTag.length(), e);
				}
			}
			
			if (tagname == null) {
				p = text.indexOf(tag);
				
				if (p != -1) {
					int e = p;

					while ((text.charAt(e + 1) == '_') || Character.isAlphabetic(text.charAt(e + 1)) || Character.isDigit(text.charAt(e + 1))) {
						e++;
					}

					tagname = text.substring(p + tag.length(), e + 1);
				}
			}

			if (tagname != null) {
				tagsParagraphesList.add(new StringData(tagname, paragraph));
			}
		}
		
		for(StringData tagParagraph: tagsParagraphesList) {
			XWPFParagraph paragraph = (XWPFParagraph) tagParagraph.getData();
			
			XmlCursor newCursor = onTag(tagParagraph.getString(), paragraph);
			
			if (newCursor != null) {
				XmlCursor currentCursor = paragraph.getCTP().newCursor();
				
				newCursor.moveXml(currentCursor);
				newCursor.dispose();

				currentCursor.removeXml();
				currentCursor.dispose();
			}

		}
	}
	
	/**
	 * Sauvegarde du document
	 * @param filename Nom du fichier de sauvegarde
	 * @throws Exception en cas d'erreur...
	 */
	public void saveDocument(String filename) throws Exception {
		saveDocument(new File(filename));
	}
	
	/**
	 * Sauvegarde du document
	 * @param file Fichier de sauvegarde
	 * @throws Exception en cas d'erreur...
	 */
	public void saveDocument(File file) throws Exception {
		document.write(new FileOutputStream(file));
		document.close();
	}
	
	/**
	 * Sauvegarde du document
	 * @param output Flux de sauvegarde
	 * @throws Exception en cas d'erreur...
	 */
	public void saveDocument(OutputStream output) throws Exception {
		document.write(output);
		document.close();
	}

	/**
	 * Extrait le champ startTag
	 * @return un String
	 */
	public String getStartTag() {
		return startTag;
	}

	/**
	 * Modifie le champ startTag
	 * @param startTag La valeur du champ startTag
	 */
	public void setStartTag(String startTag) {
		this.startTag = startTag;
	}

	/**
	 * Extrait le champ endTag
	 * @return un String
	 */
	public String getEndTag() {
		return endTag;
	}

	/**
	 * Modifie le champ endTag
	 * @param endTag La valeur du champ endTag
	 */
	public void setEndTag(String endTag) {
		this.endTag = endTag;
	}

	/**
	 * Extrait le champ tag
	 * @return un String
	 */
	public String getTag() {
		return tag;
	}

	/**
	 * Modifie le champ tag
	 * @param tag La valeur du champ tag
	 */
	public void setTag(String tag) {
		this.tag = tag;
	}

	/**
	 * Extrait le champ document
	 * @return un XWPFDocument
	 */
	public XWPFDocument getDocument() {
		return document;
	}
}
