package outils.arduino;

/**
 * Classe de base pour un programme Arduino
 * @author Claude Toupin - 2020-06-27
 */
public abstract class ArduinoBase {

	/**
	 * Ex�cution du programme
	 */
	public void run() {
		setup();
		
		while(true) {
			loop();
		}
	}
	
	/**
	 * Initialisation du programme
	 */
	public abstract void setup();
	
	/**
	 * Boucle principale
	 */
	public abstract void loop();
}
