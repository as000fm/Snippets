package outils.automatisations;

import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;

import outils.tests.automated.annotations.SkipTesting;

/**
 * Test pour l'automatisation de tests
 * @author Claude Toupin - 3 mars 2020
 */
@SkipTesting
public class AutomatisationTests {

	/**
	 * Test pour l'automatisation de tests
	 * @param args Arguments
	 * @throws AWTException en cas d'erreur...
	 */
	public static void main(String[] args) throws AWTException {
		// Utilisation du robot de AWT pour envoyer des événements au desktop
		Robot robot = new Robot();

		// Delai entre chaque commande au robot de AWT en millisecondes
		// robot.setAutoDelay(500);
		robot.setAutoDelay(0);

		while (true) {
			Point point = MouseInfo.getPointerInfo().getLocation();
			
			System.out.println("AutomatisationTests: x=" + point.x + ",y=" + point.y);
			
			robot.mouseMove(point.x + 10, point.y + 10);
			robot.mouseMove(point.x - 10, point.y - 10);
			robot.mouseMove(point.x, point.y);

			// Il est possible d'envoyer des événements de touches aussi
			// int keycode = KeyEvent.VK_A; // Lettre 'A'
			// robot.keyPress(keycode);
			// robot.keyRelease(keycode);
			
			try {
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				// Ignore..
			}
		}
	}

}
