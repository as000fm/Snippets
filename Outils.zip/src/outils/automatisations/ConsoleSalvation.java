package outils.automatisations;

import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;

import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.SkipTesting;

/**
 * Relèvement de la console
 * @author Claude Toupin - 19 mars 2020
 */
@SkipTesting
public class ConsoleSalvation {

	/**
	 * Relèvement de la console
	 * @param args Arguments
	 * @throws AWTException en cas d'erreur...
	 */
	public static void main(String[] args) throws AWTException {
		Robot robot = new Robot();

		robot.setAutoDelay(250);

		Point lastPoint = MouseInfo.getPointerInfo().getLocation();

		boolean init = true;

		while (true) {
			Point startingPoint = MouseInfo.getPointerInfo().getLocation();

			if (init) {
				OutilsCommun.console("Initialisation");
				init = false;
			} else {
				if ((startingPoint.x == lastPoint.x) && (startingPoint.y == lastPoint.y)) {
					OutilsCommun.console("Relèvement en cours: x=" + startingPoint.x + ",y=" + startingPoint.y);

					int x = startingPoint.x;
					int y = startingPoint.y;

					for (int i = 0; i <= 20; i++) {
						Point currentPoint = MouseInfo.getPointerInfo().getLocation();

						if ((x != currentPoint.x) || (y != currentPoint.y)) {
							OutilsCommun.console("Arrêt du relèvement");
							break;
						}

						int delta = ((i % 2) == 0) ? 1 : -1;

						x = startingPoint.x + delta;
						y = startingPoint.y - delta;

						robot.mouseMove(x, y);
					}

					robot.mouseMove(startingPoint.x, startingPoint.y);
				} else {
					lastPoint = startingPoint;
				}
			}

			try {
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				// Ignore..
			}
		}
	}

}
