package outils.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Encodage/Decodage en base 64 pour le web
 * @author Claude Toupin - 2016-09-14
 */
public class Base64Web {
	final private static Map<Integer, String> ENCODE_DICT;

	final private static Map<String, Integer> DECODE_DICT;

	static {
		ENCODE_DICT = new HashMap<Integer, String>();
		ENCODE_DICT.put(0, "0");
		ENCODE_DICT.put(1, "1");
		ENCODE_DICT.put(2, "2");
		ENCODE_DICT.put(3, "3");
		ENCODE_DICT.put(4, "4");
		ENCODE_DICT.put(5, "5");
		ENCODE_DICT.put(6, "6");
		ENCODE_DICT.put(7, "7");
		ENCODE_DICT.put(8, "8");
		ENCODE_DICT.put(9, "9");
		ENCODE_DICT.put(10, "A");
		ENCODE_DICT.put(11, "B");
		ENCODE_DICT.put(12, "C");
		ENCODE_DICT.put(13, "D");
		ENCODE_DICT.put(14, "E");
		ENCODE_DICT.put(15, "F");
		ENCODE_DICT.put(16, "G");
		ENCODE_DICT.put(17, "H");
		ENCODE_DICT.put(18, "I");
		ENCODE_DICT.put(19, "J");
		ENCODE_DICT.put(20, "K");
		ENCODE_DICT.put(21, "L");
		ENCODE_DICT.put(22, "M");
		ENCODE_DICT.put(23, "N");
		ENCODE_DICT.put(24, "O");
		ENCODE_DICT.put(25, "P");
		ENCODE_DICT.put(26, "Q");
		ENCODE_DICT.put(27, "R");
		ENCODE_DICT.put(28, "S");
		ENCODE_DICT.put(29, "T");
		ENCODE_DICT.put(30, "U");
		ENCODE_DICT.put(31, "V");
		ENCODE_DICT.put(32, "W");
		ENCODE_DICT.put(33, "X");
		ENCODE_DICT.put(34, "Y");
		ENCODE_DICT.put(35, "Z");
		ENCODE_DICT.put(36, "a");
		ENCODE_DICT.put(37, "b");
		ENCODE_DICT.put(38, "c");
		ENCODE_DICT.put(39, "d");
		ENCODE_DICT.put(40, "e");
		ENCODE_DICT.put(41, "f");
		ENCODE_DICT.put(42, "g");
		ENCODE_DICT.put(43, "h");
		ENCODE_DICT.put(44, "i");
		ENCODE_DICT.put(45, "j");
		ENCODE_DICT.put(46, "k");
		ENCODE_DICT.put(47, "l");
		ENCODE_DICT.put(48, "m");
		ENCODE_DICT.put(49, "n");
		ENCODE_DICT.put(50, "o");
		ENCODE_DICT.put(51, "p");
		ENCODE_DICT.put(52, "q");
		ENCODE_DICT.put(53, "r");
		ENCODE_DICT.put(54, "s");
		ENCODE_DICT.put(55, "t");
		ENCODE_DICT.put(56, "u");
		ENCODE_DICT.put(57, "v");
		ENCODE_DICT.put(58, "w");
		ENCODE_DICT.put(59, "x");
		ENCODE_DICT.put(60, "y");
		ENCODE_DICT.put(61, "z");
		ENCODE_DICT.put(62, "(");
		ENCODE_DICT.put(63, ")");

		DECODE_DICT = new HashMap<String, Integer>();
		DECODE_DICT.put("0", 0);
		DECODE_DICT.put("1", 1);
		DECODE_DICT.put("2", 2);
		DECODE_DICT.put("3", 3);
		DECODE_DICT.put("4", 4);
		DECODE_DICT.put("5", 5);
		DECODE_DICT.put("6", 6);
		DECODE_DICT.put("7", 7);
		DECODE_DICT.put("8", 8);
		DECODE_DICT.put("9", 9);
		DECODE_DICT.put("A", 10);
		DECODE_DICT.put("B", 11);
		DECODE_DICT.put("C", 12);
		DECODE_DICT.put("D", 13);
		DECODE_DICT.put("E", 14);
		DECODE_DICT.put("F", 15);
		DECODE_DICT.put("G", 16);
		DECODE_DICT.put("H", 17);
		DECODE_DICT.put("I", 18);
		DECODE_DICT.put("J", 19);
		DECODE_DICT.put("K", 20);
		DECODE_DICT.put("L", 21);
		DECODE_DICT.put("M", 22);
		DECODE_DICT.put("N", 23);
		DECODE_DICT.put("O", 24);
		DECODE_DICT.put("P", 25);
		DECODE_DICT.put("Q", 26);
		DECODE_DICT.put("R", 27);
		DECODE_DICT.put("S", 28);
		DECODE_DICT.put("T", 29);
		DECODE_DICT.put("U", 30);
		DECODE_DICT.put("V", 31);
		DECODE_DICT.put("W", 32);
		DECODE_DICT.put("X", 33);
		DECODE_DICT.put("Y", 34);
		DECODE_DICT.put("Z", 35);
		DECODE_DICT.put("a", 36);
		DECODE_DICT.put("b", 37);
		DECODE_DICT.put("c", 38);
		DECODE_DICT.put("d", 39);
		DECODE_DICT.put("e", 40);
		DECODE_DICT.put("f", 41);
		DECODE_DICT.put("g", 42);
		DECODE_DICT.put("h", 43);
		DECODE_DICT.put("i", 44);
		DECODE_DICT.put("j", 45);
		DECODE_DICT.put("k", 46);
		DECODE_DICT.put("l", 47);
		DECODE_DICT.put("m", 48);
		DECODE_DICT.put("n", 49);
		DECODE_DICT.put("o", 50);
		DECODE_DICT.put("p", 51);
		DECODE_DICT.put("q", 52);
		DECODE_DICT.put("r", 53);
		DECODE_DICT.put("s", 54);
		DECODE_DICT.put("t", 55);
		DECODE_DICT.put("u", 56);
		DECODE_DICT.put("v", 57);
		DECODE_DICT.put("w", 58);
		DECODE_DICT.put("x", 59);
		DECODE_DICT.put("y", 60);
		DECODE_DICT.put("z", 61);
		DECODE_DICT.put("(", 62);
		DECODE_DICT.put(")", 63);
	}

	/**
	 * Encode une valeur entre 0 et 63
	 * @param value La valeur à encoder
	 * @return un String représentant la valeur encodée
	 */
	@AutomatedTests({ "-1", "64" })
	final public static String encode(int value) {
		if ((value < 0) || (value > 63)) {
			throw new RuntimeException("La valeur doit être entre 0 et 63. Valeur actuelle: " + value);
		}

		return ENCODE_DICT.get(value);
	}

	/**
	 * Décode une valeur en Base64Web
	 * @param value La valeur à décoder
	 * @return un int représentant la valeur décodée
	 */
	@AutomatedTests({ "0", "A", "z" })
	final public static int decode(String value) {
		Integer result = DECODE_DICT.get(value);

		if (result == null) {
			throw new RuntimeException("Valeur invalide!. Valeur actuelle: " + value);
		}

		return result.intValue();
	}

	/**
	 * Calcul le facteur Base64Web (1,2,3 ou 6) pour un nombre items donné
	 * @param nb Nombre d'items
	 * @return le facteur calculé
	 */
	@StrictAutomatedTests({ "65", "64", "6", "3", "2" })
	final public static int getFactor(int nb) {
		if (nb > 64) {
			throw new RuntimeException("Trop d''items: " + nb);
		}

		if (nb > 8) {
			return 6;
		} else if (nb > 4) {
			return 3;
		} else if (nb > 2) {
			return 2;
		} else {
			return 1;
		}
	}

	/**
	 * Indique le nombre de caractères utilisés pour encoder un nombre de valeurs pour un facteur donné
	 * @param nb Le nombre de valeurs
	 * @param factor Le facteur
	 * @return le nombre de caractères utilisés
	 */
	@AutomatedTests({ "0", "1" })
	@AutomatedTests({ "1", "0" })
	@AutomatedTests({ "2", "2" })
	@AutomatedTests({ "2", "3" })
	final public static int encodedSize(int nb, int factor) {
		if ((nb < 1) || (factor < 1)) {
			return 0;
		}

		int positions = nb * factor;

		return (positions / 6) + (((positions % 6) != 0) ? 1 : 0);
	}

	/**
	 * Encode une liste d'items entre 0 et 63 pour un facteur donné
	 * @param items La liste d'items à encoder
	 * @return un String représentant le code de la liste d'items encodée
	 */
	@AutomatedTests({ "1", "1", "1", "2", "1", "3", "1", "6" })
	@AutomatedTests({ "1", "5", "1,2,3", "2", "-1", "2", "65", "2" })
	@AutomatedTests({ "1,2,3,4,5,6", "1", "", "2" })
	final public static String encodeItems(int[] items, int factor) {
		if (items == null) {
			throw new RuntimeException("Pas de  iste d'items à encoder");
		}

		if ((factor != 1) && (factor != 2) && (factor != 3) && (factor != 6)) {
			throw new RuntimeException("Le facteur doit être 1, 2, 3 ou 6. Facteur actuel: " + factor);
		}

		String code = "";

		int pos = 0;
		int value = 0;

		for (int item : items) {
			if ((item < 0) || (item > 63)) {
				throw new RuntimeException("La valeur de l'item doit être entre 0 et 63. Valeur de l'item: " + item);
			}

			if (pos == 6) {
				code += Base64Web.encode(value);
				value = 0;
				pos = 0;
			}

			value <<= factor;

			value |= item;

			pos += factor;
		}

		if (pos != 0) {
			while (pos < 6) {
				value <<= factor;
				pos += factor;
			}

			code += Base64Web.encode(value);
		}

		return code;
	}

	/**
	 * Décode un code pour un facteur donné
	 * @param code La valeur à décoder
	 * @return une liste d'items entre 0 et 63
	 */
	@AutomatedTests({ "R2D2", "2", "c3p0", "6" })
	final public static int[] decodeItems(String code, int factor) {
		List<Integer> list = decodeList(code, factor);

		int[] items = new int[list.size()];

		for (int i = 0; i < list.size(); i++) {
			items[i] = list.get(i).intValue();
		}

		return items;
	}

	/**
	 * Encode une liste d'items entre 0 et 63 pour un facteur donné
	 * @param list La liste d'items à encoder
	 * @return un String représentant le code de la liste d'items encodée
	 */
	@AutomatedTests({ "0,1,2,3", "2", "5,6", "3" })
	final public static String encodeList(List<Integer> list, int factor) {
		if (list == null) {
			throw new RuntimeException("Pas de liste d'items à encoder");
		}

		int[] items = new int[list.size()];

		for (int i = 0; i < list.size(); i++) {
			items[i] = list.get(i).intValue();
		}

		return encodeItems(items, factor);
	}

	/**
	 * Décode un code pour un facteur donné
	 * @param code La valeur à décoder
	 * @return une liste d'items entre 0 et 63
	 */
	@AutomatedTests({ "A", "1", "6m", "2", "k", "3", "Guru", "6" })
	final public static List<Integer> decodeList(String code, int factor) {
		List<Integer> list = new ArrayList<Integer>();

		if (!OutilsBase.isEmpty(code)) {
			for (int i = 0; i < code.length(); i++) {
				int value = decode(OutilsBase.asString(code.charAt(i)));

				switch (factor) {
					case 6:
						list.add(value);
						break;
					case 3:
						list.add((value >> 3) & 0x07);
						list.add(value & 0x07);
						break;
					case 2:
						list.add((value >> 4) & 0x03);
						list.add((value >> 2) & 0x03);
						list.add(value & 0x03);
						break;
					case 1:
						list.add((value >> 5) & 0x01);
						list.add((value >> 4) & 0x01);
						list.add((value >> 3) & 0x01);
						list.add((value >> 2) & 0x01);
						list.add((value >> 1) & 0x01);
						list.add(value & 0x01);
						break;
					default:
						throw new RuntimeException("Le facteur doit être 1, 2, 3 ou 6. Facteur actuel: " + factor);
				}
			}
		}

		return list;
	}
}
