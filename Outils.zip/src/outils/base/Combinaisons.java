package outils.base;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import outils.tests.automated.annotations.AutomatedTests;

/**
 * Classe de génération de toutes les combinaisons non vides possibles pour les eléments d'une liste ex: [a, b] -> [[a], [b], [a, b], [b, a]]
 * @author Claude Toupin - 2018-10-23
 */
public class Combinaisons<T> {
	/** Liste des items à combiner **/
	final private List<T> itemsListe;

	/** Liste des combinaisons des items */
	final private List<List<T>> combinaisonsListe;

	/**
	 * Constructeur de base
	 */
	public Combinaisons() {
		this.itemsListe = new ArrayList<T>();
		this.combinaisonsListe = new ArrayList<List<T>>();
	}

	/**
	 * Constructeur de base
	 * @param items Tableau des items à combiner
	 */
	@SafeVarargs
	public Combinaisons(T... items) {
		this(false, true, items);
	}

	/**
	 * Constructeur de base
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param items Tableau des items à combiner
	 */
	@SafeVarargs
	public Combinaisons(boolean commutatifs, T... items) {
		this(commutatifs, true, items);
	}

	/**
	 * Constructeur de base
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param tri Indicateur de tri par ordre croissant de nombre d'éléments
	 * @param items Tableau des items à combiner
	 */
	@SafeVarargs
	public Combinaisons(boolean commutatifs, boolean tri, T... items) {
		this();
		combine(commutatifs, tri, items);
	}

	/**
	 * Constructeur de base
	 * @param items Liste des items à combiner
	 */
	public Combinaisons(List<T> items) {
		this(false, true, items);
	}

	/**
	 * Constructeur de base
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param items Liste des items à combiner
	 */
	public Combinaisons(boolean commutatifs, List<T> items) {
		this(commutatifs, true, items);
	}

	/**
	 * Constructeur de base
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param tri Indicateur de tri par ordre croissant de nombre d'éléments
	 * @param items Liste des items à combiner
	 */
	public Combinaisons(boolean commutatifs, boolean tri, List<T> items) {
		this();
		combine(commutatifs, tri, items);
	}

	/**
	 * Génération de toutes les combinaisons non vides possibles pour les éléments d'un ArrayList ex: [a, b] -> [[a], [b], [a, b], [b, a]]
	 * @param liste Le ArrayList
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @return un ArrayList de toutes les combinaisons
	 */
	protected List<List<T>> genereCombinaisons(List<T> liste, boolean commutatifs) {
		if (OutilsBase.isEmpty(liste)) {
			return new ArrayList<List<T>>();
		} else if (liste.size() == 1) {
			List<List<T>> resultat = new ArrayList<List<T>>();

			List<T> ajout = new ArrayList<T>();
			ajout.add(liste.get(0));
			resultat.add(ajout);

			return resultat;
		} else if (liste.size() == 2) {
			List<List<T>> resultat = new ArrayList<List<T>>();

			List<T> ajout = new ArrayList<T>();
			ajout.add(liste.get(0));
			resultat.add(ajout);

			ajout = new ArrayList<T>();
			ajout.add(liste.get(1));
			resultat.add(ajout);

			ajout = new ArrayList<T>();
			ajout.add(liste.get(0));
			ajout.add(liste.get(1));
			resultat.add(ajout);

			if (commutatifs) {
				ajout = new ArrayList<T>();
				ajout.add(liste.get(1));
				ajout.add(liste.get(0));
				resultat.add(ajout);
			}

			return resultat;
		}

		List<List<T>> resultat = new ArrayList<List<T>>();

		for (int i = 0; i < liste.size(); i++) {
			T pivot = liste.get(i);

			List<T> ajout = new ArrayList<T>();
			ajout.add(pivot);
			resultat.add(ajout);

			List<T> sous_liste = new ArrayList<T>();

			for (int j = 0; j < liste.size(); j++) {
				if (commutatifs) {
					if (i != j) {
						sous_liste.add(liste.get(j));
					}
				} else {
					if (i < j) {
						sous_liste.add(liste.get(j));
					}
				}
			}

			List<List<T>> sous_resultat = genereCombinaisons(sous_liste, commutatifs);

			for (int j = 0; j < sous_resultat.size(); j++) {
				List<T> items = sous_resultat.get(j);

				ajout = new ArrayList<T>();
				ajout.add(pivot);
				ajout.addAll(items);

				resultat.add(ajout);
			}
		}

		return resultat;
	}

	/**
	 * Effectue la combinaison depuis une liste des items donné
	 * @param items Tableau des items à combiner
	 */
	public void combine(@SuppressWarnings("unchecked") T... items) {
		combine(false, true, items);
	}

	/**
	 * Effectue la combinaison depuis une liste des items donné
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param items Tableau des items à combiner
	 */
	public void combine(boolean commutatifs, @SuppressWarnings("unchecked") T... items) {
		combine(commutatifs, true, items);
	}

	/**
	 * Effectue la combinaison depuis une liste des items donné
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param tri Indicateur de tri par ordre croissant de nombre d'éléments
	 * @param items Tableau des items à combiner
	 */
	@AutomatedTests({ "true", "true", "A,B" })
	public void combine(boolean commutatifs, boolean tri, @SuppressWarnings("unchecked") T... items) {
		itemsListe.clear();
		combinaisonsListe.clear();

		if (items != null) {
			itemsListe.addAll(OutilsBase.asList(items));
			combine(commutatifs, tri);
		}
	}

	/**
	 * Effectue la combinaison depuis une liste des items donné
	 * @param items Liste des items à combiner
	 */
	public void combine(List<T> items) {
		combine(false, true, items);
	}

	/**
	 * Effectue la combinaison depuis une liste des items donné
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param items Liste des items à combiner
	 */
	@AutomatedTests({ "false", "A,B", "true", "A,B", "false", "A,B,C", "true", "A,B,C" })
	public void combine(boolean commutatifs, List<T> items) {
		combine(commutatifs, true, items);
	}

	/**
	 * Effectue la combinaison depuis une liste des items donné
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param tri Indicateur de tri par ordre croissant de nombre d'éléments
	 * @param items Liste des items à combiner
	 */
	@AutomatedTests(value = { "false,true", "false,true", "1" }, iterate = true)
	public void combine(boolean commutatifs, boolean tri, List<T> items) {
		itemsListe.clear();
		combinaisonsListe.clear();

		if (items != null) {
			itemsListe.addAll(items);

			combine(commutatifs, tri);
		}
	}

	/**
	 * Effectue la combinaison depuis la liste des items
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 */
	public void combine() {
		combine(false, true);
	}

	/**
	 * Effectue la combinaison depuis la liste des items
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 */
	public void combine(boolean commutatifs) {
		combine(commutatifs, true);
	}

	/**
	 * Effectue la combinaison depuis la liste des items
	 * @param commutatifs Indicateur de doublons commutatifs (i.e. [a, b] et [b, a])
	 * @param tri Indicateur de tri par ordre croissant de nombre d'éléments
	 */
	public void combine(boolean commutatifs, boolean tri) {
		combinaisonsListe.clear();

		if (!itemsListe.isEmpty()) {
			combinaisonsListe.addAll(genereCombinaisons(itemsListe, commutatifs));

			if (tri) {
				combinaisonsListe.sort(new Comparator<List<T>>() {
					@Override
					public int compare(List<T> liste1, List<T> liste2) {
						int compare = 0;

						Integer nulls = OutilsBase.compareNulls(liste1, liste2);

						if (nulls != null) {
							compare = nulls.intValue();
						} else {
							compare = OutilsBase.compare(liste1.size(), liste2.size());

							if (compare == 0) {
								for (int i = 0; i < liste1.size(); i++) {
									int index1 = itemsListe.indexOf(liste1.get(i));
									int index2 = itemsListe.indexOf(liste2.get(i));

									compare = OutilsBase.compare(index1, index2);

									if (compare != 0) {
										break;
									}
								}
							}
						}

						return compare;
					}
				});
			}
		}
	}

	/**
	 * Extrait le champ itemsListe
	 * @return un List<T>
	 */
	public List<T> getItemsListe() {
		return itemsListe;
	}

	/**
	 * Extrait le champ combinaisonsListe
	 * @return un List<List<T>>
	 */
	public List<List<T>> getCombinaisonsListe() {
		return combinaisonsListe;
	}
}
