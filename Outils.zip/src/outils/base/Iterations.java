package outils.base;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe de génération de toutes les itérations possibles pour les groupes d'eléments d'une liste ex: [a, b, c], [d], [e, f] -> [[a, d, e], [a, d, f], [b, d, e], [b, d, f], [c, d, e], [c, d, f]]
 * @author Claude Toupin - 17 janv. 2022
 */
public class Iterations<T> {
	/** Liste des items à itérer **/
	final private List<List<T>> itemsListe;

	/** Liste des itérations des items */
	final private List<List<T>> iterationsListe;

	/**
	 * Constructeur de base
	 */
	public Iterations() {
		this.itemsListe = new ArrayList<List<T>>();
		this.iterationsListe = new ArrayList<List<T>>();
	}

	/**
	 * Constructeur de base
	 * @param items Tableau des items à itérer
	 */
	@SafeVarargs
	public Iterations(T[]... items) {
		this();
		itere(items);
	}

	/**
	 * Constructeur de base
	 * @param items Liste des items à itérer
	 */
	@SafeVarargs
	public Iterations(List<T>... items) {
		this();
		itere(items);
	}

	/**
	 * Constructeur de base
	 * @param items Liste des items à itérer
	 */
	public Iterations(List<List<T>> items) {
		this();
		itere(items);
	}

	/**
	 * Génération de toutes les itérations possibles pour les groupes d'eléments d'une liste ex: [a, b, c], [d], [e, f] -> [[a, d, e], [a, d, f], [b, d, e], [b, d, f], [c, d, e], [c, d, f]]
	 * @param index Index du groupe d'éléments
	 * @param liste Liste de l'itération courante
	 * @return la liste des listes d'itérations de l'index courant
	 */
	protected List<List<T>> genereIterations(int index, List<T> liste) {
		List<List<T>> iterations = new ArrayList<List<T>>();

		if (index < itemsListe.size()) {
			for (T item : itemsListe.get(index)) {
				List<T> iterationCourante = new ArrayList<T>();
				iterationCourante.addAll(liste);
				iterationCourante.add(item);

				if ((index + 1) < itemsListe.size()) {
					iterations.addAll(genereIterations(index + 1, iterationCourante));
				} else {
					iterations.add(iterationCourante);
				}
			}
		}

		return iterations;
	}

	/**
	 * Génération de toutes les itérations possibles pour les groupes d'éléments de la liste d'items courante à itérer
	 */
	public void itere() {
		iterationsListe.clear();

		if (!itemsListe.isEmpty()) {
			iterationsListe.addAll(genereIterations(0, new ArrayList<T>()));
		}
	}

	/**
	 * Génération de toutes les itérations possibles pour les groupes d'eléments de la liste d'items à itérer
	 * @param items Tableau des items à itérer
	 */
	public void itere(@SuppressWarnings("unchecked") T[]... items) {
		itemsListe.clear();

		if (items != null) {
			for (int i = 0; i < items.length; i++) {
				itemsListe.add(OutilsBase.asList(items[i]));
			}
		}

		itere();
	}

	/**
	 * Génération de toutes les itérations possibles pour les groupes d'eléments de la liste d'items à itérer
	 * @param items Liste des items à itérer
	 */
	public void itere(@SuppressWarnings("unchecked") List<T>... items) {
		itemsListe.clear();

		if (items != null) {
			itemsListe.addAll(OutilsBase.asList(items));
		}

		itere();
	}

	/**
	 * Génération de toutes les itérations possibles pour les groupes d'eléments de la liste d'items à itérer
	 * @param items Liste des items à itérer
	 */
	public void itere(List<List<T>> items) {
		itemsListe.clear();
		itemsListe.addAll(items);

		itere();
	}

	/**
	 * Extrait le champ itemsListe
	 * @return un List<List<T>>
	 */
	public List<List<T>> getItemsListe() {
		return itemsListe;
	}

	/**
	 * Extrait le champ iterationsListe
	 * @return un List<List<T>>
	 */
	public List<List<T>> getIterationsListe() {
		return iterationsListe;
	}
}
