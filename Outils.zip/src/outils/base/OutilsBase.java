package outils.base;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import outils.listes.WordSeparatorData;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.CoverageOnly;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.StrictAutomatedTests;
import outils.types.CSVSeparatorsTypes;
import outils.types.MetricUnitsTypes;
import outils.types.WordSeparatorsTypes;

/**
 * Classe des méthodes utilitaires de base (i.e. compilable par GWT) de type final public static
 * @author Claude Toupin - 2010-10-23
 */
@CoverageTestsCases(OutilsBase.CoverageTestsCases.class)
public class OutilsBase {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			List<String[]> rowsOfColumnslist = new ArrayList<String[]>();
			rowsOfColumnslist.add(new String[] { "AAAA", "BB", "CCC" });
			rowsOfColumnslist.add(new String[] { "AA-AA", "B-B", "CC-CC" });

			OutilsBase.formatRowsOfColumns(rowsOfColumnslist);

			List<WordSeparatorData> wordSeparatorlist = new ArrayList<WordSeparatorData>();
			wordSeparatorlist.add(new WordSeparatorData("Test"));
			wordSeparatorlist.add(new WordSeparatorData(WordSeparatorsTypes.SPACE));
			wordSeparatorlist.add(new WordSeparatorData("Test"));

			OutilsBase.toWordsSeparatorsList(wordSeparatorlist);
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/**
	 * Verifie si l'objet est nulle
	 * @param value Valeur à vérifier
	 * @return Vrai si nulle
	 */
	@AutomatedTests({ "new java.util.ArrayList<String>()", "new java.util.HashMap<String, String>()", "new int[0]", "new int[1]" })
	final public static boolean isEmpty(Object value) {
		if (value != null) {
			if (value instanceof String) {
				return ((String) value).isEmpty();
			} else if (value instanceof Collection<?>) {
				return ((Collection<?>) value).isEmpty();
			} else if (value instanceof Map<?, ?>) {
				return ((Map<?, ?>) value).isEmpty();
			} else if (value.getClass().isArray()) {
				return Array.getLength(value) == 0;
			}

			return false;
		}

		return true;
	}

	/**
	 * Verifie si la string ne contient pas d'espace
	 * @param value Valeur à vérifier
	 * @return Vrai si ne contient pas d'espace
	 */
	@AutomatedTests("OutilsBase")
	final public static boolean haveNoSpace(String value) {
		if (value != null) {
			return (value.indexOf(' ') == -1);
		}

		return true;
	}

	/**
	 * Vérifie si une liste d'objets est null ou non
	 * @param objects Liste d'objets
	 * @return vrai si tous null
	 */
	final public static boolean areNulls(Object... objects) {
		if (objects != null) {
			for (Object object : objects) {
				if (object != null) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Vérifie si une liste d'objets d'objets est non-null ou non
	 * @param objects Liste d'objets
	 * @return vrai si tous non-nulls
	 */
	final public static boolean areNotNulls(Object... objects) {
		if (objects == null) {
			return false;
		}

		for (Object object : objects) {
			if (object == null) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Vérifie si une liste d'objets est isEmpty(Object) ou non
	 * @param objects Liste d'objets
	 * @return vrai si tous isEmpty
	 */
	final public static boolean areEmpties(Object... objects) {
		if (objects != null) {
			for (Object object : objects) {
				if (!isEmpty(object)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Vérifie si une liste d'objets est !isEmpty(Object) ou non
	 * @param objects Liste d'objets
	 * @return vrai si tous isEmpty
	 */
	final public static boolean areNotEmpties(Object... objects) {
		if (objects == null) {
			return false;
		}

		for (Object object : objects) {
			if (isEmpty(object)) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Vérifie si deux objets sont égaux même si il y a des objects qui sont null
	 * @param object1 Le premier objet à vérifier
	 * @param object2 Le deuxième objet à vérifier
	 * @return Vrai si égaux. Note: si null et null, alors vrai
	 */
	@AutomatedTests({ "new Object[] {}", "\"Allo\"" })
	@AutomatedTests({ "new Object[] {}", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 1, 2 }" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 3, 4 }" })
	final public static boolean areEquals(Object object1, Object object2) {
		if ((object1 == null) && (object2 == null)) {
			return true;
		} else if ((object1 == null) || (object2 == null)) {
			return false;
		} else {
			if ((object1 instanceof Object[]) && (object2 instanceof Object[])) {
				Object[] array1 = (Object[]) object1;
				Object[] array2 = (Object[]) object2;

				if (array1.length == array2.length) {
					for (int i = 0; i < array1.length; i++) {
						if (!areEquals(array1[i], array2[i])) {
							return false;
						}
					}

					return true;
				}

				return false;
			}

			return object1.equals(object2);
		}
	}

	/**
	 * Vérifie si une liste d'objets sont égaux même si il y a des objects qui sont null
	 * @param objects Liste des objets
	 * @return vrai si tous égaux
	 */
	@AutomatedTests({ "1,2,3", "1,1,1" })
	final public static boolean areEquals(Object... objects) {
		if (objects != null) {
			switch (objects.length) {
				case 0:
				case 1:
					return true;
				case 2:
					return areEquals(objects[0], objects[1]);
				default:
					for (int i = 0; i < (objects.length - 1); i++) {
						if (!areEquals(objects[i], objects[i + 1])) {
							return false;
						}
					}
					break;
			}
		}

		return true;
	}

	/**
	 * Vérifie si deux objets sont égaux (sans accent) même si il y a des objects qui sont null
	 * @param object1 Le premier objet à vérifier
	 * @param object2 Le deuxième objet à vérifier
	 * @return Vrai si égaux. Note: si null et null, alors vrai
	 */
	@AutomatedTests({ "new Object[] {}", "\"Allo\"" })
	@AutomatedTests({ "new Object[] {}", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 1, 2 }" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 3, 4 }" })
	final public static boolean areEqualsEnglish(Object object1, Object object2) {
		if ((object1 == null) && (object2 == null)) {
			return true;
		} else if ((object1 == null) || (object2 == null)) {
			return false;
		} else {
			if ((object1 instanceof String) && (object2 instanceof String)) {
				return (toEnglish((String) object1)).equals(toEnglish((String) object2));
			}

			if ((object1 instanceof Object[]) && (object2 instanceof Object[])) {
				Object[] array1 = (Object[]) object1;
				Object[] array2 = (Object[]) object2;

				if (array1.length == array2.length) {
					for (int i = 0; i < array1.length; i++) {
						if (!areEqualsEnglish(array1[i], array2[i])) {
							return false;
						}
					}

					return true;
				}

				return false;
			}

			return areEquals(object1, object2);
		}
	}

	/**
	 * Vérifie si une liste d'objets sont égaux (sans accent) même si il y a des objects qui sont null
	 * @param objects Liste des objets
	 * @return vrai si tous égaux
	 */
	@AutomatedTests({ "1,2,3", "1,1,1" })
	final public static boolean areEqualsEnglish(Object... objects) {
		if (objects != null) {
			switch (objects.length) {
				case 0:
				case 1:
					return true;
				case 2:
					return areEqualsEnglish(objects[0], objects[1]);
				default:
					for (int i = 0; i < (objects.length - 1); i++) {
						if (!areEqualsEnglish(objects[i], objects[i + 1])) {
							return false;
						}
					}
			}
		}
		return true;
	}

	/**
	 * Vérifie si deux objets sont égaux (sans la case) même si il y a des objects qui sont null
	 * @param object1 Le premier objet à vérifier
	 * @param object2 Le deuxième objet à vérifier
	 * @return Vrai si égaux. Note: si null et null, alors vrai
	 */
	@AutomatedTests({ "new Object[] {}", "\"Allo\"" })
	@AutomatedTests({ "new Object[] {}", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 1, 2 }" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 3, 4 }" })
	final public static boolean areEqualsIgnoreCase(Object object1, Object object2) {
		if ((object1 == null) && (object2 == null)) {
			return true;
		} else if ((object1 == null) || (object2 == null)) {
			return false;
		} else {
			if ((object1 instanceof String) && (object2 instanceof String)) {
				return ((String) object1).equalsIgnoreCase((String) object2);
			}

			if ((object1 instanceof Object[]) && (object2 instanceof Object[])) {
				Object[] array1 = (Object[]) object1;
				Object[] array2 = (Object[]) object2;

				if (array1.length == array2.length) {
					for (int i = 0; i < array1.length; i++) {
						if (!areEqualsIgnoreCase(array1[i], array2[i])) {
							return false;
						}
					}

					return true;
				}

				return false;
			}

			return areEquals(object1, object2);
		}
	}

	/**
	 * Vérifie si une liste d'objets sont égaux (sans la case) même si il y a des objects qui sont null
	 * @param objects Liste des objets
	 * @return vrai si tous égaux
	 */
	@AutomatedTests({ "1,2,3", "1,1,1" })
	final public static boolean areEqualsIgnoreCase(Object... objects) {
		if (objects != null) {
			switch (objects.length) {
				case 0:
				case 1:
					return true;
				case 2:
					return areEqualsIgnoreCase(objects[0], objects[1]);
				default:
					for (int i = 0; i < (objects.length - 1); i++) {
						if (!areEqualsIgnoreCase(objects[i], objects[i + 1])) {
							return false;
						}
					}
			}
		}
		return true;
	}

	/**
	 * Vérifie si deux objets sont égaux (sans accent et sans la case) même si il y a des objects qui sont null
	 * @param object1 Le premier objet à vérifier
	 * @param object2 Le deuxième objet à vérifier
	 * @return Vrai si égaux. Note: si null et null, alors vrai
	 */
	@AutomatedTests({ "new Object[] {}", "\"Allo\"" })
	@AutomatedTests({ "new Object[] {}", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] {}" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 1, 2 }" })
	@AutomatedTests({ "new Object[] { 1, 2 }", "new Object[] { 3, 4 }" })
	final public static boolean areEqualsEnglishIgnoreCase(Object object1, Object object2) {
		if ((object1 == null) && (object2 == null)) {
			return true;
		} else if ((object1 == null) || (object2 == null)) {
			return false;
		} else {
			if ((object1 instanceof String) && (object2 instanceof String)) {
				return (toEnglish((String) object1)).equalsIgnoreCase(toEnglish((String) object2));
			}

			if ((object1 instanceof Object[]) && (object2 instanceof Object[])) {
				Object[] array1 = (Object[]) object1;
				Object[] array2 = (Object[]) object2;

				if (array1.length == array2.length) {
					for (int i = 0; i < array1.length; i++) {
						if (!areEqualsEnglishIgnoreCase(array1[i], array2[i])) {
							return false;
						}
					}

					return true;
				}

				return false;
			}

			return areEquals(object1, object2);
		}
	}

	/**
	 * Vérifie si une liste d'objets sont égaux (sans accent et sans la case) même si il y a des objects qui sont null
	 * @param objects Liste des objets
	 * @return vrai si tous égaux
	 */
	@AutomatedTests({ "1,2,3", "1,1,1" })
	final public static boolean areEqualsEnglishIgnoreCase(Object... objects) {
		if (objects != null) {
			switch (objects.length) {
				case 0:
				case 1:
					return true;
				case 2:
					return areEqualsEnglishIgnoreCase(objects[0], objects[1]);
				default:
					for (int i = 0; i < (objects.length - 1); i++) {
						if (!areEqualsEnglishIgnoreCase(objects[i], objects[i + 1])) {
							return false;
						}
					}
			}
		}
		return true;
	}

	/**
	 * Compare deux objets nulles (ou non) et retourne le resultat de object1.compareTo(object2) même si null
	 * @param object1 Le premier objet à comparer
	 * @param object2 Le deuxième objet à comparer
	 * @return 0 si nulles, négatif si object1 est null, positif si object2 est null, null sinon (i.e. non nulles)
	 */
	final public static Integer compareNulls(Object object1, Object object2) {
		if ((object1 == null) && (object2 == null)) {
			return 0;
		} else if (object1 == null) {
			return -1;
		} else if (object2 == null) {
			return 1;
		}

		return null;
	}

	/**
	 * Compare deux objets et retourne le resultat de object1.compareTo(object2) même si null
	 * @param object1 Le premier objet à comparer
	 * @param object2 Le deuxième objet à comparer
	 * @return 0 si égale, négatif si object1 < object2, positif si object1 > object2
	 */
	@AutomatedTests(value = { "Boolean.TRUE, new java.util.Date(1583025602029L),1,1L,(float) 3.1,(double) 3.1, outils.types.CSVSeparatorsTypes.ENGLISH", "Boolean.FALSE,new java.util.Date(1583025602029L),2,2L,(float) 3.2,(double) 3.2, outils.types.CSVSeparatorsTypes.FRENCH" }, iterate = true)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	final public static int compare(Object object1, Object object2) {
		Integer nulls = compareNulls(object1, object2);

		if (nulls != null) {
			return nulls.intValue();
		}

		if ((object1 instanceof String) && (object2 instanceof String)) {
			return ((String) object1).compareTo((String) object2);
		} else if ((object1 instanceof Boolean) && (object2 instanceof Boolean)) {
			return ((Boolean) object1).compareTo((Boolean) object2);
		} else if ((object1 instanceof Date) && (object2 instanceof Date)) {
			return ((Date) object1).compareTo((Date) object2);
		} else if ((object1 instanceof Integer) && (object2 instanceof Integer)) {
			return ((Integer) object1).compareTo((Integer) object2);
		} else if ((object1 instanceof Long) && (object2 instanceof Long)) {
			return ((Long) object1).compareTo((Long) object2);
		} else if ((object1 instanceof Float) && (object2 instanceof Float)) {
			return ((Float) object1).compareTo((Float) object2);
		} else if ((object1 instanceof Double) && (object2 instanceof Double)) {
			return ((Double) object1).compareTo((Double) object2);
		} else if ((object1 instanceof Enum) && (object2 instanceof Enum)) {
			return ((Enum) object1).compareTo((Enum) object2);
		}

		return object1.toString().compareTo(object2.toString());
	}

	/**
	 * Compare deux objets et retourne le resultat de object1.compareTo(object2) (sans la case) même si null
	 * @param object1 Le premier objet à comparer
	 * @param object2 Le deuxième objet à comparer
	 * @return 0 si égale, négatif si objetc1 < object2, positif si objetc1 > object2
	 */
	@AutomatedTests(value = { "Boolean.TRUE, new java.util.Date(1583025602029L),1,1L,(float) 3.1,(double) 3.1, outils.types.CSVSeparatorsTypes.ENGLISH", "Boolean.FALSE,new java.util.Date(1583025602029L),2,2L,(float) 3.2,(double) 3.2, outils.types.CSVSeparatorsTypes.FRENCH" }, iterate = true)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	final public static int compareIgnoreCase(Object object1, Object object2) {
		Integer nulls = compareNulls(object1, object2);

		if (nulls != null) {
			return nulls.intValue();
		}

		if ((object1 instanceof String) && (object2 instanceof String)) {
			return ((String) object1).compareToIgnoreCase((String) object2);
		} else if ((object1 instanceof Boolean) && (object2 instanceof Boolean)) {
			return ((Boolean) object1).compareTo((Boolean) object2);
		} else if ((object1 instanceof Date) && (object2 instanceof Date)) {
			return ((Date) object1).compareTo((Date) object2);
		} else if ((object1 instanceof Integer) && (object2 instanceof Integer)) {
			return ((Integer) object1).compareTo((Integer) object2);
		} else if ((object1 instanceof Long) && (object2 instanceof Long)) {
			return ((Long) object1).compareTo((Long) object2);
		} else if ((object1 instanceof Float) && (object2 instanceof Float)) {
			return ((Float) object1).compareTo((Float) object2);
		} else if ((object1 instanceof Double) && (object2 instanceof Double)) {
			return ((Double) object1).compareTo((Double) object2);
		} else if ((object1 instanceof Enum) && (object2 instanceof Enum)) {
			return ((Enum) object1).compareTo((Enum) object2);
		}

		return object1.toString().compareToIgnoreCase(object2.toString());
	}

	/**
	 * Détermine si la valeur débute par un préfixe donné même si null
	 * @param value Valeur à vérifier
	 * @param prefix Pérfixe à débuter pas
	 * @return Vrai si débute par le préfixe donné
	 */
	final public static boolean startsWith(String value, String prefix) {
		if (!isEmpty(value) && !isEmpty(prefix)) {
			return value.startsWith(prefix);
		}

		return false;
	}

	/**
	 * Détermine si la valeur débute par un préfixe donné (sans la case) même si null
	 * @param value Valeur à vérifier
	 * @param prefix Préfixe à débuter pas
	 * @return Vrai si débute par le préfixe donné
	 */
	final public static boolean startsWithIgnoreCase(String value, String prefix) {
		if (!isEmpty(value) && !isEmpty(prefix)) {
			return value.toUpperCase().startsWith(prefix.toUpperCase());
		}

		return false;
	}

	/**
	 * Détermine si la valeur débute par un préfixe donné même si null
	 * @param value Valeur à vérifier
	 * @param suffix Suffixe à terminer pas
	 * @return Vrai si se termine par le suffixe donné
	 */
	final public static boolean endsWith(String value, String suffix) {
		if (!isEmpty(value) && !isEmpty(suffix)) {
			return value.endsWith(suffix);
		}

		return false;
	}

	/**
	 * Détermine si la valeur se termine par un suffixe donné (sans la case) même si null
	 * @param value Valeur à vérifier
	 * @param suffix Suffixe à terminer pas
	 * @return Vrai si se termine par le suffixe donné
	 */
	final public static boolean endsWithIgnoreCase(String value, String suffix) {
		if (!isEmpty(value) && !isEmpty(suffix)) {
			return value.toUpperCase().endsWith(suffix.toUpperCase());
		}

		return false;
	}

	/**
	 * Extrait la position de différence entre deux objets
	 * @param object1 Le premier objet à comparer
	 * @param object2 Le deuxième objet à comparer
	 * @return la position de différence, -1 si aucune position de différence
	 */
	@AutomatedTests(value = { "\"AAA\",\"BB\"", "\"AAA\",\"AA\",\"BB\",\"C\"" }, iterate = true)
	final public static int differentAtPos(Object object1, Object object2) {
		if (!areNulls(object1, object2)) {
			if (isEmpty(object1) || isEmpty(object2)) {
				return 0;
			}

			char[] buf1 = asString(object1).toCharArray();
			char[] buf2 = asString(object2).toCharArray();

			int min = min(buf1.length, buf2.length);
			int max = max(buf1.length, buf2.length);

			for (int i = 0; i < min; i++) {
				if (buf1[i] != buf2[i]) {
					return i;
				}
			}

			if (max > min) {
				return min;
			}
		}

		return -1;
	}

	/**
	 * Extrait la position de différence (sans la case) entre deux objets
	 * @param object1 Le premier objet à comparer
	 * @param object2 Le deuxième objet à comparer
	 * @return la position de différence, -1 si aucune position de différence
	 */
	@AutomatedTests(value = { "\"AAA\",\"BB\"", "\"AAA\",\"AA\",\"BB\",\"C\"" }, iterate = true)
	final public static int differentAtPosIgnoreCase(Object object1, Object object2) {
		if (!areNulls(object1, object2)) {
			if (isEmpty(object1) || isEmpty(object2)) {
				return 0;
			}

			char[] buf1 = asString(object1).toUpperCase().toCharArray();
			char[] buf2 = asString(object2).toUpperCase().toCharArray();

			int min = min(buf1.length, buf2.length);
			int max = max(buf1.length, buf2.length);

			for (int i = 0; i < min; i++) {
				if (buf1[i] != buf2[i]) {
					return i;
				}
			}

			if (max > min) {
				return min;
			}
		}

		return -1;
	}

	/**
	 * Extrait la valeur de l'indicateur donné en booléen
	 * @param value La valeur de l'indicateur en texte
	 * @return un booléen
	 */
	@AutomatedTests(value = "true,vrai,yes,oui,t,v,y,o,no", iterate = true)
	final public static boolean asIndicator(String value) {
		if (!isEmpty(value)) {
			return "true".equalsIgnoreCase(value) || //
					"vrai".equalsIgnoreCase(value) || //
					"yes".equalsIgnoreCase(value) || //
					"oui".equalsIgnoreCase(value) || //
					"t".equalsIgnoreCase(value) || //
					"v".equalsIgnoreCase(value) || //
					"y".equalsIgnoreCase(value) || //
					"o".equalsIgnoreCase(value) //
			;
		}

		return false;
	}

	/**
	 * Extrait la valeur de l'indicateur donné en texte en français
	 * @param value La valeur de l'indicateur en booléen
	 * @return le texte
	 */
	final public static String toIndicator(boolean value) {
		return toIndicator(value, true);
	}

	/**
	 * Extrait la valeur de l'indicateur donné en texte
	 * @param value La valeur de l'indicateur en booléen
	 * @param french Indicateur de texte en français
	 * @return le texte
	 */
	final public static String toIndicator(boolean value, boolean french) {
		return toIndicator(value, french ? "Oui" : "Yes", french ? "Non" : "No");
	}

	/**
	 * Extrait la valeur de l'indicateur donné en texte
	 * @param value La valeur de l'indicateur en booléen
	 * @param trueText Le texte pour vrai
	 * @param falseText Le texte pour faux
	 * @return le texte
	 */
	final public static String toIndicator(boolean value, String trueText, String falseText) {
		return value ? trueText : falseText;
	}

	/**
	 * Traitement des strings pour eviter d'afficher un null
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	@AutomatedTests("new int[] { 1, 2, 3}")
	final public static String asString(Object value) {
		if (isEmpty(value)) {
			return "";
		}

		if (value.getClass().isArray()) {
			String result = "";

			for (int i = 0; i < Array.getLength(value); i++) {
				if (i > 0) {
					result += ",";
				}

				result += asString(Array.get(value, i));
			}

			return result;
		}

		return value.toString();
	}

	/**
	 * Traitement des strings pour eviter d'afficher un null
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	final public static String asString(Object[] value) {
		String result = "";

		if (!isEmpty(value)) {
			for (int i = 0; i < value.length; i++) {
				if (i > 0) {
					result += ",";
				}

				result += asString(value[i]);
			}
		}

		return result;
	}

	/**
	 * Traitement des strings pour eviter d'afficher un null
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	final public static String asString(String value) {
		return isEmpty(value) ? "" : value;
	}

	/**
	 * Retourne la liste sous forme d'un string
	 * @param list Liste des données
	 * @return la liste sous forme d'une string
	 */
	final public static String asString(List<String> list) {
		return asString(list, false);
	}

	/**
	 * Retourne la liste sous forme d'un string
	 * @param list Liste des données
	 * @param trim Indicateur de suppression des blancs
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests({ "1,2,3", "false", "1,2,3", "true" })
	final public static String asString(List<String> list, boolean trim) {
		if (isEmpty(list)) {
			return "";
		}

		String result = "";

		for (String item : list) {
			result += trim ? trim(asString(item)) : asString(item);
		}

		return result;
	}

	/**
	 * Extraction d'une valeur d'un objet Integer
	 * @param value Valeur à extraire
	 * @return la valeur d'un objet Integer
	 */
	final public static int asValue(Integer value) {
		return isEmpty(value) ? 0 : value.intValue();
	}

	/**
	 * Extraction d'une valeur d'un objet Long
	 * @param value Valeur à extraire
	 * @return la valeur d'un objet Long
	 */
	final public static long asValue(Long value) {
		return isEmpty(value) ? 0 : value.longValue();
	}

	/**
	 * Extraction d'une valeur d'un objet Float
	 * @param value Valeur à extraire
	 * @return la valeur d'un objet Float
	 */
	final public static float asValue(Float value) {
		return isEmpty(value) ? 0 : value.floatValue();
	}

	/**
	 * Extraction d'une valeur d'un objet Double
	 * @param value Valeur à extraire
	 * @return la valeur d'un objet Double
	 */
	final public static double asValue(Double value) {
		return isEmpty(value) ? 0 : value.doubleValue();
	}

	/**
	 * Conversion d'une liste en une liste de textes
	 * @param list La liste à convertir
	 * @return La liste convertie
	 */
	@AutomatedTests("1,2,3")
	final public static List<String> asStringList(List<?> list) {
		List<String> stringList = new ArrayList<String>();

		if (list != null) {
			for (Object obj : list) {
				stringList.add(asString(obj));
			}
		}

		return stringList;
	}

	/**
	 * Traitement des strings pour eviter d'afficher un null ou la valeur 0
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	final public static String asStringNoZero(Integer value) {
		return isEmpty(value) ? "" : asStringNoZero(value.intValue());
	}

	/**
	 * Traitement des strings pour eviter d'afficher la valeur 0
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	@AutomatedTests("1")
	final public static String asStringNoZero(int value) {
		return (value == 0) ? "" : asString(value);
	}

	/**
	 * Traitement des strings pour eviter d'afficher un null ou la valeur 0
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	final public static String asStringNoZero(Long value) {
		return isEmpty(value) ? "" : asStringNoZero(value.longValue());
	}

	/**
	 * Traitement des strings pour eviter d'afficher la valeur 0
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	@AutomatedTests("1L")
	final public static String asStringNoZero(long value) {
		return (value == 0) ? "" : asString(value);
	}

	/**
	 * Traitement des strings pour eviter de mettre un null entre guillemets
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	final public static String asQuotedString(String value) {
		if (value == null) {
			return "null";
		}

		return "\"" + value + "\"";
	}

	/**
	 * Traitement d'un texte de caractères pour éviter d'afficher un null ou un texte vide pour le web
	 * @param value Valeur à convertir
	 * @return le texte normalisée
	 */
	@AutomatedTests({ "", " ", "<", "<>", "<body>", "<body", "body>" })
	final public static String asWebString(String value) {
		if (isEmpty(value)) {
			return "&nbsp;";
		}

		if (isEmpty(value.trim())) {
			return "&nbsp;";
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '<') {
				if ((i + 1) < charsData.length) {
					int j;
					boolean found = false;

					for (j = i + 1; j < charsData.length; j++) {
						char d = charsData[j];

						if (d == '>') {
							found = true;
							break;
						}
					}

					if (!found) {
						resultat.append("&lt;");
					} else {
						if ((j - i) == 1) {
							resultat.append("&lt;&gt;");
							i++;
						} else {
							for (int k = i; k <= j; k++) {
								resultat.append(charsData[k]);
								i = j;
							}
						}
					}
				} else {
					resultat.append("&lt;");
				}
			} else if (c == '>') {
				resultat.append("&gt;");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des strings pour convertir en URL valide (javascript: escape)
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	@AutomatedTests({ "~!#%^&(){}[]=:,;?'\"\\", "new String(new byte[] {0x10, 0x24, (byte) 0x90})" })
	final public static String asUrlString(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			// N'encode pas: @*/+-

			switch (c) {
				case ' ':
					resultat.append("%20");
					break;
				case '~':
					resultat.append("%7E");
					break;
				case '!':
					resultat.append("%21");
					break;
				case '#':
					resultat.append("%23");
					break;
				case '$':
					resultat.append("%24");
					break;
				case '%':
					resultat.append("%25");
					break;
				case '^':
					resultat.append("%5E");
					break;
				case '&':
					resultat.append("%26");
					break;
				case '(':
					resultat.append("%28");
					break;
				case ')':
					resultat.append("%29");
					break;
				case '{':
					resultat.append("%7B");
					break;
				case '}':
					resultat.append("%7D");
					break;
				case '[':
					resultat.append("%5B");
					break;
				case ']':
					resultat.append("%5D");
					break;
				case '=':
					resultat.append("%3D");
					break;
				case ':':
					resultat.append("%3A");
					break;
				case ',':
					resultat.append("%2C");
					break;
				case ';':
					resultat.append("%3B");
					break;
				case '?':
					resultat.append("%3F");
					break;
				case '\'':
					resultat.append("%27");
					break;
				case '"':
					resultat.append("%22");
					break;
				case '\\':
					resultat.append("%5C");
					break;
				default:
					if ((c <= 0x1F) || (c >= 0x80)) {
						resultat.append('%');
						resultat.append(toHexa((byte) c));
					} else {
						resultat.append(c);
					}
					break;
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des strings pour convertir en URI valide (encode moins que asUrlString) (javascript: encodeURI)
	 * @param value Valeur à convertir
	 * @return la string normaliser
	 */
	@AutomatedTests({ "%^{}[]\"\\", "new String(new byte[] {0x10, (byte) 0x90})" })
	final public static String asUriString(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			// N'encode pas: ~!@#$&*()=:/,;?+'-

			switch (c) {
				case ' ':
					resultat.append("%20");
					break;
				case '%':
					resultat.append("%25");
					break;
				case '^':
					resultat.append("%5E");
					break;
				case '{':
					resultat.append("%7B");
					break;
				case '}':
					resultat.append("%7D");
					break;
				case '[':
					resultat.append("%5B");
					break;
				case ']':
					resultat.append("%5D");
					break;
				case '"':
					resultat.append("%22");
					break;
				case '\\':
					resultat.append("%5C");
					break;
				default:
					if ((c <= 0x1F) || (c >= 0x80)) {
						resultat.append('%');
						resultat.append(toHexa((byte) c));
					} else {
						resultat.append(c);
					}
					break;
			}
		}

		return resultat.toString();
	}

	/**
	 * Création d'une liste de données sur demande à la Arrays.asList(T... a) mais pour une liste modifiable !!!
	 * @param <T> Type java des valeurs de la liste
	 * @param t Tableau de type <T> des valeurs de la liste
	 * @return une liste
	 */
	@SafeVarargs
	final public static <T> List<T> asList(T... t) {
		if (t == null) {
			return null;
		}

		List<T> list = new ArrayList<T>();

		for (int i = 0; i < t.length; i++) {
			list.add(t[i]);
		}

		return list;
	}

	/**
	 * Création d'un dictionnaire de données sur demande à la Arrays.asList(T... a)
	 * @param <K> Type java des clés du dictionnaire
	 * @param <V> Type java des valeurs du dictionnaire
	 * @param k Tableau de type <K> des clés du dictionnaire
	 * @param v Tableau de type <V> des valeurs du dictionnaire
	 * @return un dictionnaire
	 */
	final public static <K, V> Map<K, V> asMap(K[] k, V[] v) {
		if ((k == null) || (v == null)) {
			return null;
		}

		if (k.length != v.length) {
			throw new RuntimeException("Le nombre d'items des clés (" + k.length + ") doit être égale au nombre de valeurs (" + v.length + ")");
		}

		Map<K, V> map = new HashMap<K, V>();

		for (int i = 0; i < k.length; i++) {
			map.put(k[i], v[i]);
		}

		return map;
	}

	/**
	 * Extrait le texte au singulier ou au pluriel selon la taille
	 * @param size La taille
	 * @param singularText Le texte au sigulier
	 * @param pluralText Le texte au pluriel
	 * @return le texte au singulier ou au pluriel selon la taille
	 */
	@AutomatedTests({ "2", "a", "b" })
	final public static String singularOrPluralText(int size, String singularText, String pluralText) {
		return (size > 1) ? pluralText : singularText;
	}

	/**
	 * Extrait le texte au singulier ou au pluriel selon la taille
	 * @param size La taille
	 * @param singularText Le texte au sigulier
	 * @param pluralText Le texte au pluriel
	 * @return le texte au singulier ou au pluriel selon la taille
	 */
	@AutomatedTests({ "2", "a", "b" })
	final public static String singularOrPluralText(long size, String singularText, String pluralText) {
		return (size > 1) ? pluralText : singularText;
	}

	/**
	 * Extrait le pluriel selon la taille
	 * @param size La taille
	 * @return le singulier ou le pluriel selon la taille
	 */
	@AutomatedTests("2")
	final public static String plural(int size) {
		if (size > 1) {
			return "s";
		}

		return "";
	}

	/**
	 * Extrait le pluriel selon la taille
	 * @param size La taille
	 * @return le singulier ou le pluriel selon la taille
	 */
	@AutomatedTests("2")
	final public static String plural(long size) {
		if (size > 1) {
			return "s";
		}

		return "";
	}

	/**
	 * Extrait un message au pluriel selon la taille
	 * @param size La taille
	 * @param singularTexts Liste de textes au singulier
	 * @return le message au singulier ou au pluriel selon la taille
	 */
	@AutomatedTests({ "2", "A,B" })
	final public static String plural(int size, String... singularTexts) {
		String message = "";

		for (String singularText : singularTexts) {
			if (!isEmpty(message)) {
				message += " ";
			}

			message += asString(singularText).trim() + plural(size);
		}

		return message;
	}

	/**
	 * Extrait un message au pluriel selon la taille
	 * @param size La taille
	 * @param singularTexts Liste de textes au singulier
	 * @return le message au singulier ou au pluriel selon la taille
	 */
	@AutomatedTests({ "2", "A,B" })
	final public static String plural(long size, String... singularTexts) {
		String message = "";

		for (String singularText : singularTexts) {
			if (!isEmpty(message)) {
				message += " ";
			}

			message += asString(singularText).trim() + plural(size);
		}

		return message;
	}

	/**
	 * Extrait un message au pluriel selon la taille
	 * @param size La taille
	 * @param singularTexts Liste de textes au singulier
	 * @return le message au singulier ou au pluriel selon la taille
	 */
	@AutomatedTests({ "2", "A,B" })
	final public static String pluralSize(int size, String... singularTexts) {
		String message = asString(size);

		for (String singularText : singularTexts) {
			message += " " + asString(singularText).trim() + plural(size);
		}

		return message;
	}

	/**
	 * Extrait un message au pluriel selon la taille
	 * @param size La taille
	 * @param singularTexts Liste de textes au singulier
	 * @return le message au singulier ou au pluriel selon la taille
	 */
	@AutomatedTests({ "2", "A,B" })
	final public static String pluralSize(long size, String... singularTexts) {
		String message = asString(size);

		for (String singularText : singularTexts) {
			message += " " + asString(singularText).trim() + plural(size);
		}

		return message;
	}

	/**
	 * Convertion d'un nom de base en format "camel back" pour java pour un nom de classe Java
	 * @param name Le nom de base
	 * @return un String
	 */
	@AutomatedTests("c_aaa")
	final public static String parseJavaClassName(String name) {
		if (isEmpty(name)) {
			return "";
		}

		char[] buf = name.toCharArray();

		StringBuffer sb = new StringBuffer();
		sb.append(Character.toUpperCase(buf[0]));

		for (int i = 1; i < buf.length; i++) {
			char ch = buf[i];

			if (ch == '_') {
				i++;

				if (i < buf.length) {
					sb.append(Character.toUpperCase(buf[i]));
				}
			} else {
				sb.append(Character.toLowerCase(ch));
			}
		}

		return sb.toString();
	}

	/**
	 * Convertion d'un nom de base en format "camel back" pour java pour un nom de champ Java
	 * @param name Le nom de base
	 * @return un String
	 */
	@AutomatedTests("c_aaa_")
	final public static String parseJavaFieldName(String name) {
		if (isEmpty(name)) {
			return "";
		}

		char[] buf = name.toCharArray();

		StringBuffer sb = new StringBuffer();
		sb.append(Character.toLowerCase(buf[0]));

		for (int i = 1; i < buf.length; i++) {
			char ch = buf[i];

			if (ch == '_') {
				i++;

				if (i < buf.length) {
					sb.append(Character.toUpperCase(buf[i]));
				}
			} else {
				sb.append(Character.toLowerCase(ch));
			}
		}

		return sb.toString();
	}

	/**
	 * Traitement des apostrophes et guillemets pour javascript
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("A'B\"")
	final public static String parseJavascriptQuote(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '\'') {
				resultat.append("\\'");
			} else if (c == '"') {
				resultat.append("&quot;");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des apostrophes pour javascript
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("A'B")
	final public static String parseQuote(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '\'') {
				resultat.append("\\'");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des guillements pour java
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("A\"B")
	final public static String parseJavaDoubleQuote(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '"') {
				resultat.append("\\\"");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des "tags"
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("<body>")
	final public static String parseTag(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '<') {
				resultat.append("&lt;");
			} else if (c == '>') {
				resultat.append("&gt;");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Remplace les \" a 2 caractères en 1 seul (i.e. "\\\"" -> "\"")
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("\\\"A\\\\B\\C\\")
	final public static String removeEscapedQuotes(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '\\') {
				if ((i + 1) < charsData.length) {
					char d = charsData[++i];

					if (d != '"') {
						resultat.append(c);
					}

					resultat.append(d);
				} else {
					resultat.append(c);
				}
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des blancs
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	final public static String trim(String value) {
		if (isEmpty(value)) {
			return value;
		}

		return trimAtStart(trimAtEnd(value));
	}

	/**
	 * Traitement des blancs au début
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests({ "   ", " A", "\bA", "\tA", "\rA", "\nA" })
	final public static String trimAtStart(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		int s = 0;
		int e = charsData.length - 1;

		while (s <= e) {
			char c = charsData[s];

			// if (!Character.isSpaceChar(c)) {
			// break;
			// }

			// Pour GWT
			if (!((c == ' ') || (c == '\b') || (c == '\t') || (c == '\r') || (c == '\n'))) {
				break;
			}

			s++;
		}

		for (int i = s; i <= e; i++) {
			resultat.append(charsData[i]);
		}

		return resultat.toString();
	}

	/**
	 * Traitement des blancs à la fin
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests({ "   ", "B ", "B\b", "B\t", "B\r", "B\n" })
	final public static String trimAtEnd(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		int s = 0;
		int e = charsData.length - 1;

		while (e >= 0) {
			char c = charsData[e];

			// if (!Character.isSpaceChar(c)) {
			// break;
			// }

			// Pour GWT
			if (!((c == ' ') || (c == '\b') || (c == '\t') || (c == '\r') || (c == '\n'))) {
				break;
			}

			e--;
		}

		for (int i = s; i <= e; i++) {
			resultat.append(charsData[i]);
		}

		return resultat.toString();
	}

	/**
	 * Traitement des CRLF
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests({ "C", "C\r", "C\n", "C\r\n", "\rC", "\nC", "\r\nC" })
	final public static String trimCRLF(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		int s = 0;
		int e = charsData.length - 1;

		while (e >= 0) {
			char c = charsData[e];

			if ((c != 10) && (c != 13)) {
				break;
			}

			e--;
		}

		while (s < charsData.length) {
			char c = charsData[s];

			if ((c != 10) && (c != 13)) {
				break;
			}

			s++;
		}

		for (int i = s; i <= e; i++) {
			resultat.append(charsData[i]);
		}

		return resultat.toString();
	}

	/**
	 * Traitement des CRLF
	 * @param value Le texte à traiter
	 * @param atEnd Indique que le traitement se fait à la fin du texte
	 * @return le texte traité
	 */
	@AutomatedTests(value = { "C,C\r,C\n,C\r\n,\rC,\nC,\r\nC", "false,true" }, iterate = true)
	final public static String trimCRLF(String value, boolean atEnd) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		int s = 0;
		int e = charsData.length - 1;

		if (atEnd) {
			while (e >= 0) {
				char c = charsData[e];

				if ((c != 10) && (c != 13)) {
					break;
				}

				e--;
			}
		} else {
			while (s < charsData.length) {
				char c = charsData[s];

				if ((c != 10) && (c != 13)) {
					break;
				}

				s++;
			}
		}

		for (int i = s; i <= e; i++) {
			resultat.append(charsData[i]);
		}

		return resultat.toString();
	}

	/**
	 * Coupe le texte à une longueur précise si trop grand
	 * @param value Le texte à traiter
	 * @param length La longueur maximale du texte
	 * @return le texte traité
	 */
	@AutomatedTests({ "A", "-1", "Allo", "100" })
	final public static String truncate(String value, int length) {
		if (isEmpty(value)) {
			return "";
		}

		if (length < 0) {
			throw new IndexOutOfBoundsException("len < 0");
		}

		if (value.length() > length) {
			return value.substring(0, length);
		}

		return value.trim();
	}

	/**
	 * Normalise le nom de fichier
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests({ "a-b", "(0)", "A", "A_B", "[a.b]", "$a" })
	final public static String formatFileName(String value) {
		if (isEmpty(value)) {
			return value;
		}

		value = toEnglish(stripHTML(value));

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (!(((c >= '0') && (c <= '9')) || ((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) || (c == '_') || (c == '-') || (c == '(') || (c == ')') || (c == '[') || (c == ']') || (c == '.'))) {
				charsData[i] = '_';
			}
		}

		return new String(charsData);
	}

	/**
	 * Compte le nombre d'occurrences d'un caractère pour un texte donné
	 * @param value Le texte à traiter
	 * @param search Le caractère à compter
	 * @return le nombre d'occurrences trouvées
	 */
	@AutomatedTests(value = { ",Allo", "l,e,o" }, iterate = true)
	final public static int count(String value, char search) {
		int total = 0;

		if (!isEmpty(value)) {
			int pos = value.indexOf(search);

			while (pos != -1) {
				total++;

				pos = ((pos + 1) < value.length()) ? value.indexOf(search, pos + 1) : -1;
			}
		}

		return total;
	}

	/**
	 * Compte le nombre d'occurrences d'un texte pour un texte donné
	 * @param value Le texte à traiter
	 * @param search Le texte à compter
	 * @return le nombre d'occurrences trouvées
	 */
	@AutomatedTests(value = { ",Allo", ",l,Allolo,o" }, iterate = true)
	final public static int count(String value, String search) {
		int total = 0;

		if (!isEmpty(value) && !isEmpty(search)) {
			int pos = value.indexOf(search);

			while (pos != -1) {
				total++;

				pos = ((pos + 1) < value.length()) ? value.indexOf(search, pos + 1) : -1;
			}
		}

		return total;
	}

	/**
	 * Remplace tous les occurrences d'un texte avec une autre
	 * @param value Le texte à traiter
	 * @param oldString Le texte à remplacer
	 * @param newString Le texte de remplacement
	 * @return le texte traité
	 */
	final public static String replace(String value, String oldString, String newString) {
		if (isEmpty(value) || isEmpty(oldString)) {
			return value;
		}

		newString = asString(newString);

		String resultat = value;

		int oldLen = oldString.length();
		int newLen = newString.length();

		int pos = resultat.indexOf(oldString);

		while (pos != -1) {
			StringBuffer sb = new StringBuffer(resultat.substring(0, pos));
			sb.append(newString);
			sb.append(resultat.substring(pos + oldLen));
			resultat = sb.toString();
			pos = resultat.indexOf(oldString, pos + newLen);
		}

		return resultat;
	}

	/**
	 * Remplace tous les occurrences d'un texte avec une autre
	 * @param value Le texte à traiter
	 * @param oldStart Le début du texte à remplacer
	 * @param newStart Le début du texte de remplacement
	 * @param oldEnd La fin du texte à remplacer
	 * @param newEnd La fin du texte de remplacement
	 * @return le texte traité
	 */
	@AutomatedTests({ "Allo", "A", "B", "o", "a" })
	final public static String replace(String value, String oldStart, String newStart, String oldEnd, String newEnd) {
		if (isEmpty(value) || isEmpty(oldStart) || isEmpty(oldEnd)) {
			return value;
		}

		newStart = asString(newStart);
		newEnd = asString(newEnd);

		String resultat = value;

		int oldStartLen = oldStart.length();
		int oldEndLen = oldEnd.length();
		@SuppressWarnings("unused") int newStartLen = newStart.length();
		int newEndLen = newEnd.length();

		int posStart = resultat.indexOf(oldStart);

		while (posStart != -1) {
			int posEnd = resultat.indexOf(oldEnd, posStart + oldStartLen);

			if (posEnd == -1) {
				posStart = -1;
			} else {
				StringBuffer sb = new StringBuffer(resultat.substring(0, posStart));
				sb.append(newStart);
				sb.append(resultat.substring(posStart + oldStartLen, posEnd));
				sb.append(newEnd);
				sb.append(resultat.substring(posEnd + oldEndLen));
				resultat = sb.toString();

				posStart = resultat.indexOf(oldStart, posEnd + newEndLen);
			}
		}

		return resultat;
	}

	/**
	 * Retirer les espaces d'un texte
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	final public static String removeSpace(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c != ' ') {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Retirer toutes les occurrences d'un caractère d'un texte
	 * @param value Le texte à traiter
	 * @param myChar Le caractère à retirer
	 * @return le texte traité
	 */
	@AutomatedTests({ "ABC", "B" })
	final public static String removeChar(String value, char myChar) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c != myChar) {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description)
	 * @param padding Le padding au début de la section
	 * @param section Le texte de la section
	 * @param separator Le séparateur entre la section et la description
	 * @param description La description de la section
	 * @return le texte d'une section formatté
	 */
	final public static String doSection(String section, String description) {
		return doSection(null, section, null, description);
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description)
	 * @param padding Le padding au début de la section
	 * @param section Le texte de la section
	 * @param description La description de la section
	 * @return le texte d'une section formatté
	 */
	final public static String doSection(String padding, String section, String description) {
		return doSection(padding, section, null, description);
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description)
	 * @param padding Le padding au début de la section
	 * @param section Le texte de la section
	 * @param separator Le séparateur entre la section et la description
	 * @param description La description de la section
	 * @return le texte d'une section formatté
	 */
	final public static String doSection(String padding, String section, String separator, String description) {
		if (separator == null) {
			separator = ":";
		}

		return asString(padding) + asString(section) + " " + separator + " " + asString(description);
	}

	/**
	 * Découpe le texte en lignes pour une longeur par défaut
	 * @param value Le texte à découper
	 * @return une liste de lignes de textes
	 */
	final public static List<String> wrap(String value) {
		return wrap(value, 0, null);
	}

	/**
	 * Découpe le texte en lignes pour une longeur maximale donné
	 * @param value Le texte à découper
	 * @param maxLength La longeur maximale
	 * @return une liste de lignes de textes
	 */
	final public static List<String> wrap(String value, int maxLength) {
		return wrap(value, maxLength, null);
	}

	/**
	 * Découpe le texte en lignes pour une longeur maximale donné
	 * @param value Le texte à découper
	 * @param maxLength La longeur maximale (défaut: 74 caractères)
	 * @param padding Le texte à ajouter au début d'une nouvelle ligne découpée
	 * @return une liste de lignes de textes
	 */
	@AutomatedTests({ " Découpe le texte en lignes pour une longeur maximale donné", "5", "**" })
	final public static List<String> wrap(String value, int maxLength, String padding) {
		List<String> lines = new ArrayList<String>();

		if (!isEmpty(value)) {
			if (padding == null) {
				padding = "";
			}

			if (maxLength < 1) {
				maxLength = 74;
			}

			if (value.length() <= maxLength) {
				lines.add(value);
			} else {
				while (true) {
					boolean found = false;

					int pos = maxLength - 1;

					for (int i = 0; i < value.length(); i++) {
						if (Character.isWhitespace(value.charAt(i))) {
							if (i < maxLength) {
								found = true;
								pos = i;
							} else {
								break;
							}
						}
					}

					if (!found) {
						if (value.length() > maxLength) {
							lines.add(value.substring(0, maxLength));
							value = padding + value.substring(maxLength);
						}
					} else {
						if (pos <= (padding.length() - 1)) {
							if (value.length() > maxLength) {
								lines.add(value.substring(0, maxLength));
								value = padding + value.substring(maxLength);
							}
						} else {
							if (value.length() > pos) {
								lines.add(value.substring(0, pos));
								value = padding + value.substring(pos + 1);
							}
						}
					}

					if (!isEmpty(value)) {
						if (value.length() <= maxLength) {
							lines.add(value);
							break;
						}
					} else {
						break;
					}
				}
			}
		}

		return lines;
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description) découpé en lignes pour une longeur maximale par défaut
	 * @param section Le texte de la section
	 * @param description La description de la section
	 * @return le texte d'une section formatté
	 */
	final public static List<String> doWrappedSection(String section, String description) {
		return doWrappedSection(null, section, null, description, 0);
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description) découpé en lignes pour une longeur maximale par défaut
	 * @param padding Le padding au début de la section
	 * @param section Le texte de la section
	 * @param description La description de la section
	 * @return le texte d'une section formatté
	 */
	final public static List<String> doWrappedSection(String padding, String section, String description) {
		return doWrappedSection(padding, section, null, description, 0);
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description) découpé en lignes pour une longeur maximale par défaut
	 * @param padding Le padding au début de la section
	 * @param section Le texte de la section
	 * @param separator Le séparateur entre la section et la description
	 * @param description La description de la section
	 * @return le texte d'une section formatté
	 */
	final public static List<String> doWrappedSection(String padding, String section, String separator, String description) {
		return doWrappedSection(padding, section, separator, description, 0);
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description) découpé en lignes pour une longeur maximale donné
	 * @param section Le texte de la section
	 * @param description La description de la section
	 * @param maxLength La longeur maximale
	 * @return le texte d'une section formatté
	 */
	final public static List<String> doWrappedSection(String section, String description, int maxLength) {
		return doWrappedSection(null, section, null, description, maxLength);
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description) découpé en lignes pour une longeur maximale donné
	 * @param padding Le padding au début de la section
	 * @param section Le texte de la section
	 * @param description La description de la section
	 * @param maxLength La longeur maximale
	 * @return le texte d'une section formatté
	 */
	final public static List<String> doWrappedSection(String padding, String section, String description, int maxLength) {
		return doWrappedSection(padding, section, null, description, maxLength);
	}

	/**
	 * Fomattage du texte d'une section (i.e. section : description) découpé en lignes pour une longeur maximale donné
	 * @param padding Le padding au début de la section
	 * @param section Le texte de la section
	 * @param separator Le séparateur entre la section et la description
	 * @param description La description de la section
	 * @param maxLength La longeur maximale
	 * @return le texte d'une section formatté
	 */
	final public static List<String> doWrappedSection(String padding, String section, String separator, String description, int maxLength) {
		if (separator == null) {
			separator = ":";
		}

		String partial = asString(padding) + asString(section) + " " + asString(separator) + " ";

		return wrap(partial + asString(description).trim(), maxLength, padString("", ' ', partial.length()));
	}

	/**
	 * Supprime les tags HTML
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("&amp;Test&#32;<br>&quot;Test&nbsp;<body>Test&lt;Test&gt;")
	final public static String stripHTML(String value) {
		if (isEmpty(value)) {
			return value;
		}

		int p, e;

		do {
			String lc = value.toLowerCase();

			p = lc.indexOf("<br>");

			if (p != -1) {
				value = value.substring(0, p) + "\n" + value.substring(p + 4);
			}
		} while (p != -1);

		boolean html = false;
		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '<') {
				html = true;
			} else if (c == '>') {
				html = false;
			} else if (!html) {
				resultat.append(c);
			}
		}

		do {
			String s = resultat.toString();
			String lc = s.toLowerCase();

			p = lc.indexOf("&lt;");

			if (p != -1) {
				StringBuffer temp = new StringBuffer();
				temp.append(s.substring(0, p));
				temp.append('<');
				temp.append(s.substring(p + 4));
				resultat = temp;
			}
		} while (p != -1);

		do {
			String s = resultat.toString();
			String lc = s.toLowerCase();

			p = lc.indexOf("&gt;");

			if (p != -1) {
				StringBuffer temp = new StringBuffer();
				temp.append(s.substring(0, p));
				temp.append('>');
				temp.append(s.substring(p + 4));
				resultat = temp;
			}
		} while (p != -1);

		do {
			String s = resultat.toString();
			String lc = s.toLowerCase();

			p = lc.indexOf("&quot;");

			if (p != -1) {
				StringBuffer temp = new StringBuffer();
				temp.append(s.substring(0, p));
				temp.append('"');
				temp.append(s.substring(p + 4));
				resultat = temp;
			}
		} while (p != -1);

		do {
			String s = resultat.toString();
			String lc = s.toLowerCase();

			p = lc.indexOf("&amp;");

			if (p != -1) {
				StringBuffer temp = new StringBuffer();
				temp.append(s.substring(0, p));
				temp.append('&');
				temp.append(s.substring(p + 4));
				resultat = temp;
			}
		} while (p != -1);

		do {
			String s = resultat.toString();
			String lc = s.toLowerCase();

			p = lc.indexOf("&nbsp;");

			if (p != -1) {
				StringBuffer temp = new StringBuffer();
				temp.append(s.substring(0, p));
				temp.append(' ');
				temp.append(s.substring(p + 4));
				resultat = temp;
			}
		} while (p != -1);

		do {
			String s = resultat.toString();
			String lc = s.toLowerCase();

			p = lc.indexOf("&#");
			e = -1;

			if (p != -1) {
				e = lc.indexOf(';', p + 2);

				if (e != -1) {
					StringBuffer temp = new StringBuffer();
					temp.append(s.substring(0, p));
					temp.append((char) (Integer.parseInt(s.substring(p + 2, e))));
					temp.append(s.substring(e + 1));
					resultat = temp;
				}
			}
		} while ((p != -1) && (e != -1));

		return resultat.toString();
	}

	/**
	 * Sépare le texte à afficher
	 * @param splitChar Caractère de découpage
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests({ "-", "Test-Test" })
	final public static String splitString(char splitChar, String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == splitChar) {
				resultat.append("<BR>");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Sépare le texte à afficher et remplace les tags ' <' et '>'
	 * @param splitChar Caractère de découpage
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests({ "-", "Test-<body>-Test" })
	final public static String parseTagSplitString(char splitChar, String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '<') {
				resultat.append("&lt;");
			} else if (c == '>') {
				resultat.append("&gt;");
			} else if (c == splitChar) {
				resultat.append(c);
				resultat.append("<BR>");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des guillements pour le html
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("Test\"Test")
	final public static String parseDoubleQuote(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '"') {
				resultat.append("&quot;");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Traitement des caractères spéciaux pour le csv (fichier excel)
	 * @param value Le texte à traiter
	 * @return le texte traité
	 */
	@AutomatedTests("Test\"\r\nTest")
	final public static String escapeCSVCharaters(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '"') {
				resultat.append("\"\"");
			} else if ((c != '\r') && (c != '\n')) {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Formattage de la liste des valeurs en une ligne csv (fichier excel)
	 * @param values La liste des valeurs
	 * @param separator Type de séparateur
	 * @return une ligne csv (fichier excel)
	 */
	final public static String formatCSVRow(Object[] values, CSVSeparatorsTypes separator) {
		return formatCSVRow(values, separator, false);
	}

	/**
	 * Formattage de la liste des valeurs en une ligne csv (fichier excel)
	 * @param values La liste des valeurs
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @return une ligne csv (fichier excel)
	 */
	final public static String formatCSVRow(Object[] values, CSVSeparatorsTypes separator, boolean escapeQuotes) {
		if (values == null) {
			values = new Object[0];
		}

		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < values.length; i++) {
			if (i > 0) {
				sb.append(separator.getSeparator());
			}

			if (values[i] != null) {
				if (!escapeQuotes) {
					sb.append('"');
				}

				sb.append(escapeCSVCharaters(values[i].toString()));

				if (!escapeQuotes) {
					sb.append('"');
				}
			}
		}

		return sb.toString();
	}

	/**
	 * Formattage de la liste des valeurs en une ligne csv (fichier excel)
	 * @param values La liste des valeurs
	 * @param separator Type de séparateur
	 * @return une ligne csv (fichier excel)
	 */
	final public static String formatCSVRow(List<?> values, CSVSeparatorsTypes separator) {
		return formatCSVRow(values, separator, false);
	}

	/**
	 * Formattage de la liste des valeurs en une ligne csv (fichier excel)
	 * @param values La liste des valeurs
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @return une ligne csv (fichier excel)
	 */
	@AutomatedTests({ "1,null,3", "outils.types.CSVSeparatorsTypes.ENGLISH", "true" })
	final public static String formatCSVRow(List<?> values, CSVSeparatorsTypes separator, boolean escapeQuotes) {
		String[] array = new String[(values == null) ? 0 : values.size()];

		if (values != null) {
			for (int i = 0; i < values.size(); i++) {
				Object item = values.get(i);

				array[i] = (item == null) ? null : item.toString();
			}
		}

		return formatCSVRow(array, separator, escapeQuotes);
	}

	/**
	 * Découpe une ligne csv en liste des valeurs
	 * @param line La ligne csv
	 * @param separator Type de séparateur
	 * @return la liste des valeurs
	 */
	final public static String[] parseCSVRowAsArray(String line, CSVSeparatorsTypes separator) {
		List<String> values = parseCSVRowAsList(line, separator);

		return values.toArray(new String[values.size()]);
	}

	/**
	 * Découpe une ligne csv en liste des valeurs
	 * @param line La ligne csv
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @return la liste des valeurs
	 */
	final public static String[] parseCSVRowAsArray(String line, CSVSeparatorsTypes separator, boolean escapeQuotes) {
		List<String> values = parseCSVRowAsList(line, separator, escapeQuotes);

		return values.toArray(new String[values.size()]);
	}

	/**
	 * Découpe une ligne csv en liste des valeurs
	 * @param line La ligne csv
	 * @param separator Type de séparateur
	 * @return la liste des valeurs
	 */
	final public static List<String> parseCSVRowAsList(String line, CSVSeparatorsTypes separator) {
		return parseCSVRowAsList(line, separator, false);
	}

	/**
	 * Découpe une ligne csv en liste des valeurs
	 * @param line La ligne csv
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @return la liste des valeurs
	 */
	@AutomatedTests(value = { "1;;\"2\";3", "outils.types.CSVSeparatorsTypes.FRENCH", "false,true" }, iterate = true)
	final public static List<String> parseCSVRowAsList(String line, CSVSeparatorsTypes separator, boolean escapeQuotes) {
		List<String> values = new ArrayList<String>();

		if (!isEmpty(line)) {
			char[] charsData = line.toCharArray();

			int current = 0;
			int start = 0;
			boolean skip = false;

			while (current < charsData.length) {
				if (!skip) {
					skip = (charsData[current] == '"');
				} else {
					if (charsData[current] == '"') {
						skip = false;
					}
				}

				if (skip) {
					current++;
				} else {
					if (charsData[current] == separator.getSeparatorChar()) {
						if (start == current) {
							values.add(null);
						} else {
							StringBuffer sb = new StringBuffer();

							for (int i = start; i < current; i++) {
								sb.append(charsData[i]);
							}

							String s = sb.toString();

							if (escapeQuotes) {
								if (s.startsWith("\"") && s.endsWith("\"")) {
									s = s.substring(1, s.length() - 1);
								}

								s = s.replace("\"\"", "\"");
							}

							values.add(s);
						}

						current++;
						start = current;
					} else {
						current++;
					}
				}
			}

			if (start == current) {
				values.add(null);
			} else {
				StringBuffer sb = new StringBuffer();

				for (int i = start; i < current; i++) {
					sb.append(charsData[i]);
				}

				String s = sb.toString();

				if (escapeQuotes) {
					if (s.startsWith("\"") && s.endsWith("\"")) {
						s = s.substring(1, s.length() - 1);
					}

					s = s.replace("\"\"", "\"");
				}

				values.add(s);
			}
		}

		return values;
	}

	/**
	 * Formattage de la liste des valeurs en une ligne texte vec les champs séparés par des tabulations
	 * @param values La liste des valeurs
	 * @return une ligne texte (fichier excel)
	 */
	final public static String formatExcelTextRow(Object[] values) {
		return formatExcelTextRow(values, true);
	}

	/**
	 * Formattage de la liste des valeurs en une ligne texte vec les champs séparés par des tabulations
	 * @param values La liste des valeurs
	 * @param escape Indicateur d'échappement des caractères
	 * @return une ligne texte (fichier excel)
	 */
	@AutomatedTests({ "1,2,3,\"=1\",-2", "true" })
	final public static String formatExcelTextRow(Object[] values, boolean escape) {
		if (values == null) {
			values = new Object[0];
		}

		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < values.length; i++) {
			if (i > 0) {
				sb.append('\t');
			}

			if (values[i] != null) {
				if (escape) {
					if (values[i].toString().startsWith("=") || values[i].toString().startsWith("-")) {
						sb.append('\'');
					}
				}

				sb.append(values[i].toString());
			}
		}

		return sb.toString();
	}

	/**
	 * Formattage d'une colonne en taille uniforme ajoutant des espace à droite
	 * @param columns Tableau des colonnes à formatter
	 * @return Les colonnes formattées
	 */
	@AutomatedTests("AAAA,BB,CCC")
	final public static String[] formatColumns(String[] columns) {
		if (columns == null) {
			return new String[0];
		}

		if (columns.length < 2) {
			return columns;
		}

		int maxLength = 0;

		for (String column : columns) {
			maxLength = max(maxLength, column.length());
		}

		String[] result = new String[columns.length];

		for (int i = 0; i < columns.length; i++) {
			result[i] = padEndString(columns[i], ' ', maxLength);
		}

		return result;
	}

	/**
	 * Formattage d'une colonne en taille uniforme ajoutant des espace à droite
	 * @param columns Tableau des colonnes à formatter
	 * @return Les colonnes formattées
	 */
	@AutomatedTests("AAAA,BB,CCC")
	final public static List<String> formatColumns(List<String> columns) {
		if (columns == null) {
			return new ArrayList<String>();
		}

		if (columns.size() < 2) {
			return columns;
		}

		int maxLength = 0;

		for (String column : columns) {
			maxLength = max(maxLength, column.length());
		}

		List<String> result = new ArrayList<String>();

		for (String column : columns) {
			result.add(padEndString(column, ' ', maxLength));
		}

		return result;
	}

	/**
	 * Formattage d'une liste de lignes de colonnes en taille uniforme de colonnes
	 * @param rowsOfColumns La liste de lignes de colonnes à formatter
	 * @return la liste de lignes de colonnes formattée
	 */
	final public static List<String[]> formatRowsOfColumns(List<String[]> rowsOfColumns) {
		if (rowsOfColumns == null) {
			return new ArrayList<String[]>();
		}

		if (rowsOfColumns.size() < 2) {
			return rowsOfColumns;
		}

		int total = rowsOfColumns.get(0).length;

		List<String[]> result = new ArrayList<String[]>();

		for (int i = 0; i < rowsOfColumns.size(); i++) {
			result.add(new String[total]);
		}

		for (int i = 0; i < total; i++) {
			List<String> columns = new ArrayList<String>();

			for (String[] row : rowsOfColumns) {
				columns.add(asString(row[i]));
			}

			columns = formatColumns(columns);

			for (int j = 0; j < columns.size(); j++) {
				result.get(j)[i] = columns.get(j);
			}
		}

		return result;
	}

	/**
	 * Extraction d'une taille d'octets en unité métrique (i.e. Exa, Peta, Tera, Giga, Méga, Kilo) en sa valeur en octets
	 * @param value La valeur en texte
	 * @return la valeur en octets
	 */
	@AutomatedTests({ "10", "10Z", "1,2Mo", "1.2Ko" })
	final public static long parseMetricSize(String value) {
		if (isEmpty(value)) {
			return 0;
		}

		String number = "";
		String metric = "";

		for (char c : value.toCharArray()) {
			if (Character.isDigit(c)) {
				number += c;
			} else if ((c == '.') || (c == ',')) {
				number += '.';
			} else if (Character.isLetter(c)) {
				metric += c;
			}
		}

		if (isEmpty(number)) {
			return 0;
		}

		Double size = Double.parseDouble(number);

		if (isEmpty(metric)) {
			return size.longValue();
		}

		MetricUnitsTypes unit = MetricUnitsTypes.getUnit(metric);

		if (unit == null) {
			return size.longValue();
		}

		return Math.round(size.doubleValue() * unit.getUnit());
	}

	/**
	 * Formattage d'une taille d'octets en unité métrique (i.e. Exa, Peta, Tera, Giga, Méga, Kilo)
	 * @param length La taille en octet
	 * @param unit Unité métrique
	 * @param french Indicateur d'unité métrique en anglais ou français
	 * @return La dimension formatée de la taille d'octets en unité métrique
	 */
	@AutomatedTests(value = { "1024,1040,2000", ",outils.types.MetricUnitsTypes.KILO", "false,true" }, iterate = true)
	final public static String formatMetricSize(long length, MetricUnitsTypes unit, boolean french) {
		StringBuffer sb = new StringBuffer();

		if (unit != null) {
			long valeur = length * 100 / unit.getUnit();
			long main = valeur / 100;
			long fraction = valeur % 100;

			sb.append(main);

			if (fraction != 0) {
				sb.append(french ? ',' : '.');

				if (fraction < 10) {
					sb.append('0');
				}

				sb.append(fraction);
			}

			sb.append(' ');
			sb.append(unit.getPrefix());
			sb.append(french ? 'o' : 'b');
		} else {
			sb.append(length);
			sb.append(french ? " octet" : " byte");

			if (length > 1) {
				sb.append('s');
			}
		}

		return sb.toString();
	}

	/**
	 * Formattage d'une taille d'octets en unité métrique (i.e. Exa, Peta, Tera, Giga, Méga, Kilo)
	 * @param length La taille en octet
	 * @param french Indicateur d'unité métrique en anglais ou français
	 * @return La dimension formatée de la taille d'octets en unité métrique
	 */
	final public static String formatMetricSize(long length, boolean french) {
		return formatMetricSize(length, MetricUnitsTypes.getUnit(length), french);
	}

	/**
	 * Extrait un tableau de textes séparés par des caractères autre que des lettres ou chiffres
	 * @param value La valeur à extraire
	 * @return le tableau
	 */
	final public static String[] parseTextsAsArray(String value) {
		List<String> values = parseTextsAsList(value);

		return values.toArray(new String[values.size()]);
	}

	/**
	 * Extrait une liste de textes séparés par des caractères autre que des lettres ou chiffres
	 * @param value La valeur à extraire
	 * @return la liste
	 */
	final public static List<String> parseTextsAsList(String value) {
		List<String> list = new ArrayList<String>();

		if (value != null) {
			char[] charsData = toEnglish(value).toCharArray();
			char[] valueData = value.toCharArray();

			String text = "";

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];
				char v = valueData[i];

				// if (Character.isAlphabetic(c)) {
				// Pour GWT
				if (((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z'))) {
					text += v;
				} else {
					if (!text.isEmpty()) {
						list.add(text);
						text = "";
					}
				}
			}

			if (!text.isEmpty()) {
				list.add(text);
			}
		}

		return list;
	}

	/**
	 * Extrait un tableau de textes séparés par des caractères de fin de ligne
	 * @param value La valeur à extraire
	 * @return la liste
	 */
	final public static String[] parseLinesAsArray(String value) {
		List<String> values = parseLinesAsList(value);

		return values.toArray(new String[values.size()]);
	}

	/**
	 * Extrait une liste de textes séparés par des caractères de fin de ligne
	 * @param value La valeur à extraire
	 * @return la liste
	 */
	@AutomatedTests("Test\r\n\r\nTest")
	final public static List<String> parseLinesAsList(String value) {
		List<String> list = new ArrayList<String>();

		if (value != null) {
			char[] charsData = toEnglish(value).toCharArray();
			char[] valueData = value.toCharArray();

			String text = "";

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];
				char v = valueData[i];

				if ((c != 0x0A) && (c != 0x0D)) {
					text += v;
				} else {
					if (!text.isEmpty()) {
						list.add(text);
						text = "";
					}
				}
			}

			if (!text.isEmpty()) {
				list.add(text);
			}
		}

		return list;
	}

	/**
	 * Convertit un chaîne sans accents
	 * @param value La chaîne à convertir
	 * @return la chaîne convertit
	 */
	@AutomatedTests("ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßàáâãäåçèéêëìíîïðñòóôõöøùúûüýÿ\u00d7")
	final public static String toEnglish(String value) {
		if (value == null) {
			return null;
		}

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if ((c >= '\u00c0') && (c <= '\u00c5')) {
				charsData[i] = 'A';
			} else if (c == '\u00c7') {
				charsData[i] = 'C';
			} else if ((c >= '\u00c8') && (c <= '\u00cb')) {
				charsData[i] = 'E';
			} else if ((c >= '\u00cc') && (c <= '\u00cf')) {
				charsData[i] = 'I';
			} else if (c == '\u00d0') {
				charsData[i] = 'D';
			} else if (c == '\u00d1') {
				charsData[i] = 'N';
			} else if ((c >= '\u00d2') && (c <= '\u00d6')) {
				charsData[i] = 'O';
			} else if (c == '\u00d7') {
				charsData[i] = 'x';
			} else if (c == '\u00d8') {
				charsData[i] = 'o';
			} else if ((c >= '\u00d9') && (c <= '\u00dc')) {
				charsData[i] = 'U';
			} else if (c == '\u00dd') {
				charsData[i] = 'Y';
			} else if (c == '\u00df') {
				charsData[i] = 'B';
			} else if ((c >= '\u00e0') && (c <= '\u00e5')) {
				charsData[i] = 'a';
			} else if (c == '\u00e7') {
				charsData[i] = 'c';
			} else if ((c >= '\u00e8') && (c <= '\u00eb')) {
				charsData[i] = 'e';
			} else if ((c >= '\u00ec') && (c <= '\u00ef')) {
				charsData[i] = 'i';
			} else if (c == '\u00f0') {
				charsData[i] = 'o';
			} else if (c == '\u00f1') {
				charsData[i] = 'n';
			} else if ((c >= '\u00f2') && (c <= '\u00f6')) {
				charsData[i] = 'o';
			} else if (c == '\u00f8') {
				charsData[i] = 'o';
			} else if ((c >= '\u00f9') && (c <= '\u00fc')) {
				charsData[i] = 'u';
			} else if (c == '\u00fd') {
				charsData[i] = 'y';
			} else if (c == '\u00ff') {
				charsData[i] = 'y';
			}
		}

		return new String(charsData);
	}

	/**
	 * Transforme un int en String
	 * @param value Le int a transformer
	 * @return un String
	 */
	final public static String intToString(int value) {
		return (Integer.valueOf(value)).toString();
	}

	/**
	 * Normalise les caractères ascii pour le HTML
	 * @param value La string à normaliser
	 * @return la string normalisée
	 */
	@AutomatedTests("\0x10é<>&#;\"\'")
	final public static String toHTML(String value) {
		if (isEmpty(value)) {
			return value;
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if ((c < 0x20) || (c > 0x7E) || (c == '<') || (c == '>') || (c == '&') || (c == '#') || (c == ';') || (c == '"') || (c == '\'')) {
				resultat.append("&#");
				resultat.append((int) c);
				resultat.append(";");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Convertit un byte en binaire
	 * @param value La valeur a convertir
	 * @return un string en binaire
	 */
	@AutomatedTests({ "-1", "-128" })
	final public static String toBinary(byte value) {
		int v;

		if (value < 0) {
			v = 256 + value;
		} else {
			v = value;
		}

		StringBuffer resultat = new StringBuffer();

		for (int i = 0; i < 8; i++) {
			resultat.append(((v & (0x80 >> i)) != 0) ? '1' : '0');
		}

		return resultat.toString();
	}

	/**
	 * Convertit un byte en hexa
	 * @param value La valeur a convertir
	 * @return un string en hexa
	 */
	final public static String toHexa(byte value) {
		int v;

		if (value < 0) {
			v = 256 + value;
		} else {
			v = value;
		}

		char b1 = (char) ((v & 0xF0) >> 4);
		char b2 = (char) (v & 0x0F);

		b1 += (b1 < 10) ? 0x30 : 0x37;
		b2 += (b2 < 10) ? 0x30 : 0x37;

		StringBuffer resultat = new StringBuffer();
		resultat.append(b1);
		resultat.append(b2);

		return resultat.toString();
	}

	/**
	 * Convertit un int en hexa
	 * @param value La valeur a convertir
	 * @return un string en hexa
	 */
	@AutomatedTests({ "-1", "4000" })
	final public static String toHexa(int value) {
		StringBuffer resultat = new StringBuffer();

		if (value == 0) {
			return toHexa((byte) 0);
		} else {
			if (value < 0) {
				value = Integer.MAX_VALUE + value;
			}

			while (value != 0) {
				resultat.insert(0, toHexa((byte) (value & 0xFF)));
				value >>= 8;
			}
		}

		return resultat.toString();
	}

	/**
	 * Convertit un long en hexa
	 * @param value La valeur a convertir
	 * @return un string en hexa
	 */
	@AutomatedTests({ "-1", "4000" })
	final public static String toHexa(long value) {
		StringBuffer resultat = new StringBuffer();

		if (value == 0) {
			return toHexa((byte) 0);
		} else {
			if (value < 0) {
				value = Long.MAX_VALUE + value;
			}

			while (value != 0) {
				resultat.insert(0, toHexa((byte) (value & 0xFF)));
				value >>= 8;
			}
		}

		return resultat.toString();
	}

	/**
	 * Convertit un byte en hexa
	 * @param value La valeur a convertir
	 * @return un string en hexa
	 */
	@AutomatedTests("-1,-128,80")
	final public static String toHexa(byte[] value) {
		StringBuffer resultat = new StringBuffer();

		if (value != null) {
			for (byte b : value) {
				int v;

				if (b < 0) {
					v = 256 + b;
				} else {
					v = b;
				}

				char b1 = (char) ((v & 0xF0) >> 4);
				char b2 = (char) (v & 0x0F);

				b1 += (b1 < 10) ? 0x30 : 0x37;
				b2 += (b2 < 10) ? 0x30 : 0x37;

				resultat.append(b1);
				resultat.append(b2);
			}
		}

		return resultat.toString();
	}

	/**
	 * Convertit un texte en hexa en tableau en byte
	 * @param value La valeur à convertir
	 * @return un tableau en byte
	 */
	@AutomatedTests({ "3F", "3FF", "ZZ", "-3" })
	final public static byte[] fromHexa(String value) {
		byte[] resultat = null;

		if (!isEmpty(value)) {
			if ((value.length() % 2) != 0) {
				throw new RuntimeException("Le nombre de caractères doit être pair");
			}

			List<Byte> list = new ArrayList<Byte>();

			char[] charsData = value.trim().toUpperCase().toCharArray();

			for (int i = 0; i < charsData.length; i += 2) {
				byte b = 0;

				for (int j = 0; j < 2; j++) {
					b <<= 4;

					char c = charsData[i + j];

					if (Character.isLetterOrDigit(c)) {
						if (Character.isDigit(c)) {
							b |= c - 0x30;
						} else if ((c >= 'A') && (c <= 'F')) {
							b |= c - 0x37;
						} else {
							throw new RuntimeException("Le charactère " + value.charAt(i + j) + " à la position " + (i + j) + " doit être un chiffre ou une lettre entre A et F");
						}
					} else {
						throw new RuntimeException("Le charactère " + value.charAt(i + j) + " à la position " + (i + j) + " doit être un chiffre ou une lettre entre A et F");
					}
				}

				list.add(Byte.valueOf(b));
			}

			resultat = new byte[list.size()];

			for (int i = 0; i < list.size(); i++) {
				resultat[i] = list.get(i);
			}
		}

		return resultat;
	}

	/** Valeurs des multiples de conversion en format IP4 **/
	final public static long[] IP4_MULTIPLES = new long[] { 16777216L, 65536L, 256L, 1L };

	/**
	 * Extrait une adresse ip en format IP4
	 * @param value La valeur de l'adresse ip à extraire
	 * @return une adresse ip en format IP4
	 */
	final public static int[] toIP4(Long value) {
		if (value == null) {
			return null;
		}

		int[] ip4 = new int[IP4_MULTIPLES.length];

		for (int i = 0; i < IP4_MULTIPLES.length; i++) {
			ip4[i] = (int) (value / IP4_MULTIPLES[i]) % 256;
		}

		return ip4;
	}

	/**
	 * Extrait un IP4 en format adresse ip
	 * @param ip4 La valeur IP4 à extraire
	 * @return un IP4 en format adresse ip
	 */
	@AutomatedTests("128,0,0,1")
	final public static Long fromIP4(int[] ip4) {
		if (ip4 == null) {
			return null;
		} else if (ip4.length != IP4_MULTIPLES.length) {
			return null;
		}

		Long value = 0L;

		for (int i = 0; i < ip4.length; i++) {
			value += ip4[i] * IP4_MULTIPLES[i];
		}

		return value;
	}

	/**
	 * Expansion d'une version de format mois.année (ex: 0121 => 01.21)
	 * @param value La valeur à étendre
	 * @return la version de format mois.année
	 */
	final public static String expandMonthYearVersion(long value) {
		return padString((value / 100) % 100, '0', 2) + "." + padString(value % 100, '0', 2);
	}

	/**
	 * Expansion d'une version de format mois.année (ex: 0121 => 01.21)
	 * @param value La valeur à étendre
	 * @return la version de format mois.année
	 */
	final public static String expandMonthYearVersion(int value) {
		return padString((value / 100) % 100, '0', 2) + "." + padString(value % 100, '0', 2);
	}

	/**
	 * Expansion d'une version avec des points (ex: 1104, 2 => 11.0.4)
	 * @param value La valeur à étendre
	 * @param dots Le nombre de points
	 * @return la version
	 */
	final public static String expandVersion(long value, int dots) {
		return expandVersion(Long.valueOf(value).toString(), dots);
	}

	/**
	 * Expansion d'une version avec des points (ex: 1104, 2 => 11.0.4)
	 * @param value La valeur à étendre
	 * @param dots Le nombre de points
	 * @return la version
	 */
	final public static String expandVersion(int value, int dots) {
		return expandVersion(Integer.valueOf(value).toString(), dots);
	}

	/**
	 * Expansion d'une version avec des points (ex: 1104, 2 => 11.0.4)
	 * @param value La valeur à étendre
	 * @param dots Le nombre de points
	 * @return la version
	 */
	@AutomatedTests({ "1104", "2" })
	final public static String expandVersion(String value, int dots) {
		if (isEmpty(value)) {
			return value;
		}

		String result = "";

		char[] charsData = padString(value.trim(), '0', dots + 1).toCharArray();

		for (int i = charsData.length - 1; i >= 0; i--) {
			char c = charsData[i];

			result = c + result;

			if (dots > 0) {
				result = "." + result;
				dots--;
			}
		}

		return result;
	}

	/**
	 * Combine le prénom et nom selon les paramètres passés
	 * @param prenom Le prénom de l'usager
	 * @param nom Le nom de l'usager
	 * @return la combinaison
	 */
	final public static String getPrenomNom(String prenom, String nom) {
		String resultat = "";

		if (!isEmpty(prenom) && !isEmpty(nom)) {
			resultat = prenom + " " + nom;
		} else if (!isEmpty(prenom)) {
			resultat = prenom;
		} else if (!isEmpty(nom)) {
			resultat = nom;
		}

		return resultat;
	}

	/**
	 * Combine le prénom et nom selon les paramètres passés
	 * @param prenom Le prénom de l'usager
	 * @param nom Le nom de l'usager
	 * @param cod_usag Le code de l'usager
	 * @return la combinaison
	 */
	final public static String getPrenomNom(String prenom, String nom, String cod_usag) {
		String resultat = getPrenomNom(prenom, nom);

		if (!isEmpty(cod_usag)) {
			if (isEmpty(resultat)) {
				resultat = cod_usag;
			} else {
				resultat += " (" + cod_usag + ")";
			}
		}

		return resultat;
	}

	/**
	 * Composition d'un identifiant et de son nom sous forme: [id] name
	 * @param id Identifiant
	 * @param name Nom
	 * @return un String
	 */
	final public static String buildIDName(int id, String name) {
		return buildIDName(Integer.valueOf(id), name);
	}

	/**
	 * Composition d'un identifiant et de son nom sous forme: [id] name
	 * @param id Identifiant
	 * @param name Nom
	 * @return un String
	 */
	final public static String buildIDName(Integer id, String name) {
		return buildIDName((id == null) ? null : id.toString(), name);
	}

	/**
	 * Composition d'un identifiant et de son nom sous forme: [id] name
	 * @param id Identifiant
	 * @param name Nom
	 * @return un String
	 */
	final public static String buildIDName(String id, String name) {
		StringBuffer sb = new StringBuffer();

		if (!isEmpty(id)) {
			sb.append('[');
			sb.append(id);
			sb.append(']');
		}

		if (!isEmpty(name)) {
			if (sb.length() > 0) {
				sb.append(' ');
			}

			sb.append(name);
		}

		return sb.toString();
	}

	/**
	 * Effectue un nombre de copie d'une valeur donnée
	 * @param value La valeur initiale à recopier
	 * @param count Le nombre de copies à effectuer
	 * @return le texte de la copie
	 */
	@AutomatedTests({ "\"Test\"", "2" })
	final public static String duplicate(Object value, int count) {
		String source = asString(value);

		if (isEmpty(source)) {
			return source;
		}

		StringBuffer result = new StringBuffer();
		result.append(source);

		while (count > 0) {
			result.append(source);
			count--;
		}

		return result.toString();
	}

	/**
	 * Extrait la longueur (i.e. nombre de caratères) requise pour afficher une valeur donnée
	 * @param value La valeur à évaluer (ex: value = -5 -> length = 2)
	 * @return la longueur requise
	 */
	@AutomatedTests({ "105", "-5" })
	final public static int padLength(long value) {
		if (value == 0) {
			return 1;
		}

		int length = (value > 0) ? 0 : 1;

		while (value > 0) {
			length++;
			value /= 10;
		}

		return length;
	}

	/**
	 * Extrait la longueur (i.e. nombre de caratères) requise pour afficher une valeur donnée
	 * @param value La valeur à évaluer (ex: value = -5 -> length = 2)
	 * @return la longueur requise
	 */
	final public static int padLength(int value) {
		return padLength((long) value);
	}

	/**
	 * Agrandit le texte d'un objetjusqu'à la longueur spécifié en ajoutant le caractère spécifié au début du texte
	 * @param source L'objet à agrandir
	 * @param padChar Le caractère à utiliser pour au début du texte
	 * @param length La longueur total
	 * @return le texte à la longueur spécifiée
	 */
	final public static String padString(Object value, char padChar, int length) {
		String source = asString(value);

		StringBuffer result = new StringBuffer();

		int nb = length - source.length();

		while (nb > 0) {
			result.append(padChar);
			nb--;
		}

		result.append(source);

		return result.toString();
	}

	/**
	 * Agrandit le texte des objets jusqu'à la longueur spécifié de la plus longue en ajoutant le caractère spécifié au début des textes
	 * @param values Les objets à agrandir
	 * @param padChar Le caractère à utiliser pour au début des textes
	 * @return les textes à la longueur spécifiée
	 */
	final public static String[] padString(Object[] values, char padChar) {
		int length = 0;

		if (values != null) {
			String[] sources = new String[values.length];

			for (int i = 0; i < values.length; i++) {
				sources[i] = asString(values[i]);

				length = Math.max(length, sources[i].length());
			}

			for (int i = 0; i < values.length; i++) {
				sources[i] = padString(sources[i], padChar, length);
			}

			return sources;
		}

		return null;
	}

	/**
	 * Agrandit le texte des objets jusqu'à la longueur spécifié de la plus longue en ajoutant le caractère spécifié au début des textes
	 * @param sourcesListe Les objets à agrandir
	 * @param padChar Le caractère à utiliser pour au début des textes
	 * @return les textes à la longueur spécifiée
	 */
	final public static String[] padString(List<?> sourcesListe, char padChar) {
		if (sourcesListe == null) {
			return null;
		}

		return padString(sourcesListe.toArray(), padChar);
	}

	/**
	 * Agrandit le texte d'un objetjusqu'à la longueur spécifiée en ajoutant le caractère spécifié à la fin du texte
	 * @param value L'objet à agrandir
	 * @param padChar Le caractère à utiliser pour à la fin du texte
	 * @param length La longueur total
	 * @return le texte à la longueur spécifiée
	 */
	final public static String padEndString(Object value, char padChar, int length) {
		String source = asString(value);

		StringBuffer result = new StringBuffer();
		result.append(source);

		int nb = length - source.length();

		while (nb > 0) {
			result.append(padChar);
			nb--;
		}

		return result.toString();
	}

	/**
	 * Agrandit le texte des objets jusqu'à la longueur spécifié de la plus longue en ajoutant le caractère spécifié à la fin des textes
	 * @param values Les objets à agrandir
	 * @param padChar Le caractère à utiliser pour à la fin des textes
	 * @return les textes à la longueur spécifiée
	 */
	final public static String[] padEndString(Object[] values, char padChar) {
		int length = 0;

		if (values != null) {
			String[] sources = new String[values.length];

			for (int i = 0; i < values.length; i++) {
				sources[i] = asString(values[i]);

				length = Math.max(length, sources[i].length());
			}

			for (int i = 0; i < values.length; i++) {
				sources[i] = padEndString(sources[i], padChar, length);
			}

			return sources;
		}

		return null;
	}

	/**
	 * Agrandit le texte des objets jusqu'à la longueur spécifié de la plus longue en ajoutant le caractère spécifié à la fin des textes
	 * @param sourcesListe Les objets à agrandir
	 * @param padChar Le caractère à utiliser pour à la fin des textes
	 * @return les textes à la longueur spécifiée
	 */
	final public static String[] padEndString(List<?> sourcesListe, char padChar) {
		if (sourcesListe == null) {
			return null;
		}

		return padEndString(sourcesListe.toArray(), padChar);
	}

	/**
	 * Embrouille un texte
	 * @param texte Le texte à embrouiller
	 * @return le texte embrouillé
	 */
	final public static String embrouille(String texte) {
		StringBuffer resultat = new StringBuffer();

		if (!isEmpty(texte)) {
			char[] charsData = texte.toCharArray();

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];

				char hb = (char) (((c & 0xF0) >> 4) + 'C');
				char lb = (char) ('q' - (c & 0x0F));

				resultat.append(hb);
				resultat.append(lb);
			}
		}

		return resultat.toString();
	}

	/**
	 * Débrouille un texte embrouillé
	 * @param texte Le texte à débrouiller
	 * @return le texte débrouillé
	 */
	@StrictAutomatedTests(value = { "null", "outils.base.OutilsBase.embrouille(\"Automated Test Value\")" }, process = false)
	final public static String debrouille(String texte) {
		StringBuffer resultat = new StringBuffer();

		if (!isEmpty(texte)) {
			char[] charsData = texte.toCharArray();

			for (int i = 0; i < (charsData.length / 2); i++) {
				char hb = charsData[2 * i];
				char lb = charsData[(2 * i) + 1];
				char b = (char) (((hb - 'C') << 4) + (('q' - lb) & 0x0F));

				resultat.append(b);
			}
		}

		return resultat.toString();
	}

	/**
	 * Optimise les dimensions d'un tableau pour un nombre d'éléments donné
	 * @param count Le nombre d'éléments donné
	 * @param horizontal Indicateur d'optimisation horizontale (true) ou verticale (false). ex: Pour count = 6, true -> {2,3} false -> {3,2}
	 * @param square Indicateur d'optimisation carré (true) ou rectangulaire (false). ex: Pour count = 33, true -> {6,6} false -> {3,11} ou {11,3} (voir paramètre horizontal)
	 * @returnun un int[2] des dimensions {rangées, colonnes} (null si pas de dimensions)
	 */
	@AutomatedTests(value = { "1,2,3,4,6,33,36", "false,true", "false,true" }, iterate = true)
	final public static int[] optimizeArraySizes(int count, boolean horizontal, boolean square) {
		if (count < 1) {
			return null;
		} else if (count == 1) {
			return new int[] { 1, 1 };
		} else if (count == 2) {
			return horizontal ? new int[] { 1, 2 } : new int[] { 2, 1 };
		} else if (count == 3) {
			return square ? new int[] { 2, 2 } : horizontal ? new int[] { 1, 3 } : new int[] { 3, 1 };
		} else if (count == 4) {
			return new int[] { 2, 2 };
		}

		int[] result = new int[2];

		int end = count;
		int bestRows = 0;
		int bestCols = 0;
		int bestDelta = Integer.MAX_VALUE;
		int bestDeltaRatio = Integer.MAX_VALUE;

		for (int rows = 2; rows < end; rows++) {
			int cols = count / rows;
			int mod = count % rows;

			int delta = 0;

			if (mod != 0) {
				delta = rows - mod;
				cols++;
			}

			int deltaRatio = (rows >= cols) ? rows - cols : cols - rows;

			if (((delta <= bestDelta) || square) && (deltaRatio <= bestDeltaRatio)) {
				bestRows = rows;
				bestCols = cols;
				bestDelta = delta;
				bestDeltaRatio = deltaRatio;

				if ((bestDelta == 0) && (bestDeltaRatio == 0)) {
					break;
				}
			}

			if (cols < end) {
				end = cols;
			}
		}

		result[horizontal ? 0 : 1] = bestRows;
		result[horizontal ? 1 : 0] = bestCols;

		return result;
	}

	/**
	 * Supprime les guillements de début et de fin d'une valeur
	 * @param value La valeur à traiter
	 * @return la valeur sans les guillements de début et de fin
	 */
	@AutomatedTests("\"Test\"")
	final public static String unquotes(String value) {
		if (isEmpty(value)) {
			return value;
		}

		if (value.startsWith("\"")) {
			value = value.substring(1);
		}

		if (value.endsWith("\"")) {
			value = value.substring(0, value.length() - 1);
		}

		return value;
	}

	/**
	 * Supprime les guillements de début et de fin d'un tableau de valeurs
	 * @param values Le tableau de valeurs à traiter
	 * @return le tableau de valeurs sans les guillements de début et de fin
	 */
	final public static String[] unquotes(String[] values) {
		if (isEmpty(values)) {
			return values;
		}

		String[] result = new String[values.length];

		for (int i = 0; i < values.length; i++) {
			result[i] = unquotes(values[i]);
		}

		return result;
	}

	/**
	 * Harmonisation du texte afin d'éviter d'avoir 2 lettres en majuscules qui se suivent. ex: MAJAlloToto -> MajAlloToto
	 * @param value La valeur à harmoniser
	 * @return la valeur harmonisée
	 */
	@AutomatedTests({ "MAJAlloToto", "MAJ\\Allo/Toto" })
	final public static String doHarmonization(String value) {
		if (!isEmpty(value)) {
			char[] charsData = value.toCharArray();

			int count = 0;

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];

				if (Character.isLetterOrDigit(c)) {
					if (Character.isUpperCase(c)) {
						if (count != 0) {
							charsData[i] = Character.toLowerCase(c);
						}

						count++;
					} else {
						if (count > 1) {
							charsData[i - 1] = Character.toUpperCase(charsData[i - 1]);
						}

						count = 0;
					}
				} else if ((c == '\\') || (c == '/')) {
					count = 0;
				}
			}

			return new String(charsData);
		}

		return value;
	}

	/**
	 * Effectue la capitalisation du texte (i.e. mettre la première lettre du début de la phrase en majuscule)
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests("a")
	final public static String doCapitalize(String value) {
		if (!isEmpty(value)) {
			if (value.length() == 1) {
				return value.toUpperCase();
			}

			return value.substring(0, 1).toUpperCase() + value.substring(1);
		}

		return value;
	}

	/**
	 * Effectue la décapitalisation du texte (i.e. mettre la première lettre du début de la phrase en minuscule)
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests("A")
	final public static String doUncapitalize(String value) {
		if (!isEmpty(value)) {
			if (value.length() == 1) {
				return value.toLowerCase();
			}

			return value.substring(0, 1).toLowerCase() + value.substring(1);
		}

		return value;
	}

	/**
	 * Effectue la conversion en "CamelCase" (ou "CamelBack") ex: allo_toto -> AlloToto
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	final public static String doCamelCase(String value) {
		return doCamelCase(true, value);
	}

	/**
	 * Effectue la conversion en "CamelCase" (ou "CamelBack") ex: allo_toto -> AlloToto (si uppercase == true)
	 * @param uppercase Indique si la première lettre doit être en majuscule
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests(value = { "false,true", "allo_toto" }, iterate = true)
	final public static String doCamelCase(boolean uppercase, String value) {
		StringBuffer sb = new StringBuffer();

		if (!isEmpty(value)) {
			char[] charsData = value.toCharArray();

			boolean hasSeparator = false;

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];

				if (!Character.isLetterOrDigit(c)) {
					uppercase = true;
					hasSeparator = true;
				} else if ((i == 0) || hasSeparator) {
					sb.append(uppercase ? Character.toUpperCase(c) : Character.toLowerCase(c));
					uppercase = false;
					hasSeparator = false;
				} else {
					sb.append(c);
				}
			}
		}

		return sb.toString();
	}

	/**
	 * Effectue la conversion en nom de package JAVA ex: AlloToto - > allo.toto
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	final public static String doPackageName(String value) {
		return doPackageName(true, value);
	}

	/**
	 * Effectue la conversion en nom de package JAVA ex: AlloToto - > allo.toto (si lowercase == true)
	 * @param lowercase Indique si le nom du package doit être en minuscule
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests(value = { "false,true", "AlloToto,Allo\\Toto/Tata" }, iterate = true)
	final public static String doPackageName(boolean lowercase, String value) {
		StringBuffer sb = new StringBuffer();

		if (!isEmpty(value)) {
			char[] charsData = doHarmonization(value).toCharArray();

			int count = 0;

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];

				if (Character.isLetterOrDigit(c)) {
					if (count != 0) {
						if (Character.isUpperCase(c)) {
							sb.append('.');
						}
					}

					sb.append(c);

					count++;
				} else if ((c == '\\') || (c == '/')) {
					sb.append('.');
					count = 0;
				}
			}
		}

		return lowercase ? sb.toString().toLowerCase() : sb.toString();
	}

	/**
	 * Effectue la conversion en nom de constance JAVA ex: AlloToto - > ALLO_TOTO
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	final public static String doConstantName(String value) {
		return doConstantName(true, value);
	}

	/**
	 * Effectue la conversion en nom de constance JAVA ex: AlloToto - > ALLO_TOTO (si uppercase == true)
	 * @param uppercase Indique si le nom de la constante doit être en majuscule
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests(value = { "false,true", "AlloToto,Allo\\Toto/Tata_Toto-Allo A\nB\rC\tD" }, iterate = true)
	final public static String doConstantName(boolean uppercase, String value) {
		StringBuffer sb = new StringBuffer();

		if (!isEmpty(value)) {
			char[] charsData = doHarmonization(toEnglish(value)).toCharArray();

			int count = 0;
			boolean space = false;

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];

				if (Character.isLetterOrDigit(c)) {
					if (count != 0) {
						if (Character.isUpperCase(c) || space) {
							sb.append('_');
							space = false;
						}
					}

					sb.append(c);

					count++;
				} else if ((c == '\\') || (c == '/') || (c == '_') || (c == '-')) {
					sb.append('_');
					count = 0;
				} else if ((c == ' ') || (c == '\n') || (c == '\r') || (c == '\t')) {
					space = true;
				}
			}
		}

		return uppercase ? sb.toString().toUpperCase() : sb.toString().toLowerCase();
	}

	/**
	 * Conversion d'une adresse de courriel en nom de la personne (tentative de conversion...) claude.toupin@desjardins.com => Claude Toupin
	 * @param email Adresse de courriel
	 * @return le nom de la personne
	 */
	@AutomatedTests("claude.toupin@desjardins.com")
	final public static String getEmailPersonalName(String email) {
		if (!isEmpty(email)) {
			StringBuffer sb = new StringBuffer();

			char[] charsData = email.toCharArray();

			boolean upper = true;

			for (int i = 0; i < charsData.length; i++) {
				char c = charsData[i];

				if (c == '@') {
					break;
				} else if (c == '.') {
					upper = true;
					sb.append(' ');
				} else {
					sb.append(upper ? Character.toUpperCase(c) : Character.toLowerCase(c));
					upper = false;
				}
			}

			return sb.toString();
		} else {
			return email;
		}
	}

	/**
	 * Découpe en liste des mots et séparateurs d'un texte donné
	 * @param value Le texte à découper
	 * @return La liste des mots et séparateurs découpés
	 */
	final public static List<WordSeparatorData> asWordsSeparatorsList(String value) {
		return asWordsSeparatorsList(value, false);
	}

	/**
	 * Découpe en liste des mots et séparateurs d'un texte donné
	 * @param value Le texte à découper
	 * @param capitalize Indicateur de capitalisation des mots
	 * @return La liste des mots et séparateurs découpés
	 */
	@AutomatedTests(value = { "La10 10La Test", "false,true" }, iterate = true)
	final public static List<WordSeparatorData> asWordsSeparatorsList(String value, boolean capitalize) {
		List<WordSeparatorData> list = new ArrayList<WordSeparatorData>();

		if (!isEmpty(value)) {
			char[] charsData = value.toCharArray();

			int pos = 0;

			boolean first = true;
			boolean isLetter = false;

			for (int i = 0; i < charsData.length; i++) {
				if (!Character.isLetterOrDigit(charsData[i])) {
					if ((i - pos) > 0) {
						String text = value.substring(pos, i);

						if (capitalize) {
							text = doCapitalize(text.toLowerCase());
						}

						list.add(new WordSeparatorData(text));
					}

					pos = i + 1;

					first = true;

					list.add(new WordSeparatorData(WordSeparatorsTypes.getWordSeparatorsTypes(charsData[i])));
				} else {
					if (first) {
						isLetter = Character.isLetter(charsData[i]);
						first = false;
					} else {
						if (isLetter && Character.isDigit(charsData[i])) {
							// Mot
							if ((i - pos) > 0) {
								String text = value.substring(pos, i);

								if (capitalize) {
									text = doCapitalize(text.toLowerCase());
								}

								list.add(new WordSeparatorData(text));

								pos = i;

								isLetter = false;
							}
						} else if (!isLetter && Character.isLetter(charsData[i])) {
							// Nombre
							if ((i - pos) > 0) {
								String text = value.substring(pos, i);

								list.add(new WordSeparatorData(text));

								pos = i;

								isLetter = true;
							}
						}
					}
				}
			}

			if ((charsData.length - pos) > 0) {
				String text = value.substring(pos);

				if (capitalize) {
					text = doCapitalize(text.toLowerCase());
				}

				list.add(new WordSeparatorData(text));
			}

		}

		return list;
	}

	/**
	 * Retourne la liste des mots et séparateurs sous forme de texte
	 * @param list Liste des mots et séparateurs découpés
	 * @return la liste sous forme d'un texte
	 */
	final public static String toWordsSeparatorsList(List<WordSeparatorData> list) {
		if (list == null) {
			return null;
		}

		StringBuffer sb = new StringBuffer();

		for (WordSeparatorData item : list) {
			if (item.getType().isWord()) {
				sb.append(item.getText());
			} else {
				sb.append(item.getType().getSeparator());
			}
		}

		return sb.toString().trim();
	}

	/**
	 * Calcul du temps d'exécution restant
	 * @param count Le nombre
	 * @param total Le total
	 * @param start Le début de l'exécution
	 * @return le temps d'exécution restant
	 */
	final public static long timeLeft(int count, int total, Date start) {
		return timeLeft((long) count, (long) total, start);
	}

	/**
	 * Calcul du temps d'exécution restant
	 * @param count Le nombre
	 * @param total Le total
	 * @param start Le début de l'exécution
	 * @return le temps d'exécution restant
	 */
	final public static long timeLeft(long count, long total, Date start) {
		if (start == null) {
			return 0;
		}

		return timeLeft(count, total, start.getTime());
	}

	/**
	 * Calcul du temps d'exécution restant
	 * @param count Le nombre
	 * @param total Le total
	 * @param start Le début de l'exécution
	 * @return le temps d'exécution restant
	 */
	final public static long timeLeft(int count, int total, long start) {
		return timeLeft((long) count, (long) total, start);
	}

	/**
	 * Calcul du temps d'exécution restant
	 * @param count Le nombre
	 * @param total Le total
	 * @param start Le début de l'exécution
	 * @return le temps d'exécution restant
	 */
	@CoverageOnly
	@AutomatedTests({ "10", "5", "System.currentTimeMillis()" })
	final public static long timeLeft(long count, long total, long start) {
		if (count == 0) {
			return 0;
		}

		long now = System.currentTimeMillis();

		long duration = now - start;

		return ((duration * total) / count) - duration;
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @return un String
	 */
	@CoverageOnly
	@AutomatedTests("new java.util.Date()")
	final public static String topChrono(Date start) {
		if (start == null) {
			return "";
		}

		return topChrono(start.getTime());
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests(value = { "null,new java.util.Date()", "day", "hour", "minute", "second", "milli" }, iterate = true)
	final public static String topChrono(Date start, String days, String hours, String minutes, String seconds, String milli) {
		if (start == null) {
			return "";
		}

		return topChrono(start.getTime(), days, hours, minutes, seconds, milli);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @param plurial Indicateur de pluriel
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests(value = { "null,new java.util.Date()", "day", "hour", "minute", "second", "milli", "false,true" }, iterate = true)
	final public static String topChrono(Date start, String days, String hours, String minutes, String seconds, String milli, boolean plurial) {
		if (start == null) {
			return "";
		}

		return topChrono(start.getTime(), days, hours, minutes, seconds, milli, plurial);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @param plurial Indicateur de pluriel
	 * @param complete Indicateur de temps complet incluant les unités à zéro (ex: 1 heure 0 minutes 0 seconde 0 milliseconde)
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests(value = { "null, new java.util.Date()", "day", "hour", "minute", "second", "milli", "false,true", "false,true" }, iterate = true)
	final public static String topChrono(Date start, String days, String hours, String minutes, String seconds, String milli, boolean plurial, boolean complete) {
		if (start == null) {
			return "";
		}

		return topChrono(start.getTime(), days, hours, minutes, seconds, milli, plurial, complete);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests("System.currentTimeMillis()")
	final public static String topChrono(long start) {
		return duration(System.currentTimeMillis() - start);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @param complete Indicateur de temps complet incluant les unités à zéro (ex: 1 heure 0 minutes 0 seconde 0 milliseconde)
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests(value = { "System.currentTimeMillis()", "false,true" }, iterate = true)
	final public static String topChrono(long start, boolean complete) {
		return duration(System.currentTimeMillis() - start, complete);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests({ "System.currentTimeMillis()", "day", "hour", "minute", "second", "milli" })
	final public static String topChrono(long start, String days, String hours, String minutes, String seconds, String milli) {
		return duration(System.currentTimeMillis() - start, days, hours, minutes, seconds, milli);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @param plurial Indicateur de pluriel
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests(value = { "System.currentTimeMillis()", "day", "hour", "minute", "second", "milli", "false,true" }, iterate = true)
	final public static String topChrono(long start, String days, String hours, String minutes, String seconds, String milli, boolean plurial) {
		return duration(System.currentTimeMillis() - start, days, hours, minutes, seconds, milli, plurial);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param start Le début de l'exécution
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @param plurial Indicateur de pluriel
	 * @param complete Indicateur de temps complet incluant les unités à zéro (ex: 1 heure 0 minutes 0 seconde 0 milliseconde)
	 * @return un String
	 */
	@CoverageOnly
	@StrictAutomatedTests(value = { "System.currentTimeMillis()", "day", "hour", "minute", "second", "milli", "false,true", "false,true" }, iterate = true)
	final public static String topChrono(long start, String days, String hours, String minutes, String seconds, String milli, boolean plurial, boolean complete) {
		return duration(System.currentTimeMillis() - start, days, hours, minutes, seconds, milli, plurial, complete);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param runtime Le temps d'exécution en millisecondes
	 * @return un String
	 */
	final public static String duration(long runtime) {
		return duration(runtime, false);
	}

	/**
	 * Extrait le temps d'exécution sous forme jj hh:mm:ss.ms
	 * @param runtime Le temps d'exécution en millisecondes
	 * @param complete Indicateur de temps complet incluant les unités à zéro (ex: 1 heure 0 minutes 0 seconde 0 milliseconde)
	 * @return un String
	 */
	final public static String duration(long runtime, boolean complete) {
		return duration(runtime, " ", ":", ":", ".", "", false, complete);
	}

	/**
	 * Extrait le temps d'exécution
	 * @param runtime Le temps d'exécution en millisecondes
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @return un String
	 */
	final public static String duration(long runtime, String days, String hours, String minutes, String seconds, String milli) {
		return duration(runtime, days, hours, minutes, seconds, milli, false);
	}

	/**
	 * Extrait le temps d'exécution
	 * @param runtime Le temps d'exécution en millisecondes
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @param plurial Indicateur de pluriel
	 * @return un String
	 */
	final public static String duration(long runtime, String days, String hours, String minutes, String seconds, String milli, boolean plurial) {
		return duration(runtime, days, hours, minutes, seconds, milli, plurial, false);
	}

	/**
	 * Extrait le temps d'exécution
	 * @param runtime Le temps d'exécution en millisecondes
	 * @param days Séparateur du jours (null -> en heures seulement)
	 * @param hours Séparateur des heures (null -> ne pas afficher)
	 * @param minutes Séparateur des minutes (null -> ne pas afficher)
	 * @param seconds Séparateur des secondes (null -> ne pas afficher)
	 * @param milli Séparateur des millisecondes (null -> ne pas afficher)
	 * @param plurial Indicateur de pluriel
	 * @param complete Indicateur de temps complet incluant les unités à zéro (ex: 1 heure 0 minutes 0 seconde 0 milliseconde)
	 * @return un String
	 */
	@AutomatedTests(value = { "-1,0,99,720000,36000000,86400001,180122100", "day", "hour", "minute", "second", "milli", "false,true", "false,true" }, iterate = true)
	final public static String duration(long runtime, String days, String hours, String minutes, String seconds, String milli, boolean plurial, boolean complete) {
		if (runtime < 0) {
			runtime = -1 * runtime;
		}

		// jours (24 * 60 * 60 * 1000 -> 86400000)
		long daysValue = runtime / 86400000;
		runtime %= 86400000;

		// heures (60 * 60 * 1000 -> 3600000)
		long hoursValue = runtime / 3600000;
		runtime %= 3600000;

		// minutes (60 * 1000 -> 60000)
		long minutesValue = runtime / 60000;
		runtime %= 60000;

		// secondes (1000)
		long secondsValue = runtime / 1000;
		runtime %= 1000;

		// millisecondes
		long milliValue = runtime;
		runtime = 0; // Pour la forme...

		boolean sequence = false;

		StringBuffer sb = new StringBuffer();

		// jours
		if ((days != null) && ((daysValue > 0) || complete)) {
			sequence = true;

			sb.append(daysValue);

			if (plurial) {
				sb.append(' ');
				sb.append(days);
				sb.append((daysValue > 1) ? "s " : " ");
			} else {
				sb.append(days);
			}
		}

		// heures
		if ((hours != null) && ((hoursValue > 0) || complete)) {
			if (sequence && !plurial) {
				if (hoursValue < 10) {
					sb.append('0');
				}
			}

			sequence = true;

			sb.append(hoursValue);

			if (plurial) {
				sb.append(' ');
				sb.append(hours);
				sb.append((hoursValue > 1) ? "s " : " ");
			} else {
				sb.append(hours);
			}
		}

		// minutes
		if ((minutes != null) && ((minutesValue > 0) || complete)) {
			if (sequence && !plurial) {
				if (minutesValue < 10) {
					sb.append('0');
				}
			}

			sequence = true;

			sb.append(minutesValue);

			if (plurial) {
				sb.append(' ');
				sb.append(minutes);
				sb.append((minutesValue > 1) ? "s " : " ");
			} else {
				sb.append(minutes);
			}
		}

		// secondes
		if ((seconds != null) && ((secondsValue > 0) || complete)) {
			if (sequence && !plurial) {
				if (secondsValue < 10) {
					sb.append('0');
				}
			}

			sequence = true;

			sb.append(secondsValue);

			if (plurial) {
				sb.append(' ');
				sb.append(seconds);
				sb.append((secondsValue > 1) ? "s " : " ");
			} else {
				sb.append(seconds);
			}
		}

		// millisecondes
		if ((milli != null) && ((milliValue > 0) || complete)) {
			if (sequence && !plurial) {
				if (milliValue < 10) {
					sb.append("00");
				} else if (milliValue < 100) {
					sb.append('0');
				}
			}

			sequence = true;

			sb.append(milliValue);

			if (plurial) {
				sb.append(' ');
				sb.append(milli);
				sb.append((milliValue > 1) ? "s " : " ");
			} else {
				sb.append(milli);
			}
		}

		return sb.toString().trim();
	}

	/**
	 * Conversion d'une adresse IP en nombre simple (ex: "202.186.13.4" => "3401190660")
	 * @param ipstring l'adresse IP à convertir
	 * @return un long
	 */
	@AutomatedTests("202.186.13.4")
	final public static long getDot2LongIP(String ipstring) {
		String[] ipAddressInArray = ipstring.split("\\.");

		long result = 0;
		long ip = 0;

		for (int x = 3; x >= 0; x--) {
			ip = Long.parseLong(ipAddressInArray[3 - x]);
			result |= ip << (x << 3);
		}

		return result;
	}

	/**
	 * Détermine si la valeur est pair ou non
	 * @param value La valeur à déterminer
	 * @return vrai si pair
	 */
	@AutomatedTests({ "1", "2" })
	final public static boolean isEven(int value) {
		return (value % 2) == 0;
	}

	/**
	 * Détermine si une liste de valeurs est pair ou non
	 * @param values La liste de valeurs à déterminer
	 * @return vrai si pair
	 */
	@AutomatedTests({ "1,2", "1", "2" })
	final public static boolean isEven(int... values) {
		if (values != null) {
			for (int value : values) {
				if (!isEven(value)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Détermine si la valeur est impair ou non
	 * @param value La valeur à déterminer
	 * @return vrai si impair
	 */
	@AutomatedTests({ "1", "2" })
	final public static boolean isOdd(int value) {
		return (value % 2) != 0;
	}

	/**
	 * Détermine si une liste de valeurs est impair ou non
	 * @param values La liste de valeurs à déterminer
	 * @return vrai si impair
	 */
	@AutomatedTests({ "1,2", "1", "2" })
	final public static boolean isOdd(int... values) {
		if (values != null) {
			for (int value : values) {
				if (!isOdd(value)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Retourne la valeur minimale d'une liste de valeurs
	 * @param values Liste de valeurs
	 * @return un int (Integer.MAX_VALUE par défaut)
	 */
	@AutomatedTests({ "1,2", "2,1" })
	final public static int min(int... values) {
		int result = Integer.MAX_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (int value : values) {
					result = (value < result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur minimale d'une liste de valeurs
	 * @param values Liste de valeurs
	 * @return un long (Long.MAX_VALUE par défaut)
	 */
	@AutomatedTests({ "1L,2L", "2L,1L" })
	final public static long min(long... values) {
		long result = Long.MAX_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (long value : values) {
					result = (value < result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur minimale d'une liste de valeurs
	 * @param values Liste de valeurs
	 * @return un float (Float.MAX_VALUE par défaut)
	 */
	@AutomatedTests({ "1.0f,2.0f", "2.0f,1.0f" })
	final public static float min(float... values) {
		float result = Float.MAX_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (float value : values) {
					result = (value < result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur minimale d'une liste de valeurs
	 * @param values Liste de valeurs
	 * @return un double (Double.MAX_VALUE par défaut)
	 */
	@AutomatedTests({ "1.0,2.0", "2.0,1.0" })
	final public static double min(double... values) {
		double result = Double.MAX_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (double value : values) {
					result = (value < result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur maximale d'une liste de valeurs
	 * @param values Liste de valeurs
	 * @return un int (Integer.MIN_VALUE par défaut)
	 */
	@AutomatedTests({ "1,2", "2,1" })
	final public static int max(int... values) {
		int result = Integer.MIN_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (int value : values) {
					result = (value > result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur maximale d'une liste de valeurs
	 * @param values Liste de valeurs
	 * @return un long (Long.MIN_VALUE par défaut)
	 */
	@AutomatedTests({ "1L,2L", "2L,1L" })
	final public static long max(long... values) {
		long result = Long.MIN_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (long value : values) {
					result = (value > result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur maximale d'une liste de valeurs
	 * @param values Liste de valeurs
	 * @return un float (Float.MIN_VALUE par défaut)
	 */
	@AutomatedTests({ "1f,2f", "2f,1f" })
	final public static float max(float... values) {
		float result = Float.MIN_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (float value : values) {
					result = (value > result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur maximale d'une liste d'entiers
	 * @param values Liste de valeurs
	 * @return un double (Double.MIN_VALUE par défaut)
	 */
	@AutomatedTests({ "1.0,2.0", "2.0,1.0" })
	final public static double max(double... values) {
		double result = Double.MIN_VALUE;

		if (!OutilsBase.isEmpty(values)) {
			result = values[0];

			if (values.length > 1) {
				for (double value : values) {
					result = (value > result) ? value : result;
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la valeur limite pour un interval donné
	 * @param min Valeur minimale
	 * @param value Valeur à tester
	 * @param max Valeur maximale
	 * @return la valeur selon l'interval
	 */
	@AutomatedTests({ "1", "2", "3" })
	@AutomatedTests({ "1", "0", "3" })
	@AutomatedTests({ "1", "4", "3" })
	final public static int range(int min, int value, int max) {
		if (value < min) {
			return min;
		} else if (value > max) {
			return max;
		}

		return value;
	}

	/**
	 * Retourne la valeur limite pour un interval donné
	 * @param min Valeur minimale
	 * @param value Valeur à tester
	 * @param max Valeur maximale
	 * @return la valeur selon l'interval
	 */
	@AutomatedTests({ "1L", "2L", "3L" })
	@AutomatedTests({ "1L", "0L", "3L" })
	@AutomatedTests({ "1L", "4L", "3L" })
	final public static long range(long min, long value, long max) {
		if (value < min) {
			return min;
		} else if (value > max) {
			return max;
		}

		return value;
	}

	/**
	 * Retourne la valeur limite pour un interval donné
	 * @param min Valeur minimale
	 * @param value Valeur à tester
	 * @param max Valeur maximale
	 * @return la valeur selon l'interval
	 */
	@AutomatedTests({ "1.0f", "2.0f", "3.0f" })
	@AutomatedTests({ "1.0f", "0.0f", "3.0f" })
	@AutomatedTests({ "1.0f", "4.0f", "3.0f" })
	final public static float range(float min, float value, float max) {
		if (value < min) {
			return min;
		} else if (value > max) {
			return max;
		}

		return value;
	}

	/**
	 * Retourne la valeur limite pour un interval donné
	 * @param min Valeur minimale
	 * @param value Valeur à tester
	 * @param max Valeur maximale
	 * @return la valeur selon l'interval
	 */
	@AutomatedTests({ "1.0", "2.0", "3.0" })
	@AutomatedTests({ "1.0", "0.0", "3.0" })
	@AutomatedTests({ "1.0", "4.0", "3.0" })
	final public static double range(double min, double value, double max) {
		if (value < min) {
			return min;
		} else if (value > max) {
			return max;
		}

		return value;
	}

	/**
	 * Retourne la valeur absolue (positive) d'une valeur donnée
	 * @param value La valeur donné
	 * @return un int
	 */
	@AutomatedTests({ "-1", "1" })
	final public static int abs(int value) {
		return (value < 0) ? -value : value;
	}

	/**
	 * Retourne la valeur absolue (positive) d'une valeur donnée
	 * @param value La valeur donné
	 * @return un long
	 */
	@AutomatedTests({ "-1L", "1L" })
	final public static long abs(long value) {
		return (value < 0L) ? -value : value;
	}

	/**
	 * Retourne la valeur absolue (positive) d'une valeur donnée
	 * @param value La valeur donné
	 * @return un int
	 */
	@AutomatedTests({ "-1f", "1f" })
	final public static float abs(float value) {
		return (value < 0f) ? -value : value;
	}

	/**
	 * Retourne la valeur absolue (positive) d'une valeur donnée
	 * @param value La valeur donné
	 * @return un long
	 */
	@AutomatedTests({ "-1d", "1d" })
	final public static double abs(double value) {
		return (value < 0d) ? -value : value;
	}

	/**
	 * Effectue un "et logique" d'une liste de booléens
	 * @param values La liste de booléens
	 * @return un booléen
	 */
	@AutomatedTests({ "false,false", "false,true", "true, false", "true,true" })
	final public static boolean and(boolean... values) {
		boolean result = false;

		if (values != null) {
			result = true;

			for (boolean value : values) {
				result &= value;
			}
		}

		return result;
	}

	/**
	 * Effectue un "ou logique" d'une liste de booléens
	 * @param values La liste de booléens
	 * @return un booléen
	 */
	@AutomatedTests({ "false,false", "false,true", "true, false", "true,true" })
	final public static boolean or(boolean... values) {
		boolean result = false;

		if (values != null) {
			for (boolean value : values) {
				result |= value;
			}
		}

		return result;
	}

	/**
	 * Effectue un "ou exclusif logique" d'une liste de booléens
	 * @param values La liste de booléens
	 * @return un booléen
	 */
	@AutomatedTests({ "false,false", "false,true", "true, false", "true,true" })
	final public static boolean xor(boolean... values) {
		boolean result = false;

		if (values != null) {
			boolean allFalse = true;
			boolean allTrue = true;

			for (boolean value : values) {
				allFalse &= !value;
				allTrue &= value;
			}

			result = (!allFalse && !allTrue);
		}

		return result;
	}
}
