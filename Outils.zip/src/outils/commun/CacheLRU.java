package outils.commun;

import java.util.*;

import outils.tests.automated.annotations.AutomatedTests;

/**
 * Implémentation d'une cache
 */
public class CacheLRU {
	/**
	 * Classe qui contient une donnée de la cache
	 */
	public class KeyData {
		/** La clé **/
		private Object _key;
	
		/** La donnée **/
		private Object _data;
	
		/**
		 * Constructeur de base
		 * @param key La clé
		 * @param data La donnée
		 */
		public KeyData(Object key, Object data) {
			_key = key;
			_data = data;
		}
	
		/*
		 * (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (obj == null) {
				return false;
			}
	
			if (obj instanceof KeyData) {
				return _key.equals(((KeyData) obj).getKey());
			}
	
			return super.equals(obj);
		}
	
		/*
		 * (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			return Objects.hash(_key);
		}
	
		/**
		 * Gets the key
		 * @return Returns a Object
		 */
		public Object getKey() {
			return _key;
		}
	
		/**
		 * Sets the key
		 * @param key The key to set
		 */
		public void setKey(Object key) {
			_key = key;
		}
	
		/**
		 * Gets the data
		 * @return Returns a Object
		 */
		public Object getData() {
			return _data;
		}
	
		/**
		 * Sets the data
		 * @param data The data to set
		 */
		public void setData(Object data) {
			_data = data;
		}
	
	}

	/** Nombre maximum d'éléments dans la cache **/
	private int _max;

	/** éléments de la cache **/
	private LinkedList<KeyData> _cache;

	/** Clés de la cache **/
	private Hashtable<Object, Object> _keys;

	/** Position de l'élément lors d'un get (-1 si pas trouvé) **/
	private int _last_get_pos;

	/**
	 * Contructeur de la classe
	 * @param size Le nombre maximum d'éléments dans la cache
	 */
	@AutomatedTests("10")
	public CacheLRU(int max) {
		if (max < 1) {
			throw new RuntimeException("Le nombre maximum d'éléments dans la cache doit être supérieur à zéro");
		}

		_max = max;
		_cache = new LinkedList<KeyData>();
		_keys = new Hashtable<Object, Object>(_max);
		_last_get_pos = -1;
	}

	/**
	 * Dimension de la cache
	 * @return un entier
	 */
	public int size() {
		return _cache.size();
	}

	/**
	 * Efface la cache
	 */
	public void clear() {
		_cache.clear();
		_keys.clear();
	}

	/**
	 * Ajoute une donnée à la cache
	 * @param data La donnée à ajouter
	 * @return vrai si réussi...
	 */
	public boolean add(Object data) {
		return add(data, data);
	}

	/**
	 * Ajoute une donnée à la cache
	 * @param key La clé de la donnée à ajouter
	 * @param data La donnée à ajouter
	 * @return vrai si réussi...
	 */
	public boolean add(Object key, Object data) {
		if (key == null) {
			return false;
		}

		if (size() == _max) {
			_keys.remove(((KeyData) _cache.removeLast()).getKey());
		}

		_cache.addFirst(new KeyData(key, data));
		_keys.put(key, data);

		return true;
	}

	/**
	 * Supprime une donnée à la cache
	 * @param key La clé de la donnée à supprimer
	 * @return vrai si réussi...
	 */
	public boolean remove(Object key) {
		if (key == null) {
			return false;
		}

		return _cache.remove(new KeyData(key, _keys.remove(key)));
	}

	/**
	 * Extrait une donnée de la cache pour une clé donné
	 * @param key La clé de la donnée à extraire
	 * @return la donnée (null sinon...)
	 */
	public Object get(Object key) {
		if (key == null) {
			return null;
		}

		Object data = _keys.get(key);

		if (data == null) {
			_last_get_pos = -1;
			return null;
		}

		_last_get_pos = _cache.indexOf(new KeyData(key, null));

		if (_last_get_pos == -1) {
			return null;
		}

		KeyData result = (KeyData) _cache.get(_last_get_pos);

		if (_last_get_pos != 0) {
			_cache.remove(_last_get_pos);
			_cache.addFirst(result);
		}

		return result.getData();
	}

	/**
	 * Retourne le niveau de succès du dernier get (0 -> pas trouvé, max -> le premier élément de la cache)
	 * @return un nombre entre 0 et max
	 */
	public int getCacheLevel() {
		if (_last_get_pos == -1) {
			return 1;
		}

		return _max - _last_get_pos;
	}

	/**
	 * Gets the max
	 * @return Returns a int
	 */
	public int getMax() {
		return _max;
	}

}