package outils.commun;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import outils.base.OutilsBase;
import outils.commun.ExecShell.IProcessOutput.OutputTypes;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Exécution d'une application externe via le shell
 * @author Claude Toupin - 2010-05-30
 */
@CoverageTestsCases(ExecShell.CoverageTestsCases.class)
public class ExecShell {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			ExecShell es = new ExecShell(false);

			es.exec("powershell.exe", "-Command", "{Start-Sleep", "-s", "5}");
			es.kill();
			
			while(es.isRunning()) {
				Thread.sleep(500);
			}
			
			es.exec("powershell.exe", "-Command", "{Start-Sleep", "-s", "5}");
			es.killAndWait();
			es.exec("powershell.exe", "-Command", "{Start-Sleep", "-s", "5}");
			es.getAsyncException();
			es.waitFor();
			es.getStdout();
			es.getStderr();
			es.getReturnCode();
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/** Le stdout */
	private List<String> stdout;

	/** Traitement de stdout **/
	private IProcessOutput stdoutProcess;

	/** Le stderr */
	private List<String> stderr;

	/** Traitement de stderr **/
	private IProcessOutput stderrProcess;

	/** Le code de retour de l'exécution */
	private int returnCode;

	/** Mode d'execution true = synchrone, false = asynchrone */
	private boolean synchrone;

	/** Le ExecShellThread en cours d'exécution */
	private ExecShellThread execShellThread;

	// /**
	// * Test d'appel externe
	// */
	// public static void main(String[] args) {
	// ExecShell es = new ExecShell(true);
	//
	// try {
	// String cmd = "sh";
	//
	// List<String> sl = new ArrayList<String>();
	// sl.add("-c");
	// sl.add("ps -ef | grep CIAO");
	//
	// OutilsCommun.log("début de l'exécution de la commande: " + cmd + " " + OutilsCommun.toList(sl, " "));
	// OutilsCommun.log("------------------------------------");
	//
	// es.exec(cmd, sl);
	//
	// OutilsCommun.log(OutilsCommun.toCRLFList(es.getStdout()));
	// OutilsCommun.log("---- Erreur ----");
	// OutilsCommun.log(OutilsCommun.toCRLFList(es.getStderr()));
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	/**
	 * Constructeur de base
	 * @param synchrone Mode d'exécution true = synchrone, false = asynchrone
	 */
	@TestMethodsInstance
	public ExecShell(boolean synchrone) {
		this.stdout = new ArrayList<String>(1024);
		this.stdoutProcess = null;
		this.stderr = new ArrayList<String>(1024);
		this.stderrProcess = null;
		this.returnCode = 0;
		this.synchrone = synchrone;
		this.execShellThread = null;
	}

	/**
	 * Constructeur de base
	 * @param synchrone Mode d'exécution true = synchrone, false = asynchrone
	 * @param stdoutProcess Traitement de stdout
	 */
	public ExecShell(boolean synchrone, IProcessOutput stdoutProcess) {
		this(synchrone);
		this.stdoutProcess = stdoutProcess;
	}

	/**
	 * Constructeur de base
	 * @param synchrone Mode d'exécution true = synchrone, false = asynchrone
	 * @param stdoutProcess Traitement de stdout
	 * @param stderrProcess Traitement de stderr
	 */
	public ExecShell(boolean synchrone, IProcessOutput stdoutProcess, IProcessOutput stderrProcess) {
		this(synchrone);
		this.stdoutProcess = stdoutProcess;
		this.stderrProcess = stderrProcess;
	}

	/**
	 * Efface le contenu de l'exécution
	 */
	public void clear() {
		stdout.clear();
		stderr.clear();
		returnCode = 0;
	}

	/**
	 * Exécution de l'application externe
	 * @param args Les arguments d'exécution
	 * @return le code de retour d'exécution
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests("java")
	protected int execute(String... args) throws Exception {
		if (synchrone) {
			clear();

			Process process = Runtime.getRuntime().exec(args);

			StreamRedirect errorRedirect = new StreamRedirect(process.getErrorStream(), OutputTypes.STDERR);
			StreamRedirect outputRedirect = new StreamRedirect(process.getInputStream(), OutputTypes.STDOUT);

			errorRedirect.start();
			outputRedirect.start();

			returnCode = process.waitFor();

			outputRedirect.join();
			errorRedirect.join();
		} else {
			if (execShellThread != null) {
				if (execShellThread.isAlive()) {
					throw new Exception("Une exécution est en cours...");
				}
			}

			clear();

			execShellThread = new ExecShellThread(args);
			execShellThread.start();
		}

		return returnCode;
	}

	/**
	 * Exécution de l'application externe
	 * @param prog Le chemin complet de l'application externe à exécuter
	 * @param args Les arguments de l'application externe à exécuter
	 * @return le code de retour d'exécution
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "java", "-version" })
	public int exec(String prog, String... args) throws Exception {
		if (OutilsBase.isEmpty(args)) {
			return execute(new String[] { prog });
		}

		String[] exec_args = new String[1 + args.length];
		exec_args[0] = prog;

		for (int i = 0; i < args.length; i++) {
			exec_args[i + 1] = args[i];
		}

		return execute(exec_args);
	}

	/**
	 * Exécution de l'application externe
	 * @param prog Le chemin complet de l'application externe à exécuter
	 * @param args Les arguments de l'application externe à exécuter
	 * @return le code de retour d'exécution
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "java", "-version" })
	public int exec(String prog, List<String> args) throws Exception {
		if (OutilsBase.isEmpty(args)) {
			return execute(new String[] { prog });
		}

		String[] exec_args = new String[1 + args.size()];
		exec_args[0] = prog;

		for (int i = 0; i < args.size(); i++) {
			exec_args[i + 1] = args.get(i);
		}

		return execute(exec_args);
	}

	/**
	 * Vérifie si l'exécution asynchrone est toujours en cours d'exécution
	 * @return vrai si en cours
	 */
	public boolean isRunning() {
		boolean result = false;

		if (!synchrone) {
			if (execShellThread != null) {
				result = execShellThread.isAlive();
			}
		}

		return result;
	}

	/**
	 * Arrêt de l'exécution du processus
	 */
	public void kill() {
		if (!synchrone) {
			if (execShellThread != null) {
				if (execShellThread.isAlive()) {
					execShellThread.killProcess();
				}
			}
		}
	}

	/**
	 * Arrêt de l'exécution du processus et attend la fin de l'exécution
	 */
	public void killAndWait() {
		if (!synchrone) {
			if (execShellThread != null) {
				if (execShellThread.isAlive()) {
					execShellThread.killProcess();

					try {
						execShellThread.join();
					} catch (InterruptedException ie) {}
				}
			}
		}
	}

	/**
	 * Attend la fin de l'exécution du processus
	 * @return le code de retour
	 * @throws Exception en cas d'erreur...
	 */
	public int waitFor() throws Exception {
		if (synchrone) {
			return returnCode;
		}

		if (execShellThread == null) {
			return 0;
		}

		if (execShellThread.isAlive()) {
			execShellThread.join();
		}

		if (execShellThread.getException() != null) {
			throw execShellThread.getException();
		}

		return returnCode;
	}

	/**
	 * Retourne l'exception de l'exécution asynchrone
	 * @return l'exception (null sinon...)
	 */
	public Exception getAsyncException() {
		Exception result = null;

		if (!synchrone) {
			if (execShellThread != null) {
				result = execShellThread.getException();
			}
		}

		return result;
	}

	/**
	 * Gets the stdout
	 * @return a List<String>
	 */
	public List<String> getStdout() {
		if (synchrone) {
			return stdout;
		}

		if (execShellThread != null) {
			if (!execShellThread.isAlive()) {
				return stdout;
			}
		}

		return new ArrayList<String>();
	}

	/**
	 * Gets the stderr
	 * @return a List<String>
	 */
	public List<String> getStderr() {
		if (synchrone) {
			return stderr;
		}

		if (execShellThread != null) {
			if (!execShellThread.isAlive()) {
				return stderr;
			}
		}

		return new ArrayList<String>();
	}

	/**
	 * Gets the return_code
	 * @return a int
	 */
	public int getReturnCode() {
		if (synchrone) {
			return returnCode;
		}

		if (execShellThread != null) {
			if (!execShellThread.isAlive()) {
				return returnCode;
			}
		}

		return 0;
	}

	/**
	 * Interface pour le traitement de la sortie des données
	 * @author Claude Toupin - 2011-08-07
	 */
	public interface IProcessOutput {
		/**
		 * Types des sorties des données
		 */
		public static enum OutputTypes {
			STDOUT, STDERR
		};

		/**
		 * Traitement de la sortie
		 * @param type Type de sortie
		 * @param line Ligne des données
		 * @param list Liste des données
		 * @throws Exception en cas d'erreur...
		 */
		public void process(OutputTypes type, String line, List<String> list) throws Exception;
	}

	/**
	 * Classe qui permet l'exécution d'une application externe via le shell par un Thread
	 */
	protected class ExecShellThread extends Thread {
		/** Le processus */
		private Process process;

		/** Les arguments */
		private String[] args;

		/** Contient l'exception (s'il y a lieu) */
		private Exception exception;

		/**
		 * Constructeur de la classe
		 * 
		 * @param args
		 *        Les arguments d'exécution
		 */
		public ExecShellThread(String[] args) {
			this.process = null;
			this.args = args;
			this.exception = null;
		}

		/**
		 * Le run du thread
		 */
		public void run() {
			try {
				synchronized (ExecShellThread.this) {
					process = Runtime.getRuntime().exec(args);
				}

				StreamRedirect errorRedirect = new StreamRedirect(process.getErrorStream(), OutputTypes.STDERR);
				StreamRedirect outputRedirect = new StreamRedirect(process.getInputStream(), OutputTypes.STDOUT);

				errorRedirect.start();
				outputRedirect.start();

				returnCode = process.waitFor();

				outputRedirect.join();
				errorRedirect.join();

			} catch (Exception e) {
				exception = e;
			} finally {
				synchronized (ExecShellThread.this) {
					process = null;
				}
			}
		}

		/**
		 * Arrêt de l'exécution du processus
		 */
		synchronized public void killProcess() {
			if (process != null) {
				process.destroy();
			}
		}

		/**
		 * Gets the exception
		 * @return a Exception
		 */
		public Exception getException() {
			return exception;
		}

	}

	/**
	 * Classe de support pour la récupération de la sortie de la classe ExecShell.
	 */
	protected class StreamRedirect extends Thread {
		/** Le stream en entré */
		private final InputStream _inputStream;

		/** Type de sortie **/
		private final OutputTypes _outputType;

		/** Liste de la sortie **/
		private final List<String> _list;

		/** Traitement de la sortie **/
		private final IProcessOutput _process;

		/**
		 * Constructeur de la classe
		 * @param inputStream Le stream a être lu
		 * @param lines Les lignes en sortie
		 * @param process Traitement de la sortie
		 */
		public StreamRedirect(InputStream inputStream, OutputTypes outputType) {
			_inputStream = inputStream;
			_outputType = outputType;
			_list = (_outputType == OutputTypes.STDOUT) ? stdout : stderr;
			_process = (_outputType == OutputTypes.STDOUT) ? stdoutProcess : stderrProcess;
		}

		/**
		 * Le run du thread
		 */
		public void run() {
			try {
				InputStreamReader inputStreamReader = new InputStreamReader(_inputStream);
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
				String line = null;

				while ((line = bufferedReader.readLine()) != null) {
					if (_process != null) {
						_process.process(_outputType, line, _list);
					} else {
						_list.add(line);
					}
				}
			} catch (Exception e) {
				_list.add(e.toString());
			}
		}

		/**
		 * Extrait le champ _inputStream
		 * @return un InputStream
		 */
		public InputStream get_inputStream() {
			return _inputStream;
		}

		/**
		 * Extrait le champ _outputType
		 * @return un IProcessOutput.OutputTypes
		 */
		public IProcessOutput.OutputTypes get_outputType() {
			return _outputType;
		}

	}

}