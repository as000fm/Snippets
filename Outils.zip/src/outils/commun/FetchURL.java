package outils.commun;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import outils.base.OutilsBase;
import outils.commun.CookieManager.ICookieManager;
import outils.listes.NameValue;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.StrictAutomatedTests;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.RequestMethodsTypes;

/**
 * Extraction du contenu d'un URL
 * @author Claude Toupin - 2010-05-30
 */
@DefaultParameterTestValue(type = String.class, name = "url", value = "https://postman-echo.com/get")
@DefaultParameterTestValue(type = RequestMethodsTypes.class, name = "requestMethod", value = "RequestMethodsTypes.GET")
@DefaultParameterTestValue(type = List.class, typename = "java.util.List<outils.listes.NameValue>", name = "params", value = "new NameValue(\"q=Montreal\"), new NameValue(\"ts=1\")")
@DefaultParameterTestValue(type = String.class, name = "param", value = "q=Montreal")
@DefaultParameterTestValue(type = String.class, name = "filename", value = "FetchURL.html", filename = true)
@DefaultParameterTestValue(type = byte[].class, name = "data", value = "100")
@CoverageTestsCases(FetchURL.CoverageTestsCases.class)
public class FetchURL {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			FetchURL fetchURL = new FetchURL(1000);
			fetchURL.getRequestPropertiesList().add(new NameValue("Accept", "All"));
			fetchURL.setReferer("Test");
			fetchURL.setUser("user");
			fetchURL.setPassword("password");
			fetchURL.getContent("https://www.google.com/search", RequestMethodsTypes.GET, (List<NameValue>) OutilsBase.asList(new NameValue[] { new NameValue("q=Montreal"), new NameValue("ts=1") }));
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/** gestionnaire des cookies */
	private static CookieManager cookieManager = null;

	/**
	 * Extrait le champ cookieManager
	 * @return un CookieManager
	 */
	public static CookieManager getCookieManager() {
		if (cookieManager == null) {
			cookieManager = new CookieManager();
		}

		return cookieManager;
	}

	/** Utilisation des paramètres en format requête ajouté à l'url pour un GET ou DELETE **/
	private boolean queryParams;

	/** La source de l'url */
	private String referer;

	/** Nom de l'usager **/
	private String user;

	/** Mode de passe de l'usager **/
	private String password;

	/** Liste des propriétés de la requête **/
	final private List<NameValue> requestPropertiesList;

	/** Code de la réponse (voir HttpURLConnection) **/
	private int responseCode;

	/** Type mime du contenu de l'URL */
	private String contentType;

	/** Taille du contenu de l'URL */
	private int contentLength;

	/** Indique que le contenu est du texte */
	private boolean text;

	/** Temps maximum de la connexion en millisecondes **/
	private int timeout;

	/** Interface pour la gestion de cookies (i.e. callback) */
	private ICookieManager callback;

	/**
	 * Constructeur de base
	 */
	@TestMethodsInstance
	public FetchURL() {
		this.queryParams = true;
		this.referer = null;
		this.user = null;
		this.password = null;
		this.requestPropertiesList = new ArrayList<NameValue>();
		this.responseCode = HttpURLConnection.HTTP_OK;
		this.contentType = null;
		this.contentLength = -1;
		this.text = false;
		this.timeout = -1;
		this.callback = null;
	}

	/**
	 * Constructeur de base
	 * @param timeout Temps maximum de la connexion en millisecondes
	 */
	public FetchURL(int timeout) {
		this();
		this.timeout = timeout;
	}

	/**
	 * Constructeur de base
	 * @param callback Interface pour la gestion de cookies (i.e. callback)
	 */
	public FetchURL(ICookieManager callback) {
		this();
		this.callback = callback;
	}

	/**
	 * Constructeur de base
	 * @param timeout Temps maximum de la connexion en millisecondes
	 * @param callback Interface pour la gestion de cookies (i.e. callback)
	 */
	public FetchURL(int timeout, ICookieManager callback) {
		this();
		this.timeout = timeout;
		this.callback = callback;
	}

	/**
	 * Extrait le contenu d'un url donné
	 * @param url L'url à extraire
	 * @param requestMethod Méthode de la requête HTTP (i.e. DELETE, GET, POST ou PUT)
	 * @param param Paramètre pour la méthode de la requête HTTP
	 * @return la connexion
	 * @throws Exception en cas d'erreur
	 */
	protected URLConnection fetchContent(String url, RequestMethodsTypes requestMethod, String param) throws Exception {
		boolean https = url.toLowerCase().startsWith("https://");

		if (https) {
			// Creation d'un contexte qui ne vérifie pas les certificates
			SSLContext sslContext = SSLContext.getInstance("TLS");

			TrustManager[] trustManager = new TrustManager[] { new X509TrustManager() {

				@Override
				public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					// Rien
				}

				@Override
				public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					// Rien
				}

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			} };

			sslContext.init(null, // Key manager
					trustManager, // Trust manager
					new SecureRandom()); // Random number generator

			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
		}

		URL u = new URL(url);

		if (queryParams) {
			switch (requestMethod) {
				case GET:
				case DELETE:
					if (!OutilsBase.isEmpty(param)) {
						u = new URL(url + "?" + param);
						param = null;
					}
					break;
				default:
					break;
			}
		}

		URLConnection connection = u.openConnection();

		((HttpURLConnection) connection).setRequestMethod(requestMethod.name());

		if (https) {
			((HttpsURLConnection) connection).setHostnameVerifier(new HostnameVerifier() {

				@Override
				public boolean verify(String host, SSLSession session) {
					// Accepte tout
					return true;
				}
			});
		}

		if (timeout > -1) {
			connection.setConnectTimeout(timeout);
		}

		getCookieManager().setCookies(connection, callback);

		for (NameValue requestProperty : requestPropertiesList) {
			connection.setRequestProperty(requestProperty.getName(), requestProperty.getValue());
		}

		if (!OutilsBase.isEmpty(referer)) {
			connection.setRequestProperty("Referer", referer);
		}

		if (!OutilsBase.isEmpty(user)) {
			String userpassword = user + ":" + OutilsBase.asString(password);
			String basicAuth = "Basic " + Base64.getEncoder().encode(userpassword.getBytes());
			connection.setRequestProperty("Authorization", basicAuth);
		}

		if (!OutilsBase.isEmpty(param)) {
			connection.setDoOutput(true);

			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(connection.getOutputStream());
			outputStreamWriter.write(param);
			outputStreamWriter.flush();
		}

		try {
			connection.connect();
		} catch (UnknownHostException uhe) {
			responseCode = 520;
			throw uhe;
		}

		responseCode = ((HttpURLConnection) connection).getResponseCode();

		getCookieManager().storeCookies(connection);

		contentType = connection.getContentType();
		contentLength = connection.getContentLength();

		return connection;
	}

	/**
	 * Ajout d'un alias
	 * @param source L'url source
	 * @param target l'url de destination
	 * @throws MalformedURLException en cas d'erreur...
	 */
	@StrictAutomatedTests({ "http://www.hccp.org/test/cookieTest.jsp", "http://www.hccp.org/test/cookieTest.jsp" })
	public void addAlias(String source, String target) throws MalformedURLException {
		getCookieManager().addAlias(source, target);
	}

	/**
	 * Extrait le contenu d'un url donné
	 * @param url L'url à extraire
	 * @return le contenu de l'url sous forme d'un byte[]
	 * @throws Exception en cas d'erreur
	 */
	public byte[] getContent(String url) throws Exception {
		return getContent(url, RequestMethodsTypes.GET, (String) null);
	}

	/**
	 * Extrait le contenu d'un url donné
	 * @param url L'url à extraire
	 * @param requestMethod Méthode de la requête HTTP (i.e. DELETE, GET, POST ou PUT)
	 * @return le contenu de l'url sous forme d'un byte[]
	 * @throws Exception en cas d'erreur
	 */
	public byte[] getContent(String url, RequestMethodsTypes requestMethod) throws Exception {
		return getContent(url, requestMethod, (String) null);
	}

	/**
	 * Extrait le contenu d'un url donné
	 * @param url L'url à extraire
	 * @param params Liste des paramètres pour le POST
	 * @return le contenu de l'url sous forme d'un byte[]
	 * @throws Exception en cas d'erreur
	 */
	@StrictAutomatedTests({ "https://postman-echo.com/post", "null" })
	public byte[] getContent(String url, List<NameValue> params) throws Exception {
		return getContent(url, RequestMethodsTypes.POST, params);
	}

	/**
	 * Extrait le contenu d'un url donné
	 * @param url L'url à extraire
	 * @param param Paramètre pour la méthode de la requête HTTP
	 * @return le contenu de l'url sous forme d'un byte[]
	 * @throws Exception en cas d'erreur
	 */
	@StrictAutomatedTests({ "https://postman-echo.com/post", "q=Montreal" })
	@StrictAutomatedTests({ "https://postman-echo.com", "null" })
	public byte[] getContent(String url, String param) throws Exception {
		return getContent(url, RequestMethodsTypes.POST, param);
	}

	/**
	 * Extrait le contenu d'un url donné
	 * @param url L'url à extraire
	 * @param requestMethod Méthode de la requête HTTP (i.e. DELETE, GET, POST ou PUT)
	 * @param params Liste des paramètres pour la méthode de la requête HTTP
	 * @return le contenu de l'url sous forme d'un byte[]
	 * @throws Exception en cas d'erreur
	 */
	public byte[] getContent(String url, RequestMethodsTypes requestMethod, List<NameValue> params) throws Exception {
		// System.out.println("URL: " + url);
		// System.out.println("Params: ?" + OutilsCommun.toList(params, "&"));

		StringBuffer buf = null;

		if (params != null) {
			buf = new StringBuffer();

			for (int i = 0; i < params.size(); i++) {
				NameValue nv = params.get(i);

				if (i > 0) {
					buf.append('&');
				}

				buf.append(URLEncoder.encode(nv.getName(), "UTF-8"));
				buf.append('=');
				buf.append(URLEncoder.encode(nv.getValue(), "UTF-8"));
			}
		}

		// System.out.println("Params(UTF8): ?" + OutilsBase.asString(buf));

		return getContent(url, requestMethod, (buf != null) ? buf.toString() : null);
	}

	/**
	 * Extrait le contenu d'un url donné
	 * @param url L'url à extraire
	 * @param requestMethod Méthode de la requête HTTP (i.e. DELETE, GET, POST ou PUT)
	 * @param param Paramètre pour la méthode de la requête HTTP
	 * @return le contenu de l'url sous forme d'un byte[]
	 * @throws Exception en cas d'erreur
	 */
	public byte[] getContent(String url, RequestMethodsTypes requestMethod, String param) throws Exception {
		URLConnection connection = null;

		try {
			connection = fetchContent(url, requestMethod, param);
		} catch (UnknownHostException uhe) {
			return uhe.getLocalizedMessage().getBytes();
		} catch (Exception e) {
			throw e;
		}

		try {
			if (contentType == null) {
				text = true;

				return new byte[0];
			} else {
				text = contentType.startsWith("text/");

				ByteArrayOutputStream out = new ByteArrayOutputStream();

				BufferedInputStream in = new BufferedInputStream(connection.getInputStream());

				byte[] data = new byte[104857600];
				int bytesRead = 0;

				try {
					while (true) {
						bytesRead = in.read(data, 0, data.length);

						if (bytesRead == -1) {
							break;
						}

						out.write(data, 0, bytesRead);
					}
				} finally {
					in.close();
				}

				return out.toByteArray();
			}
		} catch (IOException e) {
			if (!isResponseCodeOK()) {
				return e.getLocalizedMessage().getBytes();
			}

			throw e;
		}
	}

	/**
	 * Extrait le contenu d'un url et le sauvegarde dans un fichier
	 * @param url L'url à extraire
	 * @param filename Le nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws Exception en cas d'erreur...
	 */
	public void getContentToFile(String url, String filename, boolean append) throws Exception {
		getContentToFile(url, RequestMethodsTypes.GET, (String) null, filename, append);
	}

	/**
	 * Extrait le contenu d'un url et le sauvegarde dans un fichier
	 * @param url L'url à extraire
	 * @param requestMethod Méthode de la requête HTTP (i.e. DELETE, GET, POST ou PUT)
	 * @param filename Le nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws Exception en cas d'erreur...
	 */
	public void getContentToFile(String url, RequestMethodsTypes requestMethod, String filename, boolean append) throws Exception {
		getContentToFile(url, requestMethod, (String) null, filename, append);
	}

	/**
	 * Extrait le contenu d'un url et le sauvegarde dans un fichier
	 * @param url L'url à extraire
	 * @param params Liste des paramètres pour le POST
	 * @param filename Le nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "https://postman-echo.com/post", "null", "FetchURL.html", "false,true" }, filenames = 2, iterate = true)
	public void getContentToFile(String url, List<NameValue> params, String filename, boolean append) throws Exception {
		getContentToFile(url, RequestMethodsTypes.POST, params, filename, append);
	}

	/**
	 * Extrait le contenu d'un url et le sauvegarde dans un fichier
	 * @param url L'url à extraire
	 * @param param Paramètre pour la méthode de la requête HTTP
	 * @param filename Le nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "https://postman-echo.com/post", "q=Montreal", "FetchURL.html", "false,true" }, filenames = 2, iterate = true)
	public void getContentToFile(String url, String param, String filename, boolean append) throws Exception {
		getContentToFile(url, RequestMethodsTypes.POST, param, filename, append);
	}

	/**
	 * Extrait le contenu d'un url et le sauvegarde dans un fichier
	 * @param url L'url à extraire
	 * @param requestMethod Méthode de la requête HTTP (i.e. DELETE, GET, POST ou PUT)
	 * @param params Liste des paramètres pour la méthode de la requête HTTP
	 * @param filename Le nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws Exception en cas d'erreur...
	 */
	public void getContentToFile(String url, RequestMethodsTypes requestMethod, List<NameValue> params, String filename, boolean append) throws Exception {
		StringBuffer buf = null;

		if (params != null) {
			buf = new StringBuffer();

			for (int i = 0; i < params.size(); i++) {
				NameValue nv = params.get(i);

				if (i > 0) {
					buf.append('&');
				}

				buf.append(URLEncoder.encode(nv.getName(), "UTF-8"));
				buf.append('=');
				buf.append(URLEncoder.encode(nv.getValue(), "UTF-8"));
			}
		}

		getContentToFile(url, requestMethod, (buf != null) ? buf.toString() : null, filename, append);
	}

	/**
	 * Extrait le contenu d'un url et le sauvegarde dans un fichier
	 * @param url L'url à extraire
	 * @param requestMethod Méthode de la requête HTTP (i.e. DELETE, GET, POST ou PUT)
	 * @param param Paramètre pour la méthode de la requête HTTP
	 * @param filename Le nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws Exception en cas d'erreur...
	 */
	public void getContentToFile(String url, RequestMethodsTypes requestMethod, String param, String filename, boolean append) throws Exception {
		URLConnection connection = null;

		try {
			connection = fetchContent(url, requestMethod, param);
		} catch (UnknownHostException uhe) {
			saveContentToFile(uhe.getLocalizedMessage().getBytes(), filename, append);
		} catch (Exception e) {
			throw e;
		}

		try {
			if (contentType == null) {
				text = true;

				saveContentToFile(new byte[0], filename, append);
			} else {
				text = contentType.startsWith("text/");

				InputStream in = new BufferedInputStream(connection.getInputStream());
				FileOutputStream fos = new FileOutputStream(filename, append);

				byte[] data = new byte[262144000];
				int bytesRead = 0;

				try {
					while ((bytesRead = in.read(data)) != -1) {
						fos.write(data, 0, bytesRead);
					}

					fos.flush();
				} finally {
					fos.close();
					in.close();
				}
			}
		} catch (IOException e) {
			if (!isResponseCodeOK()) {
				saveContentToFile(e.getLocalizedMessage().getBytes(), filename, append);
			}

			throw e;
		}
	}

	/**
	 * Sauvegarde le contenu d'un byte[] dans un fichier
	 * @param data Les données à sauvegarder
	 * @param filename Le nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws Exception en cas d'erreur...
	 */
	public void saveContentToFile(final byte[] data, String filename, boolean append) throws Exception {
		FileOutputStream fos = new FileOutputStream(filename, append);

		try {
			fos.write(data);
			fos.flush();
		} finally {
			fos.close();
		}
	}

	/**
	 * Extrait le champ contentType
	 * @return un String
	 */
	public String getContentType() {
		return contentType;
	}

	/**
	 * Extrait le champ contentLength
	 * @return un int
	 */
	public int getContentLength() {
		return contentLength;
	}

	/**
	 * Extrait le champ text
	 * @return un boolean
	 */
	public boolean isText() {
		return text;
	}

	/**
	 * Extrait le champ binaire
	 * @return un boolean
	 */
	public boolean isBinary() {
		return !text;
	}

	/**
	 * Extrait le champ queryParams
	 * @return un boolean
	 */
	public boolean isQueryParams() {
		return queryParams;
	}

	/**
	 * Modifie le champ queryParams
	 * @param queryParams La valeur du champ queryParams
	 */
	public void setQueryParams(boolean queryParams) {
		this.queryParams = queryParams;
	}

	/**
	 * Extrait le champ referer
	 * @return un String
	 */
	public String getReferer() {
		return referer;
	}

	/**
	 * Modifie le champ referer
	 * @param referer La valeur du champ referer
	 */
	public void setReferer(String referer) {
		this.referer = referer;
	}

	/**
	 * Extrait le champ user
	 * @return un String
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Modifie le champ user
	 * @param user La valeur du champ user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Extrait le champ password
	 * @return un String
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Modifie le champ password
	 * @param password La valeur du champ password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Extrait le champ requestPropertiesList
	 * @return un List<NameValue>
	 */
	public List<NameValue> getRequestPropertiesList() {
		return requestPropertiesList;
	}

	/**
	 * Indique si le code de résultata est OK (HTTP 200)
	 * @return un boolean
	 */
	public boolean isResponseCodeOK() {
		return responseCode == HttpURLConnection.HTTP_OK;
	}

	/**
	 * Extrait le champ responseCode
	 * @return un int
	 */
	public int getResponseCode() {
		return responseCode;
	}

	/**
	 * Modifie le champ responseCode
	 * @param responseCode La valeur du champ responseCode
	 */
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * Extrait le champ timeout
	 * @return un int
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * Modifie le champ timeout
	 * @param timeout La valeur du champ timeout
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * Extrait le champ callback
	 * @return un ICookieManager
	 */
	public ICookieManager getCallback() {
		return callback;
	}

	/**
	 * Modifie le champ callback
	 * @param callback La valeur du champ callback
	 */
	public void setCallback(ICookieManager callback) {
		this.callback = callback;
	}

}
