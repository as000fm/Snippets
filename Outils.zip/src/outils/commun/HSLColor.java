package outils.commun;

import java.awt.Color;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Couleur en format HSL (Hue, Saturation, Lightness)
 * @author Claude Toupin - 29 déc. 2022
 */
public class HSLColor {
	/** Couleur rgb **/
	private Color rgb;

	/** Couleur HSL - Hue en degrées **/
	private float hue;

	/** Couleur HSL - Saturation en % **/
	private float saturation;

	/** Couleur HSL - Saturation en % **/
	private float lightness;

	/** Couleur HSL - Alpha entre 0 et 1 **/
	private float alpha;

	/**
	 * Constructeur de base
	 */
	@TestMethodsInstance
	public HSLColor() {
		setRGB(Color.BLACK);
	}

	/**
	 * Constructeur de base
	 * @param rgb Couleur RGB
	 */
	@AutomatedTests("Color.RED")
	public HSLColor(Color rgb) {
		setRGB(rgb);
	}

	/**
	 * Constructeur de base
	 * @param hsl Les valeurs HSL sous forme { hue, saturation, lightness }
	 */
	@AutomatedTests("120,10,20")
	public HSLColor(float[] hsl) {
		setHSL(hsl);
	}

	/**
	 * Constructeur de base
	 * @param hsl Les valeurs HSL sous forme { hue, saturation, lightness }
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests({ "120,10,20", "0.75" })
	public HSLColor(float[] hsl, float alpha) {
		setHSLA(hsl, alpha);
	}

	/**
	 * Constructeur de base
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param lightness La valeur pour lightness
	 */
	public HSLColor(float hue, float saturation, float lightness) {
		setHSL(hue, saturation, lightness);
	}

	/**
	 * Constructeur de base
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param lightness La valeur pour lightness
	 * @param alpha La valeur pour alpha
	 */
	public HSLColor(float hue, float saturation, float lightness, float alpha) {
		setHSLA(hue, saturation, lightness, alpha);
	}

	/**
	 * Mise à jour des valeur de HSLA
	 * @link https://www.rapidtables.com/convert/color/rgb-to-hsl.html
	 */
	protected void majHSLA() {
		float[] components = rgb.getRGBComponents(null);
		float red = components[0];
		float green = components[1];
		float blue = components[2];

		alpha = components[3];

		float min = OutilsBase.min(red, green, blue);
		float max = OutilsBase.max(red, green, blue);
		float delta = max - min;

		hue = 0;

		if (delta == 0f) {
			hue = 0f;
		} else if (max == red) {
			hue = 60f * (((green - blue) / delta) % 6f);
		} else if (max == green) {
			hue = 60f * (((blue - red) / delta) + 2f);
		} else if (max == blue) {
			hue = 60f * (((red - green) / delta) + 4f);
		}

		if (hue < 0) {
			hue += 360f;
		}

		hue %= 360;

		lightness = OutilsBase.range(0f, 100f * (max + min) / 2f, 100f);

		saturation = OutilsBase.range(0f, (delta == 0f) ? 0f : (100f * (delta / (1f - OutilsBase.abs((2f * (lightness / 100f)) - 1f)))), 100f);
	}

	/**
	 * Mise à jour des valeurs RGBA
	 * @link https://www.rapidtables.com/convert/color/hsl-to-rgb.html
	 */
	protected void majRGBA() {
		float h = hue;
		float s = saturation / 100f;
		float l = lightness / 100f;

		float c = (1f - OutilsBase.abs((2f * l) - 1f)) * s;

		float x = c * (1f - OutilsBase.abs(((h / 60) % 2f) - 1f));

		float m = l - (c / 2);

		float r, g, b;

		if (h < 60) {
			r = c;
			g = x;
			b = 0;
		} else if (h < 120) {
			r = x;
			g = c;
			b = 0;
		} else if (h < 180) {
			r = 0;
			g = c;
			b = x;
		} else if (h < 240) {
			r = 0;
			g = x;
			b = c;
		} else if (h < 300) {
			r = x;
			g = 0;
			b = c;
		} else {
			r = c;
			g = 0;
			b = x;
		}

		rgb = new Color(r + m, g + m, b + m, alpha);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HSLColor [r=" + rgb.getRed() + ", g=" + rgb.getGreen() + ", b=" + rgb.getBlue() + ", a=" + rgb.getAlpha() + ", hue=" + hue + ", saturation=" + saturation + ", lightness=" + lightness + ", alpha=" + alpha + "]";
	}

	/**
	 * Extrait la couleur courante en format HSV
	 * @return la couleur courante en format HSV
	 */
	public HSVColor toHSVColor() {
		return new HSVColor(rgb);
	}

	/**
	 * Extrait la couleur courante en format HSV
	 * @return la couleur courante en format HSV
	 */
	public HWBColor toHWBColor() {
		return new HWBColor(rgb);
	}

	/**
	 * Ajutement de hue
	 * @param hue La valeur pour hue
	 * @return la couleur rgb
	 */
	public Color adjustHue(float hue) {
		setHue(hue);

		return rgb;
	}

	/**
	 * Ajutement de saturation
	 * @param saturation La valeur pour saturation
	 * @return la couleur rgb
	 */
	public Color adjustSaturation(float saturation) {
		setSaturation(saturation);

		return rgb;
	}

	/**
	 * Ajutement de lightness
	 * @param lightness La valeur pour lightness
	 * @return la couleur rgb
	 */
	public Color adjustLightness(float lightness) {
		setLightness(lightness);

		return rgb;
	}

	/**
	 * Ajustement de l'ombrage
	 * @param percent Le pourcentage d'ajustement de l'ombrage
	 * @return la couleur rgb
	 */
	@AutomatedTests({ "-1", "101", "50" })
	public Color adjustShade(float percent) {
		if ((percent < 0f) || (percent > 100f)) {
			throw new IllegalArgumentException("La valeur pour percent doit être entre 0 et 100 inclusivement");
		}

		float multiplier = (100f - percent) / 100f;

		setLightness(OutilsBase.max(0f, lightness * multiplier));

		return rgb;
	}

	/**
	 * Ajustement de la tonalité
	 * @param percent Le pourcentage d'ajustement de la tonalité
	 * @return la couleur rgb
	 */
	@AutomatedTests({ "-1", "101", "50" })
	public Color adjustTone(float percent) {
		if ((percent < 0f) || (percent > 100f)) {
			throw new IllegalArgumentException("La valeur pour percent doit être entre 0 et 100 inclusivement");
		}

		float multiplier = (100f + percent) / 100f;

		setLightness(OutilsBase.min(100f, lightness * multiplier));

		return rgb;
	}

	/**
	 * Extrait la couleur complémentaire
	 * @return la couleur rgb
	 */
	public Color getComplementary() {
		setHue((hue + 180f) % 360f);

		return rgb;
	}

	/**
	 * Extrait les valeurs HSL
	 * @return un float[] { hue, saturation, lightness }
	 */
	public float[] getHSL() {
		return new float[] { hue, saturation, lightness };
	}

	/**
	 * Modifie les valeurs HSL
	 * @param hsl Les valeurs HSL sous forme { hue, saturation, lightness }
	 */
	@AutomatedTests({ "1", "20,50,50" })
	public void setHSL(float[] hsl) {
		if (hsl == null) {
			throw new IllegalArgumentException("Pas de couleur HSL de spécifiée");
		} else if (hsl.length != 3) {
			throw new IllegalArgumentException("Les valeurs HSL doivent être sous forme: hue, saturation et lightness");
		}

		setHSLA(hsl[0], hsl[1], hsl[2], 1f);
	}

	/**
	 * Modifie les valeurs HSL
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param lightness La valeur pour lightness
	 */
	public void setHSL(float hue, float saturation, float lightness) {

		setHSLA(hue, saturation, lightness, 1f);
	}

	/**
	 * Extrait les valeurs HSLA
	 * @return un float[] { hue, saturation, lightness, alpha }
	 */
	public float[] getHSLA() {
		return new float[] { hue, saturation, lightness, alpha };
	}

	/**
	 * Modifie les valeurs HSLA
	 * @param hsla Les valeurs HSLA sous forme { hue, saturation, lightness, alpha }
	 */
	@AutomatedTests({ "1", "20,50,50,0.5" })
	public void setHSLA(float[] hsla) {
		if (hsla == null) {
			throw new IllegalArgumentException("Pas de couleur HSLA de spécifiée");
		} else if (hsla.length != 4) {
			throw new IllegalArgumentException("Les valeurs HSLA doivent être sous forme: hue, saturation, lightness et alpha");
		}

		setHSLA(hsla[0], hsla[1], hsla[2], hsla[3]);
	}

	/**
	 * Modifie les valeurs HSLA
	 * @param hsl Les valeurs HSL sous forme { hue, saturation, lightness }
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests({ "1", "0.5", "20,50,50", "0.5" })
	public void setHSLA(float[] hsl, float alpha) {
		if (hsl == null) {
			throw new IllegalArgumentException("Pas de couleur HSL de spécifiée");
		} else if (hsl.length != 3) {
			throw new IllegalArgumentException("Les valeurs HSL doivent être sous forme: hue, saturation et lightness");
		}

		setHSLA(hsl[0], hsl[1], hsl[2], alpha);
	}

	/**
	 * Modifie les valeurs HSLA
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param lightness La valeur pour lightness
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests(value = { "-1,10,400", "-1,20,200", "-1,20,200", "-1,0.5,2" }, iterate = true)
	public void setHSLA(float hue, float saturation, float lightness, float alpha) {
		if ((hue < 0f) || (hue > 360f)) {
			throw new IllegalArgumentException("La valeur pour hue doit être entre 0 et 360 inclusivement");
		}

		this.hue = hue % 360f;

		if ((saturation < 0f) || (saturation > 100f)) {
			throw new IllegalArgumentException("La valeur pour saturation doit être entre 0 et 100 inclusivement");
		}

		this.saturation = saturation;

		if ((lightness < 0f) || (lightness > 100f)) {
			throw new IllegalArgumentException("La valeur pour lightness doit être entre 0 et 100 inclusivement");
		}

		this.lightness = lightness;

		if ((alpha < 0f) || (alpha > 1f)) {
			throw new IllegalArgumentException("La valeur pour alpha doit être entre 0 et 1 inclusivement");
		}

		this.alpha = alpha;

		majRGBA();
	}

	/**
	 * Extrait le champ rgb
	 * @return un Color
	 */
	public Color getRGB() {
		return rgb;
	}

	/**
	 * Modifie le champ rgb
	 * @param rgb La valeur du champ rgb
	 */
	@AutomatedTests("Color.BLUE")
	public void setRGB(Color rgb) {
		if (rgb == null) {
			throw new IllegalArgumentException("Pas de couleur RGB de spécifiée");
		}

		this.rgb = rgb;

		majHSLA();
	}

	/**
	 * Extrait le champ hue
	 * @return un float
	 */
	public float getHue() {
		return hue;
	}

	/**
	 * Modifie le champ hue
	 * @param hue La valeur du champ hue
	 */
	public void setHue(float hue) {
		setHSLA(hue, saturation, lightness, alpha);
	}

	/**
	 * Extrait le champ saturation
	 * @return un float
	 */
	public float getSaturation() {
		return saturation;
	}

	/**
	 * Modifie le champ saturation
	 * @param saturation La valeur du champ saturation
	 */
	public void setSaturation(float saturation) {
		setHSLA(hue, saturation, lightness, alpha);
	}

	/**
	 * Extrait le champ lightness
	 * @return un float
	 */
	public float getLightness() {
		return lightness;
	}

	/**
	 * Modifie le champ lightness
	 * @param lightness La valeur du champ lightness
	 */
	public void setLightness(float lightness) {
		setHSLA(hue, saturation, lightness, alpha);
	}

	/**
	 * Extrait le champ alpha
	 * @return un float
	 */
	public float getAlpha() {
		return alpha;
	}

	/**
	 * Modifie le champ alpha
	 * @param alpha La valeur du champ alpha
	 */
	public void setAlpha(float alpha) {
		setHSLA(hue, saturation, lightness, alpha);
	}
}
