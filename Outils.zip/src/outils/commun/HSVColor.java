package outils.commun;

import java.awt.Color;

import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.TestMethodsInstance;
/**
 * Couleur en format HSV (Hue, Saturation, Value (ou Brightness))
 * @author Claude Toupin - 29 déc. 2022
 */
public class HSVColor {
	/** Couleur rgb **/
	private Color rgb;

	/** Couleur HSV - Hue en degrées **/
	private float hue;

	/** Couleur HSV - Saturation en % **/
	private float saturation;

	/** Couleur HSV - Value en % **/
	private float value;

	/** Couleur HSV - Alpha entre 0 et 1 **/
	private float alpha;

	/**
	 * Constructeur de base
	 */
	@TestMethodsInstance
	public HSVColor() {
		setRGB(Color.BLACK);
	}

	/**
	 * Constructeur de base
	 * @param rgb Couleur RGB
	 */
	@AutomatedTests("Color.RED")
	public HSVColor(Color rgb) {
		setRGB(rgb);
	}

	/**
	 * Constructeur de base
	 * @param hsv Les valeurs HSV sous forme { hue, saturation, value }
	 */
	@AutomatedTests("120,10,20")
	public HSVColor(float[] hsv) {
		setHSV(hsv);
	}

	/**
	 * Constructeur de base
	 * @param hsv Les valeurs HSV sous forme { hue, saturation, value }
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests({ "120,10,20", "0.75" })
	public HSVColor(float[] hsv, float alpha) {
		setHSVA(hsv, alpha);
	}

	/**
	 * Constructeur de base
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param value La valeur pour value
	 */
	public HSVColor(float hue, float saturation, float value) {
		setHSV(hue, saturation, value);
	}

	/**
	 * Constructeur de base
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param value La valeur pour value
	 * @param alpha La valeur pour alpha
	 */
	public HSVColor(float hue, float saturation, float value, float alpha) {
		setHSVA(hue, saturation, value, alpha);
	}

	/**
	 * Mise à jour des valeur de HSVA
	 * @link https://docs.oracle.com/javase/8/docs/api/java/awt/Color.html
	 */
	protected void majHSVA() {
		float[] values = Color.RGBtoHSB(rgb.getRed(), rgb.getGreen(), rgb.getBlue(), null);

		hue = values[0] * 360f;
		saturation = values[1] * 100f;
		value = values[2] * 100f; // Brightness

		alpha = rgb.getAlpha() / 255f;
	}

	/**
	 * Mise à jour des valeurs RGBA
	 * @link https://docs.oracle.com/javase/8/docs/api/java/awt/Color.html
	 */
	protected void majRGBA() {
		Color color = Color.getHSBColor(hue / 360f, saturation / 100f, value / 100f);

		rgb = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (alpha * 255f));
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HSVColor [r=" + rgb.getRed() + ", g=" + rgb.getGreen() + ", b=" + rgb.getBlue() + ", a=" + rgb.getAlpha() + ", hue=" + hue + ", saturation=" + saturation + ", value=" + value + ", alpha=" + alpha + "]";
	}

	/**
	 * Extrait la couleur courante en format HSL
	 * @return la couleur courante en format HSL
	 */
	public HSLColor toHSLColor() {
		return new HSLColor(rgb);
	}

	/**
	 * Extrait la couleur courante en format HSV
	 * @return la couleur courante en format HSV
	 */
	public HWBColor toHWBColor() {
		return new HWBColor(rgb);
	}

	/**
	 * Ajutement de hue
	 * @param hue La valeur pour hue
	 * @return la couleur rgb
	 */
	public Color adjustHue(float hue) {
		setHue(hue);

		return rgb;
	}

	/**
	 * Ajutement de saturation
	 * @param saturation La valeur pour saturation
	 * @return la couleur rgb
	 */
	public Color adjustSaturation(float saturation) {
		setSaturation(saturation);

		return rgb;
	}

	/**
	 * Ajutement de value
	 * @param value La valeur pour value
	 * @return la couleur rgb
	 */
	public Color adjustValue(float value) {
		setValue(value);

		return rgb;
	}

	/**
	 * Ajustement de l'ombrage
	 * @param percent Le pourcentage d'ajustement de l'ombrage
	 * @return la couleur rgb
	 */
	@AutomatedTests({ "-1", "101", "50" })
	public Color adjustShade(float percent) {
		if ((percent < 0f) || (percent > 100f)) {
			throw new IllegalArgumentException("La valeur pour percent doit être entre 0 et 100 inclusivement");
		}
		
		setRGB(toHSLColor().adjustShade(percent));

		return rgb;
	}

	/**
	 * Ajustement de la tonalité
	 * @param percent Le pourcentage d'ajustement de la tonalité
	 * @return la couleur rgb
	 */
	@AutomatedTests({ "-1", "101", "50" })
	public Color adjustTone(float percent) {
		if ((percent < 0f) || (percent > 100f)) {
			throw new IllegalArgumentException("La valeur pour percent doit être entre 0 et 100 inclusivement");
		}

		setRGB(toHSLColor().adjustTone(percent));

		return rgb;
	}

	/**
	 * Extrait la couleur complémentaire
	 * @return la couleur rgb
	 */
	public Color getComplementary() {
		setHue((hue + 180f) % 360f);

		return rgb;
	}

	/**
	 * Extrait les valeurs HSV
	 * @return un float[] { hue, saturation, value }
	 */
	public float[] getHSV() {
		return new float[] { hue, saturation, value };
	}

	/**
	 * Modifie les valeurs HSV
	 * @param hsv Les valeurs HSV sous forme { hue, saturation, value }
	 */
	@AutomatedTests({ "1", "20,50,50" })
	public void setHSV(float[] hsv) {
		if (hsv == null) {
			throw new IllegalArgumentException("Pas de couleur HSV de spécifiée");
		} else if (hsv.length != 3) {
			throw new IllegalArgumentException("Les valeurs HSV doivent être sous forme: hue, saturation et value");
		}

		setHSVA(hsv[0], hsv[1], hsv[2], 1f);
	}

	/**
	 * Modifie les valeurs HSV
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param value La valeur pour value
	 */
	public void setHSV(float hue, float saturation, float value) {

		setHSVA(hue, saturation, value, 1f);
	}

	/**
	 * Extrait les valeurs HSVA
	 * @return un float[] { hue, saturation, value, alpha }
	 */
	public float[] getHSVA() {
		return new float[] { hue, saturation, value, alpha };
	}

	/**
	 * Modifie les valeurs HSVA
	 * @param hsva Les valeurs HSVA sous forme { hue, saturation, value, alpha }
	 */
	@AutomatedTests({ "1", "20,50,50,0.5" })
	public void setHSVA(float[] hsva) {
		if (hsva == null) {
			throw new IllegalArgumentException("Pas de couleur HSVA de spécifiée");
		} else if (hsva.length != 4) {
			throw new IllegalArgumentException("Les valeurs HSVA doivent être sous forme: hue, saturation, value et alpha");
		}

		setHSVA(hsva[0], hsva[1], hsva[2], hsva[3]);
	}

	/**
	 * Modifie les valeurs HSVA
	 * @param hsv Les valeurs HSV sous forme { hue, saturation, value }
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests({ "1", "0.5", "20,50,50", "0.5" })
	public void setHSVA(float[] hsv, float alpha) {
		if (hsv == null) {
			throw new IllegalArgumentException("Pas de couleur HSV de spécifiée");
		} else if (hsv.length != 3) {
			throw new IllegalArgumentException("Les valeurs HSV doivent être sous forme: hue, saturation et value");
		}

		setHSVA(hsv[0], hsv[1], hsv[2], alpha);
	}

	/**
	 * Modifie les valeurs HSVA
	 * @param hue La valeur pour hue
	 * @param saturation La valeur pour saturation
	 * @param value La valeur pour value
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests(value = { "-1,10,400", "-1,20,200", "-1,20,200", "-1,0.5,2" }, iterate = true)
	public void setHSVA(float hue, float saturation, float value, float alpha) {
		if ((hue < 0f) || (hue > 360f)) {
			throw new IllegalArgumentException("La valeur pour hue doit être entre 0 et 360 inclusivement");
		}

		this.hue = hue % 360f;

		if ((saturation < 0f) || (saturation > 100f)) {
			throw new IllegalArgumentException("La valeur pour saturation doit être entre 0 et 100 inclusivement");
		}

		this.saturation = saturation;

		if ((value < 0f) || (value > 100f)) {
			throw new IllegalArgumentException("La valeur pour value doit être entre 0 et 100 inclusivement");
		}

		this.value = value;

		if ((alpha < 0f) || (alpha > 1f)) {
			throw new IllegalArgumentException("La valeur pour alpha doit être entre 0 et 1 inclusivement");
		}

		this.alpha = alpha;

		majRGBA();
	}

	/**
	 * Extrait le champ rgb
	 * @return un Color
	 */
	public Color getRGB() {
		return rgb;
	}

	/**
	 * Modifie le champ rgb
	 * @param rgb La valeur du champ rgb
	 */
	@AutomatedTests("Color.BLUE")
	public void setRGB(Color rgb) {
		if (rgb == null) {
			throw new IllegalArgumentException("Pas de couleur RGB de spécifiée");
		}

		this.rgb = rgb;

		majHSVA();
	}

	/**
	 * Extrait le champ hue
	 * @return un float
	 */
	public float getHue() {
		return hue;
	}

	/**
	 * Modifie le champ hue
	 * @param hue La valeur du champ hue
	 */
	public void setHue(float hue) {
		setHSVA(hue, saturation, value, alpha);
	}

	/**
	 * Extrait le champ saturation
	 * @return un float
	 */
	public float getSaturation() {
		return saturation;
	}

	/**
	 * Modifie le champ saturation
	 * @param saturation La valeur du champ saturation
	 */
	public void setSaturation(float saturation) {
		setHSVA(hue, saturation, value, alpha);
	}

	/**
	 * Extrait le champ value
	 * @return un float
	 */
	public float getValue() {
		return value;
	}

	/**
	 * Modifie le champ value
	 * @param value La valeur du champ value
	 */
	public void setValue(float value) {
		setHSVA(hue, saturation, value, alpha);
	}

	/**
	 * Extrait le champ alpha
	 * @return un float
	 */
	public float getAlpha() {
		return alpha;
	}

	/**
	 * Modifie le champ alpha
	 * @param alpha La valeur du champ alpha
	 */
	public void setAlpha(float alpha) {
		setHSVA(hue, saturation, value, alpha);
	}
}
