package outils.commun;

import java.awt.Color;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Couleur en format HWB (Hue, Whiteness, Blackness)
 * @author Claude Toupin - 29 déc. 2022
 */
public class HWBColor {
	/** Couleur rgb **/
	private Color rgb;

	/** Couleur HWB - Hue en degrées **/
	private float hue;

	/** Couleur HWB - Whiteness en % **/
	private float whiteness;

	/** Couleur HWB - Blackness en % **/
	private float blackness;

	/** Couleur HWB - Alpha entre 0 et 1 **/
	private float alpha;

	/**
	 * Constructeur de base
	 */
	@TestMethodsInstance
	public HWBColor() {
		setRGB(Color.BLACK);
	}

	/**
	 * Constructeur de base
	 * @param rgb Couleur RGB
	 */
	@AutomatedTests("Color.RED")
	public HWBColor(Color rgb) {
		setRGB(rgb);
	}

	/**
	 * Constructeur de base
	 * @param hwb Les valeurs HWB sous forme { hue, whiteness, blackness }
	 */
	@AutomatedTests("120,10,20")
	public HWBColor(float[] hwb) {
		setHWB(hwb);
	}

	/**
	 * Constructeur de base
	 * @param hwb Les valeurs HWB sous forme { hue, whiteness, blackness }
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests({ "120,10,20", "0.75" })
	public HWBColor(float[] hwb, float alpha) {
		setHWBA(hwb, alpha);
	}

	/**
	 * Constructeur de base
	 * @param hue La valeur pour hue
	 * @param whiteness La valeur pour whiteness
	 * @param blackness La valeur pour blackness
	 */
	public HWBColor(float hue, float whiteness, float blackness) {
		setHWB(hue, whiteness, blackness);
	}

	/**
	 * Constructeur de base
	 * @param hue La valeur pour hue
	 * @param whiteness La valeur pour whiteness
	 * @param blackness La valeur pour blackness
	 * @param alpha La valeur pour alpha
	 */
	public HWBColor(float hue, float whiteness, float blackness, float alpha) {
		setHWBA(hue, whiteness, blackness, alpha);
	}

	/**
	 * Mise à jour des valeur de HWBA
	 * @link http://alvyray.com/Papers/CG/HWB_JGTv208.pdf
	 */
	protected void majHWBA() {
		float[] values = Color.RGBtoHSB(rgb.getRed(), rgb.getGreen(), rgb.getBlue(), null);

		float saturation = values[1];
		float value = values[2]; // Brightness

		hue = values[0] * 360f;
		whiteness = 100f * ((1f - saturation) * value);
		blackness = 100f * (1f - value);

		alpha = rgb.getAlpha() / 255f;
	}

	/**
	 * Mise à jour des valeurs RGBA
	 * @link http://alvyray.com/Papers/CG/HWB_JGTv208.pdf
	 */
	protected void majRGBA() {
		float saturation = 1f - ((whiteness / 100f) / (1f - (blackness / 100f)));
		float value = 1f - (blackness / 100f);
		
		Color color = Color.getHSBColor(hue / 360f, saturation, value);

		rgb = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (alpha * 255f));
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HWBColor [r=" + rgb.getRed() + ", g=" + rgb.getGreen() + ", b=" + rgb.getBlue() + ", a=" + rgb.getAlpha() + ", hue=" + hue + ", whiteness=" + whiteness + ", blackness=" + blackness + ", alpha=" + alpha + ", w+b=" + (whiteness + blackness) + ", delta(w-b)=" + OutilsBase.abs(whiteness - blackness) + "]";
	}

	/**
	 * Extrait la couleur courante en format HSL
	 * @return la couleur courante en format HSL
	 */
	public HSLColor toHSLColor() {
		return new HSLColor(rgb);
	}

	/**
	 * Extrait la couleur courante en format HSV
	 * @return la couleur courante en format HSV
	 */
	public HSVColor toHSVColor() {
		return new HSVColor(rgb);
	}

	/**
	 * Ajutement de hue
	 * @param hue La valeur pour hue
	 * @return la couleur rgb
	 */
	public Color adjustHue(float hue) {
		setHue(hue);

		return rgb;
	}

	/**
	 * Ajutement de whiteness
	 * @param whiteness La valeur pour whiteness
	 * @return la couleur rgb
	 */
	public Color adjustWhiteness(float whiteness) {
		setWhiteness(whiteness);

		return rgb;
	}

	/**
	 * Ajutement de blackness
	 * @param blackness La valeur pour blackness
	 * @return la couleur rgb
	 */
	public Color adjustBlackness(float blackness) {
		setBlackness(blackness);

		return rgb;
	}

	/**
	 * Ajustement de l'ombrage
	 * @param percent Le pourcentage d'ajustement de l'ombrage
	 * @return la couleur rgb
	 */
	@AutomatedTests({ "-1", "101", "50" })
	public Color adjustShade(float percent) {
		if ((percent < 0f) || (percent > 100f)) {
			throw new IllegalArgumentException("La valeur pour percent doit être entre 0 et 100 inclusivement");
		}

		setRGB(toHSLColor().adjustShade(percent));

		return rgb;
	}

	/**
	 * Ajustement de la tonalité
	 * @param percent Le pourcentage d'ajustement de la tonalité
	 * @return la couleur rgb
	 */
	@AutomatedTests({ "-1", "101", "50" })
	public Color adjustTone(float percent) {
		if ((percent < 0f) || (percent > 100f)) {
			throw new IllegalArgumentException("La valeur pour percent doit être entre 0 et 100 inclusivement");
		}

		setRGB(toHSLColor().adjustTone(percent));

		return rgb;
	}

	/**
	 * Extrait la couleur complémentaire
	 * @return la couleur rgb
	 */
	public Color getComplementary() {
		setHue((hue + 180f) % 360f);

		return rgb;
	}

	/**
	 * Extrait les valeurs HWB
	 * @return un float[] { hue, whiteness, blackness }
	 */
	public float[] getHWB() {
		return new float[] { hue, whiteness, blackness };
	}

	/**
	 * Modifie les valeurs HWB
	 * @param hwb Les valeurs HWB sous forme { hue, whiteness, blackness }
	 */
	@AutomatedTests({ "1", "20,50,50" })
	public void setHWB(float[] hwb) {
		if (hwb == null) {
			throw new IllegalArgumentException("Pas de couleur HWB de spécifiée");
		} else if (hwb.length != 3) {
			throw new IllegalArgumentException("Les valeurs HWB doivent être sous forme: hue, whiteness et blackness");
		}

		setHWBA(hwb[0], hwb[1], hwb[2], 1f);
	}

	/**
	 * Modifie les valeurs HWB
	 * @param hue La valeur pour hue
	 * @param whiteness La valeur pour whiteness
	 * @param blackness La valeur pour blackness
	 */
	public void setHWB(float hue, float whiteness, float blackness) {

		setHWBA(hue, whiteness, blackness, 1f);
	}

	/**
	 * Extrait les valeurs HWBA
	 * @return un float[] { hue, whiteness, blackness, alpha }
	 */
	public float[] getHWBA() {
		return new float[] { hue, whiteness, blackness, alpha };
	}

	/**
	 * Modifie les valeurs HWBA
	 * @param hwba Les valeurs HWBA sous forme { hue, whiteness, blackness, alpha }
	 */
	@AutomatedTests({ "1", "20,50,50,0.5" })
	public void setHWBA(float[] hwba) {
		if (hwba == null) {
			throw new IllegalArgumentException("Pas de couleur HWBA de spécifiée");
		} else if (hwba.length != 4) {
			throw new IllegalArgumentException("Les valeurs HWBA doivent être sous forme: hue, whiteness, blackness et alpha");
		}

		setHWBA(hwba[0], hwba[1], hwba[2], hwba[3]);
	}

	/**
	 * Modifie les valeurs HWBA
	 * @param hwb Les valeurs HWB sous forme { hue, whiteness, blackness }
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests({ "1", "0.5", "20,50,50", "0.5" })
	public void setHWBA(float[] hwb, float alpha) {
		if (hwb == null) {
			throw new IllegalArgumentException("Pas de couleur HWB de spécifiée");
		} else if (hwb.length != 3) {
			throw new IllegalArgumentException("Les valeurs HWB doivent être sous forme: hue, whiteness et blackness");
		}

		setHWBA(hwb[0], hwb[1], hwb[2], alpha);
	}

	/**
	 * Modifie les valeurs HWBA
	 * @param hue La valeur pour hue
	 * @param whiteness La valeur pour whiteness
	 * @param blackness La valeur pour blackness
	 * @param alpha La valeur pour alpha
	 */
	@AutomatedTests(value = { "-1,10,400", "-1,20,200", "-1,20,200", "-1,0.5,2" }, iterate = true)
	public void setHWBA(float hue, float whiteness, float blackness, float alpha) {
		if ((hue < 0f) || (hue > 360f)) {
			throw new IllegalArgumentException("La valeur pour hue doit être entre 0 et 360 inclusivement");
		}

		this.hue = hue % 360f;

		if ((whiteness < 0f) || (whiteness > 100f)) {
			throw new IllegalArgumentException("La valeur pour whiteness doit être entre 0 et 100 inclusivement");
		}

		this.whiteness = whiteness;

		if ((blackness < 0f) || (blackness > 100f)) {
			throw new IllegalArgumentException("La valeur pour blackness doit être entre 0 et 100 inclusivement");
		}

		this.blackness = blackness;

		if ((alpha < 0f) || (alpha > 1f)) {
			throw new IllegalArgumentException("La valeur pour alpha doit être entre 0 et 1 inclusivement");
		}

		this.alpha = alpha;

		majRGBA();
	}

	/**
	 * Extrait le champ rgb
	 * @return un Color
	 */
	public Color getRGB() {
		return rgb;
	}

	/**
	 * Modifie le champ rgb
	 * @param rgb La valeur du champ rgb
	 */
	@AutomatedTests("Color.BLUE")
	public void setRGB(Color rgb) {
		if (rgb == null) {
			throw new IllegalArgumentException("Pas de couleur RGB de spécifiée");
		}

		this.rgb = rgb;

		majHWBA();
	}

	/**
	 * Extrait le champ hue
	 * @return un float
	 */
	public float getHue() {
		return hue;
	}

	/**
	 * Modifie le champ hue
	 * @param hue La valeur du champ hue
	 */
	public void setHue(float hue) {
		setHWBA(hue, whiteness, blackness, alpha);
	}

	/**
	 * Extrait le champ whiteness
	 * @return un float
	 */
	public float getWhiteness() {
		return whiteness;
	}

	/**
	 * Modifie le champ whiteness
	 * @param whiteness La valeur du champ whiteness
	 */
	public void setWhiteness(float whiteness) {
		setHWBA(hue, whiteness, blackness, alpha);
	}

	/**
	 * Extrait le champ blackness
	 * @return un float
	 */
	public float getBlackness() {
		return blackness;
	}

	/**
	 * Modifie le champ blackness
	 * @param blackness La valeur du champ blackness
	 */
	public void setBlackness(float blackness) {
		setHWBA(hue, whiteness, blackness, alpha);
	}

	/**
	 * Extrait le champ alpha
	 * @return un float
	 */
	public float getAlpha() {
		return alpha;
	}

	/**
	 * Modifie le champ alpha
	 * @param alpha La valeur du champ alpha
	 */
	public void setAlpha(float alpha) {
		setHWBA(hue, whiteness, blackness, alpha);
	}
}
