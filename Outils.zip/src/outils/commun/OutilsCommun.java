package outils.commun;

import static outils.base.OutilsBase.areEquals;
import static outils.base.OutilsBase.areEqualsIgnoreCase;
import static outils.base.OutilsBase.asString;
import static outils.base.OutilsBase.compareIgnoreCase;
import static outils.base.OutilsBase.doCamelCase;
import static outils.base.OutilsBase.doCapitalize;
import static outils.base.OutilsBase.doHarmonization;
import static outils.base.OutilsBase.doUncapitalize;
import static outils.base.OutilsBase.formatMetricSize;
import static outils.base.OutilsBase.isEmpty;
import static outils.base.OutilsBase.max;
import static outils.base.OutilsBase.min;
import static outils.base.OutilsBase.padString;
import static outils.base.OutilsBase.toEnglish;
import static outils.base.OutilsBase.toHexa;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermission;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.UUID;
import java.util.Vector;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.lang.model.SourceVersion;

import outils.base.OutilsBase;
import outils.commun.load.LoadCSVFormatFromFile;
import outils.commun.load.LoadCSVHeaderFromFile;
import outils.commun.load.LoadListFromFile;
import outils.commun.load.LoadNameValueListFromFile;
import outils.commun.load.LoadTextFromFile;
import outils.commun.save.SaveCSVFormatToFile;
import outils.commun.save.SaveListToFile;
import outils.commun.save.SaveTextToFile;
import outils.listes.CSVFileData;
import outils.listes.NameValue;
import outils.patterns.PatternData;
import outils.registry.types.FilePermissionsTypes;
import outils.tests.automated.annotations.AddImportsForTesting;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.CoverageOnly;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.SkipImportsForTesting;
import outils.tests.automated.annotations.SkipTesting;
import outils.tests.automated.annotations.StrictAutomatedTests;
import outils.types.CSVSeparatorsTypes;
import outils.types.FilesCharsetsTypes;
import outils.types.MessageDigestAlgorithmsTypes;
import outils.types.ParseDatesTypes;

/**
 * Classe des méthodes utilitaires de type final public static
 * @author Claude Toupin - 2010-10-23
 */
@AddImportsForTesting({ Base64.class, classes.outils.POJODataTestClass.class })
@SkipImportsForTesting(FilenameFilter.class)
@DefaultParameterTestValue(type = int.class, name = "permissions", value = "0x640")
public final class OutilsCommun {
	/** Caractères de fin de ligne **/
	final public static String LINE_SEPARATOR = System.getProperty("line.separator");

	/** Caractères de fin de ligne Windows **/
	final public static String WINDOWS_LINE_SEPARATOR = new String(new byte[] { 13, 10 });

	/** Extension d'un fichier texte **/
	final public static String TEXT_EXTENSION = ".txt";

	/** Extension d'un fichier markdown **/
	final public static String MARKDOWN_EXTENSION = ".md";

	/** Extension d'un fichier ini **/
	final public static String INI_EXTENSION = ".ini";

	/** Extension d'un fichier de propriétées **/
	final public static String PROPERTIES_EXTENSION = ".properties";

	/** Extension d'un fichier de journal **/
	final public static String LOG_EXTENSION = ".log";

	/** Extension d'un fichier compressé en format zip **/
	final public static String ZIP_EXTENSION = ".zip";

	/** Extension d'un fichier compressé en format gzip **/
	final public static String GZIP_EXTENSION = ".gz";

	/** Extension d'un fichier compressé en format 7 zip **/
	final public static String SEVEN_ZIP_EXTENSION = ".7z";

	/** Extension d'un fichier de données html **/
	final public static String HTML_EXTENSION = ".html";

	/** Extension d'un fichier de données css **/
	final public static String CSS_EXTENSION = ".css";

	/** Extension d'un fichier de données css compressé **/
	final public static String MINIFY_CSS_EXTENSION = ".min.css";

	/** Extension d'un fichier de données css compressé et gzipé **/
	final public static String MINIFY_CSS_GZIP_EXTENSION = MINIFY_CSS_EXTENSION + GZIP_EXTENSION;

	/** Extension d'un fichier de données json **/
	final public static String JSON_EXTENSION = ".json";

	/** Extension d'un fichier de données xml **/
	final public static String XML_EXTENSION = ".xml";

	/** Extension d'un fichier de données csv **/
	final public static String CSV_EXTENSION = ".csv";

	/** Extension d'un fichier compressé en format jar **/
	final public static String JAR_EXTENSION = ".jar";

	/** Extension d'un fichier source en java **/
	final public static String JAVA_EXTENSION = ".java";

	/** Extension d'un fichier source d'une grammaire en format JavaCC **/
	final public static String JAVACC_EXTENSION = ".jj";

	/** Extension d'un fichier sql **/
	final public static String SQL_EXTENSION = ".sql";

	/** Extension d'un fichier source en groovy **/
	final public static String GROOVY_EXTENSION = ".groovy";

	/** Extension d'un fichier source en powershell **/
	final public static String POWERSHELL_EXTENSION = ".ps1";

	/** Extension d'un fichier de module en powershell **/
	final public static String POWERSHELL_MODULE_EXTENSION = ".psm1";

	/** Extension d'un fichier de liste multimédia en format Latin-1 **/
	final public static String M3U_COMMAND_EXTENSION = ".m3u";

	/** Extension d'un fichier de liste multimédia en format UTF-8 **/
	final public static String M3U8_COMMAND_EXTENSION = ".m3u8";

	/** Extension d'un fichier compressé en format war **/
	final public static String WAR_EXTENSION = ".war";

	/** Extension d'un fichier de commande selon l'environnement courant **/
	final public static String COMMAND_EXTENSION;

	/** Extension d'un fichier de commande unix/linux **/
	final public static String UNIX_COMMAND_EXTENSION = ".sh";

	/** java.io.File.separator de unix/linux **/
	final public static String UNIX_FILE_SEPARATOR = "/";

	/** java.io.File.separatorChar de unix/linux **/
	final public static char UNIX_FILE_SEPARATOR_CHAR = '/';

	/** Extension d'un fichier de commande Windows **/
	final public static String WINDOWS_COMMAND_EXTENSION = ".cmd";

	/** java.io.File.pathSeparator de Windows **/
	final public static String WINDOWS_FILE_PATH_SEPARATOR = ";";

	/** java.io.File.pathSeparatorChar de Windows **/
	final public static char WINDOWS_FILE_PATH_SEPARATOR_CHAR = ';';

	/** java.io.File.separator de Windows **/
	final public static String WINDOWS_FILE_SEPARATOR = "\\";

	/** java.io.File.separatorChar de Windows **/
	final public static char WINDOWS_FILE_SEPARATOR_CHAR = '\\';

	/** Jours ouvrables **/
	final public static int[] BUSINESS_DAYS;

	/** Fin de semaine **/
	final public static int[] WEEKEND_DAYS;

	/** Minuit **/
	final public static Date MIDNIGHT = asTime(0, 0, 0);

	/** Midi **/
	final public static Date NOON = asTime(12, 0, 0);

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat TIMESTAMP_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat DATE_YEAR_FORMAT = new SimpleDateFormat("yyyy");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat DATE_YEAR_MONTH_FORMAT = new SimpleDateFormat("yyyy-MM");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat DATE_LONG_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat DATE_TIME_SHORT_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat DATE_TIME_SHORT_FRENCH_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH'h'mm");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat COMPRESS_DATE_TIME_SHORT_FORMAT = new SimpleDateFormat("yyyyMMddHHmm");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat DATE_TIME_LONG_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat COMPRESS_DATE_TIME_LONG_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat DATE_TIME_LONG_MS_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

	/** Format de la date et heure des fonctions de conversion **/
	final private static SimpleDateFormat COMPRESS_DATE_TIME_LONG_MS_FORMAT = new SimpleDateFormat("yyyyMMddHHmmssSSS");

	/** Format de l'heure des fonctions de conversion **/
	final private static SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm");

	/** Format de l'heure des fonctions de conversion **/
	final private static SimpleDateFormat TIME_FORMAT_FRENCH = new SimpleDateFormat("HH'h'mm");

	/** Format de l'heure des fonctions de conversion **/
	final private static SimpleDateFormat TIME_LONG_FORMAT = new SimpleDateFormat("HH:mm:ss");

	/** Format de l'heure des fonctions de conversion **/
	final private static SimpleDateFormat TIME_LONG_MS_FORMAT = new SimpleDateFormat("HH:mm:ss.SSS");

	/** Format de l'heure des fonctions de conversion **/
	final private static SimpleDateFormat TIMEOUT_FORMAT = new SimpleDateFormat("mm:ss");

	/** Format de la date et heure des fonctions de journalisation **/
	final private static SimpleDateFormat LOG_DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/** Format de la date et heure des champs Date en CSV **/
	final private static SimpleDateFormat CSV_DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/** Format de la date d'une période (journée) des fonctions de journalisation **/
	final private static SimpleDateFormat LOG_DATE_PERIOD_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

	/** Patron du nombre pour le pourcentage **/
	final private static String PERCENTAGE_FORMAT_PATTERN = "#0.#";

	/** Format du nombre pour le pourcentage **/
	final private static DecimalFormat PERCENTAGE_FORMAT = new DecimalFormat(PERCENTAGE_FORMAT_PATTERN);

	/** Générateur de nombres aléatoires **/
	final private static Random RANDOM = new Random();

	/** Version courante de Java **/
	final private static String JAVA_VERSION;

	/** Indicateur d'exécution sous Eclipse **/
	final private static boolean ECLIPSE_IDE;

	/** Indicateur de plateforme Windows **/
	final private static boolean WINDOWS_OS;

	/** Indicateur de la version de Windows **/
	final private static String WINDOWS_OS_VERSION;

	/** Indicateur de plateforme Windows 32 bits (x86) **/
	final private static boolean WINDOWS_32_OS;

	/** Indicateur de plateforme Windows 64 bits (amd) **/
	final private static boolean WINDOWS_64_OS;

	/** Indicateur de plateforme Mac **/
	final private static boolean MAC_OS;

	/** Indicateur de plateforme AIX **/
	final private static boolean AIX_OS;

	/** Indicateur de plateforme Linux **/
	final private static boolean LINUX_OS;

	/** Indicateur de plateforme Sun **/
	final private static boolean SUN_OS;

	/** Indicateur de plateforme HP-UX **/
	final private static boolean HP_UX_OS;

	/** Console d'impression **/
	final private static PrintWriter CONSOLE;

	/** Console d'impression en erreur **/
	final private static PrintWriter CONSOLE_ERROR;

	static {
		JAVA_VERSION = System.getProperty("java.version");

		String jcp = System.getProperty("java.class.path").toLowerCase().trim();

		// Il s'agit d'une path (beurk) car il n'y a pas d'autre moyen de le savoir... :(
		ECLIPSE_IDE = (jcp.contains("eclipse") || jcp.contains("workspace")) && (System.console() == null);

		String osName = asString(System.getProperty("os.name")).toLowerCase().trim();

		WINDOWS_OS = osName.startsWith("windows");
		MAC_OS = osName.startsWith("mac os");
		AIX_OS = osName.startsWith("aix");
		LINUX_OS = osName.startsWith("linux");
		SUN_OS = osName.startsWith("solaris") || osName.startsWith("sunos");
		HP_UX_OS = osName.startsWith("hp-ux");

		if (WINDOWS_OS) {
			WINDOWS_OS_VERSION = asString(osName.substring(7)).toLowerCase().trim();

			String osArch = asString(System.getProperty("os.arch")).toLowerCase().trim();

			WINDOWS_32_OS = areEqualsIgnoreCase("x86", osArch);
			WINDOWS_64_OS = areEqualsIgnoreCase("amd", osArch);

			COMMAND_EXTENSION = ".cmd";

			String oemcp = null;

			if (OutilsBase.isEmpty(oemcp)) {
				if (asString(System.getProperty("java.version")).startsWith("1.8")) {
					try {
						Field charOutField = System.out.getClass().getDeclaredField("charOut");
						charOutField.setAccessible(true);

						oemcp = ((OutputStreamWriter) charOutField.get(System.out)).getEncoding();

						if (OutilsBase.areEquals(oemcp, "Cp1252")) {
							// Impossible de forcer UTF-8 via un chcp 65001 :(
							oemcp = "UTF8";
						}
					} catch (Exception e) {
						oemcp = "Cp850";
					}
				} else {
					// Encore une autre path (beurk) pour java 9 et plus :(
					oemcp = ECLIPSE_IDE ? "UTF8" : "Cp850";
				}
			}

			if (!isEmpty(oemcp)) {
				PrintWriter console;
				PrintWriter console_error;

				try {
					console = new PrintWriter(new OutputStreamWriter(System.out, oemcp));
				} catch (UnsupportedEncodingException e) {
					System.err.println("Erreur lors de la creation de la console ayant le code de page " + oemcp + " : " + e.getLocalizedMessage());
					console = new PrintWriter(new OutputStreamWriter(System.out));
				}

				try {
					console_error = new PrintWriter(new OutputStreamWriter(System.err, oemcp));
				} catch (UnsupportedEncodingException e) {
					System.err.println("Erreur lors de la creation de la console d'erreur ayant le code de page " + oemcp + " : " + e.getLocalizedMessage());
					console_error = new PrintWriter(new OutputStreamWriter(System.err));
				}

				CONSOLE = console;
				CONSOLE_ERROR = console_error;
			} else {
				CONSOLE = new PrintWriter(new OutputStreamWriter(System.out));
				CONSOLE_ERROR = new PrintWriter(new OutputStreamWriter(System.err));
			}
		} else {
			COMMAND_EXTENSION = ".sh";
			CONSOLE = new PrintWriter(new OutputStreamWriter(System.out));
			CONSOLE_ERROR = new PrintWriter(new OutputStreamWriter(System.err));

			WINDOWS_OS_VERSION = null;
			WINDOWS_32_OS = false;
			WINDOWS_64_OS = false;
		}

		BUSINESS_DAYS = new int[] { //
				Calendar.MONDAY, //
				Calendar.TUESDAY, //
				Calendar.WEDNESDAY, //
				Calendar.THURSDAY, //
				Calendar.FRIDAY, //
		};

		WEEKEND_DAYS = new int[] { //
				Calendar.SATURDAY, //
				Calendar.SUNDAY, //
		};
	}

	/**
	 * Conversion d'un nombre en String
	 * @param number Le nombre à convertir
	 * @return le nombre convertit
	 */
	final public static String asNumericString(Double number) {
		return (number != null) ? asNumericString(number.doubleValue()) : "";
	}

	/**
	 * Conversion d'un nombre en String
	 * @param number Le nombre à convertir
	 * @return le nombre convertit
	 */
	final public static String asNumericString(double number) {
		return asNumericString(number, 1);
	}

	/**
	 * Conversion d'un nombre en String
	 * @param number Le nombre à convertir
	 * @return le nombre convertit
	 */
	final public static String asNumericString(Float number) {
		return (number != null) ? asNumericString(number.doubleValue()) : "";
	}

	/**
	 * Conversion d'un nombre en String
	 * @param number Le nombre à convertir
	 * @return le nombre convertit
	 */
	final public static String asNumericString(float number) {
		return asNumericString((double) number);
	}

	/**
	 * Conversion d'un nombre en String
	 * @param number Le nombre à convertir
	 * @param precision Nombre de chiffres après la virgule
	 * @return le nombre convertit
	 */
	final public static String asNumericString(Double number, int precision) {
		return (number != null) ? asNumericString(number.doubleValue(), precision) : "";
	}

	/**
	 * Conversion d'un nombre en String
	 * @param number Le nombre à convertir
	 * @param precision Nombre de chiffres après la virgule
	 * @return le nombre convertit
	 */
	final public static String asNumericString(double number, int precision) {
		if (precision < 1) {
			return new DecimalFormat("#0").format(number);
		}

		return new DecimalFormat("#0." + OutilsBase.padString("", '#', precision)).format(number);
	}

	/**
	 * Extrait l'estampille courante
	 * @return un String
	 */
	@CoverageOnly
	final public static String getCurrentTimestamp() {
		return TIMESTAMP_FORMAT.format(new Date());
	}

	/**
	 * Extrait l'estampille d'une date et heure donné
	 * @param date La date et heure donné
	 * @return un String
	 */
	final public static String getTimestamp(Date date) {
		try {
			return TIMESTAMP_FORMAT.format(date);
		} catch (Exception e) {
			throw new RuntimeException("Exception lors du formattage de la date: " + date, e);
		}
	}

	/**
	 * Création d'une date et heure
	 * @param datetime La date et heure
	 * @return un Date
	 */
	final public static Date asDateTime(Date datetime) {
		if (datetime == null) {
			return null;
		}

		return asDateTime(datetime, true);
	}

	/**
	 * Création d'une date et heure
	 * @param datetime La date et heure
	 * @param seconds Indicateur d'inclure les secondes. Si faux, alors les secondes sont à zéro
	 * @return un Date
	 */
	final public static Date asDateTime(Date datetime, boolean seconds) {
		if (datetime == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.setTime(datetime);

		if (!seconds) {
			calendar.set(Calendar.SECOND, 0);
		}

		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	/**
	 * Création d'une date et heure
	 * @param date La date
	 * @param time L'heure
	 * @return un Date
	 */
	final public static Date asDateTime(Date date, Date time) {
		if ((date == null) && (time == null)) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.clear();

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);

		if (date != null) {
			Calendar dateCalendar = Calendar.getInstance();
			dateCalendar.setTime(date);

			year = dateCalendar.get(Calendar.YEAR);
			month = dateCalendar.get(Calendar.MONTH);
			day = dateCalendar.get(Calendar.DAY_OF_MONTH);
		}

		if (time != null) {
			Calendar timeCalendar = Calendar.getInstance();
			timeCalendar.setTime(time);

			hour = timeCalendar.get(Calendar.HOUR_OF_DAY);
			minute = timeCalendar.get(Calendar.MINUTE);
			second = timeCalendar.get(Calendar.SECOND);
		}

		calendar.set(year, month, day, hour, minute, second);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	/**
	 * Création d'une date et heure
	 * @param year Année
	 * @param month Mois
	 * @param day Jour
	 * @param hour Heure
	 * @param minute Minute
	 * @param second Seconde
	 * @return un Date
	 */
	final public static Date asDateTime(int year, int month, int day, int hour, int minute, int second) {
		return asDateTime(year, month, day, hour, minute, second, 0);
	}

	/**
	 * Création d'une date et heure
	 * @param year Année
	 * @param month Mois
	 * @param day Jour
	 * @param hour Heure
	 * @param minute Minute
	 * @param second Seconde
	 * @param millisecond Milliseconde
	 * @return un Date
	 */
	final public static Date asDateTime(int year, int month, int day, int hour, int minute, int second, int millisecond) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, month - 1, day, hour, minute, second);
		calendar.set(Calendar.MILLISECOND, millisecond);

		return calendar.getTime();
	}

	/**
	 * Création d'une date sans heure
	 * @param date La date
	 * @return un Date
	 */
	final public static Date asDate(Date date) {
		if (date == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);

		calendar.clear();
		calendar.set(year, month, day, 0, 0, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	/**
	 * Création d'une date sans heure
	 * @param year Année
	 * @param month Mois
	 * @param day Jour
	 * @return un Date
	 */
	final public static Date asDate(int year, int month, int day) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, month - 1, day, 0, 0, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	/**
	 * Création d'une heure sans date
	 * @param time L'heure
	 * @return un Date
	 */
	final public static Date asTime(Date time) {
		if (time == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);

		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);

		calendar.clear();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		calendar.set(Calendar.SECOND, second);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	/**
	 * Création d'une heure sans date
	 * @param hour Heure
	 * @param minute Minute
	 * @param second Seconde
	 * @return un Date
	 */
	final public static Date asTime(int hour, int minute, int second) {
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		calendar.set(Calendar.SECOND, second);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	/**
	 * Formattage d'une date AAAA
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asDateYearString(Date date) {
		return (date != null) ? DATE_YEAR_FORMAT.format(date) : "";
	}

	/**
	 * Formattage d'une date AAAA-MM
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asDateYearMonthString(Date date) {
		return (date != null) ? DATE_YEAR_MONTH_FORMAT.format(date) : "";
	}

	/**
	 * Formattage d'une date AAAA-MM-JJ
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asDateString(Date date) {
		return (date != null) ? DATE_LONG_FORMAT.format(date) : "";
	}

	/**
	 * Formattage d'une date AAAA-MM-JJ HH:MM:SS
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asDateTimeString(Date date) {
		return asDateTimeString(date, true);
	}

	/**
	 * Formattage d'une date AAAA-MM-JJ HH:MM ou AAAA-MM-JJ HH:MM:SS
	 * @param date La date à formatter
	 * @param seconds Indicateur d'afficher les secondes
	 * @return un String ("" si null)
	 */
	final public static String asDateTimeString(Date date, boolean seconds) {
		if (date == null) {
			return "";
		}

		return seconds ? DATE_TIME_LONG_FORMAT.format(date) : DATE_TIME_SHORT_FORMAT.format(date);
	}

	/**
	 * Formattage d'une date compressée AAAAMMJJHHMM ou AAAAMMJJHHMMSS
	 * @param date La date à formatter
	 * @param seconds Indicateur d'afficher les secondes
	 * @return un String ("" si null)
	 */
	final public static String asCompressDateTimeString(Date date, boolean seconds) {
		if (date == null) {
			return "";
		}

		return seconds ? COMPRESS_DATE_TIME_LONG_FORMAT.format(date) : COMPRESS_DATE_TIME_SHORT_FORMAT.format(date);
	}

	/**
	 * Formattage d'une date AAAA-MM-JJ HH:MM:SS.SSS
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asDateTimeMiliisecondsString(Date date) {
		if (date == null) {
			return "";
		}

		return DATE_TIME_LONG_MS_FORMAT.format(date);
	}

	/**
	 * Formattage d'une date compressée AAAAMMJJHHMMSSSSS
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asCompressDateTimeMiliisecondsString(Date date) {
		if (date == null) {
			return "";
		}

		return COMPRESS_DATE_TIME_LONG_MS_FORMAT.format(date);
	}

	/**
	 * Formattage d'une date AAAA-MM-JJ HHhMM en français
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asFrenchDateTimeString(Date date) {
		if (date == null) {
			return "";
		}

		return DATE_TIME_SHORT_FRENCH_FORMAT.format(date);
	}

	/**
	 * Formattage d'une heure HH:MM:SS
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asTimeString(Date date) {
		return asTimeString(date, true);
	}

	/**
	 * Formattage d'une heure HH:MM ou HH:MM:SS
	 * @param date La date à formatter
	 * @param seconds Indicateur d'afficher les secondes
	 * @return un String ("" si null)
	 */
	final public static String asTimeString(Date date, boolean seconds) {
		if (date == null) {
			return "";
		}

		return seconds ? TIME_LONG_FORMAT.format(date) : TIME_FORMAT.format(date);
	}

	/**
	 * Formattage d'une heure MM:SS
	 * @param date La date à formatter
	 * @param seconds Indicateur d'afficher les secondes
	 * @return un String ("" si null)
	 */
	final public static String asTimeoutString(Date date, boolean seconds) {
		if (date == null) {
			return "";
		}

		return TIMEOUT_FORMAT.format(date);
	}

	/**
	 * Formattage d'une heure HH:MM:SS.SSS
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asTimeMillisecondsString(Date date, boolean seconds) {
		if (date == null) {
			return "";
		}

		return TIME_LONG_MS_FORMAT.format(date);
	}

	/**
	 * Formattage d'une heure HHhMM en français
	 * @param date La date à formatter
	 * @return un String ("" si null)
	 */
	final public static String asFrenchTimeString(Date date) {
		if (date == null) {
			return "";
		}

		return TIME_FORMAT_FRENCH.format(date);
	}

	/**
	 * Conversion d'un texte en date
	 * @param value La valeur à convertir en date
	 * @param parseDateType Type de conversion à effectuer
	 * @return un Date (null si vide)
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "2020-02-29 20:20:02", "null" })
	final public static Date asStringToDate(String value, ParseDatesTypes parseDateType) throws Exception {
		if (isEmpty(value)) {
			return null;
		}

		if (parseDateType != null) {
			switch (parseDateType) {
				case YYYY:
					try {
						return DATE_YEAR_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case YYYY_MM:
					try {
						return DATE_YEAR_MONTH_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case YYYY_MM_DD:
					try {
						return DATE_LONG_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case YYYY_MM_DD_HH_MM:
					try {
						return DATE_TIME_SHORT_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case YYYY_MM_DD_HH_MM_FRENCH:
					try {
						return DATE_TIME_SHORT_FRENCH_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case YYYY_MM_DD_HH_MM_SS:
					try {
						return DATE_TIME_LONG_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case YYYY_MM_DD_HH_MM_SS_SSS:
					try {
						return DATE_TIME_LONG_MS_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case HH_MM:
					try {
						return TIME_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case HH_MM_FRENCH:
					try {
						return TIME_FORMAT_FRENCH.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case HH_MM_SS:
					try {
						return TIME_LONG_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case HH_MM_SS_SSS:
					try {
						return TIME_LONG_MS_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				case MM_SS:
					try {
						return TIMEOUT_FORMAT.parse(value);
					} catch (Exception e) {
						throw new Exception("Exception lors du formattage de la date: " + value, e);
					}
				default:
					throw new Exception("Erreur interne: Pas de traitement pour " + parseDateType);
			}
		}

		return DATE_TIME_LONG_FORMAT.parse(value);
	}

	/**
	 * Conversion d'une date en date
	 * @param value La valeur à convertir en date
	 * @param parseDateType Type de conversion à effectuer
	 * @return un Date (null si vide)
	 * @throws Exception en cas d'erreur...
	 */
	final public static Date asDateToDate(Date value, ParseDatesTypes parseDateType) throws Exception {
		if ((value == null) || (parseDateType == null)) {
			return value;
		}

		switch (parseDateType) {
			case YYYY:
				return asStringToDate(DATE_YEAR_FORMAT.format(value), parseDateType);
			case YYYY_MM:
				return asStringToDate(DATE_YEAR_MONTH_FORMAT.format(value), parseDateType);
			case YYYY_MM_DD:
				return asStringToDate(DATE_LONG_FORMAT.format(value), parseDateType);
			case YYYY_MM_DD_HH_MM:
				return asStringToDate(DATE_TIME_SHORT_FORMAT.format(value), parseDateType);
			case YYYY_MM_DD_HH_MM_FRENCH:
				return asStringToDate(DATE_TIME_SHORT_FRENCH_FORMAT.format(value), parseDateType);
			case YYYY_MM_DD_HH_MM_SS:
				return asStringToDate(DATE_TIME_LONG_FORMAT.format(value), parseDateType);
			case YYYY_MM_DD_HH_MM_SS_SSS:
				return asStringToDate(DATE_TIME_LONG_MS_FORMAT.format(value), parseDateType);
			case HH_MM:
				return asStringToDate(TIME_FORMAT.format(value), parseDateType);
			case HH_MM_FRENCH:
				return asStringToDate(TIME_FORMAT_FRENCH.format(value), parseDateType);
			case HH_MM_SS:
				return asStringToDate(TIME_LONG_FORMAT.format(value), parseDateType);
			case HH_MM_SS_SSS:
				return asStringToDate(TIME_LONG_MS_FORMAT.format(value), parseDateType);
			case MM_SS:
				return asStringToDate(TIMEOUT_FORMAT.format(value), parseDateType);
			default:
				throw new Exception("Erreur interne: Pas de traitement pour " + parseDateType);
		}
	}

	/**
	 * Extrait le nombre de millisecondes d'une heure
	 * @param time L'heure
	 * @return le nombre de millisecondes (0 si time == null)
	 */
	final public static long asMilliseconds(Date time) {
		if (time == null) {
			return 0;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);

		long hour = calendar.get(Calendar.HOUR_OF_DAY);
		long minute = calendar.get(Calendar.MINUTE);
		long second = calendar.get(Calendar.SECOND);
		long millisecond = calendar.get(Calendar.MILLISECOND);

		return (hour * 3600000) + (minute * 60000) + (second * 1000) + millisecond;
	}

	/**
	 * Extrait le nombre de millisecondes entre 2 heures
	 * @param time1 L'heure 1
	 * @param time2 L'heure 2
	 * @return le nombre de millisecondes entre 2 heures
	 */
	final public static long asMilliseconds(Date time1, Date time2) {
		return Math.abs(asMilliseconds(time1) - asMilliseconds(time2));
	}

	/**
	 * Extrait le nombre de secondes d'une heure
	 * @param time L'heure
	 * @return le nombre de secondes (0 si time == null)
	 */
	final public static long asSeconds(Date time) {
		if (time == null) {
			return 0;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);

		long hour = calendar.get(Calendar.HOUR_OF_DAY);
		long minute = calendar.get(Calendar.MINUTE);
		long second = calendar.get(Calendar.SECOND);

		return (hour * 3600) + (minute * 60) + second;
	}

	/**
	 * Extrait le nombre de secondes entre 2 heures
	 * @param time1 L'heure 1
	 * @param time2 L'heure 2
	 * @return le nombre de secondes entre 2 heures
	 */
	final public static long asSeconds(Date time1, Date time2) {
		return Math.abs(asSeconds(time1) - asSeconds(time2));
	}

	/**
	 * Extrait le nombre de minutes d'une heure
	 * @param time L'heure
	 * @return le nombre de minutes (0 si time == null)
	 */
	final public static long asMinutes(Date time) {
		if (time == null) {
			return 0;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);

		long hour = calendar.get(Calendar.HOUR_OF_DAY);
		long minute = calendar.get(Calendar.MINUTE);

		return (hour * 60) + minute;
	}

	/**
	 * Extrait le nombre de minutes entre 2 heures
	 * @param time1 L'heure 1
	 * @param time2 L'heure 2
	 * @return le nombre de minutes entre 2 heures
	 */
	final public static long asMinutes(Date time1, Date time2) {
		return Math.abs(asMinutes(time1) - asMinutes(time2));
	}

	/**
	 * Extrait le nombre d'heures d'une heure
	 * @param time L'heure
	 * @return le nombre d'heures (0 si time == null)
	 */
	final public static long asHours(Date time) {
		if (time == null) {
			return 0;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);

		long hour = calendar.get(Calendar.HOUR_OF_DAY);

		return hour;
	}

	/**
	 * Extrait le nombre d'heures entre 2 heures
	 * @param time1 L'heure 1
	 * @param time2 L'heure 2
	 * @return le nombre d'heures entre 2 heures
	 */
	final public static long asHours(Date time1, Date time2) {
		return Math.abs(asHours(time1) - asHours(time2));
	}

	/**
	 * Extrait la date en jours depuis la date "0" du système
	 * @param date La date
	 * @return le nombre de jours (0 si date == null)
	 */
	final public static long asDays(Date date) {
		if (date == null) {
			return 0L;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(asDate(date));

		Calendar zero = Calendar.getInstance();
		zero.clear();

		// 86400000 = 24 * 60 * 60 * 1000 (1 journée en ms)
		return (calendar.getTimeInMillis() - zero.getTimeInMillis()) / 86400000;
	}

	/**
	 * Extrait la date en jours entre 2 dates
	 * @param date1 La date 1
	 * @param date1 La date 2
	 * @return le nombre de jours entre les 2 dates
	 */
	final public static long asDays(Date date1, Date date2) {
		return Math.abs(asDays(date1) - asDays(date2));
	}

	/**
	 * Extrait le jour de la semaine courant
	 * @return le jour de la semaine courant (valeur de la classe Calendar)
	 */
	@CoverageOnly // null -> retourne le jour de la semaine courante
	final public static int asDayOfWeek() {
		return asDayOfWeek(null);
	}

	/**
	 * Extrait le jour de la semaine d'une date donnée
	 * @param date La date à extraire le jour de la semaine (si null alors aujourd'hui)
	 * @return le jour de la semaine (valeur de la classe Calendar)
	 */
	@CoverageOnly // null -> retourne le jour de la semaine courante
	final public static int asDayOfWeek(Date date) {
		if (date == null) {
			date = new Date();
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		return calendar.get(Calendar.DAY_OF_WEEK);
	}

	/**
	 * Extrait le jour du mois d'une date donnée
	 * @return le jour du mois
	 */
	@CoverageOnly // null -> retourne le jour du mois courant
	final public static int asDayOfMonth() {
		return asDayOfMonth(null);
	}

	/**
	 * Extrait le jour du mois d'une date donnée
	 * @param date La date à extraire le jour du mois (si null alors aujourd'hui)
	 * @return le jour du mois
	 */
	@CoverageOnly // null -> retourne le jour du mois courant
	final public static int asDayOfMonth(Date date) {
		if (date == null) {
			date = new Date();
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		return calendar.get(Calendar.DAY_OF_MONTH);
	}

	/**
	 * Extrait la date et heure de la prochaine fois à minuit par rapport au temps actuel
	 * @return la date et heure de la prochaine fois à minuit
	 */
	final public static Date nextTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.clear();

		return nextTime(calendar.getTime());
	}

	/**
	 * Extrait la date et heure de la prochaine fois à une heure donnée par rapport au temps actuel
	 * @param time L'heure de la prochaine fois
	 * @return la date et heure de la prochaine
	 */
	final public static Date nextTime(Date time) {
		if (time == null) {
			return nextTime();
		}

		Date now = new Date();

		Date nextTime = asDateTime(now, time);

		if (now.getTime() > nextTime.getTime()) {
			return asDateTime(tomorrow(), time);
		}

		return nextTime;
	}

	/**
	 * Extrait la date de demain
	 * @return la date de demain
	 */
	final public static Date tomorrow() {
		return nextDay((Date) null);
	}

	/**
	 * Extrait la date du jour donné suivant
	 * @param date La date du jour à extraire le jour suivant
	 * @return le jour donné suivant
	 */
	final public static Date nextDay(Date date) {
		if (date == null) {
			date = new Date();
		}

		return addDays(date, 1);
	}

	/**
	 * Extrait la date du jour suivant
	 * @param businessDay Indicateur de prochain jour ouvrable (i.e lundi à vendredi)
	 * @return le jour suivant
	 */
	final public static Date nextDay(boolean businessDay) {
		return nextDay(null, businessDay);
	}

	/**
	 * Extrait la date du jour donné suivant
	 * @param date La date du jour à extraire le jour suivant
	 * @param businessDay Indicateur de prochain jour ouvrable (i.e lundi à vendredi)
	 * @return le jour donné suivant
	 */
	final public static Date nextDay(Date date, boolean businessDay) {
		if (date == null) {
			date = new Date();
		}

		if (businessDay) {
			return nextDay(date, BUSINESS_DAYS);
		}

		return nextDay(date);
	}

	/**
	 * Extrait la date du jour suivant
	 * @param days Indicateur de jours permis (i.e jour de la classe Calendar)
	 * @return le jour suivant (null si aucun jour premis)
	 */
	@AutomatedTests("10")
	final public static Date nextDay(int... days) {
		return nextDay(null, days);
	}

	/**
	 * Extrait la date du jour donné suivant
	 * @param date La date du jour à extraire le jour suivant
	 * @param days Indicateur de jours permis (i.e jour de la classe Calendar)
	 * @return le jour donné suivant (null si aucun jour premis)
	 */
	final public static Date nextDay(Date date, int... days) {
		if (date == null) {
			date = new Date();
		}

		date = nextDay(date);

		if (days != null) {
			boolean ok = false;

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);

			for (int i = 0; i < 7; i++) {
				int day = calendar.get(Calendar.DAY_OF_WEEK);

				for (int item : days) {
					if (day == item) {
						ok = true;
						break;
					}
				}

				if (ok) {
					break;
				}

				date = nextDay(date);

				calendar.setTime(date);
			}

			if (!ok) {
				return null;
			}
		}

		return date;
	}

	/**
	 * Extrait la date du prochain mois
	 * @return la date du prochain mois
	 */
	final public static Date nextMonth() {
		return nextMonth(null);
	}

	/**
	 * Extrait la date du prochain mois
	 * @param date La date à extraire le prochain mois
	 * @return la date du prochain mois
	 */
	final public static Date nextMonth(Date date) {
		if (date == null) {
			date = new Date();
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, 1);

		return calendar.getTime();
	}

	/**
	 * Extrait la date du prochain mois au même jour du mois donné (si possible, attention aux valeurs entre 29 et 31 !!!)
	 * @param day Le jour du mois donné
	 * @return la date du prochain mois
	 */
	final public static Date nextMonth(int day) {
		return nextMonth(null, day);
	}

	/**
	 * Extrait la date du prochain mois au même jour du mois donné (si possible, attention aux valeurs entre 29 et 31 !!!)
	 * @param date La date à extraire le prochain mois
	 * @param day Le jour du mois donné
	 * @return la date du prochain mois
	 */
	final public static Date nextMonth(Date date, int day) {
		if (date == null) {
			date = new Date();
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, max(1, min(calendar.getActualMaximum(Calendar.DAY_OF_MONTH), day)));
		calendar.add(Calendar.MONTH, 1);
		calendar.set(Calendar.DAY_OF_MONTH, max(1, min(calendar.getActualMaximum(Calendar.DAY_OF_MONTH), day)));

		return calendar.getTime();
	}

	/**
	 * Extrait la date de hier
	 * @return la date de hier
	 */
	final public static Date yesterday() {
		return previousDay((Date) null);
	}

	/**
	 * Extrait la date du jour donné précédent
	 * @param date La date du jour à extraire le jour précédent
	 * @return le jour donné précédent
	 */
	final public static Date previousDay(Date date) {
		if (date == null) {
			date = new Date();
		}

		return addDays(date, -1);
	}

	/**
	 * Extrait la date du jour précédent
	 * @param businessDay Indicateur de prochain jour ouvrable (i.e lundi à vendredi)
	 * @return le jour précédent
	 */
	final public static Date previousDay(boolean businessDay) {
		return previousDay(null, businessDay);
	}

	/**
	 * Extrait la date du jour donné précédent
	 * @param date La date du jour à extraire le jour précédent
	 * @param businessDay Indicateur de prochain jour ouvrable (i.e lundi à vendredi)
	 * @return le jour donné précédent
	 */
	final public static Date previousDay(Date date, boolean businessDay) {
		if (date == null) {
			date = new Date();
		}

		if (businessDay) {
			return previousDay(date, BUSINESS_DAYS);
		}

		return previousDay(date);
	}

	/**
	 * Extrait la date du jour précédent
	 * @param days Indicateur de jours permis (i.e jour de la classe Calendar)
	 * @return le jour précédent (null si aucun jour premis)
	 */
	@AutomatedTests("10")
	final public static Date previousDay(int... days) {
		return previousDay(null, days);
	}

	/**
	 * Extrait la date du jour donné précédent
	 * @param date La date du jour à extraire le jour précédent
	 * @param days Indicateur de jours permis (i.e jour de la classe Calendar)
	 * @return le jour donné précédent (null si aucun jour premis)
	 */
	final public static Date previousDay(Date date, int... days) {
		if (date == null) {
			date = new Date();
		}

		date = previousDay(date);

		if (days != null) {
			boolean ok = false;

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);

			for (int i = 6; i >= 0; i--) {
				int day = calendar.get(Calendar.DAY_OF_WEEK);

				for (int item : days) {
					if (day == item) {
						ok = true;
						break;
					}
				}

				if (ok) {
					break;
				}

				date = previousDay(date);

				calendar.setTime(date);
			}

			if (!ok) {
				return null;
			}
		}

		return date;
	}

	/**
	 * Extrait la date du mois précédent
	 * @return la date du mois précédent
	 */
	final public static Date previousMonth() {
		return previousMonth(null);
	}

	/**
	 * Extrait la date du mois précédent
	 * @param date La date à extraire le prochain mois
	 * @return la date du mois précédent
	 */
	final public static Date previousMonth(Date date) {
		if (date == null) {
			date = new Date();
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, -1);

		return calendar.getTime();
	}

	/**
	 * Extrait la date du mois précédent au même jour du mois donné (si possible, attention aux valeurs entre 29 et 31 !!!)
	 * @param day Le jour du mois donné
	 * @return la date du mois précédent
	 */
	final public static Date previousMonth(int day) {
		return previousMonth(null, day);
	}

	/**
	 * Extrait la date du mois précédent au même jour du mois donné (si possible, attention aux valeurs entre 29 et 31 !!!)
	 * @param date La date à extraire le prochain mois
	 * @param day Le jour du mois donné
	 * @return la date du mois précédent
	 */
	final public static Date previousMonth(Date date, int day) {
		if (date == null) {
			date = new Date();
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, max(1, min(calendar.getActualMaximum(Calendar.DAY_OF_MONTH), day)));
		calendar.add(Calendar.MONTH, -1);
		calendar.set(Calendar.DAY_OF_MONTH, max(1, min(calendar.getActualMaximum(Calendar.DAY_OF_MONTH), day)));

		return calendar.getTime();
	}

	/**
	 * Ajoute un nombre de millisecondes à une date donnée
	 * @param date La date à ajouter les millisecondes
	 * @param milliseconds Le nombre de millisecondes
	 * @return une nouvelle date (null si date == null)
	 */
	final public static Date addMilliseconds(Date date, int milliseconds) {
		return addDaysTime(date, 0, 0, 0, 0, milliseconds);
	}

	/**
	 * Ajoute un nombre de secondes à une date donnée
	 * @param date La date à ajouter les secondes
	 * @param seconds Le nombre de secondes
	 * @return une nouvelle date (null si date == null)
	 */
	final public static Date addSeconds(Date date, int seconds) {
		return addDaysTime(date, 0, 0, 0, seconds, 0);
	}

	/**
	 * Ajoute un nombre de minutes et secondes à une date donnée
	 * @param date La date à ajouter les minutes
	 * @param minutes Le nombre de minutes
	 * @return une nouvelle date (null si date == null)
	 */
	final public static Date addMinutes(Date date, int minutes) {
		return addDaysTime(date, 0, 0, minutes, 0, 0);
	}

	/**
	 * Ajoute un nombre d'heures à une date donnée
	 * @param date La date à ajouter les heures
	 * @param hours Le nombre d'heures
	 * @return une nouvelle date (null si date == null)
	 */
	final public static Date addHours(Date date, int hours) {
		return addDaysTime(date, 0, hours, 0, 0, 0);
	}

	/**
	 * Ajoute un nombre d'heures, minutes et secondes à une date donnée
	 * @param date La date à ajouter le temps
	 * @param hours Le nombre d'heures
	 * @param minutes Le nombre de minutes
	 * @param seconds Le nombre de secondes
	 * @return une nouvelle date (null si date == null)
	 */
	final public static Date addTime(Date date, int hours, int minutes, int seconds) {
		return addDaysTime(date, 0, hours, minutes, seconds, 0);
	}

	/**
	 * Ajoute un nombre d'heures, minutes, secondes et millisecondes à une date donnée
	 * @param date La date à ajouter le temps
	 * @param hours Le nombre d'heures
	 * @param minutes Le nombre de minutes
	 * @param seconds Le nombre de secondes
	 * @param milliseconds Le nombre de millisecondes
	 * @return une nouvelle date (null si date == null)
	 */
	final public static Date addTime(Date date, int hours, int minutes, int seconds, int milliseconds) {
		return addDaysTime(date, 0, hours, minutes, seconds, milliseconds);
	}

	/**
	 * Ajoute un nombre de jours à une date donnée
	 * @param date La date à ajouter les jours
	 * @param days Le nombre de jours
	 * @return une nouvelle date (null si date == null)
	 */
	final public static Date addDays(Date date, int days) {
		return addDaysTime(date, days, 0, 0, 0, 0);
	}

	/**
	 * Ajoute du temps à une date donnée
	 * @param date La date à ajouter le temps
	 * @param days Le nombre de jours
	 * @param hours Le nombre d'heures
	 * @param minutes Le nombre de minutes
	 * @param seconds Le nombre de secondes
	 * @param milliseconds Le nombre de millisecondes
	 * @return une nouvelle date (null si date == null)
	 */
	@AutomatedTests(value = { "new java.util.Date()", "0,1", "0,1", "0,1", "0,1", "0,1" }, iterate = true)
	final public static Date addDaysTime(Date date, int days, int hours, int minutes, int seconds, int milliseconds) {
		if (date == null) {
			return null;
		}

		if ((days == 0) && (hours == 0) && (minutes == 0) && (seconds == 0) && (milliseconds == 0)) {
			return date;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		calendar.add(Calendar.MILLISECOND, milliseconds);
		calendar.add(Calendar.SECOND, seconds);
		calendar.add(Calendar.MINUTE, minutes);
		calendar.add(Calendar.HOUR, hours);
		calendar.add(Calendar.DATE, days);

		return calendar.getTime();
	}

	/**
	 * Nombre aléatoire entre 0 et max
	 * @param max La valeur maximale
	 * @return le monbre aléatoire
	 */
	final public static int random(int max) {
		return random(0, max);
	}

	/**
	 * Nombre aléatoire entre min et max
	 * @param min La valeur minimale
	 * @param max La valeur maximale
	 * @return le monbre aléatoire
	 */
	final public static int random(int min, int max) {
		return min + RANDOM.nextInt(1 + (max - min));
	}

	/**
	 * Nombre aléatoire entre 0 et max
	 * @param max La valeur maximale
	 * @return le monbre aléatoire
	 */
	final public static double random(double max) {
		return random(0.0, max);
	}

	/**
	 * Nombre aléatoire entre min et max
	 * @param min La valeur minimale
	 * @param max La valeur maximale
	 * @return le monbre aléatoire
	 */
	final public static double random(double min, double max) {
		return min + RANDOM.nextDouble() * (max - min);
	}

	/**
	 * Extrait un UUID aléatoire
	 * @return le UUID aléatoire
	 */
	@CoverageOnly
	final public static String randomUUID() {
		return UUID.randomUUID().toString();
	}

	/**
	 * Traitement d'une chaine de caractères pour du code en java
	 * @param value Valeur à convertir
	 * @return la chaine de caractères normalisée entre guillemets
	 */
	@AutomatedTests("\b\t\n\f\r'\"\\")
	@AutomatedTests("new String(new char[] { 2, 3, 4 })")
	final public static String asJavaString(String value) {
		if (isEmpty(value)) {
			return "\"\"";
		}

		StringBuffer resultat = new StringBuffer();
		resultat.append('"');

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == 8) {
				resultat.append("\\b");
			} else if (c == 9) {
				resultat.append("\\t");
			} else if (c == 10) {
				resultat.append("\\n");
			} else if (c == 12) {
				resultat.append("\\f");
			} else if (c == 13) {
				resultat.append("\\r");
			} else if (c == '\'') {
				resultat.append("\\'");
			} else if (c == '"') {
				resultat.append("\\\"");
			} else if (c == '\\') {
				resultat.append("\\\\");
			} else if (Character.isISOControl(c)) {
				resultat.append("\\0x" + toHexa((byte) c));
			} else {
				resultat.append(c);
			}
		}

		resultat.append('"');
		return resultat.toString();
	}

	/**
	 * Extrait la version de Java
	 * @return la version de Java
	 */
	@CoverageOnly
	final public static String getJavaVersion() {
		return JAVA_VERSION;
	}

	/**
	 * Determine si la plateforme est Windows
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isEclipseIDE() {
		return ECLIPSE_IDE;
	}

	/**
	 * Determine si la plateforme est Windows
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isWindows() {
		return WINDOWS_OS;
	}

	/**
	 * Extrait la version de Windows (ex: 7, 10, etc.)
	 * @return la version de Windows (null si non Windows)
	 */
	@CoverageOnly
	final public static String getWindowsVersion() {
		return WINDOWS_OS_VERSION;
	}

	/**
	 * Determine si la plateforme est Windows 32 bits (x86)
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isWindows32() {
		return WINDOWS_32_OS;
	}

	/**
	 * Determine si la plateforme est Windows 64 bits (amd)
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isWindows64() {
		return WINDOWS_64_OS;
	}

	/**
	 * Determine si la plateforme est Mac
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isMac() {
		return MAC_OS;
	}

	/**
	 * Determine si la plateforme est Unix
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isUnix() {
		return AIX_OS || LINUX_OS || SUN_OS || HP_UX_OS;
	}

	/**
	 * Determine si la plateforme est AIX
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isAIX() {
		return AIX_OS;
	}

	/**
	 * Determine si la plateforme est Linux
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isLinux() {
		return LINUX_OS;
	}

	/**
	 * Determine si la plateforme est Sun
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isSun() {
		return SUN_OS;
	}

	/**
	 * Determine si la plateforme est HP-UX
	 * @return vrai si c'est le cas
	 */
	@CoverageOnly
	final public static boolean isHP_UX() {
		return HP_UX_OS;
	}

	/**
	 * Initialise le code de retour au lieu d'utiliser System.exit(int)
	 * @param code Le code de retour à initialiser
	 */
	final public static void setExitCode(int code) {
		if (WINDOWS_OS) {
			System.setProperty("sun.java.command", "exit:" + code); // C:\> java Main & echo %errorlevel%
		} else {
			System.setProperty("exit.code", Integer.toString(code)); // $ java Main; echo $?
		}
	}

	/**
	 * Détermine si une valeur correspond à un patron composé de caractères ! (négation), ? et * (wildcards)
	 * @param value La valeur à déterminer
	 * @param pattern Le patron composé de caractères ! (négation), ? et * (wildcards)
	 * @return vrai si correspond
	 */
	final public static boolean isMatching(String value, String pattern) {
		if ((value == null) || (pattern == null)) {
			return areEquals(value, pattern);
		}

		return new PatternData(pattern).isMatching(value);
	}

	/**
	 * Détermine si une valeur ne correspond pas à un patron composé de caractères ! (négation), ? et * (wildcards)
	 * @param value La valeur à déterminer
	 * @param pattern Le patron composé de caractères ! (négation), ? et * (wildcards)
	 * @return vrai si correspond
	 */
	final public static boolean isNotMatching(String value, String pattern) {
		if ((value == null) || (pattern == null)) {
			return areEquals(value, pattern);
		}

		return new PatternData(pattern).isNotMatching(value);
	}

	/**
	 * Convertion d'un byte signé en int non signé
	 * @param b Le byte signé
	 * @return le int non signé
	 */
	final public static int unsignedByteToInt(byte b) {
		return (int) b & 0xFF;
	}

	/**
	 * Extrait l'information d'un tableau binaire séparés par des CRLF
	 * @param list Le tableau binaire
	 * @param skip Indicateur de saut de ligne vide
	 * @param trim Indicateur de trime
	 * @return un List<String>
	 */
	@AutomatedTests(value = { "new byte[] { (byte) 0, (byte) 13, (byte) 10, (byte) 0 }", "false;true", "false;true" }, separator = ';', iterate = true)
	@AutomatedTests(value = { "new byte[] { (byte) 0, (byte) 13, (byte) 10, (byte) 13, (byte) 10, (byte) 0 }", "false;true", "false;true" }, separator = ';', iterate = true)
	final public static List<String> doArrayOfBytes(byte[] list, boolean skip, boolean trim) {
		List<String> result = new ArrayList<String>();

		if (list != null) {
			if (list.length > 0) {
				int pos = 0;
				byte[] buf = new byte[list.length];

				for (int i = 0; i < list.length; i++) {
					byte b = list[i];

					if (b == 13) {
						continue;
					} else if (b == 10) {
						if (skip) {
							if (pos > 0) {
								if (trim) {
									result.add(new String(buf, 0, pos).trim());
								} else {
									result.add(new String(buf, 0, pos));
								}
							}
						} else {
							if (trim) {
								result.add(new String(buf, 0, pos).trim());
							} else {
								result.add(new String(buf, 0, pos));
							}
						}

						pos = 0;
					} else {
						buf[pos++] = b;
					}
				}

				if (pos > 0) {
					if (trim) {
						result.add(new String(buf, 0, pos).trim());
					} else {
						result.add(new String(buf, 0, pos));
					}
				}
			}
		}

		return result;
	}

	/**
	 * Extrait une liste de strings séparés par des ";" (ex: s1;s2)
	 * @param list Liste des strings
	 * @return un List<String>
	 */
	final public static List<String> asStringList(String list) {
		return asStringList(list, ";");
	}

	/**
	 * Extrait une liste de strings séparés par un séparateur (ex: s1;s2)
	 * @param list Liste des strings
	 * @param separator Le caractére qui sépare les éléments de la liste
	 * @return un List<String>
	 */
	@AutomatedTests({ "s1;s2", "null", "s1;s2", ",", "s1;s2", ";" })
	final public static List<String> asStringList(String list, String separator) {
		List<String> result = new ArrayList<String>();

		if (!OutilsBase.isEmpty(list)) {
			if (OutilsBase.isEmpty(separator)) {
				result.add(list);
			} else if (list.indexOf(separator) == -1) {
				result.add(list);
			} else {
				StringTokenizer tokens = new StringTokenizer(list, separator);

				while (tokens.hasMoreTokens()) {
					result.add(tokens.nextToken());
				}
			}

		}

		return result;
	}

	/**
	 * Extrait une liste contenue dans un StringBuffer séparés par des CRLF
	 * @param list Le StringBuffer
	 * @return un List<String>
	 */
	@AutomatedTests({ "new StringBuffer()", "new StringBuffer(\"AAA\")" })
	final public static List<String> asStringList(StringBuffer list) {
		if (list != null) {
			if (list.length() > 0) {
				return doArrayOfBytes(list.toString().getBytes(), false, false);
			}
		}

		return new ArrayList<String>();
	}

	/**
	 * Extrait une liste contenue dans un tableau binaire séparés par des CRLF
	 * @param list Le tableau binaire
	 * @return un List<String>
	 */
	final public static List<String> asStringList(byte[] list) {
		return doArrayOfBytes(list, false, false);
	}

	/**
	 * Extrait une liste contenue dans un array d'objets
	 * @param list L'array d'objets
	 * @return un List<String>
	 */
	final public static List<String> asStringList(Object[] list) {
		List<String> result = new ArrayList<String>();

		if (list != null) {
			for (Object value : list) {
				result.add(asString(value));
			}
		}

		return result;
	}

	/**
	 * Extrait une liste contenue dans un Throwable
	 * @param t Le Throwable
	 * @return un List<String>
	 */
	final public static List<String> asStringList(Throwable t) {
		if (t != null) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PrintStream ps = new PrintStream(baos);
			t.printStackTrace(ps);
			return doArrayOfBytes(baos.toByteArray(), true, false);
		}

		return new ArrayList<String>();
	}

	/**
	 * Extrait une liste de pairs séparés par des ";" (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @return un List<NameValue>
	 */
	final public static List<NameValue> asNameValueList(String list) {
		return asNameValueList(list, ';');
	}

	/**
	 * Extrait une liste de pairs séparés par des séparateurs (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @return un List<NameValue>
	 */
	final public static List<NameValue> asNameValueList(String list, char separator) {
		return asNameValueList(list, separator, false);
	}

	/**
	 * Extrait une liste de pairs séparés par des ";" (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param addName Indicateur qui force a avoir un nom pour à la paire
	 * @return un List<NameValue>
	 */
	final public static List<NameValue> asNameValueList(String list, boolean addName) {
		return asNameValueList(list, ';', addName);
	}

	/**
	 * Extrait une liste de pairs séparés par des séparateurs (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param separator Le séparateur entre chaque élément
	 * @param addName Indicateur qui force a avoir un nom pour à la paire
	 * @return un List<NameValue>
	 */
	@AutomatedTests(value = { "n1=v1;n2=v2;n2;=v2", ";", "false,true" }, iterate = true)
	final public static List<NameValue> asNameValueList(String list, char separator, boolean addName) {
		List<NameValue> result = new ArrayList<NameValue>();

		while (!isEmpty(list)) {
			String s = list;
			int pos = list.indexOf(separator);

			if (pos != -1) {
				s = list.substring(0, pos);
				list = list.substring(pos + 1);
			} else {
				list = "";
			}

			pos = s.indexOf("=");

			if (pos != -1) {
				result.add(new NameValue(s.substring(0, pos), s.substring(pos + 1)));
			} else {
				result.add(new NameValue(addName ? "Valeur" : "", s));
			}
		}

		return result;
	}

	/**
	 * Extrait une liste de pairs séparés par des ";" (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param addName Indicateur qui force a avoir un nom à la paire
	 * @param atEnd Indicateur de recherche du "=" à la fin de la paire
	 * @return un List<NameValue>
	 */
	final public static List<NameValue> asNameValueList(String list, boolean addName, boolean atEnd) {
		return asNameValueList(list, ';', addName, atEnd);
	}

	/**
	 * Extrait une liste de pairs séparés par des séparateurs (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param separator Le séparateur entre chaque élément
	 * @param addName Indicateur qui force a avoir un nom à la paire
	 * @param atEnd Indicateur de recherche du "=" à la fin de la paire
	 * @return un List<NameValue>
	 */
	@AutomatedTests(value = { "n1=v1;n2=v2;n3=n4=v34;n2;=v2", ";", "false,true", "false,true" }, iterate = true)
	final public static List<NameValue> asNameValueList(String list, char separator, boolean addName, boolean atEnd) {
		List<NameValue> result = new ArrayList<NameValue>();

		while (!isEmpty(list)) {
			String s = list;
			int pos = list.indexOf(separator);

			if (pos != -1) {
				s = list.substring(0, pos);
				list = list.substring(pos + 1);
			} else {
				list = "";
			}

			if (atEnd) {
				pos = s.lastIndexOf("=");
			} else {
				pos = s.indexOf("=");
			}

			if (pos != -1) {
				result.add(new NameValue(s.substring(0, pos), s.substring(pos + 1)));
			} else {
				result.add(new NameValue(addName ? "valeur" : "", s));
			}
		}

		return result;
	}

	/**
	 * Extrait une liste de pairs séparés par des ";" (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param prefix Prefixe à ajouter au nom de la paire
	 * @return un List<NameValue>
	 */
	final public static List<NameValue> asNameValueList(String list, String prefix) {
		return asNameValueList(list, ';', prefix);
	}

	/**
	 * Extrait une liste de pairs séparés par des séparateurs (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param separator Le séparateur entre chaque élément
	 * @param prefix Prefixe à ajouter au nom de la paire
	 * @return un List<NameValue>
	 */
	@AutomatedTests({ "n1=v1;n2=v2;n2;=v2", ";", "prefix" })
	final public static List<NameValue> asNameValueList(String list, char separator, String prefix) {
		List<NameValue> result = new ArrayList<NameValue>();

		while (!isEmpty(list)) {
			String s = list;
			int pos = list.indexOf(separator);

			if (pos != -1) {
				s = list.substring(0, pos);
				list = list.substring(pos + 1);
			} else {
				list = "";
			}

			pos = s.indexOf("=");

			if (pos != -1) {
				result.add(new NameValue(prefix + s.substring(0, pos), s.substring(pos + 1)));
			} else {
				result.add(new NameValue(prefix, s));
			}
		}

		return result;
	}

	/**
	 * Extrait une liste de pairs séparés par des ";" (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param prefix Prefixe à ajouter au nom de la paire
	 * @param atEnd Indicateur de recherche du "=" à la fin de la paire
	 * @return un List<NameValue>
	 */
	final public static List<NameValue> asNameValueList(String list, String prefix, boolean atEnd) {
		return asNameValueList(list, ';', prefix, atEnd);
	}

	/**
	 * Extrait une liste de pairs séparés par des séparateurs (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param separator Le séparateur entre chaque élément
	 * @param prefix Prefixe à ajouter au nom de la paire
	 * @param atEnd Indicateur de recherche du "=" à la fin de la paire
	 * @return un List<NameValue>
	 */
	@AutomatedTests(value = { "n1=v1;n2=v2;n3=n4=v34;n2;=v2", ";", "prefix", "false,true" }, iterate = true)
	final public static List<NameValue> asNameValueList(String list, char separator, String prefix, boolean atEnd) {
		List<NameValue> result = new ArrayList<NameValue>();

		while (!isEmpty(list)) {
			String s = list;
			int pos = list.indexOf(separator);

			if (pos != -1) {
				s = list.substring(0, pos);
				list = list.substring(pos + 1);
			} else {
				list = "";
			}

			if (atEnd) {
				pos = s.lastIndexOf("=");
			} else {
				pos = s.indexOf("=");
			}

			if (pos != -1) {
				result.add(new NameValue(prefix + s.substring(0, pos), s.substring(pos + 1)));
			} else {
				result.add(new NameValue(prefix, s));
			}
		}

		return result;
	}

	/**
	 * Extrait une liste de pairs séparés par des ";" (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param force Indicateur qui force a avoir un nom et une valeur à la paire
	 * @return un List<NameValue>
	 */
	final public static List<NameValue> asNameValueList(String list, int force) {
		return asNameValueList(list, ';', force);
	}

	/**
	 * Extrait une liste de pairs séparés par des séparateurs (ex: n1=v1;n2=v2)
	 * @param list Liste des pairs
	 * @param separator Le séparateur entre chaque élément
	 * @param force Indicateur qui force a avoir un nom et une valeur à la paire
	 * @return un List<NameValue>
	 */
	@AutomatedTests(value = { "n1=v1;n2=v2;n3=n4=v34;n2;n6=;=v2", ";", "0,1" }, iterate = true)
	final public static List<NameValue> asNameValueList(String list, char separator, int force) {
		List<NameValue> result = new ArrayList<NameValue>();

		while (!isEmpty(list)) {
			String s = list;
			int pos = list.indexOf(separator);

			if (pos != -1) {
				s = list.substring(0, pos);
				list = list.substring(pos + 1);
			} else {
				list = "";
			}

			pos = s.indexOf("=");

			if (pos != -1) {
				String n = s.substring(0, pos);
				String v = s.substring(pos + 1);

				if (isEmpty(v)) {
					result.add(new NameValue(n, (force != 0) ? n : ""));
				} else {
					result.add(new NameValue(n, v));
				}
			} else {
				result.add(new NameValue(s, (force != 0) ? s : ""));
			}
		}

		return result;
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des ";" (ex: s1;s2)
	 * @param list Liste des données
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests("1,2,3")
	final public static String toList(List<?> list) {
		return toList(list, ";");
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par un séparateur
	 * @param list Liste des données
	 * @param separator Le séparateur entre chaque élément
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests({ "1,2,3", ";" })
	final public static String toList(List<?> list, String separator) {
		return getStringBufferList(list, separator).toString();
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par un séparateur
	 * @param list Liste des données
	 * @param separator Le séparateur entre chaque élément
	 * @param between Mettre chaque élément entre deux strings spécifiques
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests({ "1,2,3", ";", "$" })
	final public static String toList(List<?> list, String separator, String between) {
		return getStringBufferList(list, separator, between).toString();
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par un séparateur
	 * @param list Liste des données
	 * @param separator Le séparateur entre chaque élément
	 * @param left Préfixé chaque élément entre avec le string donné
	 * @param right Suffixé chaque élément entre avec le string donné
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests({ "1,2,3", ";", "(", ")" })
	final public static String toList(List<?> list, String separator, String left, String right) {
		return getStringBufferList(list, separator, left, right).toString();
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des CRLF
	 * @param list Liste des données
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests("1,2,3")
	final public static String toCRLFList(List<?> list) {
		return getCRLFStringBufferList(list).toString();
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des CRLF
	 * @param list Liste des données
	 * @param endWithCRLF Indicateur de terminer avec un CRLF
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests({ "1,2,3", "false" })
	@AutomatedTests({ "1,2,3", "true" })
	final public static String toCRLFList(List<?> list, boolean endWithCRLF) {
		return getCRLFStringBufferList(list, endWithCRLF).toString();
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des CRLF de Windows
	 * @param list Liste des données
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests("1,2,3")
	final public static String toWindowsCRLFList(List<?> list) {
		return getWindowsCRLFStringBufferList(list).toString();
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des CRLF de Windows
	 * @param list Liste des données
	 * @param endWithCRLF Indicateur de terminer avec un CRLF de Windows
	 * @return la liste sous forme d'une string
	 */
	@AutomatedTests({ "1,2,3", "false" })
	@AutomatedTests({ "1,2,3", "true" })
	final public static String toWindowsCRLFList(List<?> list, boolean endWithCRLF) {
		return getWindowsCRLFStringBufferList(list, endWithCRLF).toString();
	}

	/**
	 * Retourne une liste de strings pour un IN dans un SQL
	 * @param list Liste des données
	 * @return la liste pour le IN dans un SQL
	 */
	@AutomatedTests("1,,2")
	final public static String getSqlInList(List<?> list) {
		StringBuffer result = new StringBuffer();

		if (list != null) {
			for (Object obj : list) {
				if (obj != null) {
					String s = obj.toString();

					if (result.length() > 0) {
						result.append(", ");
					}

					result.append('\'');
					result.append(parseDatabaseQuote(s));
					result.append('\'');
				}
			}
		}

		return result.toString();
	}

	/**
	 * Retourne la liste sous forme d'un OutputStream des éléments séparés par des CRLF
	 * @param list Liste des données
	 * @return la liste sous forme d'un OutputStream
	 */
	@AutomatedTests("1,,2")
	final public static OutputStream getOutputStreamList(List<?> list) {
		ByteArrayOutputStream result = new ByteArrayOutputStream();

		if (list != null) {
			for (Object obj : list) {
				if (obj != null) {
					String data = obj.toString();
					result.write(data.getBytes(), 0, data.length());
					result.write(LINE_SEPARATOR.getBytes(), 0, LINE_SEPARATOR.length());
				}
			}
		}

		return result;
	}

	/**
	 * Extrait le nom du fichier compressé pour un nom de fichier css donné
	 * @param filename Le nom du fichier css à extraire
	 * @return le nom du fichier compressé
	 */
	@AutomatedTests("a.css")
	final public static String getMinifyCSSFilename(String filename) {
		if (!OutilsBase.isEmpty(filename)) {
			if (OutilsBase.endsWithIgnoreCase(filename, OutilsCommun.CSS_EXTENSION)) {
				return filename.substring(0, filename.length() - OutilsCommun.CSS_EXTENSION.length()) + OutilsCommun.MINIFY_CSS_EXTENSION;
			}

			return filename + OutilsCommun.MINIFY_CSS_EXTENSION;
		}

		return filename;
	}

	/**
	 * Extrait le fichier compressé pour un fichier css donné
	 * @param file Le nom du fichier css à extraire
	 * @return le fichier compressé
	 * @throws IOException en cas d'erreur...
	 */
	final public static File getMinifyCSSFile(File file) throws IOException {
		if (file != null) {
			return new File(getMinifyCSSFilename(file.getCanonicalPath()));
		}

		return file;
	}

	/**
	 * Ajoute d'une liste a un fichier
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void addListToFile(List<?> list, String filename) throws IOException {
		addListToFile(list, filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Ajoute d'une liste a un fichier
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 1, iterate = true)
	final public static void addListToFile(List<?> list, String filename, FilesCharsetsTypes charsetType) throws IOException {
		if (list != null) {
			new SaveListToFile(list, filename, charsetType, true);
		}
	}

	/**
	 * Ajoute d'une liste a un fichier
	 * @param list Liste des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void addListToFile(List<?> list, File file) throws IOException {
		addListToFile(list, file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Ajoute d'une liste a un fichier
	 * @param list Liste des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.ISO_8859_1" }, filenames = 1, iterate = true)
	final public static void addListToFile(List<?> list, File file, FilesCharsetsTypes charsetType) throws IOException {
		if (list != null) {
			new SaveListToFile(list, file, charsetType, true);
		}
	}

	/**
	 * Sauvegarde d'une liste a un fichier
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void saveListToFile(List<?> list, String filename) throws IOException {
		saveListToFile(list, filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Sauvegarde d'une liste a un fichier
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 1, iterate = true)
	final public static void saveListToFile(List<?> list, String filename, FilesCharsetsTypes charsetType) throws IOException {
		if (list != null) {
			new SaveListToFile(list, filename, charsetType, false);
		}
	}

	/**
	 * Sauvegarde d'une liste a un fichier
	 * @param list Liste des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void saveListToFile(List<?> list, File file) throws IOException {
		saveListToFile(list, file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Sauvegarde d'une liste a un fichier
	 * @param list Liste des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.ISO_8859_1" }, filenames = 1, iterate = true)
	final public static void saveListToFile(List<?> list, File file, FilesCharsetsTypes charsetType) throws IOException {
		if (list != null) {
			new SaveListToFile(list, file, charsetType, false);
		}
	}

	/**
	 * Ajoute d'un texte a un fichier
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void addToFile(String text, String filename) throws IOException {
		addToFile(text, filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Ajoute d'un texte a un fichier
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 1, iterate = true)
	final public static void addToFile(String text, String filename, FilesCharsetsTypes charsetType) throws IOException {
		if (text != null) {
			new SaveTextToFile(text, filename, charsetType, true);
		}
	}

	/**
	 * Ajoute d'un texte a un fichier
	 * @param text Texte des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void addToFile(String text, File file) throws IOException {
		addToFile(text, file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Ajoute d'un texte a un fichier
	 * @param text Texte des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.ISO_8859_1" }, filenames = 1, iterate = true)
	final public static void addToFile(String text, File file, FilesCharsetsTypes charsetType) throws IOException {
		if (text != null) {
			new SaveTextToFile(text, file, charsetType, true);
		}
	}

	/**
	 * Sauvegarde d'un texte a un fichier
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void saveToFile(String text, String filename) throws IOException {
		saveToFile(text, filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Sauvegarde d'un texte a un fichier
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 1, iterate = true)
	final public static void saveToFile(String text, String filename, FilesCharsetsTypes charsetType) throws IOException {
		if (text != null) {
			new SaveTextToFile(text, filename, charsetType, false);
		}
	}

	/**
	 * Sauvegarde d'un texte a un fichier
	 * @param text Texte des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt" }, filenames = 1, iterate = true)
	final public static void saveToFile(String text, File file) throws IOException {
		saveToFile(text, file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Sauvegarde d'un texte a un fichier
	 * @param text Texte des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",A", "OutilsCommun.txt", "FilesCharsetsTypes.ISO_8859_1" }, filenames = 1, iterate = true)
	final public static void saveToFile(String text, File file, FilesCharsetsTypes charsetType) throws IOException {
		if (text != null) {
			new SaveTextToFile(text, file, charsetType, false);
		}
	}

	/**
	 * Ajout d'un contenu binaire a un fichier
	 * @param data Contenu binaire des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "100", "OutilsCommun.txt" }, filenames = 1)
	final public static void addToFile(byte[] data, String filename) throws IOException {
		addToFile(data, new File(filename));
	}

	/**
	 * Ajout d'un contenu binaire a un fichier
	 * @param data Contenu binaire des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "100", "OutilsCommun.txt" }, filenames = 1)
	final public static void addToFile(byte[] data, File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file, true);

		try {
			fos.write(data);
			fos.flush();
		} finally {
			fos.close();
		}
	}

	/**
	 * Sauvegarde d'un contenu binaire a un fichier
	 * @param data Contenu binaire des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "100", "OutilsCommun.txt" }, filenames = 1)
	final public static void saveToFile(byte[] data, String filename) throws IOException {
		saveToFile(data, new File(filename));
	}

	/**
	 * Sauvegarde d'un contenu binaire a un fichier
	 * @param data Contenu binaire des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "100", "OutilsCommun.txt" }, filenames = 1)
	final public static void saveToFile(byte[] data, File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);

		try {
			fos.write(data);
			fos.flush();
		} finally {
			fos.close();
		}
	}

	/**
	 * Ajout d'un flux de données a un fichier
	 * @param inputStream Flux de données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "InputStream.txt", "OutilsCommun.txt" }, filenames = { 0, 1 })
	final public static void addToFile(InputStream inputStream, String filename) throws IOException {
		addToFile(inputStream, new File(filename));
	}

	/**
	 * Ajout d'un flux de données a un fichier
	 * @param inputStream Flux de données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "InputStream.txt", "OutilsCommun.txt" }, filenames = { 0, 1 })
	final public static void addToFile(InputStream inputStream, File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file, true);

		try {
			int read;

			byte[] buf = new byte[32768];

			while ((read = inputStream.read(buf)) != -1) {
				fos.write(buf, 0, read);
			}

			fos.flush();
		} finally {
			fos.close();
			inputStream.close();
		}
	}

	/**
	 * Sauvegarde d'un flux de données a un fichier
	 * @param inputStream Flux de données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "InputStream.txt", "OutilsCommun.txt" }, filenames = { 0, 1 })
	final public static void saveToFile(InputStream inputStream, String filename) throws IOException {
		saveToFile(inputStream, new File(filename));
	}

	/**
	 * Sauvegarde d'un flux de données a un fichier
	 * @param inputStream Flux de données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "InputStream.txt", "OutilsCommun.txt" }, filenames = { 0, 1 })
	final public static void saveToFile(InputStream inputStream, File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);

		try {
			int read;

			byte[] buf = new byte[32768];

			while ((read = inputStream.read(buf)) != -1) {
				fos.write(buf, 0, read);
			}

			fos.flush();
		} finally {
			fos.close();
			inputStream.close();
		}
	}

	/**
	 * Sauvegrade des données CSV dans un fichier
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param filename Nom du fichier CSV
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "null", "CSVSeparatorsTypes.FRENCH", "true", "OutilsCommun.csv" }, filenames = { 3 })
	final public static void saveToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, String filename) throws IOException {
		saveToFile(csvFileData, separator, escapeQuotes, filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "new CSVFileData()", "CSVSeparatorsTypes.FRENCH", "true", "OutilsCommun.csv", "FilesCharsetsTypes.UTF_8" }, filenames = { 3 })
	final public static void saveToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, String filename, FilesCharsetsTypes charsetType) throws IOException {
		if (csvFileData != null) {
			new SaveCSVFormatToFile(csvFileData, separator, escapeQuotes, filename, charsetType);
		}
	}

	/**
	 * Sauvegrade des données CSV dans un fichier
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param file Fichier CSV
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "null", "CSVSeparatorsTypes.FRENCH", "true", "OutilsCommun.csv" }, filenames = { 3 })
	final public static void saveToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, File file) throws IOException {
		saveToFile(csvFileData, separator, escapeQuotes, file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "new CSVFileData()", "CSVSeparatorsTypes.FRENCH", "true", "OutilsCommun.csv", "FilesCharsetsTypes.ISO_8859_1" }, filenames = { 3 })
	final public static void saveToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, File file, FilesCharsetsTypes charsetType) throws IOException {
		if (csvFileData != null) {
			new SaveCSVFormatToFile(csvFileData, separator, escapeQuotes, file, charsetType);
		}
	}

	/**
	 * Charge la liste à partir d'un fichier
	 * @param filename Nom du fichier
	 * @return un List<String>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "source.txt", filenames = 0)
	final public static List<String> loadListFromFile(String filename) throws IOException {
		return loadListFromFile(filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste à partir d'un fichier
	 * @param file Fichier
	 * @return un List<String>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "source.txt", filenames = 0)
	final public static List<String> loadListFromFile(File file) throws IOException {
		return loadListFromFile(file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste à partir d'un fichier
	 * @param inputStream Flux de données
	 * @return un List<String>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "source.txt", filenames = 0)
	final public static List<String> loadListFromFile(InputStream inputStream) throws IOException {
		return loadListFromFile(inputStream, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Charge la liste à partir d'un fichier
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @return un List<String>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "source.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static List<String> loadListFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadListFromFile(filename, charsetType).getList();
	}

	/**
	 * Charge la liste à partir d'un fichier
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @return un List<String>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "source.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static List<String> loadListFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadListFromFile(file, charsetType).getList();
	}

	/**
	 * Charge la liste à partir d'un fichier
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @return un List<String>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "source.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static List<String> loadListFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadListFromFile(inputStream, charsetType).getList();
	}

	/**
	 * Charge la liste de NameValue de NameValue à partir d'un fichier
	 * @param filename Nom du fichier
	 * @return un List<NameValue>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "NameValueList.txt", filenames = 0)
	final public static List<NameValue> loadNameValueListFromFile(String filename) throws IOException {
		return loadNameValueListFromFile(filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste de NameValue de NameValue à partir d'un fichier
	 * @param file Fichier
	 * @return un List<NameValue>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "NameValueList.txt", filenames = 0)
	final public static List<NameValue> loadNameValueListFromFile(File file) throws IOException {
		return loadNameValueListFromFile(file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste de NameValue de NameValue à partir d'un fichier
	 * @param inputStream Flux de données
	 * @return un List<NameValue>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "NameValueList.txt", filenames = 0)
	final public static List<NameValue> loadNameValueListFromFile(InputStream inputStream) throws IOException {
		return loadNameValueListFromFile(inputStream, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Charge la liste de NameValue de NameValue à partir d'un fichier
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @return un List<NameValue>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "NameValueList.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static List<NameValue> loadNameValueListFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadNameValueListFromFile(filename, charsetType).getNameValueList();
	}

	/**
	 * Charge la liste de NameValue de NameValue à partir d'un fichier
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @return un List<NameValue>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "NameValueList.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static List<NameValue> loadNameValueListFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadNameValueListFromFile(file, charsetType).getNameValueList();
	}

	/**
	 * Charge la liste de NameValue de NameValue à partir d'un fichier
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @return un List<NameValue>
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "NameValueList.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static List<NameValue> loadNameValueListFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadNameValueListFromFile(inputStream, charsetType).getNameValueList();
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "LoadCSVFormatFromFile UTF-8.csv", filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename) throws IOException {
		return loadCSVHeaderFromFile(filename, CSVSeparatorsTypes.ENGLISH, 1, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "LoadCSVFormatFromFile UTF-8.csv", filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file) throws IOException {
		return loadCSVHeaderFromFile(file, CSVSeparatorsTypes.ENGLISH, 1, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "LoadCSVFormatFromFile UTF-8.csv", filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream) throws IOException {
		return loadCSVHeaderFromFile(inputStream, CSVSeparatorsTypes.ENGLISH, 1, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename, long lineNo) throws IOException {
		return loadCSVHeaderFromFile(filename, CSVSeparatorsTypes.ENGLISH, lineNo, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file, long lineNo) throws IOException {
		return loadCSVHeaderFromFile(file, CSVSeparatorsTypes.ENGLISH, lineNo, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream, long lineNo) throws IOException {
		return loadCSVHeaderFromFile(inputStream, CSVSeparatorsTypes.ENGLISH, lineNo, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(filename, CSVSeparatorsTypes.ENGLISH, 1, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(file, CSVSeparatorsTypes.ENGLISH, 1, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(inputStream, CSVSeparatorsTypes.ENGLISH, 1, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(filename, CSVSeparatorsTypes.ENGLISH, lineNo, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(file, CSVSeparatorsTypes.ENGLISH, lineNo, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(inputStream, CSVSeparatorsTypes.ENGLISH, lineNo, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVHeaderFromFile(filename, separator, 1, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVHeaderFromFile(file, separator, 1, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param separator Type de séparateur
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVHeaderFromFile(inputStream, separator, 1, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return loadCSVHeaderFromFile(filename, separator, lineNo, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return loadCSVHeaderFromFile(file, separator, lineNo, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return loadCSVHeaderFromFile(inputStream, separator, lineNo, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename, CSVSeparatorsTypes separator, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(filename, separator, 1, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file, CSVSeparatorsTypes separator, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(file, separator, 1, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param separator Type de séparateur
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream, CSVSeparatorsTypes separator, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVHeaderFromFile(inputStream, separator, 1, charsetType);
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(String filename, CSVSeparatorsTypes separator, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadCSVHeaderFromFile(filename, separator, lineNo, charsetType).getCSVHeaders();
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(File file, CSVSeparatorsTypes separator, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadCSVHeaderFromFile(file, separator, lineNo, charsetType).getCSVHeaders();
	}

	/**
	 * Charge la liste des entêtes de la première ligne d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @return un String[] (null si fichier vide)
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String[] loadCSVHeaderFromFile(InputStream inputStream, CSVSeparatorsTypes separator, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadCSVHeaderFromFile(inputStream, separator, lineNo, charsetType).getCSVHeaders();
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "LoadCSVFormatFromFile UTF-8.csv", filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename) throws IOException {
		return loadCSVDataFromFile(filename, FilesCharsetsTypes.AUTO_DETECTION, CSVSeparatorsTypes.ENGLISH, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "LoadCSVFormatFromFile UTF-8.csv", filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file) throws IOException {
		return loadCSVDataFromFile(file, FilesCharsetsTypes.AUTO_DETECTION, CSVSeparatorsTypes.ENGLISH, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "LoadCSVFormatFromFile UTF-8.csv", filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream) throws IOException {
		return loadCSVDataFromFile(inputStream, FilesCharsetsTypes.ISO_8859_1, CSVSeparatorsTypes.ENGLISH, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename, long lineNo) throws IOException {
		return loadCSVDataFromFile(filename, FilesCharsetsTypes.AUTO_DETECTION, CSVSeparatorsTypes.ENGLISH, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file, long lineNo) throws IOException {
		return loadCSVDataFromFile(file, FilesCharsetsTypes.AUTO_DETECTION, CSVSeparatorsTypes.ENGLISH, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream, long lineNo) throws IOException {
		return loadCSVDataFromFile(inputStream, FilesCharsetsTypes.ISO_8859_1, CSVSeparatorsTypes.ENGLISH, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVDataFromFile(filename, charsetType, CSVSeparatorsTypes.ENGLISH, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVDataFromFile(file, charsetType, CSVSeparatorsTypes.ENGLISH, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param charsetType Type de jeu de caractères
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		return loadCSVDataFromFile(inputStream, charsetType, CSVSeparatorsTypes.ENGLISH, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename, FilesCharsetsTypes charsetType, long lineNo) throws IOException {
		return loadCSVDataFromFile(filename, charsetType, CSVSeparatorsTypes.ENGLISH, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file, FilesCharsetsTypes charsetType, long lineNo) throws IOException {
		return loadCSVDataFromFile(file, charsetType, CSVSeparatorsTypes.ENGLISH, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param charsetType Type de jeu de caractères
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream, FilesCharsetsTypes charsetType, long lineNo) throws IOException {
		return loadCSVDataFromFile(inputStream, charsetType, CSVSeparatorsTypes.ENGLISH, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVDataFromFile(filename, FilesCharsetsTypes.AUTO_DETECTION, separator, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVDataFromFile(file, FilesCharsetsTypes.AUTO_DETECTION, separator, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param separator Type de séparateur
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVDataFromFile(inputStream, FilesCharsetsTypes.ISO_8859_1, separator, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return loadCSVDataFromFile(filename, FilesCharsetsTypes.AUTO_DETECTION, separator, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return loadCSVDataFromFile(file, FilesCharsetsTypes.AUTO_DETECTION, separator, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return loadCSVDataFromFile(inputStream, FilesCharsetsTypes.ISO_8859_1, separator, lineNo);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVDataFromFile(filename, charsetType, separator, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVDataFromFile(file, charsetType, separator, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "CSVSeparatorsTypes.FRENCH" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator) throws IOException {
		return loadCSVDataFromFile(inputStream, charsetType, separator, 1);
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(String filename, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return new LoadCSVFormatFromFile(filename, charsetType, separator, true, lineNo).getCSVFileData();
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(File file, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return new LoadCSVFormatFromFile(file, charsetType, separator, true, lineNo).getCSVFileData();
	}

	/**
	 * Charge le contenu d'un fichier CSV
	 * @param inputStream Flux de données CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @return un CSVFileData
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "LoadCSVFormatFromFile UTF-8.csv", "FilesCharsetsTypes.UTF_8", "CSVSeparatorsTypes.FRENCH", "1" }, filenames = 0)
	final public static CSVFileData loadCSVDataFromFile(InputStream inputStream, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		return new LoadCSVFormatFromFile(inputStream, charsetType, separator, true, lineNo).getCSVFileData();
	}

	/**
	 * Charge une chaîne de caractères à partir d'un fichier
	 * @param filename Nom du fichier
	 * @return un String
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "source.txt", filenames = 0)
	final public static String loadFromFile(String filename) throws IOException {
		return loadFromFile(filename, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge une chaîne de caractères à partir d'un fichier
	 * @param file Fichier
	 * @return un String
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "source.txt", filenames = 0)
	final public static String loadFromFile(File file) throws IOException {
		return loadFromFile(file, FilesCharsetsTypes.AUTO_DETECTION);
	}

	/**
	 * Charge une chaîne de caractères à partir d'un fichier
	 * @param inputStream Flux de données
	 * @return un String
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "source.txt", filenames = 0)
	final public static String loadFromFile(InputStream inputStream) throws IOException {
		return loadFromFile(inputStream, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Charge une chaîne de caractères à partir d'un fichier
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @return un String
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "source.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String loadFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadTextFromFile(filename, charsetType).getText();
	}

	/**
	 * Charge une chaîne de caractères à partir d'un fichier
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @return un String
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "source.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String loadFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadTextFromFile(file, charsetType).getText();
	}

	/**
	 * Charge une chaîne de caractères à partir d'un fichier
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @return un String
	 * @throws IOException en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "source.txt", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static String loadFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		return new LoadTextFromFile(inputStream, charsetType).getText();
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des ";" (ex: s1;s2)
	 * @param list Liste des données
	 * @return la liste sous forme d'un StringBuffer
	 */
	final public static StringBuffer getStringBufferList(List<?> list) {
		return getStringBufferList(list, ";");
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par un séparateur
	 * @param list Liste des données
	 * @param separator Le séparateur entre chaque élément
	 * @return la liste sous forme d'un StringBuffer
	 */
	@AutomatedTests({ "1,,2", "," })
	final public static StringBuffer getStringBufferList(List<?> list, String separator) {
		StringBuffer result = new StringBuffer();

		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				if (i > 0) {
					result.append(separator);
				}

				Object obj = list.get(i);

				if (obj != null) {
					result.append(obj.toString());
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par un séparateur
	 * @param list Liste des données
	 * @param separator Le séparateur entre chaque élément
	 * @param between Mettre chaque élément entre deux strings spécifiques
	 * @return la liste sous forme d'un StringBuffer
	 */
	@AutomatedTests({ "1,,2", ",", "|" })
	final public static StringBuffer getStringBufferList(List<?> list, String separator, String between) {
		StringBuffer result = new StringBuffer();

		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				if (i > 0) {
					result.append(separator);
				}

				result.append(between);

				Object obj = list.get(i);

				if (obj != null) {
					result.append(obj.toString());
				}

				result.append(between);
			}
		}

		return result;
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par un séparateur
	 * @param list Liste des données
	 * @param separator Le séparateur entre chaque élément
	 * @param left Préfixé chaque élément entre avec le string donné
	 * @param right Suffixé chaque élément entre avec le string donné
	 * @return la liste sous forme d'un StringBuffer
	 */
	@AutomatedTests({ "1,,2", ",", "<", ">" })
	final public static StringBuffer getStringBufferList(List<?> list, String separator, String left, String right) {
		StringBuffer result = new StringBuffer();

		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				if (i > 0) {
					result.append(separator);
				}

				result.append(left);

				Object obj = list.get(i);

				if (obj != null) {
					result.append(obj.toString());
				}

				result.append(right);
			}
		}

		return result;
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des CRLF
	 * @param list Liste des données
	 * @return la liste sous forme d'un StringBuffer
	 */
	final public static StringBuffer getCRLFStringBufferList(List<?> list) {
		return getCRLFStringBufferList(list, true);
	}

	/**
	 * Retourne la liste courante sous forme de pairs séparés par des CRLF
	 * @param list Liste des données
	 * @param endWithCRLF Indicateur de terminer avec un CRLF
	 * @return la liste sous forme d'un StringBuffer
	 */
	@AutomatedTests(value = { "1,2", "false,true" }, iterate = true)
	@AutomatedTests({ "1,2", "false" })
	@AutomatedTests({ "1,2", "true" })
	final public static StringBuffer getCRLFStringBufferList(List<?> list, boolean endWithCRLF) {
		StringBuffer result = new StringBuffer();

		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				result.append(list.get(i));

				if ((i + 1) == list.size()) {
					if (endWithCRLF) {
						result.append(LINE_SEPARATOR);
					}
				} else {
					result.append(LINE_SEPARATOR);
				}
			}
		}

		return result;
	}

	/**
	 * Retourne la liste sous forme de pairs séparés par des CRLF de Windows
	 * @param list Liste des données
	 * @return la liste sous forme d'un StringBuffer
	 */
	final public static StringBuffer getWindowsCRLFStringBufferList(List<?> list) {
		return getWindowsCRLFStringBufferList(list, true);
	}

	/**
	 * Retourne la liste courante sous forme de pairs séparés par des CRLF de Windows
	 * @param list Liste des données
	 * @param endWithCRLF Indicateur de terminer avec un CRLF de Windows
	 * @return la liste sous forme d'un StringBuffer
	 */
	@AutomatedTests(value = { "1,2", "false,true" }, iterate = true)
	@AutomatedTests({ "1,2", "false" })
	@AutomatedTests({ "1,2", "true" })
	final public static StringBuffer getWindowsCRLFStringBufferList(List<?> list, boolean endWithCRLF) {
		StringBuffer result = new StringBuffer();

		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				result.append(list.get(i));

				if ((i + 1) == list.size()) {
					if (endWithCRLF) {
						result.append(WINDOWS_LINE_SEPARATOR);
					}
				} else {
					result.append(WINDOWS_LINE_SEPARATOR);
				}
			}
		}

		return result;
	}

	/**
	 * Extrait la liste des champs d'une classe de données
	 * @param object L'objet de la classe de données
	 * @return la liste des champs
	 */
	final public static List<Field> getFieldsList(Object object) {
		if (object == null) {
			return new ArrayList<Field>();
		}

		return getFieldsList(object.getClass());
	}

	/**
	 * Extrait la liste des champs d'une classe de données
	 * @param object L'objet de la classe de données
	 * @param parent Indicateur d'extraction des champs de la classe parent
	 * @return la liste des champs
	 */
	final public static List<Field> getFieldsList(Object object, boolean parent) {
		if (object == null) {
			return new ArrayList<Field>();
		}

		return getFieldsList(object.getClass(), parent);
	}

	/**
	 * Extrait la liste des champs d'une classe de données
	 * @param classData La classe de données
	 * @return la liste des champs
	 */
	final public static List<Field> getFieldsList(Class<?> classData) {
		return getFieldsList(classData, true);
	}

	/**
	 * Extrait la liste des champs d'une classe de données
	 * @param classData La classe de données
	 * @param parent Indicateur d'extraction des champs de la classe parent
	 * @return la liste des champs
	 */
	final public static List<Field> getFieldsList(Class<?> classData, boolean parent) {
		List<Field> fieldsList = new ArrayList<Field>();

		if (classData != null) {
			if (!classData.equals(Object.class)) {
				if (parent) {
					fieldsList.addAll(getFieldsList(classData.getSuperclass(), parent));
				}

				for (Field field : classData.getDeclaredFields()) {
					int modifiers = field.getModifiers();

					if (Modifier.isVolatile(modifiers) || Modifier.isStatic(modifiers)) {
						continue;
					}

					field.setAccessible(true);
					fieldsList.add(field);
				}
			}
		}

		return fieldsList;
	}

	/**
	 * Normalisation d'un texte en nom java valide
	 * @param uppercase Indicateur de la première lettre en majuscule
	 * @param harmonize Indicateur d'effectuer l'harmonisation du texte afin d'éviter d'avoir 2 lettres en majuscules qui se suivent
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests(value = { "false,true", "false,true", "ALLO,élève,allo_toto,7zip,for" }, iterate = true)
	final public static String doJavaName(boolean uppercase, boolean harmonize, String value) {
		if (!isEmpty(value)) {
			StringBuffer sb = new StringBuffer();

			String english = toEnglish(value);

			char[] charsData = english.toCharArray();

			boolean hasSeparator = false;

			for (char c : charsData) {
				if (Character.isJavaIdentifierPart(c)) {
					hasSeparator |= !Character.isLetterOrDigit(c);
					sb.append(c);
				}
			}

			if (hasSeparator) {
				if (harmonize) {
					value = doCamelCase(uppercase, doHarmonization(sb.toString()));
				} else {
					value = doCamelCase(uppercase, sb.toString());
				}
			} else {
				if (uppercase) {
					if (harmonize) {
						value = doHarmonization(doCapitalize(sb.toString()));
					} else {
						value = doCapitalize(sb.toString());
					}
				} else {
					if (harmonize) {
						value = doUncapitalize(doHarmonization(sb.toString()));
					} else {
						value = doUncapitalize(sb.toString());
					}
				}
			}

			if (!Character.isJavaIdentifierStart(value.charAt(0))) {
				value = (Character.isDigit(value.charAt(0)) ? (uppercase ? "N" : "n") : "_") + value;
			}

			if (SourceVersion.isKeyword(value)) {
				value += "_";
			}
		}

		return value;
	}

	/**
	 * Normalisation d'un texte en nom de classe java valide
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	final public static String doJavaClassname(String value) {
		return doJavaName(true, true, value);
	}

	/**
	 * Normalisation d'un texte en nom de classe java valide
	 * @param harmonize Indicateur d'effectuer l'harmonisation du texte afin d'éviter d'avoir 2 lettres en majuscules qui se suivent
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests(value = { "false,true", "ALLO" }, iterate = true)
	final public static String doJavaClassname(boolean harmonize, String value) {
		return doJavaName(true, harmonize, value);
	}

	/**
	 * Normalisation d'un texte en nom de champ java valide
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	final public static String doJavaFieldname(String value) {
		return doJavaFieldname(true, value);
	}

	/**
	 * Normalisation d'un texte en nom de champ java valide
	 * @param harmonize Indicateur d'effectuer l'harmonisation du texte afin d'éviter d'avoir 2 lettres en majuscules qui se suivent
	 * @param value La valeur à traiter
	 * @return la valeur convertie
	 */
	@AutomatedTests(value = { "false,true", "ALLO,data" }, iterate = true)
	final public static String doJavaFieldname(boolean harmonize, String value) {
		String fieldname = doJavaName(false, harmonize, value);

		if (OutilsBase.areEquals("data", fieldname)) {
			fieldname += "_";
		}

		return fieldname;
	}

	/**
	 * Formattage des valeurs d'un objet en une ligne csv (fichier excel)
	 * @param object Object à formatter
	 * @param separator Type de séparateur
	 * @return une ligne csv (fichier excel)
	 */
	@StrictAutomatedTests({ "null", "CSVSeparatorsTypes.ENGLISH" })
	@StrictAutomatedTests({ "new POJODataTestClass()", "CSVSeparatorsTypes.ENGLISH" })
	final public static String formatCSVRow(Object object, CSVSeparatorsTypes separator) {
		List<String> values = new ArrayList<String>();

		for (Field field : getFieldsList(object)) {
			try {
				Object data = field.get(object);

				if (data != null) {
					if (data instanceof Date) {
						values.add(CSV_DATE_TIME_FORMAT.format((Date) data));
					} else {
						values.add(OutilsBase.asString(data));
					}
				} else {
					values.add((String) null);
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

		return toList(values, separator.getSeparator(), "\"");
	}

	/**
	 * Formattage des noms des champs d'un objet en une ligne csv (fichier excel)
	 * @param object Object à formatter
	 * @param separator Type de séparateur
	 * @return une ligne csv (fichier excel)
	 */
	@StrictAutomatedTests({ "null", "CSVSeparatorsTypes.ENGLISH" })
	@StrictAutomatedTests({ "new POJODataTestClass()", "CSVSeparatorsTypes.ENGLISH" })
	final public static String formatCSVHeaderRow(Object object, CSVSeparatorsTypes separator) {
		List<String> values = new ArrayList<String>();

		for (Field field : getFieldsList(object)) {
			values.add(asString(field.getName()));
		}

		return toList(values, separator.getSeparator(), "\"");
	}

	/**
	 * Formattage d'un objet en une liste de lignes csv (fichier excel)
	 * @param object Object à formatter
	 * @param separator Type de séparateur
	 * @return une ligne csv (fichier excel)
	 */
	@StrictAutomatedTests({ "null", "CSVSeparatorsTypes.ENGLISH" })
	@StrictAutomatedTests({ "new POJODataTestClass()", "CSVSeparatorsTypes.ENGLISH" })
	final public static List<String> formatCSV(Object object, CSVSeparatorsTypes separator) {
		if (object == null) {
			return new ArrayList<String>();
		}

		List<String> csvList = new ArrayList<String>();
		csvList.add(formatCSVHeaderRow(object, separator));
		csvList.add(formatCSVRow(object, separator));

		return csvList;
	}

	/**
	 * Formattage de la liste des objets en une liste de lignes csv (fichier excel)
	 * @param list La liste des objets
	 * @param separator Type de séparateur
	 * @return une ligne csv (fichier excel)
	 */
	@AutomatedTests({ "1,2,3", "CSVSeparatorsTypes.ENGLISH" })
	final public static List<String> formatCSVList(List<?> list, CSVSeparatorsTypes separator) {
		if (OutilsBase.isEmpty(list)) {
			return new ArrayList<String>();
		}

		List<String> csvList = new ArrayList<String>();
		csvList.add(formatCSVHeaderRow(list.get(0), separator));

		for (Object object : list) {
			csvList.add(formatCSVRow(object, separator));
		}

		return csvList;
	}

	/**
	 * Formattage de la liste des objets en une liste de lignes csv (fichier excel)
	 * @param list La liste des objets
	 * @param separator Type de séparateur
	 * @return une ligne csv (fichier excel)
	 */
	@AutomatedTests({ "1,2,3", "CSVSeparatorsTypes.TAB" })
	final public static List<String> formatCSVArray(Object[] list, CSVSeparatorsTypes separator) {
		if (isEmpty(list)) {
			return new ArrayList<String>();
		}

		List<String> csvList = new ArrayList<String>();
		csvList.add(formatCSVHeaderRow(list[0], separator));

		for (Object object : list) {
			csvList.add(formatCSVRow(object, separator));
		}

		return csvList;
	}

	/**
	 * Compression d'un objet sérialisable
	 * @param data Les données à compresser
	 * @return un byte[] contenant les données compressés
	 * @throws Exception en cas d'erreur...
	 */
	final public static byte[] compressSerializable(Serializable data) throws Exception {
		if (data == null) {
			throw new Exception("Pas de données à compresser");
		}

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutput oo = new ObjectOutputStream(baos);
		oo.writeObject(data);
		oo.close();
		byte[] buf = baos.toByteArray();

		baos = new ByteArrayOutputStream();
		GZIPOutputStream gzos = new GZIPOutputStream(baos);
		gzos.write(buf);
		gzos.close();
		buf = Base64.getEncoder().encode(baos.toByteArray());

		return buf;
	}

	/**
	 * Décompression d'un objet sérialisable
	 * @param data Les données à décompresser
	 * @return un objet sérialisable contenant les données décompressés
	 * @throws Exception en cas d'erreur...
	 */
	final public static Serializable decompressSerializable(byte[] data) throws Exception {
		if (data == null) {
			throw new Exception("Pas de données à décompresser");
		}

		Serializable resultat = null;

		if (data.length > 0) {
			byte[] buf = Base64.getDecoder().decode(data);

			GZIPInputStream gzis = new GZIPInputStream(new ByteArrayInputStream(buf));
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			try {
				int sChunk = 32768;
				byte[] b = new byte[sChunk];
				int length;
				while ((length = gzis.read(b, 0, sChunk)) != -1) {
					baos.write(b, 0, length);
				}

				baos.flush();
				;
			} finally {
				baos.close();
				gzis.close();
			}

			ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));

			try {
				resultat = (Serializable) ois.readObject();
			} finally {
				ois.close();
			}
		} else {
			resultat = null;
		}

		return resultat;
	}

	/**
	 * Compression d'un vecteur (Vector)
	 * @param data Les données à compresser
	 * @param slice Découpe en tranche pour le StringList
	 * @return un List<String> contenant les données compressés
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",new Vector<String>()", "0,1" }, iterate = true)
	final public static List<String> compress(Vector<?> data, int slice) throws Exception {
		if (data == null) {
			throw new Exception("Pas de données à compresser");
		}

		if (slice < 1) {
			throw new Exception("La tranche doit être supérieur à zéro");
		}

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutput oo = new ObjectOutputStream(baos);
		oo.writeObject(data);
		oo.close();
		byte[] buf = baos.toByteArray();

		baos = new ByteArrayOutputStream();
		GZIPOutputStream gzos = new GZIPOutputStream(baos);
		gzos.write(buf);
		gzos.close();
		buf = Base64.getEncoder().encode(baos.toByteArray());

		return split(buf, slice);
	}

	/**
	 * Découpage d'un tableau binaire dans un StringList
	 * @param buf Les données à découper
	 * @param slice Découpe en tranche pour le StringList
	 * @return un List<String> contenant les données découpées
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "new byte[0]", "1", "1,2,3", "1" })
	final public static List<String> split(byte[] buf, int slice) throws Exception {
		if (buf == null) {
			throw new Exception("Pas de données à découper");
		}

		if (slice < 1) {
			throw new Exception("La tranche doit être supérieur à zéro");
		}

		List<String> resultat = new ArrayList<String>();

		if (buf.length > 0) {
			int nb_lignes = buf.length / slice;

			for (int i = 0; i <= nb_lignes; i++) {
				int start = i * slice;
				int end = ((i + 1) * slice) - 1;

				if (end >= buf.length) {
					end = buf.length - 1;
				}

				int size = (end - start) + 1;

				byte[] sb = new byte[size];

				System.arraycopy(buf, start, sb, 0, size);

				resultat.add(new String(sb));
			}
		}

		return resultat;
	}

	/**
	 * Découpage d'un array de char dans un StringList
	 * @param buf Les données à découper
	 * @param slice Découpe en tranche pour le StringList
	 * @return un List<String> contenant les données découpées
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "new char[0]", "1", "1,2,3", "1" })
	final public static List<String> split(char[] buf, int slice) throws Exception {
		if (buf == null) {
			throw new Exception("Pas de données à découper");
		}

		if (slice < 1) {
			throw new Exception("La tranche doit être supérieur à zéro");
		}

		List<String> resultat = new ArrayList<String>();

		if (buf.length > 0) {
			int nb_lignes = buf.length / slice;

			for (int i = 0; i <= nb_lignes; i++) {
				int start = i * slice;
				int end = ((i + 1) * slice) - 1;

				if (end >= buf.length) {
					end = buf.length - 1;
				}

				int size = (end - start) + 1;

				char[] sb = new char[size];

				System.arraycopy(buf, start, sb, 0, size);

				resultat.add(new String(sb));
			}
		}

		return resultat;
	}

	/**
	 * Décompression d'un vecteur (Vector)
	 * @param data Les données à décompresser
	 * @return un vecteur contenant les données décompressés
	 * @throws Exception en cas d'erreur...
	 */
	final public static Vector<?> decompress(List<String> data) throws Exception {
		if (data == null) {
			throw new Exception("Pas de données à décompresser");
		}

		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < data.size(); i++) {
			sb.append(data.get(i));
		}

		return decompress(sb);
	}

	/**
	 * Décompression d'un vecteur (Vector)
	 * @param data Les données à décompresser
	 * @return un vecteur contenant les données décompressés
	 * @throws Exception en cas d'erreur...
	 */
	final public static Vector<?> decompress(StringBuffer data) throws Exception {
		if (data == null) {
			throw new Exception("Pas de données à décompresser");
		}

		Vector<?> resultat = null;

		if (data.length() > 0) {
			byte[] buf = Base64.getDecoder().decode(data.toString().getBytes());

			GZIPInputStream gzis = new GZIPInputStream(new ByteArrayInputStream(buf));
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			try {
				int sChunk = 32768;
				byte[] b = new byte[sChunk];
				int length;

				while ((length = gzis.read(b, 0, sChunk)) != -1) {
					baos.write(b, 0, length);
				}

				baos.flush();
			} finally {
				baos.close();
				gzis.close();
			}

			ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));

			try {
				resultat = (Vector<?>) ois.readObject();
			} finally {
				ois.close();
			}
		} else {
			resultat = new Vector<Object>();
		}

		return resultat;
	}

	/**
	 * Extrait le type MIME pour un fichier donné
	 * @param filename Le nom du fichier
	 * @return le type MIME
	 */
	@AutomatedTests(value = "source.txt", filenames = 0)
	@AutomatedTests(value = "OutilsCommun")
	final public static String getMIME(String filename) {
		if (!isEmpty(filename)) {
			File file = new File(filename);

			if (file.exists()) {
				try {
					String type = Files.probeContentType(file.toPath());

					if (!isEmpty(type)) {
						return type;
					}
				} catch (IOException e) {
					// ignore...
					e.printStackTrace();
				}
			}

			String ext = filename.toLowerCase();

			int pos = ext.lastIndexOf(".");

			if (pos != -1) {
				ext = ext.substring(pos + 1);

				switch (ext) {
					case "pyc":
						return "applicaiton/x-bytecode.python";
					case "dwg":
						return "application/acad";
					case "arj":
						return "application/arj";
					case "mm":
					case "mme":
						return "application/base64";
					case "hqx":
						return "application/binhex";
					case "boo":
					case "book":
						return "application/book";
					case "ccad":
						return "application/clariscad";
					case "dp":
						return "application/commonground";
					case "drw":
						return "application/drafting";
					case "tsp":
						return "application/dsptype";
					case "xl":
					case "xla":
					case "xlb":
					case "xlc":
					case "xld":
					case "xlk":
					case "xll":
					case "xlm":
					case "xls":
					case "xlt":
					case "xlv":
					case "xlw":
						return "application/excel";
					case "frl":
						return "application/freeloader";
					case "spl":
						return "application/futuresplash";
					case "vew":
						return "application/groupwise";
					case "hta":
						return "application/hta";
					case "unv":
						return "application/i-deas";
					case "inf":
						return "application/inf";
					case "class":
						return "application/java";
					case "mrc":
						return "application/marc";
					case "mbd":
						return "application/mbedlet";
					case "aps":
						return "application/mime";
					case "pot":
					case "pps":
					case "ppt":
					case "ppz":
						return "application/mspowerpoint";
					case "doc":
					case "dot":
					case "w6w":
					case "wiz":
					case "word":
						return "application/msword";
					case "wri":
						return "application/mswrite";
					case "mcp":
						return "application/netmc";
					case "a":
					case "arc":
					case "com":
					case "dump":
					case "exe":
					case "o":
					case "psd":
					case "saveme":
					case "zoo":
						return "application/octet-stream";
					case "oda":
						return "application/oda";
					case "pdf":
						return "application/pdf";
					case "p7s":
						return "application/pkcs7-signature";
					case "crl":
						return "application/pkix-crl";
					case "ai":
					case "eps":
					case "ps":
						return "application/postscript";
					case "part":
					case "prt":
						return "application/pro_eng";
					case "rng":
						return "application/ringing-tones";
					case "set":
						return "application/set";
					case "smi":
					case "smil":
						return "application/smil";
					case "sol":
						return "application/solids";
					case "sdr":
						return "application/sounder";
					case "step":
					case "stp":
						return "application/step";
					case "ssm":
						return "application/streamingmedia";
					case "vda":
						return "application/vda";
					case "fdf":
						return "application/vnd.fdf";
					case "hgl":
					case "hpg":
					case "hpgl":
						return "application/vnd.hp-hpgl";
					case "sst":
						return "application/vnd.ms-pki.certstore";
					case "pko":
						return "application/vnd.ms-pki.pko";
					case "cat":
						return "application/vnd.ms-pki.seccat";
					case "ppa":
					case "pwz":
						return "application/vnd.ms-powerpoint";
					case "mpp":
						return "application/vnd.ms-project";
					case "ncm":
						return "application/vnd.nokia.configuration-message";
					case "rnx":
						return "application/vnd.rn-realplayer";
					case "wmlc":
						return "application/vnd.wap.wmlc";
					case "wmlsc":
						return "application/vnd.wap.wmlscriptc";
					case "web":
						return "application/vnd.xara";
					case "vmd":
						return "application/vocaltec-media-desc";
					case "vmf":
						return "application/vocaltec-media-file";
					case "wp":
					case "wp5":
					case "wp6":
					case "wpd":
						return "application/wordperfect";
					case "w60":
						return "application/wordperfect6.0";
					case "w61":
						return "application/wordperfect6.1";
					case "wk1":
						return "application/x-123";
					case "aim":
						return "application/x-aim";
					case "aab":
						return "application/x-authorware-bin";
					case "aam":
						return "application/x-authorware-map";
					case "aas":
						return "application/x-authorware-seg";
					case "bcpio":
						return "application/x-bcpio";
					case "bin":
						return "application/x-binary";
					case "bsh":
						return "application/x-bsh";
					case "bz":
						return "application/x-bzip";
					case "boz":
					case "bz2":
						return "application/x-bzip2";
					case "cdf":
						return "application/x-cdf";
					case "vcd":
						return "application/x-cdlink";
					case "cha":
					case "chat":
						return "application/x-chat";
					case "cco":
						return "application/x-cocoa";
					case "tgz":
					case "z":
					case "zip":
						return "application/x-compressed";
					case "nsc":
						return "application/x-conference";
					case "cpio":
						return "application/x-cpio";
					case "cpt":
						return "application/x-cpt";
					case "csh":
						return "application/x-csh";
					case "deepv":
						return "application/x-deepv";
					case "dcr":
					case "dir":
					case "dxr":
						return "application/x-director";
					case "dvi":
						return "application/x-dvi";
					case "elc":
						return "application/x-elc";
					case "env":
					case "evy":
						return "application/x-envoy";
					case "es":
						return "application/x-esrehber";
					case "pre":
						return "application/x-freelance";
					case "gsp":
						return "application/x-gsp";
					case "gss":
						return "application/x-gss";
					case "gtar":
						return "application/x-gtar";
					case "gz":
					case "gzip":
						return "application/x-gzip";
					case "hdf":
						return "application/x-hdf";
					case "help":
						return "application/x-helpfile";
					case "imap":
						return "application/x-httpd-imap";
					case "ima":
						return "application/x-ima";
					case "ins":
						return "application/x-internett-signup";
					case "iv":
						return "application/x-inventor";
					case "ip":
						return "application/x-ip2";
					case "jcm":
						return "application/x-java-commerce";
					case "js":
						return "application/x-javascript";
					case "skd":
					case "skm":
					case "skp":
					case "skt":
						return "application/x-koan";
					case "ksh":
						return "application/x-ksh";
					case "latex":
					case "ltx":
						return "application/x-latex";
					case "lha":
						return "application/x-lha";
					case "lsp":
						return "application/x-lisp";
					case "ivy":
						return "application/x-livescreen";
					case "wq1":
						return "application/x-lotus";
					case "lzh":
						return "application/x-lzh";
					case "lzx":
						return "application/x-lzx";
					case "mc$":
						return "application/x-magic-cap-package-1.0";
					case "mcd":
						return "application/x-mathcad";
					case "mif":
						return "application/x-mif";
					case "nix":
						return "application/x-mix-transfer";
					case "ani":
						return "application/x-navi-animation";
					case "nvd":
						return "application/x-navidoc";
					case "map":
						return "application/x-navimap";
					case "stl":
						return "application/x-navistyle";
					case "nc":
						return "application/x-netcdf";
					case "pkg":
						return "application/x-newton-compatible-pkg";
					case "aos":
						return "application/x-nokia-9000-communicator-add-on-software";
					case "omc":
						return "application/x-omc";
					case "omcd":
						return "application/x-omcdatamaker";
					case "omcr":
						return "application/x-omcregerator";
					case "pm4":
					case "pm5":
						return "application/x-pagemaker";
					case "pcl":
						return "application/x-pcl";
					case "plx":
						return "application/x-pixclscript";
					case "p10":
						return "application/x-pkcs10";
					case "p12":
						return "application/x-pkcs12";
					case "p7r":
						return "application/x-pkcs7-certreqresp";
					case "p7c":
					case "p7m":
						return "application/x-pkcs7-mime";
					case "p7a":
						return "application/x-pkcs7-signature";
					case "mpc":
					case "mpt":
					case "mpv":
					case "mpx":
						return "application/x-project";
					case "wb1":
						return "application/x-qpro";
					case "sdp":
						return "application/x-sdp";
					case "sea":
						return "application/x-sea";
					case "sl":
						return "application/x-seelogo";
					case "sh":
						return "application/x-sh";
					case "shar":
						return "application/x-shar";
					case "swf":
						return "application/x-shockwave-flash";
					case "spr":
					case "sprite":
						return "application/x-sprite";
					case "sit":
						return "application/x-stuffit";
					case "sv4cpio":
						return "application/x-sv4cpio";
					case "sv4crc":
						return "application/x-sv4crc";
					case "tar":
						return "application/x-tar";
					case "sbk":
					case "tbk":
						return "application/x-tbook";
					case "tex":
						return "application/x-tex";
					case "texi":
					case "texinfo":
						return "application/x-texinfo";
					case "roff":
					case "t":
					case "tr":
						return "application/x-troff";
					case "man":
						return "application/x-troff-man";
					case "me":
						return "application/x-troff-me";
					case "ms":
						return "application/x-troff-ms";
					case "ustar":
						return "application/x-ustar";
					case "vsd":
					case "vst":
					case "vsw":
						return "application/x-visio";
					case "mzz":
						return "application/x-vnd.audioexplosion.mzz";
					case "xpix":
						return "application/x-vnd.ls-xpix";
					case "src":
					case "wsrc":
						return "application/x-wais-source";
					case "hlp":
						return "application/x-winhelp";
					case "wtk":
						return "application/x-wintalk";
					case "svr":
						return "application/x-world";
					case "cer":
					case "crt":
					case "der":
						return "application/x-x509-ca-cert";
					case "snd":
						return "audio/basic";
					case "it":
						return "audio/it";
					case "funk":
					case "my":
					case "pfunk":
						return "audio/make";
					case "rmi":
						return "audio/mid";
					case "kar":
					case "mid":
					case "midi":
						return "audio/midi";
					case "m2a":
					case "mp2":
					case "mpa":
					case "mpga":
						return "audio/mpeg";
					case "mp3":
						return "audio/mpeg3";
					case "s3m":
						return "audio/s3m";
					case "tsi":
						return "audio/tsp-audio";
					case "qcp":
						return "audio/vnd.qcelp";
					case "voc":
						return "audio/voc";
					case "vox":
						return "audio/voxware";
					case "wav":
						return "audio/wav";
					case "aif":
					case "aifc":
					case "aiff":
						return "audio/x-aiff";
					case "au":
						return "audio/x-au";
					case "gsd":
					case "gsm":
						return "audio/x-gsm";
					case "jam":
						return "audio/x-jam";
					case "lam":
						return "audio/x-liveaudio";
					case "mod":
						return "audio/x-mod";
					case "m3u":
						return "audio/x-mpequrl";
					case "la":
					case "lma":
						return "audio/x-nspaudio";
					case "ram":
					case "rm":
					case "rmm":
					case "rmp":
						return "audio/x-pn-realaudio";
					case "rpm":
						return "audio/x-pn-realaudio-plugin";
					case "sid":
						return "audio/x-psid";
					case "ra":
						return "audio/x-realaudio";
					case "vqf":
						return "audio/x-twinvq";
					case "vqe":
					case "vql":
						return "audio/x-twinvq-plugin";
					case "mjf":
						return "audio/x-vnd.audioexplosion.mjuicemediafile";
					case "xm":
						return "audio/xm";
					case "pdb":
					case "xyz":
						return "chemical/x-pdb";
					case "ivr":
						return "i-world/i-vrml";
					case "bm":
					case "bmp":
						return "image/bmp";
					case "ras":
					case "rast":
						return "image/cmu-raster";
					case "fif":
						return "image/fif";
					case "flo":
					case "turbot":
						return "image/florian";
					case "g3":
						return "image/g3fax";
					case "gif":
						return "image/gif";
					case "ief":
					case "iefs":
						return "image/ief";
					case "jfif":
					case "jfif-tbnl":
					case "jpe":
					case "jpeg":
					case "jpg":
						return "image/jpeg";
					case "jut":
						return "image/jutvision";
					case "nap":
					case "naplps":
						return "image/naplps";
					case "pic":
					case "pict":
						return "image/pict";
					case "png":
					case "x-png":
						return "image/png";
					case "tif":
					case "tiff":
						return "image/tiff";
					case "fpx":
						return "image/vnd.fpx";
					case "rf":
						return "image/vnd.rn-realflash";
					case "rp":
						return "image/vnd.rn-realpix";
					case "wbmp":
						return "image/vnd.wap.wbmp";
					case "xif":
						return "image/vnd.xiff";
					case "dxf":
					case "svf":
						return "image/x-dwg";
					case "ico":
						return "image/x-icon";
					case "art":
						return "image/x-jg";
					case "jps":
						return "image/x-jps";
					case "nif":
					case "niff":
						return "image/x-niff";
					case "pcx":
						return "image/x-pcx";
					case "pct":
						return "image/x-pict";
					case "pnm":
						return "image/x-portable-anymap";
					case "pbm":
						return "image/x-portable-bitmap";
					case "pgm":
						return "image/x-portable-graymap";
					case "ppm":
						return "image/x-portable-pixmap";
					case "qif":
					case "qti":
					case "qtif":
						return "image/x-quicktime";
					case "rgb":
						return "image/x-rgb";
					case "xwd":
						return "image/x-xwd";
					case "xbm":
						return "image/xbm";
					case "xpm":
						return "image/xpm";
					case "mht":
					case "mhtml":
						return "message/rfc822";
					case "iges":
					case "igs":
						return "model/iges";
					case "dwf":
						return "model/vnd.dwf";
					case "vrml":
					case "wrl":
					case "wrz":
						return "model/vrml";
					case "pov":
						return "model/x-pov";
					case "pvu":
						return "paleovu/x-pv";
					case "css":
						return "text/css";
					case "acgi":
					case "htm":
					case "html":
					case "htmls":
					case "htx":
					case "shtml":
						return "text/html";
					case "asm":
					case "asp":
					case "c":
					case "c++":
					case "cc":
					case "conf":
					case "cpp":
					case "cxx":
					case "def":
					case "el":
					case "etx":
					case "f":
					case "f77":
					case "f90":
					case "for":
					case "g":
					case "h":
					case "hh":
					case "hlb":
					case "idc":
					case "jav":
					case "java":
					case "list":
					case "log":
					case "lst":
					case "m":
					case "mar":
					case "mcf":
					case "p":
					case "pas":
					case "pl":
					case "pm":
					case "py":
					case "rexx":
					case "s":
					case "sdml":
					case "tcl":
					case "tcsh":
					case "text":
					case "txt":
					case "zsh":
						return "text/plain";
					case "rt":
					case "rtf":
					case "rtx":
						return "text/richtext";
					case "wsc":
						return "text/scriplet";
					case "tsv":
						return "text/tab-separated-values";
					case "uni":
					case "unis":
					case "uri":
					case "uris":
						return "text/uri-list";
					case "abc":
						return "text/vnd.abc";
					case "flx":
						return "text/vnd.fmi.flexstor";
					case "wml":
						return "text/vnd.wap.wml";
					case "wmls":
						return "text/vnd.wap.wmlscript";
					case "htt":
						return "text/webviewhtml";
					case "aip":
						return "text/x-audiosoft-intra";
					case "htc":
						return "text/x-component";
					case "lsx":
						return "text/x-la-asf";
					case "ssi":
						return "text/x-server-parsed-html";
					case "sgm":
					case "sgml":
						return "text/x-sgml";
					case "spc":
					case "talk":
						return "text/x-speech";
					case "uil":
						return "text/x-uil";
					case "uu":
					case "uue":
						return "text/x-uuencode";
					case "vcs":
						return "text/x-vcalendar";
					case "xml":
						return "text/xml";
					case "afl":
						return "video/animaflex";
					case "avi":
						return "video/avi";
					case "avs":
						return "video/avs-video";
					case "dl":
						return "video/dl";
					case "fli":
						return "video/fli";
					case "gl":
						return "video/gl";
					case "mp4":
						return "video/mp4";
					case "m1v":
					case "m2v":
					case "mpe":
					case "mpeg":
					case "mpg":
						return "video/mpeg";
					case "moov":
					case "mov":
					case "qt":
						return "video/quicktime";
					case "vdo":
						return "video/vdo";
					case "viv":
					case "vivo":
						return "video/vivo";
					case "rv":
						return "video/vnd.rn-realvideo";
					case "vos":
						return "video/vosaic";
					case "xdr":
						return "video/x-amt-demorun";
					case "xsr":
						return "video/x-amt-showrun";
					case "fmf":
						return "video/x-atomic3d-feature";
					case "dif":
					case "dv":
						return "video/x-dv";
					case "isu":
						return "video/x-isvideo";
					case "mjpg":
						return "video/x-motion-jpeg";
					case "asf":
					case "asx":
						return "video/x-ms-asf";
					case "qtc":
						return "video/x-qtc";
					case "scm":
						return "video/x-scm";
					case "movie":
					case "mv":
						return "video/x-sgi-movie";
					case "wmf":
						return "windows/metafile";
					case "mime":
						return "www/mime";
					case "ice":
						return "x-conference/x-cooltalk";
					case "3dmf":
					case "qd3":
					case "qd3d":
						return "x-world/x-3dmf";
					case "vrt":
						return "x-world/x-vrt";
					case "xgz":
						return "xgl/drawing";
					case "xmz":
						return "xgl/movie";
				}
			}
		}

		return "application/octet-stream";
	}

	/**
	 * Extrait le répertoire <i>Mes Documents</i> de l'usager courant sous Windows
	 * @return le répertoire complet
	 * @throws Error si exécuté en dehors de Windows
	 */
	@CoverageOnly
	final public static String getMyDocuments() {
		if (!OutilsCommun.isWindows()) {
			throw new Error("La méthode OutilsCommun.getMyDocuments() doit être exécutée sous Windows");
		}

		return getFullname(getCurrentHomeDirectory(), "My Documents");
	}

	/**
	 * Extrait le répertoire de l'usager courant
	 * @return le répertoire de l'usager courant
	 */
	@CoverageOnly
	final public static String getCurrentHomeDirectory() {
		return System.getProperty("user.home");
	}

	/**
	 * Extrait le répertoire courant
	 * @return le répertoire courant
	 */
	@CoverageOnly
	final public static String getCurrentDirectory() {
		return System.getProperty("user.dir");
	}

	/**
	 * Extrait l'usager courant
	 * @return l'usager courant
	 */
	@CoverageOnly
	final public static String getCurrentUsername() {
		return System.getProperty("user.name");
	}

	/**
	 * Extrait le répertoire temporaire
	 * @return le répertoire temporaire
	 */
	@CoverageOnly
	final public static String getTempDirectory() {
		String tmpdir = System.getProperty("java.io.tmpdir");

		if (!isEmpty(tmpdir)) {
			return tmpdir;
		}

		File temp = null;

		try {
			temp = File.createTempFile(OutilsCommun.class.getSimpleName(), TEXT_EXTENSION);

			return temp.getAbsoluteFile().getParent();
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			if (temp != null) {
				if (temp.exists()) {
					temp.delete();
				}
			}
		}
	}

	/**
	 * Extrait le répertoire courant du workspace d'Eclipse
	 * @return le répertoire courant du workspace d'Eclipse (getCurrentDirectory() si on n'est pas dans Eclipse)
	 */
	final public static String getCurrentEclipseWorkspaceDirectory() {
		String path = getCurrentDirectory();

		if (isEclipseIDE()) {
			path = new File(path).getAbsoluteFile().getParent();
		}

		return path;
	}

	/**
	 * Extrait le projet courant du workspace d'Eclipse (i.e. nom du répertoire courant)
	 * @return le projet courant du workspace d'Eclipse
	 */
	final public static String getCurrentEclipseProject() {
		return new File(getCurrentDirectory()).getAbsoluteFile().getName();
	}

	/**
	 * Extrait le nom de l'ordinateur local
	 * @return le nom de l'ordinateur local
	 */
	@CoverageOnly
	final public static String getHostName() {
		InetAddress addr;

		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			addr = null;
		}

		if (addr == null) {
			return null;
		}

		return addr.getHostName();
	}

	/**
	 * Extrait le nom complet de l'ordinateur local
	 * @return le nom complet de l'ordinateur local
	 */
	@CoverageOnly
	final public static String getFullHostName() {
		InetAddress addr;

		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			addr = null;
		}

		if (addr == null) {
			return null;
		}

		return addr.getCanonicalHostName();
	}

	/**
	 * Extrait le nom du domaine de l'ordinateur local
	 * @return le nom du domaine de l'ordinateur local
	 */
	@CoverageOnly
	final public static String getHostDomainName() {
		InetAddress addr;

		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			addr = null;
		}

		if (addr == null) {
			return null;
		}

		int hostnameLength = addr.getHostName().length() + 1;
		String fullname = addr.getCanonicalHostName();

		if (fullname.length() >= hostnameLength) {
			return fullname.substring(hostnameLength);
		}

		return null;
	}

	/**
	 * Extrait l'adresse IP d'une adresse donnée
	 * @param inetAddress Adresse à extraire
	 * @return l'adresse IP d'une adresse donnée
	 */
	@CoverageOnly // Voir getIPAddress()
	final public static int[] getIPAddress(InetAddress inetAddress) {
		if (inetAddress == null) {
			return null;
		}

		byte[] buf = inetAddress.getAddress();

		if (isEmpty(buf)) {
			return null;
		}

		int[] result = new int[buf.length];

		for (int i = 0; i < buf.length; i++) {
			result[i] = unsignedByteToInt(buf[i]);
		}

		return result;
	}

	/**
	 * Extrait l'adresse IP de l'ordinateur local
	 * @return l'adresse IP de l'ordinateur local
	 */
	@CoverageOnly
	final public static int[] getIPAddress() {
		InetAddress inetAddress;

		try {
			inetAddress = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			inetAddress = null;
		}

		return getIPAddress(inetAddress);
	}

	/**
	 * Extrait l'adresse IP de l'ordinateur donné
	 * @param host Nom de l'ordinateur à extraire
	 * @return l'adresse IP de l'ordinateur donné
	 */
	@CoverageOnly
	@StrictAutomatedTests("localhost")
	final public static int[] getIPAddress(String host) {
		InetAddress inetAddress;

		try {
			inetAddress = InetAddress.getByName(host);
		} catch (UnknownHostException e) {
			inetAddress = null;
		}

		return getIPAddress(inetAddress);
	}

	/**
	 * Extrait l'adresse IP de l'ordinateur local
	 * @return l'adresse IP de l'ordinateur local
	 */
	@CoverageOnly
	final public static String getIPAddressStr() {
		InetAddress inetAddress;

		try {
			inetAddress = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			inetAddress = null;
		}

		if (inetAddress == null) {
			return null;
		}

		return inetAddress.getHostAddress();
	}

	/**
	 * Extrait l'adresse IP de l'ordinateur donné
	 * @param host Nom de l'ordinateur à extraire
	 * @return l'adresse IP de l'ordinateur donné
	 */
	@CoverageOnly
	@StrictAutomatedTests("localhost")
	final public static String getIPAddressStr(String host) {
		InetAddress inetAddress;

		try {
			inetAddress = InetAddress.getByName(host);
		} catch (UnknownHostException e) {
			inetAddress = null;
		}

		if (inetAddress == null) {
			return null;
		}

		return inetAddress.getHostAddress();
	}

	/**
	 * Extrait l'adresse IP de l'ordinateur sur l'internet
	 * @return l'adresse IP de l'ordinateur sur l'internet
	 */
	@CoverageOnly
	final public static int[] getInternetIPAddress() {
		String internet = getInternetIPAddressStr();

		if (!isEmpty(internet)) {
			String[] parts = internet.split("\\.");

			if (parts.length == 4) {
				int[] result = new int[4];

				for (int i = 0; i < parts.length; i++) {
					result[i] = Integer.parseInt(parts[i]);
				}

				return result;
			}
		}

		return null;
	}

	/**
	 * Extrait l'adresse IP de l'ordinateur sur l'internet
	 * @return l'adresse IP de l'ordinateur sur l'internet
	 */
	@CoverageOnly
	final public static String getInternetIPAddressStr() {
		FetchURL fetchURL = new FetchURL();

		try {
			byte[] buf = fetchURL.getContent("https://api.ipify.org");

			if (fetchURL.isResponseCodeOK()) {
				if (fetchURL.isText()) {
					return new String(buf);
				}
			}
		} catch (Exception e) {
			// Ignore
		}

		try {
			byte[] buf = fetchURL.getContent("https://api.my-ip.io/ip");

			if (fetchURL.isResponseCodeOK()) {
				if (fetchURL.isText()) {
					return new String(buf);
				}
			}
		} catch (Exception e) {
			// Ignore
		}

		return null;
	}

	/**
	 * Envoi une requête ping à un ordinateur donné
	 * @param timeout Temps maximum d'attente en millisecondes
	 * @return vrai si l'ordinateur répond à la requête ping en moins de 5 secondes
	 */
	@CoverageOnly
	@StrictAutomatedTests("localhost")
	final public static boolean sendPingRequest(String host) {
		return sendPingRequest(host, 5000);
	}

	/**
	 * Envoi une requête ping à un ordinateur donné
	 * @param host Nom de l'ordinateur à envoyer la requête ping
	 * @param timeout Temps maximum d'attente en millisecondes
	 * @return vrai si l'ordinateur répond à la requête ping dans le temps prescript
	 */
	@CoverageOnly
	@StrictAutomatedTests({ "localhost", "1000", "outilscommun", "500" })
	final public static boolean sendPingRequest(String host, int timeout) {
		InetAddress inetAddress;

		try {
			inetAddress = InetAddress.getByName(host);
		} catch (UnknownHostException e) {
			inetAddress = null;
		}

		if (inetAddress != null) {
			try {
				return inetAddress.isReachable(timeout);
			} catch (IOException e) {
				return false;
			}
		}

		return false;
	}

	/**
	 * Envoi une requête ping à un ordinateur donné
	 * @param timeout Temps maximum d'attente en millisecondes
	 * @return le temps réponse en millisecondes à la requête ping (-1L si pas de réponse)
	 */
	@CoverageOnly
	@StrictAutomatedTests("localhost")
	final public static long sendPingRequestTime(String host) {
		return sendPingRequestTime(host, 5000);
	}

	/**
	 * Envoi une requête ping à un ordinateur donné
	 * @param host Nom de l'ordinateur à envoyer la requête ping
	 * @param timeout Temps maximum d'attente en millisecondes
	 * @return le temps réponse en millisecondes à la requête ping (-1L si pas de réponse)
	 */
	@CoverageOnly
	@StrictAutomatedTests({ "localhost", "1000", "outilscommun", "500" })
	final public static long sendPingRequestTime(String host, int timeout) {
		InetAddress inetAddress;

		try {
			inetAddress = InetAddress.getByName(host);
		} catch (UnknownHostException e) {
			inetAddress = null;
		}

		if (inetAddress != null) {
			try {
				long start = System.currentTimeMillis();

				if (inetAddress.isReachable(timeout)) {
					return System.currentTimeMillis() - start;
				}
			} catch (IOException e) {
				return -1L;
			}
		}

		return -1L;
	}

	/**
	 * Extrait un nom basé sur une classe java et la date et heure actuel
	 * @param javaClass Classe java à extraire
	 * @return le nom extrait
	 */
	@CoverageOnly
	final public static String getClassTimestampName(Class<?> javaClass) {
		if (javaClass == null) {
			javaClass = OutilsCommun.class;
		}

		return getTimestampName(javaClass.getSimpleName());
	}

	/**
	 * Extrait un nom basé sur une nom de base et la date et heure actuel
	 * @param name Le nom de base
	 * @return le nom extrait
	 */
	@CoverageOnly
	final public static String getTimestampName(String name) {
		if (name == null) {
			name = OutilsCommun.class.getSimpleName();
		}

		return name + "_" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
	}

	/**
	 * Extrait le chemin complet d'un fichier
	 * @param values Liste des valeurs du chemin complet d'un fichier à extraire
	 * @return le chemin complet d'un fichier
	 */
	@AutomatedTests("a,b,c")
	@AutomatedTests("new String[] { \"a\", \"b\", \"\\\\c\", \"d\\\\\", \"e\" }")
	final public static String getFullname(String... values) {
		String fullname = "";

		if (values != null) {
			for (String value : values) {
				if (!isEmpty(value)) {
					if (value.endsWith(File.separator)) {
						value = value.substring(0, value.length() - 1);
					}

					if (value.startsWith(File.separator)) {
						fullname += value;
					} else {
						if (!isEmpty(fullname)) {
							if (!fullname.endsWith(File.separator)) {
								fullname += File.separator;
							}
						}

						fullname += value;
					}
				}
			}
		}

		return fullname;
	}

	/**
	 * Extrait le chemin complet d'un fichier unix/linux
	 * @param values Liste des valeurs du chemin complet d'un fichier à extraire
	 * @return le chemin complet d'un fichier unix/linux
	 */
	@AutomatedTests("a,b,c")
	@AutomatedTests("new String[] { \"a\", \"b\", \"//c\", \"d//\", \"e\" }")
	final public static String getUnixFullname(String... values) {
		String fullname = "";

		if (values != null) {
			for (String value : values) {
				if (!isEmpty(value)) {
					if (value.endsWith(UNIX_FILE_SEPARATOR)) {
						value = value.substring(0, value.length() - 1);
					}

					if (value.startsWith(UNIX_FILE_SEPARATOR)) {
						fullname += value;
					} else {
						if (!isEmpty(fullname)) {
							if (!fullname.endsWith(UNIX_FILE_SEPARATOR)) {
								fullname += UNIX_FILE_SEPARATOR;
							}
						}

						fullname += value;
					}
				}
			}
		}

		return fullname;
	}

	/**
	 * Extrait le chemin complet d'un fichier Windows
	 * @param values Liste des valeurs du chemin complet d'un fichier à extraire
	 * @return le chemin complet d'un fichier Windows
	 */
	@AutomatedTests("a,b,c")
	@AutomatedTests("new String[] { \"a\", \"b\", \"\\\\c\", \"d\\\\\", \"e\" }")
	final public static String getWindowsFullname(String... values) {
		String fullname = "";

		if (values != null) {
			for (String value : values) {
				if (!isEmpty(value)) {
					if (value.endsWith(WINDOWS_FILE_SEPARATOR)) {
						value = value.substring(0, value.length() - 1);
					}

					if (value.startsWith(WINDOWS_FILE_SEPARATOR)) {
						fullname += value;
					} else {
						if (!isEmpty(fullname)) {
							if (!fullname.endsWith(WINDOWS_FILE_SEPARATOR)) {
								fullname += WINDOWS_FILE_SEPARATOR;
							}
						}

						fullname += value;
					}
				}
			}
		}

		return fullname;
	}

	/**
	 * Vérifie si une valeur contient des caractères de recherche * ou ?
	 * @param value La valeur à vérifier
	 * @return vrai si contient des caractères de recherche
	 */
	@AutomatedTests(value = "*,?", iterate = true)
	final public static boolean hasWildcard(String value) {
		if (isEmpty(value)) {
			return false;
		}

		return (value.contains("*") || value.contains("?"));
	}

	/**
	 * Indique si le chemin de fichier donné est absolu ou non
	 * @param path Le chemin de fichier
	 * @return vrai si absolu
	 */
	@AutomatedTests("C:\\Windows")
	final public static boolean isAbsolutePath(String path) {
		if (path != null) {
			path = path.trim();

			if (isWindows()) {
				if (path.length() >= 2) {
					return Character.isLetter(path.charAt(0)) && (path.charAt(1) == ':');
				}
			} else {
				return path.startsWith(File.separator);
			}
		}

		return false;
	}

	/**
	 * Indique si le chemin de fichier donné est absolu ou non
	 * @param path Le chemin de fichier
	 * @return vrai si absolu
	 */
	@AutomatedTests("C:\\Windows")
	final public static boolean isRelativePath(String path) {
		if (path != null) {
			return !isAbsolutePath(path);
		}

		return false;
	}

	/**
	 * Normalisation d'un chemin de fichier relatif
	 * @param path Le chemin
	 * @return le chemin normalisé
	 */
	@AutomatedTests(value = "C:\\Windows,a,\\a,.a,.\\a", iterate = true)
	@AutomatedTests(value = "\"\"", process = false)
	final public static String getRelativePath(String path) {
		if (path != null) {
			path = path.trim();

			if (isRelativePath(path)) {
				if (isEmpty(path)) {
					path = ".";
				} else if (!path.startsWith(".")) {
					if (path.startsWith(File.separator)) {
						path = "." + path;
					} else {
						path = "." + File.separator + path;
					}
				} else if (!path.startsWith("." + File.separator)) {
					path = "." + File.separator + path;
				}
			}
		}

		return path;
	}

	/**
	 * Extrait le chemin relatif d'un fichier par rapport à un chemin donné
	 * @param path Le chemin
	 * @param file Le fichier
	 * @return le chemin relatif du fichier (null si impossible)
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "a", "a\\b", "a", "c", "a\\b", "c" })
	final public static String toRelativePath(String path, String file) throws Exception {
		if (isEmpty(path)) {
			return !isEmpty(file) ? file : null;
		}

		if (!isEmpty(file)) {
			File relativeFile = toRelativePath(new File(path), new File(file));

			if (relativeFile != null) {
				return relativeFile.getPath();
			}
		}

		return null;
	}

	/**
	 * Extrait le chemin relatif d'un fichier par rapport à un chemin donné
	 * @param path Le chemin
	 * @param file Le fichier
	 * @return le chemin relatif du fichier (null si impossible)
	 * @throws Exception en cas d'erreur...
	 */
	final public static File toRelativePath(File path, File file) throws Exception {
		if (path == null) {
			return file;
		}

		String fullPath = path.getCanonicalPath();
		String fullFile = file.getCanonicalPath();

		if (fullFile.startsWith(fullPath)) {
			String relativeFile = fullFile.substring(fullPath.length());

			if (relativeFile.startsWith(File.separator)) {
				relativeFile = relativeFile.substring(File.separator.length());
			}

			return new File(relativeFile);
		}

		return toRelativePath(path.getCanonicalFile().getParentFile(), file);
	}

	/**
	 * Lecture d'un fichier binaire dans un tableau binaire
	 * @param file Le fichier binaire déjà ouvert
	 * @return un byte[]
	 * @throws IOException en cas d'erreur...
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "source.txt" }, filenames = 0)
	final public static byte[] getBytesFromFile(File file) throws IOException, Exception {
		InputStream is = new FileInputStream(file);

		// Get the size of the file
		long length = file.length();

		// You cannot create an array using a long type.
		// It needs to be an int type.
		// Before converting to an int type, check
		// to ensure that file is not larger than Integer.MAX_VALUE.
		if (length > Integer.MAX_VALUE) {
			// File is too large
			is.close();
			throw new Exception("Le fichier binaire est trop grand.  Maximum: " + Integer.MAX_VALUE);
		}

		// Create the byte array to hold the data
		byte[] bytes = new byte[(int) length];

		// Read in the bytes
		int offset = 0;
		int numRead = 0;
		while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
			offset += numRead;
		}

		// Ensure all the bytes have been read in
		if (offset < bytes.length) {
			is.close();
			throw new IOException("Erreur lors de la lecture du fichier " + file.getName());
		}

		// Close the input stream and return bytes
		is.close();
		return bytes;
	}

	/**
	 * Scan un répertoire
	 * @param list La liste
	 * @param base Le chemin courant
	 * @param subdir Indicateur de sous-répertoire
	 * @param current Le nom du sous-répertoire courant relatif à la base
	 * @param filter Le filtre
	 * @throws Exception en cas d'erreur...
	 */
	final protected static void scanForFiles(List<NameValue> list, File base, final boolean subdir, String current, final FilenameFilter filter) throws Exception {
		String[] filenames = null;

		if (base.exists()) {
			if (base.isDirectory()) {
				filenames = base.list(new FilenameFilter() {

					@Override
					public boolean accept(File dir, String name) {
						File f = new File(getFullname(dir.getAbsolutePath(), name));

						if (f.isDirectory()) {
							if (!subdir) {
								return false;
							}
						}

						return (filter != null) ? filter.accept(dir, name) : true;
					}
				});

				if (filenames != null) {
					Arrays.sort(filenames, new Comparator<String>() {

						@Override
						public int compare(String arg0, String arg1) {
							return compareIgnoreCase(arg0, arg1);
						}
					});
				}
			} else {
				throw new Exception("Le répertoire " + base.getName() + " est un fichier !!!");
			}
		} else {
			throw new Exception("Le répertoire " + base.getName() + " n'existe pas !!!");
		}

		for (String name : filenames) {
			String filename = getFullname(base.getAbsolutePath(), name);

			File file = new File(filename);

			if (file.isFile()) {
				list.add(new NameValue(current, name));
			} else if (file.isDirectory()) {
				scanForFiles(list, file, subdir, getFullname(current, name), filter);
			}
		}
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(String baseDir) throws Exception {
		return scanForFiles(new File(baseDir));
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(File baseDir) throws Exception {
		return scanForFiles(baseDir, null, true);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(String baseDir, boolean subdir) throws Exception {
		return scanForFiles(new File(baseDir), subdir);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(File baseDir, boolean subdir) throws Exception {
		List<NameValue> list = new ArrayList<NameValue>();

		scanForFiles(list, baseDir, subdir, "", null);

		return list;
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de fichiers
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(String baseDir, FilenameFilter filter) throws Exception {
		return scanForFiles(new File(baseDir), filter);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de fichiers
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(File baseDir, FilenameFilter filter) throws Exception {
		return scanForFiles(baseDir, filter, true);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de fichiers
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(String baseDir, FilenameFilter filter, boolean subdir) throws Exception {
		return scanForFiles(new File(baseDir), filter, subdir);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de fichiers
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForFiles(File baseDir, FilenameFilter filter, boolean subdir) throws Exception {
		List<NameValue> list = new ArrayList<NameValue>();

		scanForFiles(list, baseDir, subdir, "", filter);

		return list;
	}

	/**
	 * Scan un répertoire
	 * @param list La liste
	 * @param base Le chemin courant
	 * @param subdir Indicateur de sous-répertoire
	 * @param reverse Indicateur d'inversion de l'arbre parcouru
	 * @param current Le nom du sous-répertoire courant relatif à la base
	 * @param filter Le filtre des noms de répertoires
	 * @throws Exception en cas d'erreur...
	 */
	final protected static void scanForDirectories(List<NameValue> list, File base, boolean subdir, boolean reverse, String current, final FilenameFilter filter) throws Exception {
		String[] directoriesNames = null;

		if (base.exists()) {
			if (base.isDirectory()) {
				directoriesNames = base.list(new FilenameFilter() {

					@Override
					public boolean accept(File dir, String name) {
						File f = new File(getFullname(dir.getAbsolutePath(), name));

						return f.isDirectory() ? ((filter != null) ? filter.accept(dir, name) : true) : false;
					}
				});

				if (directoriesNames != null) {
					Arrays.sort(directoriesNames, new Comparator<String>() {

						@Override
						public int compare(String arg0, String arg1) {
							return compareIgnoreCase(arg0, arg1);
						}
					});
				}
			} else {
				throw new Exception("Le répertoire " + base.getName() + " est un fichier !!!");
			}
		} else {
			throw new Exception("Le répertoire " + base.getName() + " n'existe pas !!!");
		}

		for (String name : directoriesNames) {
			String directoryName = getFullname(base.getAbsolutePath(), name);

			File directory = new File(directoryName);

			if (directory.isDirectory()) {
				if (!reverse) {
					list.add(new NameValue(current, name));
				}

				if (subdir) {
					scanForDirectories(list, directory, subdir, reverse, getFullname(current, name), filter);
				}

				if (reverse) {
					list.add(new NameValue(current, name));
				}
			}
		}
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(String baseDir) throws Exception {
		return scanForDirectories(new File(baseDir));
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(File baseDir) throws Exception {
		return scanForDirectories(baseDir, null, true, false);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(String baseDir, boolean subdir) throws Exception {
		return scanForDirectories(new File(baseDir), subdir);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(File baseDir, boolean subdir) throws Exception {
		return scanForDirectories(baseDir, null, subdir, false);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param subdir Indicateur de sous-répertoire
	 * @param reverse Indicateur d'inversion de l'arbre parcouru
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(String baseDir, boolean subdir, boolean reverse) throws Exception {
		return scanForDirectories(new File(baseDir), subdir, reverse);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param subdir Indicateur de sous-répertoire
	 * @param reverse Indicateur d'inversion de l'arbre parcouru
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(File baseDir, boolean subdir, boolean reverse) throws Exception {
		return scanForDirectories(baseDir, null, subdir, reverse);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de répertoires
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(String baseDir, FilenameFilter filter) throws Exception {
		return scanForDirectories(new File(baseDir), filter);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de répertoires
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(File baseDir, FilenameFilter filter) throws Exception {
		return scanForDirectories(baseDir, filter, true, false);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de répertoires
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(String baseDir, FilenameFilter filter, boolean subdir) throws Exception {
		return scanForDirectories(new File(baseDir), filter, subdir);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de répertoires
	 * @param subdir Indicateur de sous-répertoire
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(File baseDir, FilenameFilter filter, boolean subdir) throws Exception {
		return scanForDirectories(baseDir, filter, subdir, false);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de répertoires
	 * @param subdir Indicateur de sous-répertoire
	 * @param reverse Indicateur d'inversion de l'arbre parcouru
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(String baseDir, FilenameFilter filter, boolean subdir, boolean reverse) throws Exception {
		return scanForDirectories(new File(baseDir), filter, subdir, reverse);
	}

	/**
	 * Scan un répertoire
	 * @param baseDir Le répertoire de base
	 * @param filter Le filtre des noms de répertoires
	 * @param subdir Indicateur de sous-répertoire
	 * @param reverse Indicateur d'inversion de l'arbre parcouru
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<NameValue> scanForDirectories(File baseDir, FilenameFilter filter, boolean subdir, boolean reverse) throws Exception {
		List<NameValue> list = new ArrayList<NameValue>();

		scanForDirectories(list, baseDir, subdir, reverse, "", filter);

		return list;
	}

	/**
	 * Copie un fichier a un autre fichier
	 * @param source Le fichier source
	 * @param destination Le fichier de destination
	 * @throws Exception en cas d'erreur...
	 */
	final public static void copyFile(File source, File destination) throws Exception {
		if (source == null) {
			throw new Exception("Pas de fichier source");
		}

		if (destination == null) {
			throw new Exception("Pas de fichier de destination");
		}

		if (isWindows()) {
			if (destination.getAbsolutePath().equalsIgnoreCase(source.getAbsolutePath())) {
				throw new Exception("La destination est la même que la source");
			}
		} else {
			if (destination.getAbsolutePath().equals(source.getAbsolutePath())) {
				throw new Exception("La destination est la même que la source");
			}
		}

		Files.copy(source.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
	}

	/**
	 * Copie un nom de fichier a un autre nom de fichier
	 * @param source Le nom de fichier source
	 * @param destination Le nom de fichier de destination
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",source.txt", ",OutilsCommun.txt" }, filenames = { 0, 1 }, iterate = true)
	final public static void copyFile(String source, String destination) throws Exception {
		if (isEmpty(source)) {
			throw new Exception("Pas de nom de fichier source");
		}

		if (isEmpty(destination)) {
			throw new Exception("Pas de nom de fichier de destination");
		}

		copyFile(new File(source), new File(destination));
	}

	/**
	 * Copie un ichier a un autre nom de fichier
	 * @param source Le fichier source
	 * @param destination Le nom de fichier de destination
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",source.txt", ",OutilsCommun.txt" }, filenames = { 0, 1 }, iterate = true)
	final public static void copyFile(File source, String destination) throws Exception {
		if (isEmpty(destination)) {
			throw new Exception("Pas de nom de fichier de destination");
		}

		copyFile(source, new File(destination));
	}

	/**
	 * Renome un fichier a un autre fichier
	 * @param source Le fichier source
	 * @param destination Le fichier de destination
	 * @throws Exception en cas d'erreur...
	 */
	final public static void renameFile(File source, File destination) throws Exception {
		if (source == null) {
			throw new Exception("Pas de fichier source");
		}

		if (destination == null) {
			throw new Exception("Pas de fichier de destination");
		}

		if (isWindows()) {
			if (destination.getAbsolutePath().equalsIgnoreCase(source.getAbsolutePath())) {
				throw new Exception("La destination est la même que la source");
			}
		} else {
			if (destination.getAbsolutePath().equals(source.getAbsolutePath())) {
				throw new Exception("La destination est la même que la source");
			}
		}

		Files.move(source.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
	}

	/**
	 * Renome un nom de fichier a un autre nom de fichier
	 * @param source Le nom de fichier source
	 * @param destination Le nom de fichier de destination
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void renameFile(String source, String destination) throws Exception {
		if (isEmpty(source)) {
			throw new Exception("Pas de nom de fichier source");
		}

		if (isEmpty(destination)) {
			throw new Exception("Pas de nom de fichier de destination");
		}

		renameFile(new File(source), new File(destination));
	}

	/**
	 * Renome un fichier a un autre nom de fichier
	 * @param source Le fichier source
	 * @param destination Le nom de fichier de destination
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void renameFile(File source, String destination) throws Exception {
		if (isEmpty(destination)) {
			throw new Exception("Pas de nom de fichier de destination");
		}

		renameFile(source, new File(destination));
	}

	/**
	 * Historisation d'un fichier en plusieurs versions
	 * @param baseFileName Nom de fichier de base sans extension
	 * @param extension Extension du fichier
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void backupFile(String baseFileName, String extension) throws Exception {
		backupFile(baseFileName, extension, 9);
	}

	/**
	 * Historisation d'un fichier en plusieurs versions
	 * @param baseFileName Nom de fichier de base sans extension
	 * @param extension Extension du fichier
	 * @param maxVersion Nombre maximun de versions
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void backupFile(String baseFileName, String extension, int maxVersion) throws Exception {
		File currentFile = new File(baseFileName + extension);

		if (currentFile.exists()) {
			for (int id = (maxVersion - 1); id > 0; id--) {
				File backupFile = new File(baseFileName + "-" + id + extension);

				if (backupFile.exists()) {
					File backupFilePlus = new File(baseFileName + "-" + (id + 1) + extension);

					Files.copy(backupFile.toPath(), backupFilePlus.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
				}
			}

			File backupFile = new File(baseFileName + "-1" + extension);

			Files.copy(currentFile.toPath(), backupFile.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
		}
	}

	/**
	 * Effectue la copie récursive de fichiers
	 * @param source Répertoire source
	 * @param destination Répertoire destination
	 * @throws Exception en cas d'erreur...
	 */
	final protected static void doCopyDirectory(String source, String destination) throws Exception {
		List<NameValue> list = scanForFiles(source);

		for (NameValue item : list) {
			File sourceDir = new File(getFullname(source, item.getName()));
			File destDir = new File(getFullname(destination, item.getName()));

			if (!destDir.exists()) {
				destDir.mkdirs();
			}

			copyFile(getFullname(sourceDir.getAbsolutePath(), item.getValue()), getFullname(destDir.getAbsolutePath(), item.getValue()));
		}
	}

	/**
	 * Copie un répertoire a un autre répertoire
	 * @param source Le répertoire source
	 * @param destination Le répertoire de destination
	 * @throws Exception en cas d'erreur...
	 */
	final public static void copyDirectory(File source, File destination) throws Exception {
		if (source == null) {
			throw new Exception("Pas de répertoire source");
		}

		if (destination == null) {
			throw new Exception("Pas de répertoire de destination");
		}

		if (isWindows()) {
			if (destination.getAbsolutePath().equalsIgnoreCase(source.getAbsolutePath())) {
				throw new Exception("La destination est la même que la source");
			}
		} else {
			if (destination.getAbsolutePath().equals(source.getAbsolutePath())) {
				throw new Exception("La destination est la même que la source");
			}
		}

		doCopyDirectory(source.getAbsolutePath(), destination.getAbsolutePath());
	}

	/**
	 * Copie un nom de répertoire a un autre nom de répertoire
	 * @param source Le nom de répertoire source
	 * @param destination Le nom de répertoire de destination
	 * @throws Exception en cas d'erreur...
	 */
	final public static void copyDirectory(String source, String destination) throws Exception {
		if (isEmpty(source)) {
			throw new Exception("Pas de nom de répertoire source");
		}

		if (isEmpty(destination)) {
			throw new Exception("Pas de nom de répertoire de destination");
		}

		doCopyDirectory(source, destination);
	}

	/**
	 * Copie un ichier a un autre nom de répertoire
	 * @param source Le répertoire source
	 * @param destination Le nom de répertoire de destination
	 * @throws Exception en cas d'erreur...
	 */
	final public static void copyDirectory(File source, String destination) throws Exception {
		if (isEmpty(destination)) {
			throw new Exception("Pas de nom de répertoire de destination");
		}

		doCopyDirectory(source.getAbsolutePath(), destination);
	}

	/**
	 * Supprresion d'un répertoire qui est vide
	 * @param dir Nom du répertoire vide à supprimer
	 * @return vrai si réussi
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static boolean deleteEmptyDirectory(String dirName) throws Exception {
		return deleteEmptyDirectory(new File(dirName));
	}

	/**
	 * Supprresion d'un répertoire qui est vide
	 * @param dir Répertoire vide à supprimer
	 * @return vrai si réussi
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static boolean deleteEmptyDirectory(File dir) throws Exception {
		if (dir.exists() && dir.isDirectory()) {
			if (dir.list().length == 0) {
				return Files.deleteIfExists(dir.toPath());
			}
		}

		return true;
	}

	/**
	 * Supprresion d'un répertoire qui est vide
	 * @param dir Répertoire vide à supprimer
	 * @param retries Nombre d'essais
	 * @return vrai si réussi
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static boolean deleteEmptyDirectory(File dir, int retries) throws Exception {
		if (dir.exists() && dir.isDirectory()) {
			if (dir.list().length == 0) {
				return Files.deleteIfExists(dir.toPath());
			}

			while (retries != 0) {
				try {
					if (!dir.exists()) {
						return true;
					}

					return Files.deleteIfExists(dir.toPath());
				} catch (DirectoryNotEmptyException dnee) {
					if (retries == 0) {
						throw dnee;
					} else {
						retries--;

						try {
							Thread.sleep(500);
						} catch (Exception e1) {
							// Ignore...
						}
					}
				}
			}
		}

		return true;
	}

	/**
	 * Supprime un fichier ou répertoire
	 * @param filename Le nom de fichier à supprimer
	 * @return vrai si supprimé
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static boolean deleteFileDirectory(String filename) throws Exception {
		if (isEmpty(filename)) {
			throw new Exception("Pas de nom de fichier à supprimer");
		}

		return deleteFileDirectory(new File(filename));
	}

	/**
	 * Supprime un fichier ou répertoire
	 * @param file Le fichier à supprimer
	 * @return vrai si supprimé
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static boolean deleteFileDirectory(File file) throws Exception {
		if (file == null) {
			throw new Exception("Pas de fichier à supprimer");
		}

		if (file.exists() && file.isDirectory()) {
			cleanDirectories(file.listFiles());

			return deleteEmptyDirectory(file, 10);
		}

		return Files.deleteIfExists(file.toPath());
	}

	/**
	 * Creation d'un répertoire
	 * @param baseDir Le chemin complet du répertoire à créer
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void buildDirectory(String baseDir) throws Exception {
		File base = new File(baseDir);

		if (!base.exists()) {
			base.mkdirs();
		} else if (base.isFile()) {
			throw new Exception("Le répertoire " + baseDir + " est un fichier !!!");
		}
	}

	/**
	 * Creation d'un répertoire
	 * @param baseDir Le chemin complet du répertoire à créer
	 * @param permissions Le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void buildDirectory(String baseDir, int permissions) throws Exception {
		File base = new File(baseDir);

		if (!base.exists()) {
			base.mkdirs();
			setDirectoryPermissions(base, permissions);
		} else if (base.isFile()) {
			throw new Exception("Le répertoire " + baseDir + " est un fichier !!!");
		}
	}

	/**
	 * Creation d'un répertoire
	 * @param baseDir Le chemin complet du répertoire à créer
	 * @param force Indicateur pour forcer la création
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void buildDirectory(String baseDir, boolean force) throws Exception {
		File base = new File(baseDir);

		if (!base.exists()) {
			base.mkdirs();
		} else if (base.isDirectory()) {
			if (force) {
				cleanDirectories(base.listFiles());
			}
		} else if (force) {
			if (!Files.deleteIfExists(base.toPath())) {
				throw new Exception("Erreur lors de la suppression du fichier " + base.getName());
			}

			base.mkdirs();
		} else {
			throw new Exception("Le répertoire " + baseDir + " est un fichier !!!");
		}
	}

	/**
	 * Creation d'un répertoire
	 * @param baseDir Le chemin complet du répertoire à créer
	 * @param permissions Le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @param force Indicateur pour forcer la création
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void buildDirectory(String baseDir, int permissions, boolean force) throws Exception {
		File base = new File(baseDir);

		if (!base.exists()) {
			base.mkdirs();
			setDirectoryPermissions(base, permissions);
		} else if (base.isDirectory()) {
			if (force) {
				cleanDirectories(base.listFiles());
			}
		} else if (force) {
			if (!Files.deleteIfExists(base.toPath())) {
				throw new Exception("Erreur lors de la suppression du fichier " + base.getName());
			}

			base.mkdirs();
			setDirectoryPermissions(base, permissions);
		} else {
			throw new Exception("Le répertoire " + baseDir + " est un fichier !!!");
		}
	}

	/**
	 * Efface le contenu d'un répertoire
	 * @param content Le contenu d'un répertoire
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests("null")
	final public static void cleanDirectories(File[] content) throws Exception {
		if (content == null) {
			return;
		}

		for (int i = 0; i < content.length; i++) {
			if (content[i].exists()) {
				if (content[i].isFile()) {
					try {
						Files.deleteIfExists(content[i].toPath());
					} catch (Exception e) {
						throw new Exception("Erreur lors de la suppression du fichier " + content[i].getName());
					}
				} else if (content[i].isDirectory()) {
					cleanDirectories(content[i].listFiles());
					deleteEmptyDirectory(content[i], 10);
				} else {
					throw new Exception("N'est pas un fichier ou un répertoire " + content[i].getName());
				}
			}
		}
	}

	/**
	 * Efface le contenu d'un répertoire
	 * @param baseDir Le chemin complet du répertoire à créer
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void cleanDirectories(String baseDir) throws Exception {
		File base = new File(baseDir);

		if (base.exists()) {
			if (base.isDirectory()) {
				cleanDirectories(base.listFiles());
			} else {
				throw new Exception("Le répertoire " + baseDir + " est un fichier !!!");
			}
		} else {
			base.mkdirs();
		}
	}

	/**
	 * Efface les répertoires vides
	 * @param content Le contenu d'un répertoire
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void removeEmptyDirectories(File[] content) throws Exception {
		if (content == null) {
			return;
		}

		for (int i = 0; i < content.length; i++) {
			if (content[i].isDirectory()) {
				removeEmptyDirectories(content[i].listFiles());

				if (content[i].listFiles().length == 0) {
					if (!Files.deleteIfExists(content[i].toPath())) {
						throw new Exception("Erreur lors de la suppression du répertoire " + content[i].getName());
					}
				}
			}
		}
	}

	/**
	 * Efface les répertoires vides
	 * @param baseDir Le chemin complet du répertoire à créer
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void removeEmptyDirectories(String baseDir) throws Exception {
		File base = new File(baseDir);

		if (base.exists()) {
			if (base.isDirectory()) {
				removeEmptyDirectories(base.listFiles());
			} else {
				throw new Exception("Le répertoire " + baseDir + " est un fichier !!!");
			}
		} else {
			throw new Exception("Le répertoire " + baseDir + " n'existe pas !!!");
		}
	}

	/**
	 * Extrait les permissions d'un fichier donné
	 * @param filename Le chemin complet du fichier à extraire les permissions
	 * @return le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = "source.txt", filenames = 0)
	final public static int getFilePermissions(String filename) throws Exception {
		if (isEmpty(filename)) {
			throw new Exception("Pas de nom de fichier de spécifié");
		}

		return getFilePermissions(new File(filename));
	}

	/**
	 * Extrait les permissions d'un fichier donné
	 * @param file Le fichier à extraire les permissions
	 * @return le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests("new File(JunitHelper.TEST_TEMP_DIR)")
	final public static int getFilePermissions(File file) throws Exception {
		if (file == null) {
			throw new Exception("Pas de fichier de spécifié");
		}

		if (!file.exists()) {
			throw new Exception("Fichier inexistant: " + file.getCanonicalPath());
		}

		if (!file.isFile()) {
			throw new Exception("Doit être un fichier: " + file.getCanonicalPath());
		}

		return getPathPermissions(file.toPath());
	}

	/**
	 * Extrait les permissions d'un répertoire donné
	 * @param directory Le chemin complet du répertoire à extraire les permissions
	 * @return le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = "junit.JunitHelper.TEST_TEMP_DIR", process = false)
	final public static int getDirectoryPermissions(String directory) throws Exception {
		if (isEmpty(directory)) {
			throw new Exception("Pas de nom de répertoire de spécifié");
		}

		return getDirectoryPermissions(new File(directory));
	}

	/**
	 * Extrait les permissions d'un répertoire donné
	 * @param directory Le répertoire à extraire les permissions
	 * @return le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	final public static int getDirectoryPermissions(File directory) throws Exception {
		if (directory == null) {
			throw new Exception("Pas de répertoire de spécifié");
		}

		if (!directory.exists()) {
			throw new Exception("Répertoire inexistant: " + directory.getCanonicalPath());
		}

		if (!directory.isDirectory()) {
			throw new Exception("Doit être un répertoire: " + directory.getCanonicalPath());
		}

		return getPathPermissions(directory.toPath());
	}

	/**
	 * Extrait les permissions d'un path donné
	 * @param path Le path à extraire les permissions
	 * @return le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	final public static int getPathPermissions(Path path) throws Exception {
		if (path == null) {
			throw new Exception("Pas de path de spécifié");
		}

		int value = 0;

		File file = path.toFile();

		if (file.exists()) {
			if (isUnix()) {
				value = FilePermissionsTypes.getPermissions(Files.getPosixFilePermissions(path));
			} else {
				value |= file.canRead() ? FilePermissionsTypes.OWNER_READ.getPosition() : 0;
				value |= file.canWrite() ? FilePermissionsTypes.OWNER_WRITE.getPosition() : 0;
				value |= file.canExecute() ? FilePermissionsTypes.OWNER_EXECUTE.getPosition() : 0;
			}
		} else {
			throw new Exception("Path inexistant: " + file.getCanonicalPath());
		}

		return value;
	}

	/**
	 * Modifie les permissions d'un fichier donné
	 * @param filename Le chemin complet du fichier à modifier les permissions
	 * @param permissions Le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	final public static void setFilePermissions(String filename, int permissions) throws Exception {
		if (isEmpty(filename)) {
			throw new Exception("Pas de nom de fichier de spécifié");
		}

		setFilePermissions(new File(filename), permissions);
	}

	/**
	 * Modifie les permissions d'un fichier donné
	 * @param file Le fichier à modifier les permissions
	 * @param permissions Le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	final public static void setFilePermissions(File file, int permissions) throws Exception {
		if (file == null) {
			throw new Exception("Pas de fichier de spécifié");
		}

		if (!file.exists()) {
			throw new Exception("Fichier inexistant: " + file.getCanonicalPath());
		}

		if (!file.isFile()) {
			throw new Exception("Doit être un fichier: " + file.getCanonicalPath());
		}

		setPathPermissions(file.toPath(), permissions);
	}

	/**
	 * Modifie les permissions d'un répertoire donné
	 * @param directory Le chemin complet du répertoire à modifier les permissions
	 * @param permissions Le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	final public static void setDirectoryPermissions(String directory, int permissions) throws Exception {
		if (isEmpty(directory)) {
			throw new Exception("Pas de nom de répertoire de spécifié");
		}

		setDirectoryPermissions(new File(directory), permissions);
	}

	/**
	 * Modifie les permissions d'un répertoire donné
	 * @param directory Le répertoire à modifier les permissions
	 * @param permissions Le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	final public static void setDirectoryPermissions(File directory, int permissions) throws Exception {
		if (directory == null) {
			throw new Exception("Pas de répertoire de spécifié");
		}

		if (!directory.exists()) {
			throw new Exception("Répertoire inexistant: " + directory.getCanonicalPath());
		}

		if (!directory.isDirectory()) {
			throw new Exception("Doit être un répertoire: " + directory.getCanonicalPath());
		}

		setPathPermissions(directory.toPath(), permissions);
	}

	/**
	 * Modifie les permissions d'un path donné
	 * @param path Le path à modifier les permissions
	 * @param permissions Le masque des des permissions en hexadecimal (ex: 0x640) Masque Unix
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "setPathPermissions", "0x640" })
	@AutomatedTests(value = { "path", "-1" }, process = false)
	final public static void setPathPermissions(Path path, int permissions) throws Exception {
		if (path == null) {
			throw new Exception("Pas de path de spécifié");
		}

		if (permissions < 0) {
			throw new Exception("La valeur des permissions doit être 0 ou positve (i.e. >= 0)");
		}

		File file = path.toFile();

		if (file.exists()) {
			Set<PosixFilePermission> set = FilePermissionsTypes.getPosixFilePermissions(permissions);

			if (isUnix()) {
				Files.setPosixFilePermissions(path, set);
			} else {
				file.setReadable(FilePermissionsTypes.isReadable(set), FilePermissionsTypes.isReadableByOwnerOnly(set));
				file.setWritable(FilePermissionsTypes.isWritable(set), FilePermissionsTypes.isWritableByOwnerOnly(set));
				file.setExecutable(FilePermissionsTypes.isExecutable(set), FilePermissionsTypes.isExecutableByOwnerOnly(set));
			}
		} else {
			throw new Exception("Path inexistant: " + file.getCanonicalPath());
		}
	}

	/**
	 * Découpe un fichier en sous-fichiers de taille "bytesPerSplit"
	 * @param filename Le nom du fichier
	 * @param bytesPerSplit La taille du découpage
	 * @param destination Répertoire de destination
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<String> splitFile(String filename, long bytesPerSplit, String destination) throws Exception {
		return splitFile(new File(filename), bytesPerSplit, destination);
	}

	/**
	 * Découpe un fichier en sous-fichiers de taille "bytesPerSplit"
	 * @param file Le fichier
	 * @param bytesPerSplit La taille du découpage
	 * @param destination Répertoire de destination
	 * @return la liste ded sous-fichiers
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<String> splitFile(File file, long bytesPerSplit, String destination) throws Exception {
		if (file == null) {
			throw new RuntimeException("Pas de fichier");
		}

		if (!file.exists()) {
			throw new RuntimeException("Le fichier \"" + file.getName() + "\" n'existe pas");
		}

		if (bytesPerSplit < 1) {
			throw new RuntimeException("bytesPerSplit doit être > 0");
		}

		List<String> files = new ArrayList<String>();

		RandomAccessFile raf = new RandomAccessFile(file, "r");

		long sourceSize = raf.length();

		long numSplits = (sourceSize / bytesPerSplit) + (((sourceSize % bytesPerSplit) == 0) ? 0 : 1);

		long total = 0;

		int length = 0;

		for (long i = numSplits; i > 0; i /= 10) {
			length++;
		}

		long maxReadBufferSize = (bytesPerSplit < 32768) ? (int) bytesPerSplit : 32768; // 32Ko

		long numReads = (bytesPerSplit / maxReadBufferSize) + (((bytesPerSplit % maxReadBufferSize) == 0) ? 0 : 1);

		byte[] buf;
		int val;

		for (int destIx = 1; destIx <= numSplits; destIx++) {
			String filename = getFullname(destination, file.getName() + "-" + padString(destIx, '0', length));

			files.add(filename);

			BufferedOutputStream bw = new BufferedOutputStream(new FileOutputStream(filename));

			if ((sourceSize - total) >= bytesPerSplit) {
				total += bytesPerSplit;

				long count = bytesPerSplit;

				for (long i = 0; i < numReads; i++) {
					long bufSize = (count >= maxReadBufferSize) ? maxReadBufferSize : count;

					buf = new byte[(int) bufSize];
					val = raf.read(buf);

					if (val != -1) {
						bw.write(buf);
					}

					count -= bufSize;
				}
			} else if ((sourceSize - total) > 0) {
				while (true) {
					buf = new byte[(int) maxReadBufferSize];
					val = raf.read(buf);

					if (val != -1) {
						bw.write(buf, 0, val);
					} else {
						break;
					}
				}
			}

			bw.close();
		}

		raf.close();

		return files;
	}

	/**
	 * Extrait la date et heure courante en UTC (GMT)
	 * @return un Date
	 */
	final public static Date getUTCCurrentDateTime() {
		return getUTCDateTime(null);
	}

	/**
	 * Convertion en date UTC une date locale
	 * @param local La date locale
	 * @return une date en UTC
	 */
	final public static String asUTCDate(Date local) {
		if (local == null) {
			return null;
		}

		DateFormat formatterUTC = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
		formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

		return formatterUTC.format(local);
	}

	/**
	 * Extrait la date et heure donnée en UTC (GMT)
	 * @param localDateTime Date et heure à convertir (null => date et heure courante)
	 * @return un Date
	 */
	final public static Date getUTCDateTime(Date localDateTime) {
		Calendar calendar = Calendar.getInstance();

		if (localDateTime != null) {
			calendar.setTime(localDateTime);
		}

		TimeZone timeZone = calendar.getTimeZone();
		int offset = timeZone.getRawOffset();

		if (timeZone.inDaylightTime(new Date())) {
			offset = offset + timeZone.getDSTSavings();
		}

		int offsetHrs = offset / 1000 / 60 / 60;
		int offsetMins = offset / 1000 / 60 % 60;

		calendar.add(Calendar.HOUR_OF_DAY, (-offsetHrs));
		calendar.add(Calendar.MINUTE, (-offsetMins));

		return calendar.getTime();
	}

	/**
	 * Convertion d'un java.util.Date en String de format aaaa-mm-jj
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatDate(java.sql.Timestamp value) {
		if (value == null) {
			return null;
		}

		return formatDate(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertion d'un java.sql.Timestamp en String de format aaaa-mm-jj hh:mm
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatDateTime(java.sql.Timestamp value) {
		if (value == null) {
			return null;
		}

		return formatDateTime(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertion d'un java.sql.Timestamp en String de format hh:mm
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatTime(java.sql.Timestamp value) {
		if (value == null) {
			return null;
		}

		return formatTime(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertion d'un String de format aaaa-mm-jj en java.util.Date
	 * @param value La valeur à convertir
	 * @return une date
	 * @throws Exception si la valeur n'est pas une date valide
	 */
	@AutomatedTests({ "2021-02-29", "2020-02-29" })
	final public static java.util.Date convertDate(String value) throws Exception {
		if (isEmpty(value)) {
			throw new Exception("La valeur à convertir est vide");
		}

		if (value.length() != 10) {
			throw new Exception("Le format doit être aaaa-mm-jj");
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date resultat = formatter.parse(value, new ParsePosition(0));

		if (!(value.equals(formatter.format(resultat)))) {
			throw new Exception("La date " + value + " est invalide");
		}
		return resultat;
	}

	/**
	 * Convertion d'un String de format aaaa-mm-jj hh:mm en java.util.Date
	 * @param value La valeur à convertir
	 * @return une date
	 * @throws Exception si la valeur n'est pas une dateheure valide
	 */
	@AutomatedTests({ "2021-02-29 20:22", "2020-02-29 20:22" })
	final public static java.util.Date convertDateTime(String value) throws Exception {
		if (isEmpty(value)) {
			throw new Exception("La valeur à convertir est vide");
		}

		if (value.length() != 16) {
			throw new Exception("Le format doit être aaaa-mm-jj hh:mm");
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		java.util.Date resultat = formatter.parse(value, new ParsePosition(0));

		if (!(value.equals(formatter.format(resultat)))) {
			throw new Exception("La dateheure " + value + " est invalide");
		}

		return resultat;
	}

	/**
	 * Convertion d'un String de format hh:mm en java.util.Date
	 * @param value La valeur à convertir
	 * @return une date contenant l'heure
	 * @throws Exception si la valeur n'est pas une heure valide
	 */
	@AutomatedTests({ "20:62", "20:22" })
	final public static java.util.Date convertTime(String value) throws Exception {
		if (isEmpty(value)) {
			throw new Exception("La valeur à convertir est vide");
		}

		if (value.length() != 5) {
			throw new Exception("Le format doit être hh:mm");
		}

		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
		java.util.Date resultat = formatter.parse(value, new ParsePosition(0));

		if (!(value.equals(formatter.format(resultat)))) {
			throw new Exception("L'heure " + value + " est invalide");
		}

		return resultat;
	}

	/**
	 * Convertion d'un java.util.Date en String de format aaaa-mm-jj
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatDate(java.util.Date value) {
		if (value == null) {
			return null;
		}

		return asDateString(value);
	}

	/**
	 * Convertion d'un java.sql.Date en String de format aaaa-mm-jj
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatDate(java.sql.Date value) {
		if (value == null) {
			return null;
		}

		return formatDate(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertion d'un java.util.Date en String de format aaaa-mm-jj hh:mm
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatDateTime(java.util.Date value) {
		if (value == null) {
			return null;
		}

		return asDateTimeString(value, false);
	}

	/**
	 * Convertion d'un java.sql.Date en String de format aaaa-mm-jj hh:mm
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatDateTime(java.sql.Date value) {
		if (value == null) {
			return null;
		}

		return formatDateTime(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertion d'un java.util.Date en String de format hh:mm
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatTime(java.util.Date value) {
		if (value == null) {
			return null;
		}

		return (new SimpleDateFormat("HH:mm")).format(value);
	}

	/**
	 * Convertion d'un java.sql.Time en String de format hh:mm
	 * @param value La valeur à convertir
	 * @return un String (null si value == null)
	 */
	final public static String formatTime(java.sql.Time value) {
		if (value == null) {
			return null;
		}

		return formatTime(new java.util.Date(value.getTime()));
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @return le poucentage formatté
	 */
	final public static String percentage(int count, int total) {
		return percentage((long) count, (long) total, true);
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @param ratio Indicateur d'ajout du ratio au texte du pourcentage
	 * @return le poucentage formatté
	 */
	final public static String percentage(int count, int total, boolean ratio) {
		return percentage((long) count, (long) total, ratio);
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @return le poucentage formatté
	 */
	final public static String percentage(long count, long total) {
		return percentage(count, total, true);
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @param ratio Indicateur d'ajout du ratio au texte du pourcentage
	 * @return le poucentage formatté
	 */
	@AutomatedTests({ "1", "1", "true" })
	final public static String percentage(long count, long total, boolean ratio) {
		double pc = (total != 0) ? (Math.round(1000.0 * ((double) count) / ((double) total)) / 10.0) : 0;
		return PERCENTAGE_FORMAT.format(pc) + "%" + (ratio ? (" (" + count + " / " + total + ")") : "");
	}

	/**
	 * Calcul d'un pourcentage avec étiquette
	 * @param count Le nombre
	 * @param total Le total
	 * @param label L'étiquette
	 * @return le poucentage formatté
	 */
	final public static String percentage(int count, int total, String label) {
		return percentage((long) count, (long) total, true, label);
	}

	/**
	 * Calcul d'un pourcentage avec étiquette
	 * @param count Le nombre
	 * @param total Le total
	 * @param ratio Indicateur d'ajout du ratio au texte du pourcentage
	 * @param label L'étiquette
	 * @return le poucentage formatté
	 */
	final public static String percentage(int count, int total, boolean ratio, String label) {
		return percentage((long) count, (long) total, ratio, label);
	}

	/**
	 * Calcul d'un pourcentage avec étiquette
	 * @param count Le nombre
	 * @param total Le total
	 * @param label L'étiquette
	 * @return le poucentage formatté
	 */
	final public static String percentage(long count, long total, String label) {
		return percentage(count, total, true, label);
	}

	/**
	 * Calcul d'un pourcentage avec étiquette
	 * @param count Le nombre
	 * @param total Le total
	 * @param ratio Indicateur d'ajout du ratio au texte du pourcentage
	 * @param label L'étiquette
	 * @return le poucentage formatté
	 */
	final public static String percentage(long count, long total, boolean ratio, String label) {
		double pc = (total != 0) ? (Math.round(1000.0 * ((double) count) / ((double) total)) / 10.0) : 0;
		return PERCENTAGE_FORMAT.format(pc) + "%" + (ratio ? (" (" + OutilsBase.pluralSize(count, label) + " / " + OutilsBase.pluralSize(total, label) + ")") : "");
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @param french Indicateur d'unité métrique en anglais ou français
	 * @return le poucentage formatté
	 */
	final public static String percentageMetricSize(int count, int total, boolean french) {
		return percentageMetricSize((long) count, (long) total, true, french);
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @param ratio Indicateur d'ajout du ratio au texte du pourcentage
	 * @param french Indicateur d'unité métrique en anglais ou français
	 * @return le poucentage formatté
	 */
	final public static String percentageMetricSize(int count, int total, boolean ratio, boolean french) {
		return percentageMetricSize((long) count, (long) total, ratio, french);
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @param french Indicateur d'unité métrique en anglais ou français
	 * @return le poucentage formatté
	 */
	final public static String percentageMetricSize(long count, long total, boolean french) {
		return percentageMetricSize(count, total, true, french);
	}

	/**
	 * Calcul d'un pourcentage
	 * @param count Le nombre
	 * @param total Le total
	 * @param ratio Indicateur d'ajout du ratio au texte du pourcentage
	 * @param french Indicateur d'unité métrique en anglais ou français
	 * @return le poucentage formatté
	 */
	final public static String percentageMetricSize(long count, long total, boolean ratio, boolean french) {
		double pc = Math.round(1000.0 * ((double) count) / ((double) total)) / 10.0;
		return PERCENTAGE_FORMAT.format(pc) + "%" + (ratio ? (" (" + formatMetricSize(count, french) + " / " + formatMetricSize(total, french) + ")") : "");
	}

	/**
	 * Traitement des apostrophes pour base de données
	 * @param value La chaine à traiter
	 * @return la chaine traitée
	 */
	@AutomatedTests("'Quote'")
	final public static String parseDatabaseQuote(String value) {
		if (isEmpty(value)) {
			return "";
		}

		StringBuffer resultat = new StringBuffer();

		char[] charsData = value.toCharArray();

		for (int i = 0; i < charsData.length; i++) {
			char c = charsData[i];

			if (c == '\'') {
				resultat.append("''");
			} else {
				resultat.append(c);
			}
		}

		return resultat.toString();
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param text Le texte à encrypter
	 * @param secretKey La clé secrète en base 64
	 * @return les données binaires encryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests({ "OutilsCommun", "c2VjcmV0S2V5" }) // secretKey -> Base64("secretKey")
	final public static byte[] encrypt(String text, String secretKey) throws Exception {
		return encrypt(text.getBytes(), Base64.getDecoder().decode(secretKey));
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param value Les données binaires à encrypter
	 * @param secretKey La clé secrète en base 64
	 * @return les données binaires encryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"OutilsCommun\".getBytes()", "\"c2VjcmV0S2V5\"" }, process = false) // secretKey -> Base64("secretKey")
	final public static byte[] encrypt(byte[] value, String secretKey) throws Exception {
		return encrypt(value, Base64.getDecoder().decode(secretKey));
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param text Le texte à encrypter
	 * @param secretKey La clé secrète en binaire
	 * @return les données binaires encryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"OutilsCommun\"", "\"c2VjcmV0S2V5\".getBytes()" }, process = false) // secretKey -> Base64("secretKey")
	final public static byte[] encrypt(String text, byte[] secretKey) throws Exception {
		return encrypt(text.getBytes(), Base64.getDecoder().decode(secretKey));
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param value Les données binaires à encrypter
	 * @param secretKey La clé secrète en binaire
	 * @return les données binaires encryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"OutilsCommun\".getBytes()", "Base64.getDecoder().decode(\"c2VjcmV0S2V5\")" }, process = false) // secretKey -> Base64("secretKey")
	final public static byte[] encrypt(byte[] value, byte[] secretKey) throws Exception {
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey, "Blowfish");

		Cipher cipher = Cipher.getInstance("Blowfish");
		cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);

		byte[] encrypted = cipher.doFinal(value);

		return encrypted;
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param text Le texte à encrypter
	 * @param secretKey La clé secrète en base 64
	 * @return un String encrypté en base 64
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests({ "OutilsCommun", "c2VjcmV0S2V5" }) // secretKey -> Base64("secretKey")
	final public static String encryptAsString(String text, String secretKey) throws Exception {
		return Base64.getEncoder().encodeToString(encrypt(text, secretKey));
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param value Les données binaires à encrypter
	 * @param secretKey La clé secrète en base 64
	 * @return un String encrypté en base 64
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"OutilsCommun\".getBytes()", "\"c2VjcmV0S2V5\"" }, process = false) // secretKey -> Base64("secretKey")
	final public static String encryptAsString(byte[] value, String secretKey) throws Exception {
		return Base64.getEncoder().encodeToString(encrypt(value, secretKey));
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param text Le texte à encrypter
	 * @param secretKey La clé secrète en binaire
	 * @return un String encrypté en base 64
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"OutilsCommun\"", "\"c2VjcmV0S2V5\".getBytes()" }, process = false) // secretKey -> Base64("secretKey")
	final public static String encryptAsString(String text, byte[] secretKey) throws Exception {
		return Base64.getEncoder().encodeToString(encrypt(text, secretKey));
	}

	/**
	 * Encryption d'un texte avec clé secrete utilisant l'algorithme Blowfish
	 * @param value Les données binaires à encrypter
	 * @param secretKey La clé secrète en binaire
	 * @return un String encrypté en base 64
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"OutilsCommun\".getBytes()", "Base64.getDecoder().decode(\"c2VjcmV0S2V5\")" }, process = false) // secretKey -> Base64("secretKey")
	final public static String encryptAsString(byte[] value, byte[] secretKey) throws Exception {
		return Base64.getEncoder().encodeToString(encrypt(value, secretKey));
	}

	/**
	 * Décryption d'un texte encrypté avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedText Texte encrypté en base 64
	 * @param secretKey La clé secrète en base 64
	 * @return les données binaires décryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests({ "aVnxqL186Sz1t4MpodYomg==", "c2VjcmV0S2V5" }) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static byte[] decrypt(String encryptedText, String secretKey) throws Exception {
		return decrypt(Base64.getDecoder().decode(encryptedText), Base64.getDecoder().decode(secretKey));
	}

	/**
	 * Décryption de données binaires encryptées avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedValue Les données binaires encryptées
	 * @param secretKey La clé secrète en base 64
	 * @return les données binaires décryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "Base64.getDecoder().decode(\"aVnxqL186Sz1t4MpodYomg==\")", "\"c2VjcmV0S2V5\"" }, process = false) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static byte[] decrypt(byte[] encryptedValue, String secretKey) throws Exception {
		return decrypt(encryptedValue, Base64.getDecoder().decode(secretKey));
	}

	/**
	 * Décryption d'un texte encrypté avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedText Texte encrypté en base 64
	 * @param secretKey La clé secrète en binaire
	 * @return les données binaires décryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"aVnxqL186Sz1t4MpodYomg==\"", "\"c2VjcmV0S2V5\".getBytes()" }, process = false) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static byte[] decrypt(String encryptedText, byte[] secretKey) throws Exception {
		return decrypt(Base64.getDecoder().decode(encryptedText), Base64.getDecoder().decode(secretKey));
	}

	/**
	 * Décryption dde données binaires encryptées avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedValue Les données binaires encryptées
	 * @param secretKey La clé secrète en binaire
	 * @return les données binaires décryptées
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "Base64.getDecoder().decode(\"aVnxqL186Sz1t4MpodYomg==\")", "Base64.getDecoder().decode(\"c2VjcmV0S2V5\")" }, process = false) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static byte[] decrypt(byte[] encryptedValue, byte[] secretKey) throws Exception {
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey, "Blowfish");

		Cipher cipher = Cipher.getInstance("Blowfish");
		cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);

		byte[] decrypted = cipher.doFinal(encryptedValue);

		return decrypted;
	}

	/**
	 * Décryption d'un texte encrypté avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedText Texte encrypté en base 64
	 * @param secretKey La clé secrète en base 64
	 * @return un String décrypté
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests({ "aVnxqL186Sz1t4MpodYomg==", "c2VjcmV0S2V5" }) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static String decryptAsString(String encryptedText, String secretKey) throws Exception {
		return new String(decrypt(encryptedText, secretKey));
	}

	/**
	 * Décryption d'un texte encrypté avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedValue Les données binaires encryptées
	 * @param secretKey La clé secrète en base 64
	 * @return un String décrypté
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "Base64.getDecoder().decode(\"aVnxqL186Sz1t4MpodYomg==\")", "\"c2VjcmV0S2V5\"" }, process = false) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static String decryptAsString(byte[] encryptedValue, String secretKey) throws Exception {
		return new String(decrypt(encryptedValue, secretKey));
	}

	/**
	 * Décryption d'un texte encrypté avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedText Texte encrypté en base 64
	 * @param secretKey La clé secrète en binaire
	 * @return un String décrypté
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "\"aVnxqL186Sz1t4MpodYomg==\"", "\"c2VjcmV0S2V5\".getBytes()" }, process = false) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static String decryptAsString(String encryptedText, byte[] secretKey) throws Exception {
		return new String(decrypt(encryptedText, secretKey));
	}

	/**
	 * Décryption d'un texte encrypté avec clé secrète utilisant l'algorithme Blowfish
	 * @param encryptedValue Les données binaires encryptées
	 * @param secretKey La clé secrète en binaire
	 * @return un String décrypté
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "Base64.getDecoder().decode(\"aVnxqL186Sz1t4MpodYomg==\")", "Base64.getDecoder().decode(\"c2VjcmV0S2V5\")" }, process = false) // encryptedText -> encrypt("OutilsCommun", Base64("secretKey"))
	final public static String decryptAsString(byte[] encryptedValue, byte[] secretKey) throws Exception {
		return new String(decrypt(encryptedValue, secretKey));
	}

	/**
	 * Génération d'un clé secrete utilisant l'algorithme Blowfish
	 * @return la clé secrète binaire
	 * @throws Exception en cas d'erreur...
	 */
	final public static byte[] generateSecretKey() throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance("Blowfish");
		SecretKey secretKey = keyGenerator.generateKey();

		return secretKey.getEncoded();
	}

	/**
	 * Génération d'un clé secrete utilisant l'algorithme Blowfish
	 * @return un String de la clé secrète en base 64
	 * @throws Exception en cas d'erreur...
	 */
	@CoverageOnly
	final public static String generateSecretKeyAsString() throws Exception {
		return Base64.getEncoder().encodeToString(generateSecretKey());
	}

	/**
	 * Extrait la valeur de hashage d'un chemin de fichier pour un algorithme donné
	 * @param filename Chemin du fichier à extraire
	 * @param algorithm Type d'algorithme à utiliser
	 * @return la valeur de hashage
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = { "source.txt", "MessageDigestAlgorithmsTypes.MD5" }, filenames = 0)
	final public static String getFileHashing(String filename, MessageDigestAlgorithmsTypes algorithm) throws Exception {
		if (isEmpty(filename)) {
			return null;
		}

		if (algorithm == null) {
			throw new Exception("Pas d'algorithme de spécifié");
		}

		return getFileHashing(new File(filename), algorithm);
	}

	/**
	 * Extrait la valeur de hashage d'un fichier pour un algorithme donné
	 * @param file Le fichier à extraire
	 * @param algorithm Type d'algorithme à utiliser
	 * @return la valeur de hashage
	 * @throws Exception en cas d'erreur...
	 */
	final public static String getFileHashing(File file, MessageDigestAlgorithmsTypes algorithm) throws Exception {
		if (file == null) {
			return null;
		}

		if (algorithm == null) {
			throw new Exception("Pas d'algorithme de spécifié");
		}

		if (!file.exists()) {
			throw new Exception("Pas de fichier " + file);
		} else if (!file.isFile()) {
			throw new Exception("Le fichier " + file + " n'est pas un fichier !!!");
		}

		return getFileHashing(new FileInputStream(file), algorithm);
	}

	/**
	 * Extrait la valeur de hashage d'un flux de données pour un algorithme donné
	 * @param inputStream Flux de données à extraire
	 * @param algorithm Type d'algorithme à utiliser
	 * @return la valeur de hashage
	 * @throws Exception en cas d'erreur...
	 */
	final public static String getFileHashing(InputStream inputStream, MessageDigestAlgorithmsTypes algorithm) throws Exception {
		if (inputStream == null) {
			return null;
		}

		if (algorithm == null) {
			throw new Exception("Pas d'algorithme de spécifié");
		}

		MessageDigest md = MessageDigest.getInstance(algorithm.getAlgorithm());

		try {
			byte[] buf = new byte[32768];
			int read = 0;

			while ((read = inputStream.read(buf)) != -1) {
				md.update(buf, 0, read);
			}
		} catch (IOException e) {
			inputStream.close();
		}

		return new BigInteger(1, md.digest()).toString(16);
	}

	/**
	 * Extrait la valeur de hashage d'un texte pour un algorithme donné
	 * @param inputStream Flux de données à extraire
	 * @param algorithm Type d'algorithme à utiliser
	 * @return la valeur de hashage
	 * @throws Exception en cas d'erreur...
	 */
	final public static String getBufferHashing(String value, MessageDigestAlgorithmsTypes algorithm) throws Exception {
		if (value == null) {
			return null;
		}

		if (algorithm == null) {
			throw new Exception("Pas d'algorithme de spécifié");
		}

		MessageDigest md = MessageDigest.getInstance(algorithm.getAlgorithm());
		md.update(value.getBytes());

		return new BigInteger(1, md.digest()).toString(16);
	}

	/**
	 * Extrait la valeur de hashage d'un tableau binaire pour un algorithme donné
	 * @param inputStream Flux de données à extraire
	 * @param algorithm Type d'algorithme à utiliser
	 * @return la valeur de hashage
	 * @throws Exception en cas d'erreur...
	 */
	final public static String getBufferHashing(byte[] buf, MessageDigestAlgorithmsTypes algorithm) throws Exception {
		if (buf == null) {
			return null;
		}

		if (algorithm == null) {
			throw new Exception("Pas d'algorithme de spécifié");
		}

		MessageDigest md = MessageDigest.getInstance(algorithm.getAlgorithm());
		md.update(buf);

		return new BigInteger(1, md.digest()).toString(16);
	}

	/**
	 * Extrait la période (journée) des fonctions de journalisation
	 * @param date La date de la période (null -> maintenant)
	 * @return la date de la période demandée
	 */
	@CoverageOnly // Utilise la date courante
	final public static String getLogPeriod(java.util.Date date) {
		return LOG_DATE_PERIOD_FORMAT.format((date != null) ? date : new java.util.Date());
	}

	/**
	 * Message de journalisation
	 * @param message Le message à journaliser
	 * @return le message journalisé
	 */
	@CoverageOnly // Utilise la date courante
	final public static String asLog(String message) {
		return (LOG_DATE_TIME_FORMAT.format(new java.util.Date()) + " -- " + message);
	}

	/**
	 * Liste de messages de journalisation
	 * @param messagesList Liste de messages à journaliser
	 * @return une liste de messages journalisés
	 */
	@AutomatedTests("1,,2")
	final public static List<String> asLog(List<String> messagesList) {
		List<String> list = new ArrayList<String>();

		if (messagesList != null) {
			for (String message : messagesList) {
				list.add(asLog(message));
			}
		}

		return list;
	}

	/**
	 * Tableau de messages de journalisation
	 * @param messagesArray Tableau de messages à journaliser
	 * @return une liste de messages journalisés
	 */
	@AutomatedTests("1,2")
	final public static List<String> asLog(String[] messagesArray) {
		List<String> list = new ArrayList<String>();

		if (messagesArray != null) {
			for (String message : messagesArray) {
				list.add(asLog(message));
			}
		}

		return list;
	}

	/**
	 * Message d'exception de journalisation
	 * @param throwable L'exception à journaliser
	 * @return une liste de messages journalisés
	 */
	@AutomatedTests("new Exception(\"OutilsCommun\")")
	final public static List<String> asLog(Throwable throwable) {
		List<String> list = new ArrayList<String>();

		if (throwable != null) {
			list.add(asLog("Exception : " + throwable.getLocalizedMessage()));

			list.add(asLog("**** Début de la trace ****"));

			list.addAll(asLog(asStringList(throwable)));

			list.add(asLog("**** Fin de la trace ****"));
		}

		return list;
	}

	/**
	 * Message d'exception de journalisation
	 * @param message Le message à journaliser
	 * @param throwable L'exception à journaliser
	 * @return une liste de messages journalisés
	 */
	@AutomatedTests({ "asLog", "new Exception(\"OutilsCommun\")" })
	final public static List<String> asLog(String message, Throwable throwable) {
		List<String> list = new ArrayList<String>();

		list.add(asLog(message));
		list.addAll(asLog(throwable));

		return list;
	}

	/**
	 * Journalise un message à la console
	 * @param message Le message à afficher
	 */
	final public static void log(String message) {
		console(asLog(asString(message)));
	}

	/**
	 * Journalise une liste de message à la console
	 * @param messagesList Liste de messages à afficher
	 */
	@AutomatedTests("1,2")
	final public static void log(List<String> messagesList) {
		if (messagesList != null) {
			for (String message : messagesList) {
				log(message);
			}
		}
	}

	/**
	 * Journalise un tableau de message à la console
	 * @param messagesArray Tableau de messages à afficher
	 */
	@AutomatedTests("1,2")
	final public static void log(String[] messagesArray) {
		if (messagesArray != null) {
			for (String message : messagesArray) {
				log(message);
			}
		}
	}

	/**
	 * Journalise une exception à la console
	 * @param throwable L'exception à afficher
	 */
	final public static void log(Throwable throwable) {
		console(asLog(throwable));
	}

	/**
	 * Journalise un message et une exception à la console
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void log(String message, Throwable throwable) {
		console(asLog(message, throwable));
	}

	/**
	 * Journalise un message à la console d'erreur
	 * @param message Le message à afficher
	 */
	final public static void logerr(String message) {
		consoleError(asLog(asString(message)));
	}

	/**
	 * Journalise une liste de messages à la console d'erreur
	 * @param messagesList Liste de messages à afficher
	 */
	@AutomatedTests("1,2")
	final public static void logerr(List<String> messagesList) {
		if (messagesList != null) {
			for (String message : messagesList) {
				logerr(message);
			}
		}
	}

	/**
	 * Journalise un tableau de messages à la console d'erreur
	 * @param messagesArray Tableau de messages à afficher
	 */
	@AutomatedTests("1,2")
	final public static void logerr(String[] messagesArray) {
		if (messagesArray != null) {
			for (String message : messagesArray) {
				logerr(message);
			}
		}
	}

	/**
	 * Journalise une exception à la console d'erreur
	 * @param throwable L'exception à afficher
	 */
	final public static void logerr(Throwable throwable) {
		consoleError(asLog(throwable));
	}

	/**
	 * Journalise un message et une exception à la console d'erreur
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void logerr(String message, Throwable throwable) {
		consoleError(asLog(message, throwable));
	}

	/**
	 * Journalise un message dans un fichier
	 * @param filename Nom du fichier
	 * @param message Le message à journaliser
	 */
	@StrictAutomatedTests(value = { ",OutilsCommun.log", "logFile" }, filenames = 0, iterate = true)
	@StrictAutomatedTests({ "A:\\OutilsCommun.log", "logFile" })
	final public static void logfile(String filename, String message) {
		try {
			List<String> messagesList = new ArrayList<String>();
			messagesList.add(message);

			addListToFile(asLog(messagesList), filename, FilesCharsetsTypes.UTF_8);
		} catch (IOException e) {
			logerr("logfile(\"" + filename + "\", \"" + message + "\")", e);
		}
	}

	/**
	 * Journalise une liste de messages dans un fichier
	 * @param filename Nom du fichier
	 * @param messagesList Liste de messages à journaliser
	 */
	@StrictAutomatedTests(value = { ",OutilsCommun.log", "logFile" }, filenames = 0, iterate = true)
	@StrictAutomatedTests({ "A:\\OutilsCommun.log", "logFile" })
	final public static void logfile(String filename, List<String> messagesList) {
		try {
			addListToFile(asLog(messagesList), filename, FilesCharsetsTypes.UTF_8);
		} catch (IOException e) {
			logerr("logfile(\"" + filename + "\", " + messagesList + ")", e);
		}
	}

	/**
	 * Journalise un tableau de messages dans un fichier
	 * @param filename Nom du fichier
	 * @param messagesArray Tableau de messages à journaliser
	 */
	@StrictAutomatedTests(value = { ",OutilsCommun.log", "logFile" }, filenames = 0, iterate = true)
	@StrictAutomatedTests({ "A:\\OutilsCommun.log", "logFile" })
	final public static void logfile(String filename, String[] messagesArray) {
		try {
			addListToFile(asLog(messagesArray), filename, FilesCharsetsTypes.UTF_8);
		} catch (IOException e) {
			logerr("logfile(\"" + filename + "\", " + messagesArray + ")", e);
		}
	}

	/**
	 * Journalise une exception dans un fichier
	 * @param filename Nom du fichier
	 * @param throwable L'exception à journaliser
	 */
	@StrictAutomatedTests(value = { "(String) null", "(Throwable) null" }, process = false)
	@StrictAutomatedTests(value = { "JunitHelper.getFullname(\"A:\", \"OutilsCommun.log\")", "new Exception(\"logfile\")" }, process = false)
	@StrictAutomatedTests(value = { "JunitHelper.getFullname(JunitHelper.TEST_TEMP_DIR, \"OutilsCommun.log\")", "new Exception(\"logfile\")" }, process = false)
	final public static void logfile(String filename, Throwable throwable) {
		if (throwable != null) {
			try {
				addListToFile(asLog(throwable), filename, FilesCharsetsTypes.UTF_8);
			} catch (IOException e) {
				logerr("logfile(\"" + filename + "\", " + throwable.getMessage() + ")");
				logerr(e);
			}
		}
	}

	/**
	 * Journalise un message et une exception dans un fichier
	 * @param filename Nom du fichier
	 * @param message Le message à journaliser
	 * @param throwable L'exception à journaliser
	 */
	@StrictAutomatedTests(value = { "(String) null", "(String) null", "(Throwable) null" }, process = false)
	@StrictAutomatedTests(value = { "JunitHelper.getFullname(\"A:\", \"OutilsCommun.log\")", "\"logFile\"", "new Exception(\"logfile\")" }, process = false)
	@StrictAutomatedTests(value = { "JunitHelper.getFullname(JunitHelper.TEST_TEMP_DIR, \"OutilsCommun.log\")", "\"logFile\"", "new Exception(\"logfile\")" }, process = false)
	final public static void logfile(String filename, String message, Throwable throwable) {
		if (throwable != null) {
			try {
				addListToFile(asLog(message, throwable), filename, FilesCharsetsTypes.UTF_8);
			} catch (IOException e) {
				logerr("logfile(\"" + filename + "\", \"" + message + "\", " + throwable.getLocalizedMessage() + ")", e);
			}
		}
	}

	/**
	 * Extrait la console
	 * @return un PrintWriter
	 */
	final public static PrintWriter getConsole() {
		return CONSOLE;
	}

	/**
	 * Message de console
	 * @param message Le message pour la console
	 * @return le message pour la console
	 */
	final public static String asConsole(String message) {
		return asString(message);
	}

	/**
	 * Liste de messages de console
	 * @param messagesList Liste de messages pour la console
	 * @return une liste de message pour la console
	 */
	final public static List<String> asConsole(List<String> messagesList) {
		List<String> list = new ArrayList<String>();

		if (messagesList != null) {
			for (String message : messagesList) {
				list.add(asConsole(message));
			}
		}

		return list;
	}

	/**
	 * Tableau de messages de console
	 * @param messagesArray Tableau de messages pour la console
	 * @return une liste de message pour la console
	 */
	final public static List<String> asConsole(String[] messagesArray) {
		List<String> list = new ArrayList<String>();

		if (messagesArray != null) {
			for (String message : messagesArray) {
				list.add(asConsole(message));
			}
		}

		return list;
	}

	/**
	 * Message d'exception de console
	 * @param throwable L'exception pour la console
	 * @return une liste de message pour la console
	 */
	@AutomatedTests("new Exception(\"Automated Test Value\")")
	final public static List<String> asConsole(Throwable throwable) {
		List<String> list = new ArrayList<String>();

		if (throwable != null) {
			String message = asString(throwable.getLocalizedMessage());

			if (isEclipseIDE() && message.length() > 500) {
				message = message.substring(0, 495) + "[...]";
			}

			list.add(asConsole("Exception : " + message));

			list.add(asConsole("**** Début de la trace ****"));

			list.addAll(asConsole(asStringList(throwable)));

			list.add(asConsole("**** Fin de la trace ****"));
		}

		return list;
	}

	/**
	 * Message d'exception de console
	 * @param message Le message pour la console
	 * @param throwable L'exception pour la console
	 * @return une liste de message pour la console
	 */
	final public static List<String> asConsole(String message, Throwable throwable) {
		List<String> list = new ArrayList<String>();

		list.add(asConsole(message));
		list.addAll(asConsole(throwable));

		return list;
	}

	/**
	 * Affichage d'un message à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 */
	final public static void console(Object message) {
		console(asString(message), true);
	}

	/**
	 * Affichage d'un message à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 */
	final public static void console(String message) {
		console(message, true);
	}

	/**
	 * Affichage d'un message à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param detail Le détail à afficher
	 */
	final public static void console(String message, String detail) {
		console(message, detail, true);
	}

	/**
	 * Affichage d'un message à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(Object message, boolean newline) {
		console(asString(message), newline);
	}

	/**
	 * Affichage d'un message à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(String message, boolean newline) {
		if (message != null) {
			if (newline) {
				CONSOLE.println(asConsole(message));
			} else {
				CONSOLE.print(asConsole(message));
			}

			CONSOLE.flush();
		}
	}

	/**
	 * Affichage d'un message à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param detail Le détail à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(String message, String detail, boolean newline) {
		console(message, newline);
		console("**** Début du détail ****", newline);
		console(detail, newline);
		console("**** Fin du détail ****", newline);
	}

	/**
	 * Affichage d'une liste de messages à la console autant pour eclipse que pour cmd.exe
	 * @param messagesList Liste de messages à afficher
	 */
	final public static void console(List<String> messagesList) {
		console(messagesList, true);
	}

	/**
	 * Affichage d'un tableau de messages à la console autant pour eclipse que pour cmd.exe
	 * @param messagesArray Tableau de messages à afficher
	 */
	final public static void console(String[] messagesArray) {
		console(messagesArray, true);
	}

	/**
	 * Affichage d'une liste de messages à la console autant pour eclipse que pour cmd.exe
	 * @param messagesList Liste de messages à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(List<String> messagesList, boolean newline) {
		if (messagesList != null) {
			for (String message : messagesList) {
				console(message, newline);
			}
		}
	}

	/**
	 * Affichage d'un tableau de messages à la console autant pour eclipse que pour cmd.exe
	 * @param messagesArray Tableau de messages à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(String[] messagesArray, boolean newline) {
		if (messagesArray != null) {
			for (String message : messagesArray) {
				console(message, newline);
			}
		}
	}

	/**
	 * Affichage d'une exception à la console autant pour eclipse que pour cmd.exe
	 * @param throwable L'exception à afficher
	 */
	final public static void console(Throwable throwable) {
		console(throwable, true);
	}

	/**
	 * Affichage d'une exception à la console autant pour eclipse que pour cmd.exe
	 * @param throwable L'exception à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(Throwable throwable, boolean newline) {
		console(asConsole(throwable), newline);
	}

	/**
	 * Affichage d'un message et d'une exception à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void console(Object message, Throwable throwable) {
		console(asString(message), throwable, true);
	}

	/**
	 * Affichage d'un message et d'une exception à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void console(Object[] message, Throwable throwable) {
		console(asString(message), throwable, true);
	}

	/**
	 * Affichage d'un message et d'une exception à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void console(String message, Throwable throwable) {
		console(message, throwable, true);
	}

	/**
	 * Affichage d'un message et d'une exception à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(Object message, Throwable throwable, boolean newline) {
		console(asConsole(asString(message), throwable), newline);
	}

	/**
	 * Affichage d'un message et d'une exception à la console autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void console(String message, Throwable throwable, boolean newline) {
		console(asConsole(message, throwable), newline);
	}

	/**
	 * Affichage d'un message à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher d'erreur
	 */
	final public static void consoleError(Object message) {
		consoleError(asString(message), true);
	}

	/**
	 * Affichage d'un message à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher d'erreur
	 */
	final public static void consoleError(String message) {
		consoleError(message, true);
	}

	/**
	 * Affichage d'un message à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher d'erreur
	 * @param detail Le détail à afficher d'erreur
	 */
	final public static void consoleError(String message, String detail) {
		consoleError(message, detail, true);
	}

	/**
	 * Affichage d'un message à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher d'erreur
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(Object message, boolean newline) {
		consoleError(asString(message), newline);
	}

	/**
	 * Affichage d'un message à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher d'erreur
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(String message, boolean newline) {
		if (message != null) {
			if (newline) {
				CONSOLE_ERROR.println(asConsole(message));
			} else {
				CONSOLE_ERROR.print(asConsole(message));
			}

			CONSOLE_ERROR.flush();
		}
	}

	/**
	 * Affichage d'un message à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher d'erreur
	 * @param detail Le détail à afficher d'erreur
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(String message, String detail, boolean newline) {
		consoleError(message, newline);
		consoleError("**** Début du détail ****", newline);
		consoleError(detail, newline);
		consoleError("**** Fin du détail ****", newline);
	}

	/**
	 * Affichage d'une liste de messages à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param messagesList Liste de messages à afficher
	 */
	final public static void consoleError(List<String> messagesList) {
		consoleError(messagesList, true);
	}

	/**
	 * Affichage d'un tableau de messages à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param messagesArray Tableau de messages à afficher
	 */
	final public static void consoleError(String[] messagesArray) {
		consoleError(messagesArray, true);
	}

	/**
	 * Affichage d'une liste de messages à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param messagesList Liste de messages à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(List<String> messagesList, boolean newline) {
		if (messagesList != null) {
			for (String message : messagesList) {
				consoleError(message, newline);
			}
		}
	}

	/**
	 * Affichage d'un tableau de messages à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param messagesArray Tableau de messages à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(String[] messagesArray, boolean newline) {
		if (messagesArray != null) {
			for (String message : messagesArray) {
				consoleError(message, newline);
			}
		}
	}

	/**
	 * Affichage d'une exception à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param throwable L'exception à afficher
	 */
	final public static void consoleError(Throwable throwable) {
		consoleError(throwable, true);
	}

	/**
	 * Affichage d'une exception à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param throwable L'exception à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(Throwable throwable, boolean newline) {
		consoleError(asConsole(throwable), newline);
	}

	/**
	 * Affichage d'un message et d'une exception à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void consoleError(Object message, Throwable throwable) {
		consoleError(asString(message), throwable, true);
	}

	/**
	 * Affichage d'un message et d'une exception à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void consoleError(Object[] message, Throwable throwable) {
		consoleError(asString(message), throwable, true);
	}

	/**
	 * Affichage d'un message et d'une exception à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 */
	final public static void consoleError(String message, Throwable throwable) {
		consoleError(message, throwable, true);
	}

	/**
	 * Affichage d'un message et d'une exception à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(Object message, Throwable throwable, boolean newline) {
		consoleError(asConsole(asString(message), throwable), newline);
	}

	/**
	 * Affichage d'un message et d'une exception à la console d'erreur autant pour eclipse que pour cmd.exe
	 * @param message Le message à afficher
	 * @param throwable L'exception à afficher
	 * @param newline Indicateur d'impression de retour de ligne ou non
	 */
	final public static void consoleError(String message, Throwable throwable, boolean newline) {
		consoleError(asConsole(message, throwable), newline);
	}

	/**
	 * Extrait les n dernières lignes d'un fichier texte
	 * @param file Fichier texte
	 * @param lines Nombre de lignes
	 * @return les n dernières lignes sous forme de StringBuffer
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = { "file", "1" }, process = false)
	final public static byte[] tail(File file, int lines) throws Exception {
		RandomAccessFile fileHandler = null;

		try {
			fileHandler = new java.io.RandomAccessFile(file, "r");
			long fileLength = file.length() - 1;
			List<Byte> list = new ArrayList<Byte>();
			int line = 0;

			for (long filePointer = fileLength; filePointer != -1; filePointer--) {
				fileHandler.seek(filePointer);
				byte readByte = fileHandler.readByte();

				if (readByte == 0xA) {
					if (line == lines) {
						if (filePointer == fileLength) {
							continue;
						} else {
							break;
						}
					}
				} else if (readByte == 0xD) {
					line = line + 1;

					if (line == lines) {
						if (filePointer == fileLength - 1) {
							continue;
						} else {
							break;
						}
					}
				}

				list.add(Byte.valueOf(readByte));
			}

			if (list.size() < 2) {
				return new byte[0];
			}

			byte[] result = new byte[list.size() - 1];

			int pos = 0;

			for (int i = list.size() - 1; i > 0; i--) {
				result[pos++] = list.get(i).byteValue();
			}

			return result;
		} finally {
			if (fileHandler != null) {
				fileHandler.close();
			}
		}
	}
}
