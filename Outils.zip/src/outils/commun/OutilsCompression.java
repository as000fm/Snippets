package outils.commun;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import outils.abstractions.IRawFileConverter;
import outils.abstractions.RawFileConverter;
import outils.base.OutilsBase;
import outils.listes.NameValue;
import outils.listes.StringData;
import outils.tests.automated.annotations.SkipImportsForTesting;
import outils.tests.automated.annotations.SkipTesting;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Classe des méthodes utilitaires de type final public static pour la compression en format zip et gzip
 * @author Claude Toupin - 11 août 2022
 */
@SkipImportsForTesting({ List.class, NameValue.class })
public class OutilsCompression {
	/**
	 * Zip de données
	 * @param data Les données à ziper
	 * @param name Le nom des données (i.e. fichier) à ziper
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",100", "zipFile", "OutilsCompression.zip" }, filenames = { 2 }, iterate = true)
	final public static void zipFile(byte[] data, String name, String zipFilename) throws Exception {
		if (data == null) {
			data = new byte[0];
		}

		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFilename));

		try {
			zos.putNextEntry(new ZipEntry(name));
			zos.write(data, 0, data.length);
		} finally {
			zos.closeEntry();
			zos.close();
		}
	}

	/**
	 * Zip le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à ziper
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "zipFile.txt", "OutilsCompression.zip" }, filenames = { 0, 1 })
	final public static void zipFile(String filename, String zipFilename) throws Exception {
		File file = new File(filename);

		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFilename));

		try {
			zos.putNextEntry(new ZipEntry(file.getName()));

			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
			} finally {
				fis.close();
			}
		} finally {
			zos.closeEntry();
			zos.close();
		}
	}

	/**
	 * Zip le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à ziper
	 * @param name Le nom des données (i.e. fichier) à ziper
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "zipFile.txt", "zipFile", "OutilsCompression.zip" }, filenames = { 0, 2 })
	final public static void zipFile(String filename, String name, String zipFilename) throws Exception {
		File file = new File(filename);

		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFilename));

		try {
			zos.putNextEntry(new ZipEntry(name));

			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
			} finally {
				fis.close();
			}
		} finally {
			zos.closeEntry();
			zos.close();
		}
	}

	/**
	 * Zip de données
	 * @param data Les données à ziper
	 * @param name Le nom des données (i.e. fichier) à ziper
	 * @return Le contenu ziper
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",100", "zipFileContent" }, iterate = true)
	final public static byte[] zipFileContent(byte[] data, String name) throws Exception {
		if (data == null) {
			data = new byte[0];
		}

		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		ZipOutputStream zos = new ZipOutputStream(baos);

		try {
			zos.putNextEntry(new ZipEntry(name));
			zos.write(data, 0, data.length);
		} finally {
			zos.closeEntry();
			zos.close();
		}

		return baos.toByteArray();
	}

	/**
	 * Zip le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à ziper
	 * @return Le contenu ziper
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "zipFile.txt", filenames = 0)
	final public static byte[] zipFileContent(String filename) throws Exception {
		File file = new File(filename);

		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		ZipOutputStream zos = new ZipOutputStream(baos);

		try {
			zos.putNextEntry(new ZipEntry(file.getName()));

			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}

			} finally {
				fis.close();
			}
		} finally {
			zos.closeEntry();
			zos.close();
		}

		return baos.toByteArray();
	}

	/**
	 * Zip le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à ziper
	 * @param name Le nom des données (i.e. fichier) à ziper
	 * @return Le contenu ziper
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "zipFile.txt", "zipFileContent" }, filenames = 0)
	final public static byte[] zipFileContent(String filename, String name) throws Exception {
		return zipFileContent(new File(filename), name);
	}

	/**
	 * Zip le contenu d'un fichier
	 * @param file Le fichier à ziper
	 * @param name Le nom des données (i.e. fichier) à ziper
	 * @return Le contenu ziper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static byte[] zipFileContent(File file, String name) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		ZipOutputStream zos = new ZipOutputStream(baos);

		try {
			zos.putNextEntry(new ZipEntry(name));

			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}

			} finally {
				fis.close();
			}
		} finally {
			zos.closeEntry();
			zos.close();
		}

		return baos.toByteArray();
	}

	/**
	 * Zip le contenu d'un répertoire
	 * @param baseDir Le répertoire source
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "tests\\files\\commun", "OutilsCompression.zip" }, filenames = 1)
	final public static void zipDirectory(String baseDir, String zipFilename) throws Exception {
		zipDirectoryList(OutilsCommun.scanForFiles(baseDir), baseDir, zipFilename);
	}

	/**
	 * Zip le contenu basé sur la liste des fichiers d'un répertoire
	 * @param La liste des fichiers du répertoire
	 * @param baseDir Le répertoire source
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void zipDirectoryList(List<NameValue> filesList, String baseDir, String zipFilename) throws Exception {
		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFilename));

		try {
			for (NameValue item : filesList) {
				String entry = OutilsCommun.getFullname(item.getName(), item.getValue());

				zos.putNextEntry(new ZipEntry(entry));

				String filename = OutilsCommun.getFullname(baseDir, entry);

				FileInputStream fis = new FileInputStream(filename);

				try {
					int len;

					byte[] buffer = new byte[32768];

					while ((len = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, len);
					}
				} finally {
					fis.close();
				}
			}
		} finally {
			zos.closeEntry();
			zos.close();
		}
	}

	/**
	 * Zip le contenu basé sur la liste des fichiers d'un répertoire
	 * @param baseDir Le répertoire source
	 * @return le contenu zipper en format binaire
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests("tests\\files\\commun")
	final public static byte[] zipDirectoryList(String baseDir) throws Exception {
		return zipDirectoryList(OutilsCommun.scanForFiles(baseDir), baseDir);
	}

	/**
	 * Zip le contenu basé sur la liste des fichiers d'un répertoire
	 * @param La liste des fichiers du répertoire
	 * @param baseDir Le répertoire source
	 * @return le contenu zipper en format binaire
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static byte[] zipDirectoryList(List<NameValue> filesList, String baseDir) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		ZipOutputStream zos = new ZipOutputStream(baos);

		try {
			for (NameValue item : filesList) {
				String entry = OutilsCommun.getFullname(item.getName(), item.getValue());

				zos.putNextEntry(new ZipEntry(entry));

				String filename = OutilsCommun.getFullname(baseDir, entry);

				FileInputStream fis = new FileInputStream(filename);

				try {
					int len;

					byte[] buffer = new byte[32768];

					while ((len = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, len);
					}
				} finally {
					fis.close();
				}
			}
		} finally {
			zos.closeEntry();
			zos.close();
		}

		return baos.toByteArray();
	}

	/**
	 * Extrait la liste des fichiers depuis un fichier zip source donné
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur..
	 */
	@StrictAutomatedTests(value = { "zipFile.zip" }, filenames = 0)
	final public static List<NameValue> zipListFiles(String zipFilename) throws Exception {
		return zipListFiles(zipFilename, null);
	}

	/**
	 * Extrait la liste des fichiers depuis un fichier zip source donné
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur..
	 */
	@SkipTesting
	final public static List<NameValue> zipListFiles(String zipFilename, FilenameFilter filter) throws Exception {
		List<NameValue> filesList = new ArrayList<NameValue>();

		ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilename));

		try {
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {
				if (!ze.isDirectory()) {
					boolean ok = true;

					File file = new File(ze.getName());

					if (filter != null) {
						ok = filter.accept(file.getParentFile(), file.getName());
					}

					if (ok) {
						filesList.add(new NameValue(file.getParent(), file.getName()));
					}
				}

				ze = zis.getNextEntry();
			}
		} finally {
			zis.closeEntry();
			zis.close();
		}

		filesList.sort(new NameValue.Compare(true, false));

		return filesList;
	}

	/**
	 * Dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void unzipFile(String baseDir, String zipFilename) throws Exception {
		unzipFile(baseDir, zipFilename, null, false);
	}

	/**
	 * Dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param force Indicateur pour forcer la création
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void unzipFile(String baseDir, String zipFilename, boolean force) throws Exception {
		unzipFile(baseDir, zipFilename, null, force);
	}

	/**
	 * Dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void unzipFile(String baseDir, String zipFilename, FilenameFilter filter) throws Exception {
		unzipFile(baseDir, zipFilename, filter, false);
	}

	/**
	 * Dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @param force Indicateur pour forcer la création
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void unzipFile(String baseDir, String zipFilename, FilenameFilter filter, boolean force) throws Exception {
		OutilsCommun.buildDirectory(baseDir, force);

		ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilename));

		try {
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {
				boolean ok = true;

				File file = new File(ze.getName());

				if (filter != null) {
					ok = filter.accept(file.getParentFile(), file.getName());
				}

				if (ok) {
					file = new File(OutilsCommun.getFullname(baseDir, ze.getName())).getCanonicalFile();

					if (ze.isDirectory()) {
						file.mkdirs();
					} else {
						file.getParentFile().mkdirs();

						FileOutputStream fos = new FileOutputStream(file);

						try {
							int len;

							byte[] buffer = new byte[32768];

							while ((len = zis.read(buffer)) > 0) {
								fos.write(buffer, 0, len);
							}
						} finally {
							fos.close();
						}
					}
				}

				ze = zis.getNextEntry();
			}
		} finally {
			zis.closeEntry();
			zis.close();
		}
	}

	/**
	 * Dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "zipFile.zip", filenames = 0)
	final public static List<StringData> unzipFile(String zipFilename) throws Exception {
		return unzipFile(zipFilename, null, new RawFileConverter());
	}

	/**
	 * Dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "zipFile.zip", "null" }, filenames = 0)
	final public static List<StringData> unzipFile(String zipFilename, FilenameFilter filter) throws Exception {
		return unzipFile(zipFilename, filter, new RawFileConverter());
	}

	/**
	 * Dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param converter Conversion de données brute selon le type du fichier
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "zipFile.zip", "null" }, filenames = 0)
	final public static List<StringData> unzipFile(String zipFilename, IRawFileConverter converter) throws Exception {
		return unzipFile(zipFilename, null, converter);
	}

	/**
	 * Dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @param converter Conversion de données brute selon le type du fichier
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "zipFile.zip", "null", "null" }, filenames = 0)
	final public static List<StringData> unzipFile(String zipFilename, FilenameFilter filter, IRawFileConverter converter) throws Exception {
		List<StringData> list = new ArrayList<StringData>();

		ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilename));

		try {
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {
				if (!ze.isDirectory()) {
					boolean ok = true;

					if (filter != null) {
						File file = new File(ze.getName());
						ok = filter.accept(file.getParentFile(), file.getName());
					}

					if (ok) {
						StringData data = new StringData(ze.getName());
						list.add(data);

						ByteArrayOutputStream baos = new ByteArrayOutputStream();

						int len;

						byte[] buffer = new byte[32768];

						while ((len = zis.read(buffer)) > 0) {
							baos.write(buffer, 0, len);
						}

						if (converter != null) {
							data.setData(converter.convert(data.getString(), baos.toByteArray()));
						} else {
							data.setData(baos.toByteArray());
						}
					}
				}

				ze = zis.getNextEntry();
			}
		} finally {
			zis.closeEntry();
			zis.close();
		}

		return list;
	}

	/**
	 * Dézip un contenu binaire en format zip en mémoire
	 * @param content Le contenu binaire en format zip à dézipper
	 * @return la liste des fichiers et données
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<StringData> unzipFile(byte[] content) throws Exception {
		return unzipFile(content, null, new RawFileConverter());
	}

	/**
	 * Dézip un contenu binaire en format zip en mémoire
	 * @param content Le contenu binaire en format zip à dézipper
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @return la liste des fichiers et données
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<StringData> unzipFile(byte[] content, FilenameFilter filter) throws Exception {
		return unzipFile(content, filter, new RawFileConverter());
	}

	/**
	 * Dézip un contenu binaire en format zip en mémoire
	 * @param content Le contenu binaire en format zip à dézipper
	 * @param converter Conversion de données brute selon le type du fichier
	 * @return la liste des fichiers et données
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<StringData> unzipFile(byte[] content, IRawFileConverter converter) throws Exception {
		return unzipFile(content, null, converter);
	}

	/**
	 * Dézip un contenu binaire en format zip en mémoire
	 * @param content Le contenu binaire en format zip à dézipper
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @param converter Conversion de données brute selon le type du fichier
	 * @return la liste des fichiers et données
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<StringData> unzipFile(byte[] content, FilenameFilter filter, IRawFileConverter converter) throws Exception {
		List<StringData> list = new ArrayList<StringData>();

		ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(content));

		try {
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {
				if (!ze.isDirectory()) {
					boolean ok = true;

					if (filter != null) {
						File file = new File(ze.getName());
						ok = filter.accept(file.getParentFile(), file.getName());
					}

					if (ok) {
						StringData data = new StringData(ze.getName());
						list.add(data);

						ByteArrayOutputStream baos = new ByteArrayOutputStream();

						int len;

						byte[] buffer = new byte[32768];

						while ((len = zis.read(buffer)) > 0) {
							baos.write(buffer, 0, len);
						}

						if (converter != null) {
							data.setData(converter.convert(data.getString(), baos.toByteArray()));
						} else {
							data.setData(baos.toByteArray());
						}
					}
				}

				ze = zis.getNextEntry();
			}
		} finally {
			zis.closeEntry();
			zis.close();
		}

		return list;
	}

	/**
	 * Extrait la liste des items d'un fichier zip
	 * @param content Le contenu binaire en format zip à dézipper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<ZipEntry> unzipListEntries(byte[] content) throws Exception {
		return unzipListEntries(content, null);
	}

	/**
	 * Extrait la liste des items d'un fichier zip
	 * @param content Le contenu binaire en format zip à dézipper
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<ZipEntry> unzipListEntries(byte[] content, FilenameFilter filter) throws Exception {
		List<ZipEntry> entriesList = new ArrayList<ZipEntry>();

		ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(content));

		try {
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {
				boolean ok = true;

				if (filter != null) {
					File file = new File(ze.getName());
					ok = filter.accept(file.getParentFile(), file.getName());
				}

				if (ok) {
					entriesList.add(ze);
				}

				ze = zis.getNextEntry();
			}
		} finally {
			zis.closeEntry();
			zis.close();
		}

		return entriesList;
	}

	/**
	 * Extrait la liste des items d'un contenu binaire en format zip
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "zipFile.zip", filenames = 0)
	final public static List<ZipEntry> unzipListEntries(String zipFilename) throws Exception {
		return unzipListEntries(zipFilename, null);
	}

	/**
	 * Extrait la liste des items d'un contenu binaire en format zip
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<ZipEntry> unzipListEntries(String zipFilename, FilenameFilter filter) throws Exception {
		List<ZipEntry> entriesList = new ArrayList<ZipEntry>();

		ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilename));

		try {
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {
				boolean ok = true;

				if (filter != null) {
					File file = new File(ze.getName());
					ok = filter.accept(file.getParentFile(), file.getName());
				}

				if (ok) {
					entriesList.add(ze);
				}

				ze = zis.getNextEntry();
			}
		} finally {
			zis.closeEntry();
			zis.close();
		}

		return entriesList;
	}

	/**
	 * GZIP de données
	 * @param data Les données à gziper
	 * @param gzipFilename Le chemin complet du fichier gzip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",100", "OutilsCompression.gz" }, filenames = { 1 }, iterate = true)
	final public static void gzipFile(byte[] data, String gzipFilename) throws Exception {
		if (data == null) {
			data = new byte[0];
		}

		GZIPOutputStream gos = new GZIPOutputStream(new FileOutputStream(gzipFilename));

		try {
			gos.write(data, 0, data.length);
		} finally {
			gos.close();
		}
	}

	/**
	 * GZIP le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à gziper
	 * @param gzipFilename Le chemin complet du fichier gzip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "gzipFile.txt", "gzipFile.gz" }, filenames = { 0, 1 })
	final public static void gzipFile(String filename, String gzipFilename) throws Exception {
		File file = new File(filename);

		GZIPOutputStream gos = new GZIPOutputStream(new FileOutputStream(gzipFilename));

		try {
			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					gos.write(buffer, 0, len);
				}
			} finally {
				fis.close();
			}
		} finally {
			gos.close();
		}
	}

	/**
	 * GZIP de données
	 * @param data Les données à gziper
	 * @return Le contenu gziper
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = ",100", iterate = true)
	final public static byte[] gzipFileContent(byte[] data) throws Exception {
		if (data == null) {
			data = new byte[0];
		}

		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		GZIPOutputStream gos = new GZIPOutputStream(baos);

		try {
			gos.write(data, 0, data.length);
		} finally {
			gos.close();
		}

		return baos.toByteArray();
	}

	/**
	 * GZIP le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à gziper
	 * @return Le contenu gziper
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "zipFile.txt", filenames = 0)
	final public static byte[] gzipFileContent(String filename) throws Exception {
		return gzipFileContent(new File(filename));
	}

	/**
	 * GZIP le contenu d'un fichier
	 * @param file Le fichier à gziper
	 * @return Le contenu gziper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static byte[] gzipFileContent(File file) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		GZIPOutputStream gos = new GZIPOutputStream(baos);

		try {
			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					gos.write(buffer, 0, len);
				}

			} finally {
				fis.close();
			}
		} finally {
			gos.close();
		}

		return baos.toByteArray();
	}

	/**
	 * GZIP le contenu d'un répertoire
	 * @param baseDir Le répertoire source
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests("tests\\files\\commun\\gzipDirectory")
	final public static void gzipDirectory(String baseDir) throws Exception {
		gzipDirectoryList(OutilsCommun.scanForFiles(baseDir), baseDir);
	}

	/**
	 * GZIP le contenu basé sur la liste des fichiers d'un répertoire
	 * @param La liste des fichiers du répertoire
	 * @param baseDir Le répertoire source
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void gzipDirectoryList(List<NameValue> filesList, String baseDir) throws Exception {
		for (NameValue item : filesList) {
			String entry = OutilsCommun.getFullname(item.getName(), item.getValue());

			String filename = OutilsCommun.getFullname(baseDir, entry);

			String gzipFilename = filename + OutilsCommun.GZIP_EXTENSION;

			gzipFile(filename, gzipFilename);
		}
	}

	/**
	 * Dézip le contenu d'un fichier gzip
	 * @param gzipFilename Le chemin complet du fichier gzip source
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "zipFile.zip,gzipFile.gz", filenames = 0, iterate = true)
	final public static void ungzipFile(String gzipFilename) throws Exception {
		String filename;

		if (OutilsBase.endsWithIgnoreCase(gzipFilename, OutilsCommun.GZIP_EXTENSION)) {
			filename = gzipFilename.substring(0, gzipFilename.length() - OutilsCommun.GZIP_EXTENSION.length());
		} else {
			throw new Exception("Le nom du fichier gzip ne se termine pas par l'extension " + OutilsCommun.GZIP_EXTENSION);
		}

		ungzipFile(gzipFilename, filename);
	}

	/**
	 * Dézip le contenu d'un fichier gzip
	 * @param gzipFilename Le chemin complet du fichier gzip source
	 * @param filename Le chemin complet du fichier de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void ungzipFile(String gzipFilename, String filename) throws Exception {
		GZIPInputStream gis = new GZIPInputStream(new FileInputStream(gzipFilename));

		try {
			FileOutputStream fos = new FileOutputStream(filename);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = gis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
			} finally {
				fos.close();
			}
		} finally {
			gis.close();
		}
	}

	/**
	 * Dézip le contenu d'un fichier gzip en mémoire
	 * @param gzipFilename Le chemin complet du fichier gzip source
	 * @return le contenu d'un fichier gzip en mémoire
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "gzipFile.gz", filenames = 0)
	final public static Object ungzipFileToObject(String gzipFilename) throws Exception {
		return ungzipFileToObject(gzipFilename, new RawFileConverter());
	}

	/**
	 * Dézip le contenu d'un fichier gzip en mémoire
	 * @param gzipFilename Le chemin complet du fichier gzip source
	 * @param converter Conversion de données brute selon le type du fichier
	 * @return le contenu d'un fichier gzip en mémoire
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "zipFile.zip,gzipFile.gz", "null" }, filenames = 0, iterate = true)
	final public static Object ungzipFileToObject(String gzipFilename, IRawFileConverter converter) throws Exception {
		String filename;

		if (OutilsBase.endsWithIgnoreCase(gzipFilename, OutilsCommun.GZIP_EXTENSION)) {
			filename = gzipFilename.substring(0, gzipFilename.length() - OutilsCommun.GZIP_EXTENSION.length());
		} else {
			throw new Exception("Le nom du fichier gzip ne se termine pas par l'extension " + OutilsCommun.GZIP_EXTENSION);
		}

		return ungzipFileToObject(gzipFilename, filename, converter);
	}

	/**
	 * Dézip le contenu d'un fichier gzip en mémoire
	 * @param gzipFilename Le chemin complet du fichier gzip source
	 * @param filename Le chemin complet du fichier gzip source
	 * @param converter Conversion de données brute selon le type du fichier
	 * @return le contenu d'un fichier gzip en mémoire
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static Object ungzipFileToObject(String gzipFilename, String filename, IRawFileConverter converter) throws Exception {
		GZIPInputStream gis = new GZIPInputStream(new FileInputStream(gzipFilename));

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			int len;

			byte[] buffer = new byte[32768];

			while ((len = gis.read(buffer)) > 0) {
				baos.write(buffer, 0, len);
			}

			if (converter != null) {
				return converter.convert(filename, baos.toByteArray());
			} else {
				return baos.toByteArray();
			}
		} finally {
			gis.close();
		}
	}

	/**
	 * Dézip un contenu binaire en format gzip en mémoire
	 * @param content Le contenu binaire en format gzip à dézipper
	 * @return le contenu binaire en format gzip en mémoire
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static byte[] ungzipFile(byte[] content) throws Exception {
		GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(content));

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			int len;

			byte[] buffer = new byte[32768];

			while ((len = gis.read(buffer)) > 0) {
				baos.write(buffer, 0, len);
			}

			return baos.toByteArray();
		} finally {
			gis.close();
		}
	}
}
