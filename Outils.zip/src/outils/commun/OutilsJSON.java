package outils.commun;

import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Classe des méthodes utilitaires json de type final public static
 * ALERTE: NE PAS MODIFIER MANUELLEMENT CETTE CLASSE !!!
 * @author Projet: Outils, Classe: json.outils.json.OutilsJSONClassGenerator
 */
public class OutilsJSON {
 	// ALERTE: NE PAS MODIFIER MANUELLEMENT CETTE CLASSE !!!
	// Utilisez la classe json.outils.json.OutilsJSONClassGenerator du projet Outils

	// OutilsJSONClassTemplate

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type String en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJSON(String value) {
		if (value == null) {
			return null;
		}

		return "\"" + value.replace("\\", "\\\\") + "\"";
	}

	/**
	 * Convertit un champ de type String en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, String value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type String[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0","item1",...] (null si items == null)
	 */
	final public static String asJSON(String[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (String item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type String[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0","item1",...] (["item0","item1",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, String[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type java.util.Date en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJSON(java.util.Date value) {
		if (value == null) {
			return null;
		}

		return OutilsCommun.asDateTimeString(value);
	}

	/**
	 * Convertit un champ de type java.util.Date en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, java.util.Date value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type java.util.Date[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0","item1",...] (null si items == null)
	 */
	final public static String asJSON(java.util.Date[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (java.util.Date item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type java.util.Date[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0","item1",...] (["item0","item1",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, java.util.Date[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type java.sql.Date en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJSON(java.sql.Date value) {
		if (value == null) {
			return null;
		}

		return OutilsCommun.asDateTimeString(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertit un champ de type java.sql.Date en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, java.sql.Date value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type java.sql.Date[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0","item1",...] (null si items == null)
	 */
	final public static String asJSON(java.sql.Date[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (java.sql.Date item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type java.sql.Date[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0","item1",...] (["item0","item1",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, java.sql.Date[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Instant en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJSON(Instant value) {
		if (value == null) {
			return null;
		}

		return asJSON(value.getEpochSecond());
	}

	/**
	 * Convertit un champ de type Instant en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Instant value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Instant[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0","item1",...] (null si items == null)
	 */
	final public static String asJSON(Instant[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Instant item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Instant[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0","item1",...] (["item0","item1",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Instant[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Time en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJSON(Time value) {
		if (value == null) {
			return null;
		}

		return OutilsCommun.asTimeString(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertit un champ de type Time en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Time value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Time[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0","item1",...] (null si items == null)
	 */
	final public static String asJSON(Time[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Time item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Time[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0","item1",...] (["item0","item1",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Time[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Timestamp en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJSON(Timestamp value) {
		if (value == null) {
			return null;
		}

		return OutilsCommun.asDateTimeString(new java.util.Date(value.getTime()));
	}

	/**
	 * Convertit un champ de type Timestamp en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Timestamp value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Timestamp[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0","item1",...] (null si items == null)
	 */
	final public static String asJSON(Timestamp[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Timestamp item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Timestamp[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0","item1",...] (["item0","item1",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Timestamp[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Enum<?> en format json
	 * @param value Valeur à convertir
	 * @return "value.name()" (null si value == null)
	 */
	final public static String asJSON(Enum<?> value) {
		if (value == null) {
			return null;
		}

		return asJSON(value.name());
	}

	/**
	 * Convertit un champ de type Enum<?> en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value.name()" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Enum<?> value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Enum<?>[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0.name()","item1.name()",...] (null si items == null)
	 */
	final public static String asJSON(Enum<?>[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Enum<?> item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Enum<?>[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0.name()","item1.name()",...] (["item0.name()","item1.name()",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Enum<?>[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type BigDecimal en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJSON(BigDecimal value) {
		if (value == null) {
			return null;
		}

		return asJSON(value.toString());
	}

	/**
	 * Convertit un champ de type BigDecimal en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":"value" ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, BigDecimal value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type BigDecimal[] en format json
	 * @param items Tableau des items à convertir
	 * @return ["item0","item1",...] (null si items == null)
	 */
	final public static String asJSON(BigDecimal[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (BigDecimal item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type BigDecimal[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":["item0","item1",...] (["item0","item1",...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, BigDecimal[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type int en format json
	 * @param value Valeur à convertir
	 * @return value
	 */
	final public static String asJSON(int value) {
		// Pas de test requis pour value == null
		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type int en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value (value si name est vide)
	 */
	final public static String asJSON(String name, int value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type int[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(int[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (int item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			json += asJSON(item);
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type int[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, int[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Integer en format json
	 * @param value Valeur à convertir
	 * @return value (null si value == null)
	 */
	final public static String asJSON(Integer value) {
		if (value == null) {
			return null;
		}

		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type Integer en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Integer value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Integer[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(Integer[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Integer item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Integer[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Integer[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type long en format json
	 * @param value Valeur à convertir
	 * @return value
	 */
	final public static String asJSON(long value) {
		// Pas de test requis pour value == null
		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type long en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value (value si name est vide)
	 */
	final public static String asJSON(String name, long value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type long[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(long[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (long item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			json += asJSON(item);
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type long[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, long[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Long en format json
	 * @param value Valeur à convertir
	 * @return value (null si value == null)
	 */
	final public static String asJSON(Long value) {
		if (value == null) {
			return null;
		}

		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type Long en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Long value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Long[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(Long[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Long item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Long[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Long[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type float en format json
	 * @param value Valeur à convertir
	 * @return value
	 */
	final public static String asJSON(float value) {
		// Pas de test requis pour value == null
		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type float en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value (value si name est vide)
	 */
	final public static String asJSON(String name, float value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type float[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(float[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (float item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			json += asJSON(item);
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type float[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, float[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Float en format json
	 * @param value Valeur à convertir
	 * @return value (null si value == null)
	 */
	final public static String asJSON(Float value) {
		if (value == null) {
			return null;
		}

		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type Float en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Float value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Float[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(Float[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Float item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Float[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Float[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type double en format json
	 * @param value Valeur à convertir
	 * @return value
	 */
	final public static String asJSON(double value) {
		// Pas de test requis pour value == null
		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type double en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value (value si name est vide)
	 */
	final public static String asJSON(String name, double value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type double[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(double[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (double item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			json += asJSON(item);
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type double[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, double[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Double en format json
	 * @param value Valeur à convertir
	 * @return value (null si value == null)
	 */
	final public static String asJSON(Double value) {
		if (value == null) {
			return null;
		}

		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type Double en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Double value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Double[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(Double[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Double item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Double[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Double[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type boolean en format json
	 * @param value Valeur à convertir
	 * @return value
	 */
	final public static String asJSON(boolean value) {
		// Pas de test requis pour value == null
		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type boolean en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value (value si name est vide)
	 */
	final public static String asJSON(String name, boolean value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type boolean[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(boolean[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (boolean item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			json += asJSON(item);
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type boolean[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, boolean[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	// AsJSONTemplate

	/**
	 * Convertit une valeur de type Boolean en format json
	 * @param value Valeur à convertir
	 * @return value (null si value == null)
	 */
	final public static String asJSON(Boolean value) {
		if (value == null) {
			return null;
		}

		return OutilsBase.asString(value);
	}

	/**
	 * Convertit un champ de type Boolean en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":value ("value" si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Boolean value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Boolean[] en format json
	 * @param items Tableau des items à convertir
	 * @return [item0,item1,...] (null si items == null)
	 */
	final public static String asJSON(Boolean[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Boolean item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (!OutilsBase.areNulls(item)) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Boolean[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[item0,item1,...] ([item0,item1,...] si name est vide, null si items == null)
	 */
	final public static String asJSON(String name, Boolean[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}


	/**
	 * Convertit une valeur de type Object en format json
	 * @param value Valeur à convertir
	 * @return json (null si value == null)
	 */
	@AutomatedTests({ "(Object) new java.util.Date(1583025602029L)", "(Object) new java.sql.Date(1583025602029L)", "(Object) Instant.ofEpochMilli(1583025602029L)", "(Object) new Integer(10)" })
	final public static String asJSON(Object value) {
		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			return asJSON(value.toString());
		} else if (value instanceof java.util.Date) {
			return asJSON((java.util.Date) value);
		} else if (value instanceof Instant) {
			return asJSON((Instant) value);
		}

		return value.toString();
	}

	/**
	 * Convertit un champ de type Object en format json
	 * @param name Nom du champ
	 * @param value Valeur à convertir
	 * @return "name":json (json si name est vide, null si value == null)
	 */
	final public static String asJSON(String name, Object value) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(value);
		}

		return asJSON(name) + ":" + asJSON(value);
	}

	/**
	 * Convertit un tableau de type Object en format json
	 * @param items Tableau des items à convertir
	 * @return [json0,json1,...] (null si items == null)
	 */
	final public static String asJSON(Object[] items) {
		if (items == null) {
			return null;
		}

		String json = "";

		for (Object item : items) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (item != null) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ de type Object[] en format json
	 * @param name Nom du champ
	 * @param items Tableau des items à convertir
	 * @return "name":[json0,json1,...] (null si name est vide ou items == null)
	 */
	final public static String asJSON(String name, Object[] items) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(items);
		}

		return asJSON(name) + ":" + asJSON(items);
	}

	/**
	 * Convertit une liste générique en format json
	 * @param list La liste générique à convertir
	 * @return la liste des champs en format json [json0,json1,...] (null si list == null)
	 */
	@AutomatedTests("null,A,B")
	final public static String asJSON(List<?> list) {
		if (list == null) {
			return null;
		}

		String json = "";

		for (Object item : list) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (item != null) {
				json += asJSON(item);
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ d'une liste générique en format json
	 * @param name Nom du champ
	 * @param list La liste générique à convertir
	 * @return la liste des champs en format json "name":[json0,json1,...] (null si name est vide ou list == null)
	 */
	final public static String asJSON(String name, List<?> list) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(list);
		}

		return asJSON(name) + ":" + asJSON(list);
	}

	/**
	 * Convertit une liste générique en format String json
	 * @param list La liste générique à convertir
	 * @return la liste des champs en format json ["item0","item1",...] (null si list == null)
	 */
	@AutomatedTests("null,A,B")
	final public static String asJSONAsString(List<?> list) {
		if (list == null) {
			return null;
		}

		String json = "";

		for (Object item : list) {
			if (!json.isEmpty()) {
				json += ",";
			}

			if (item != null) {
				json += asJSON(item.toString());
			} else {
				json += "null";
			}
		}

		return "[" + json + "]";
	}

	/**
	 * Convertit un champ d'une liste générique en format String json
	 * @param name Nom du champ
	 * @param list La liste générique à convertir
	 * @return la liste des champs en format json "name":["item0","item1",...] (null si name est vide ou list == null)
	 */
	final public static String asJSONAsString(String name, List<?> list) {
		if (OutilsBase.isEmpty(name)) {
			return asJSON(list);
		}

		return asJSON(name) + ":" + asJSONAsString(list);
	}

	/**
	 * Extrait une liste de champs en format json
	 * @param list La liste des champs
	 * @return la liste des champs en format json {item0,item1,...} (null si list == null)
	 */
	@AutomatedTests({ "null,A,B", ",1,2", "1,2,", ",1,2," })
	final public static String toJSON(List<?> list) {
		if (list == null) {
			return null;
		}

		String json = "";

		for (Object item : list) {
			if (item != null) {
				if (!json.isEmpty()) {
					json += ",";
				}

				json += OutilsBase.asString(item);
			}
		}

		if (OutilsBase.isEmpty(json)) {
			return "";
		}

		if (json.startsWith("{") && json.endsWith("}")) {
			return json;
		}

		return "{" + json + "}";
	}

	/**
	 * Extrait une liste de champs en format json
	 * @param name Nom du champ
	 * @param list La liste des champs
	 * @return la liste des champs en format json "name":[{item0,item1,...}] (null si name est vide ou list == null)
	 */
	@AutomatedTests({ "Test", "null,A,B" })
	final public static String toJSON(String name, List<?> list) {
		String json = toJSON(list);

		if (OutilsBase.isEmpty(name)) {
			return "[" + json + "]";
		}

		return "\"" + name + "\":[" + json + "]";
	}
}
