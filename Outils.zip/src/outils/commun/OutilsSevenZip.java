package outils.commun;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;

import outils.abstractions.IRawFileConverter;
import outils.abstractions.RawFileConverter;
import outils.listes.NameValue;
import outils.listes.StringData;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.SkipImportsForTesting;
import outils.tests.automated.annotations.SkipTesting;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Classe des méthodes utilitaires de type final public static pour la compression en format 7z
 * @author Claude Toupin - 11 août 2022
 */
@SkipImportsForTesting({ List.class, NameValue.class })
@CoverageTestsCases(OutilsSevenZip.CoverageTestsCases.class)
public class OutilsSevenZip {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases, FilenameFilter {

		@Override
		public void doBeforeAll() throws Exception {
			String baseDir = OutilsCommun.getFullname(OutilsCommun.getTempDirectory(), OutilsSevenZip.class.getSimpleName(), CoverageTestsCases.class.getSimpleName());
			
			OutilsCommun.buildDirectory(baseDir, true);

			String sevenZipFilename = OutilsCommun.getFullname(OutilsCommun.getCurrentDirectory(), "tests", "files", "commun", "sevenZipFile.7z");

			OutilsSevenZip.sevenZipListFiles(sevenZipFilename, this);

			outils.commun.OutilsSevenZip.sevenUnzipFile(baseDir, sevenZipFilename);

			outils.commun.OutilsSevenZip.sevenUnzipFile(baseDir, sevenZipFilename, true);

			outils.commun.OutilsSevenZip.sevenUnzipFile(baseDir, sevenZipFilename, (FilenameFilter) null);

			outils.commun.OutilsSevenZip.sevenUnzipFile(baseDir, sevenZipFilename, this);

			outils.commun.OutilsSevenZip.sevenUnzipFile(baseDir, sevenZipFilename, (FilenameFilter) null, true);

			outils.commun.OutilsSevenZip.sevenUnzipFile(baseDir, sevenZipFilename, this, true);

			OutilsSevenZip.sevenUnzipFile(sevenZipFilename, this);

			OutilsSevenZip.sevenUnzipListEntries(sevenZipFilename, this);
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

		@Override
		public boolean accept(File dir, String name) {
			return "cat.txt".equals(name);
		}

	}
	/**
	 * 7 zip de données
	 * @param data Les données à ziper
	 * @param name Le nom des données (i.e. fichier) à ziper
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { ",100", "sevenZipFile", "OutilsCompression.7z" }, filenames = { 2 }, iterate = true)
	final public static void sevenZipFile(byte[] data, String name, String zipFilename) throws Exception {
		if (data == null) {
			data = new byte[0];
		}

		SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File(zipFilename));

		try {
			SevenZArchiveEntry entry = new SevenZArchiveEntry();
			entry.setDirectory(false);
			entry.setName(name);
			entry.setLastModifiedDate(new Date());

			sevenZOutputFile.putArchiveEntry(entry);

			sevenZOutputFile.write(data, 0, data.length);

			sevenZOutputFile.closeArchiveEntry();
		} finally {
			sevenZOutputFile.finish();
			sevenZOutputFile.close();
		}
	}

	/**
	 * 7 zip le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à ziper
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "sevenZipFile.txt", "OutilsCompression.7z" }, filenames = { 0, 1 })
	final public static void sevenZipFile(String filename, String zipFilename) throws Exception {
		File file = new File(filename);

		SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File(zipFilename));

		try {
			sevenZOutputFile.putArchiveEntry(sevenZOutputFile.createArchiveEntry(file, file.getName()));

			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					sevenZOutputFile.write(buffer, 0, len);
				}
			} finally {
				fis.close();
			}

			sevenZOutputFile.closeArchiveEntry();
		} finally {
			sevenZOutputFile.finish();
			sevenZOutputFile.close();
		}
	}

	/**
	 * 7 zip le contenu d'un fichier
	 * @param filename Le chemin complet du fichier à ziper
	 * @param name Le nom des données (i.e. fichier) à ziper
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "sevenZipFile.txt", "sevenZipFile", "OutilsCompression.7z" }, filenames = { 0, 2 })
	final public static void sevenZipFile(String filename, String name, String zipFilename) throws Exception {
		File file = new File(filename);

		SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File(zipFilename));

		try {
			SevenZArchiveEntry entry = new SevenZArchiveEntry();
			entry.setDirectory(false);
			entry.setName(name);
			entry.setLastModifiedDate(new Date(file.lastModified()));
			
			sevenZOutputFile.putArchiveEntry(entry);

			FileInputStream fis = new FileInputStream(file);

			try {
				int len;

				byte[] buffer = new byte[32768];

				while ((len = fis.read(buffer)) > 0) {
					sevenZOutputFile.write(buffer, 0, len);
				}
			} finally {
				fis.close();
			}

			sevenZOutputFile.closeArchiveEntry();
		} finally {
			sevenZOutputFile.finish();
			sevenZOutputFile.close();
		}
	}

	/**
	 * 7 zip le contenu d'un répertoire
	 * @param baseDir Le répertoire source
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "tests\\files\\commun", "OutilsCompression.7z" }, filenames = 1)
	final public static void sevenZipDirectory(String baseDir, String zipFilename) throws Exception {
		sevenZipDirectoryList(OutilsCommun.scanForFiles(baseDir), baseDir, zipFilename);
	}

	/**
	 * 7 zip le contenu basé sur la liste des fichiers d'un répertoire
	 * @param La liste des fichiers du répertoire
	 * @param baseDir Le répertoire source
	 * @param zipFilename Le chemin complet du fichier zip de sortie
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void sevenZipDirectoryList(List<NameValue> filesList, String baseDir, String zipFilename) throws Exception {
		SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File(zipFilename));

		try {
			for (NameValue item : filesList) {
				String entry = OutilsCommun.getFullname(item.getName(), item.getValue());

				File fileEntry = new File(OutilsCommun.getFullname(baseDir, entry));

				sevenZOutputFile.putArchiveEntry(sevenZOutputFile.createArchiveEntry(fileEntry, entry));

				FileInputStream fis = new FileInputStream(fileEntry);

				try {
					int len;

					byte[] buffer = new byte[32768];

					while ((len = fis.read(buffer)) > 0) {
						sevenZOutputFile.write(buffer, 0, len);
					}
				} finally {
					fis.close();
				}

				sevenZOutputFile.closeArchiveEntry();
			}
		} finally {
			sevenZOutputFile.finish();
			sevenZOutputFile.close();
		}
	}

	/**
	 * Extrait la liste des fichiers depuis un fichier zip source donné
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur..
	 */
	@StrictAutomatedTests(value = { "sevenZipFile.7z" }, filenames = 0)
	final public static List<NameValue> sevenZipListFiles(String zipFilename) throws Exception {
		return sevenZipListFiles(zipFilename, null);
	}

	/**
	 * Extrait la liste des fichiers depuis un fichier zip source donné
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers
	 * @return une liste de paires sous forme répertoire=fichier
	 * @throws Exception en cas d'erreur..
	 */
	@SkipTesting
	final public static List<NameValue> sevenZipListFiles(String zipFilename, FilenameFilter filter) throws Exception {
		List<NameValue> filesList = new ArrayList<NameValue>();

		SevenZFile sevenZfile = new SevenZFile(new File(zipFilename));

		try {
			SevenZArchiveEntry sevenZArchiveEntry = sevenZfile.getNextEntry();

			while (sevenZArchiveEntry != null) {
				if (!sevenZArchiveEntry.isDirectory()) {
					boolean ok = true;

					File file = new File(sevenZArchiveEntry.getName());

					if (filter != null) {
						ok = filter.accept(file.getParentFile(), file.getName());
					}

					if (ok) {
						filesList.add(new NameValue(file.getParent(), file.getName()));
					}
				}

				sevenZArchiveEntry = sevenZfile.getNextEntry();
			}
		} finally {
			sevenZfile.close();
		}

		filesList.sort(new NameValue.Compare(true, false));

		return filesList;
	}

	/**
	 * 7 dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void sevenUnzipFile(String baseDir, String zipFilename) throws Exception {
		sevenUnzipFile(baseDir, zipFilename, null, false);
	}

	/**
	 * 7 dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param force Indicateur pour forcer la création
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void sevenUnzipFile(String baseDir, String zipFilename, boolean force) throws Exception {
		sevenUnzipFile(baseDir, zipFilename, null, force);
	}

	/**
	 * 7 dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void sevenUnzipFile(String baseDir, String zipFilename, FilenameFilter filter) throws Exception {
		sevenUnzipFile(baseDir, zipFilename, filter, false);
	}

	/**
	 * 7 dézip le contenu d'un fichier zip
	 * @param baseDir Le répertoire de sortie
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @param force Indicateur pour forcer la création
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static void sevenUnzipFile(String baseDir, String zipFilename, FilenameFilter filter, boolean force) throws Exception {
		OutilsCommun.buildDirectory(baseDir, force);

		SevenZFile sevenZfile = new SevenZFile(new File(zipFilename));

		try {
			SevenZArchiveEntry sevenZArchiveEntry = sevenZfile.getNextEntry();

			while (sevenZArchiveEntry != null) {
				boolean ok = true;

				File file = new File(sevenZArchiveEntry.getName());

				if (filter != null) {
					ok = filter.accept(file.getParentFile(), file.getName());
				}

				if (ok) {
					file = new File(OutilsCommun.getFullname(baseDir, sevenZArchiveEntry.getName())).getCanonicalFile();

					if (sevenZArchiveEntry.isDirectory()) {
						file.mkdirs();
					} else {
						file.getParentFile().mkdirs();

						FileOutputStream fos = new FileOutputStream(file);

						try {
							int len;

							byte[] buffer = new byte[32768];

							while ((len = sevenZfile.read(buffer)) > 0) {
								fos.write(buffer, 0, len);
							}
						} finally {
							fos.close();
						}
					}
				}

				sevenZArchiveEntry = sevenZfile.getNextEntry();
			}
		} finally {
			sevenZfile.close();
		}
	}

	/**
	 * 7 dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "sevenZipFile.7z", filenames = 0)
	final public static List<StringData> sevenUnzipFile(String zipFilename) throws Exception {
		return sevenUnzipFile(zipFilename, null, new RawFileConverter());
	}

	/**
	 * 7 dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "sevenZipFile.7z", "null" }, filenames = 0)
	final public static List<StringData> sevenUnzipFile(String zipFilename, FilenameFilter filter) throws Exception {
		return sevenUnzipFile(zipFilename, filter, new RawFileConverter());
	}

	/**
	 * 7 dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param converter Conversion de données brute selon le type du fichier
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "sevenZipFile.7z", "null" }, filenames = 0)
	final public static List<StringData> sevenUnzipFile(String zipFilename, IRawFileConverter converter) throws Exception {
		return sevenUnzipFile(zipFilename, null, converter);
	}

	/**
	 * 7 dézip le contenu d'un fichier zip en mémoire
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @param converter Conversion de données brute selon le type du fichier
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = { "sevenZipFile.7z", "null", "null" }, filenames = 0)
	final public static List<StringData> sevenUnzipFile(String zipFilename, FilenameFilter filter, IRawFileConverter converter) throws Exception {
		List<StringData> list = new ArrayList<StringData>();

		SevenZFile sevenZfile = new SevenZFile(new File(zipFilename));

		try {
			SevenZArchiveEntry sevenZArchiveEntry = sevenZfile.getNextEntry();

			while (sevenZArchiveEntry != null) {
				if (!sevenZArchiveEntry.isDirectory()) {
					boolean ok = true;

					if (filter != null) {
						File file = new File(sevenZArchiveEntry.getName());
						ok = filter.accept(file.getParentFile(), file.getName());
					}

					if (ok) {
						StringData data = new StringData(sevenZArchiveEntry.getName());
						list.add(data);

						ByteArrayOutputStream baos = new ByteArrayOutputStream();

						int len;

						byte[] buffer = new byte[32768];

						while ((len = sevenZfile.read(buffer)) > 0) {
							baos.write(buffer, 0, len);
						}

						if (converter != null) {
							data.setData(converter.convert(data.getString(), baos.toByteArray()));
						} else {
							data.setData(baos.toByteArray());
						}
					}
				}

				sevenZArchiveEntry = sevenZfile.getNextEntry();
			}
		} finally {
			sevenZfile.close();
		}

		return list;
	}

	/**
	 * Extrait la liste des items d'un contenu binaire en format zip
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @throws Exception en cas d'erreur...
	 */
	@StrictAutomatedTests(value = "sevenZipFile.7z", filenames = 0)
	final public static List<SevenZArchiveEntry> sevenUnzipListEntries(String zipFilename) throws Exception {
		return sevenUnzipListEntries(zipFilename, null);
	}

	/**
	 * Extrait la liste des items d'un contenu binaire en format zip
	 * @param zipFilename Le chemin complet du fichier zip source
	 * @param filter Le filtre des noms de fichiers à déziper
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	final public static List<SevenZArchiveEntry> sevenUnzipListEntries(String zipFilename, FilenameFilter filter) throws Exception {
		List<SevenZArchiveEntry> entriesList = new ArrayList<SevenZArchiveEntry>();

		SevenZFile sevenZfile = new SevenZFile(new File(zipFilename));

		try {
			SevenZArchiveEntry sevenZArchiveEntry = sevenZfile.getNextEntry();

			while (sevenZArchiveEntry != null) {
				boolean ok = true;

				if (filter != null) {
					File file = new File(sevenZArchiveEntry.getName());
					ok = filter.accept(file.getParentFile(), file.getName());
				}

				if (ok) {
					entriesList.add(sevenZArchiveEntry);
				}

				sevenZArchiveEntry = sevenZfile.getNextEntry();
			}
		} finally {
			sevenZfile.close();
		}

		return entriesList;
	}
}
