package outils.commun;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Paths;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import outils.base.OutilsBase;
import outils.listes.NameValue;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.SkipTesting;
import outils.xml.data.NodeXML;

/**
 * Classe des méthodes utilitaires de type final public static pour le XML
 * @author Claude Toupin - 2018-07-21
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "ParseXML.xml", filename = true)
@DefaultParameterTestValue(type = File.class, name = "file", value = "ParseXML.xml", filename = true)
@DefaultParameterTestValue(type = String.class, name = "text", value = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><a:b></a:b>")
@CoverageTestsCases(ParseXML.CoverageTestsCases.class)
public class ParseXML {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			String uri = "file:///" + Paths.get("tests\\files\\commun\\ParseXML.xml").toAbsolutePath().toString().replace(":", "|").replace(File.separator, "/");

			byte[] buffer = OutilsBase.asString("<?xml version=\"1.0\" encoding=\"UTF-8\"?><a:b></a:b>").getBytes();

			outils.commun.ParseXML.parseXMLURI(uri);
			outils.commun.ParseXML.parseXMLURI(uri, true);

			outils.commun.ParseXML.parseXMLBuffer(buffer);
			outils.commun.ParseXML.parseXMLBuffer(buffer, true);
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/**
	 * Traitement du nomn d'un noeud
	 * @param name Nom du noeud
	 * @param removePrefix Indicateur de suppression des préfixes dans les noms de noeuds
	 * @return le nom du noeud traité
	 */
	protected static String processName(String name, boolean removePrefix) {
		if (removePrefix) {
			if (!OutilsBase.isEmpty(name)) {
				int pos = name.indexOf(':');
				
				if (pos != -1) {
					return name.substring(pos + 1);
				}
			}
		}
		
		return name;
	}

	/**
	 * Traitement d'une liste de noeuds
	 * @param parent Noeud parent XML
	 * @param nodeList Liste des noeuds à traiter
	 * @param removePrefix Indicateur de suppression des préfixes dans les noms de noeuds
	 * @return le noeud racine
	 */
	protected static NodeXML processNodeList(NodeXML parent, NodeList nodeList, boolean removePrefix) {
		NodeXML current = null;

		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);

			switch (node.getNodeType()) {
				case Node.ELEMENT_NODE:
					current = new NodeXML(parent, processName(node.getNodeName(), removePrefix));
					
					NamedNodeMap namedNodeMap = node.getAttributes();

					if (namedNodeMap != null) {
						for (int j = 0; j < namedNodeMap.getLength(); j++) {
							Node item = namedNodeMap.item(j);
							current.getAttributesList().add(new NameValue(processName(item.getNodeName(), removePrefix), item.getNodeValue()));
						}
					}

					processNodeList(current, node.getChildNodes(), removePrefix);
					break;
				case Node.TEXT_NODE:
					parent.setText(OutilsBase.asString(node.getNodeValue()).trim());
					current = parent;
					break;
				case Node.COMMENT_NODE:
					// Ignore...
					break;
				default:
					System.err.println("Pas de traitement pour getNodeType()=" + node.getNodeType());
					System.exit(1);
			}
		}

		return current;
	}

	/**
	 * Traitement d'un fichier XML
	 * @param filename Nom du fichier
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	public static NodeXML parseXMLFile(String filename) throws Exception {
		return parseXMLFile(filename, false);
	}

	/**
	 * Traitement d'un fichier XML
	 * @param filename Nom du fichier
	 * @param removePrefix Indicateur de suppression des préfixes dans les noms de noeuds
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	public static NodeXML parseXMLFile(String filename, boolean removePrefix) throws Exception {
		return parseXMLFile(new File(filename), removePrefix);
	}

	/**
	 * Traitement d'un fichier XML
	 * @param file Fichier XML
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	public static NodeXML parseXMLFile(File file) throws Exception {
		return parseXMLFile(file, false);
	}

	/**
	 * Traitement d'un fichier XML
	 * @param file Fichier XML
	 * @param removePrefix Indicateur de suppression des préfixes dans les noms de noeuds
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	public static NodeXML parseXMLFile(File file, boolean removePrefix) throws Exception {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.parse(file);
		document.getDocumentElement().normalize();

		return processNodeList(null, document.getChildNodes(), removePrefix);
	}

	/**
	 * Traitement d'un URI
	 * @param uri Adresse du URI
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	public static NodeXML parseXMLURI(String uri) throws Exception {
		return parseXMLURI(uri, false);
	}

	/**
	 * Traitement d'un URI
	 * @param uri Adresse du URI
	 * @param removePrefix Indicateur de suppression des préfixes dans les noms de noeuds
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	public static NodeXML parseXMLURI(String uri, boolean removePrefix) throws Exception {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.parse(uri);
		document.getDocumentElement().normalize();

		return processNodeList(null, document.getChildNodes(), removePrefix);
	}

	/**
	 * Traitement d'un texte XML
	 * @param text Texte XML à traiter
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	public static NodeXML parseXMLText(String text) throws Exception {
		return parseXMLText(text, false);
	}

	/**
	 * Traitement d'un texte XML
	 * @param text Texte XML à traiter
	 * @param removePrefix Indicateur de suppression des préfixes dans les noms de noeuds
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	public static NodeXML parseXMLText(String text, boolean removePrefix) throws Exception {
		return parseXMLBuffer(OutilsBase.asString(text).getBytes(), removePrefix);
	}

	/**
	 * Traitement d'un tampon XML
	 * @param buffer Tampon XML à traiter
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	public static NodeXML parseXMLBuffer(byte[] buffer) throws Exception {
		return parseXMLBuffer(buffer, false);
	}

	/**
	 * Traitement d'un tampon XML
	 * @param buffer Tampon XML à traiter
	 * @param removePrefix Indicateur de suppression des préfixes dans les noms de noeuds
	 * @return un NodeXML
	 * @throws Exception en cas d'erreur...
	 */
	@SkipTesting
	public static NodeXML parseXMLBuffer(byte[] buffer, boolean removePrefix) throws Exception {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.parse(new InputSource(new ByteArrayInputStream(buffer)));
		document.getDocumentElement().normalize();

		return processNodeList(null, document.getChildNodes(), removePrefix);
	}
}
