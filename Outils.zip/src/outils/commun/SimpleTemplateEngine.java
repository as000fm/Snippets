package outils.commun;

import java.util.ArrayList;
import java.util.List;

import outils.abstractions.TemplateProducer;
import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.NoParentMethodsTesting;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Implémentation de SimpleTemplateEngine de Groovy
 * @author Claude Toupin - 2018-07-10
 */
@NoParentMethodsTesting
public class SimpleTemplateEngine extends TemplateProducer {
	/** Balise de début **/
	final public static String START_TAG = "${";

	/** Balise de fin **/
	final public static String END_TAG = "}";

	/** Contenu du modèle **/
	private String template;

	/**
	 * Constructeur de base
	 */
	public SimpleTemplateEngine() {
		this(null);
	}

	/**
	 * Constructeur de base
	 * @param template Contenu du modèle
	 */
	@StrictAutomatedTests("Test: ${auto}")
	public SimpleTemplateEngine(String template) {
		super();
		setStartTag(START_TAG);
		setEndTag(END_TAG);

		this.template = template;
	}

	/**
	 * Creation d'un modèle
	 * @param template Contenu du modèle
	 * @return un SimpleTemplateEngine
	 */
	public SimpleTemplateEngine createTemplate(String template) {
		this.template = template;
		return this;
	}

	/**
	 * Substitution du modèle selon les valeurs de balises données
	 * @param binding Les valeurs des balises
	 * @return un String
	 */
	@AutomatedTests({ "new Object[] { \"test\", null, \"auto\", \"123\" }" })
	public String make(Object... binding) {
		getTagsDictionary().clear();

		if (binding != null) {
			for (int i = 0; i < binding.length; i += 2) {
				String key = OutilsBase.asString(binding[i]);
				String value = ((i + 1) < binding.length) ? OutilsBase.asString(binding[i + 1]) : null;

				if (value == null) {
					getTagsDictionary().remove(key);
				} else {
					getTagsDictionary().put(key, value);
				}
			}
		}

		List<String> t = new ArrayList<String>();
		t.add(this.template);

		try {
			return OutilsCommun.toCRLFList(produce(t), false);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Modifie la valeur d'une balise
	 * @param binding Les valeurs des balises
	 * @return un Object[]
	 */
	@AutomatedTests({ "new Object[] { \"test\", null, \"auto\", \"123\" }" })
	public Object[] setBinding(Object... binding) {
		getTagsDictionary().clear();

		if (binding != null) {
			for (int i = 0; i < binding.length; i += 2) {
				String key = OutilsBase.asString(binding[i]);
				String value = ((i + 1) < binding.length) ? OutilsBase.asString(binding[i + 1]) : null;

				if (value == null) {
					getTagsDictionary().remove(key);
				} else {
					getTagsDictionary().put(key, value);
				}
			}
		}

		binding = new Object[getTagsDictionary().keySet().size() * 2];

		int index = 0;

		for (String key : getTagsDictionary().keySet()) {
			binding[index++] = key;
			binding[index++] = getTagsDictionary().get(key);
		}

		return binding;
	}

	/**
	 * Modifie la valeur d'une balise
	 * @param tag La balise
	 * @param value La valeur
	 * @return un Object[]
	 */
	@AutomatedTests({ "test", "null", "auto", "\"123\"" })
	public Object[] setBinding(String tag, Object value) {
		if (value == null) {
			getTagsDictionary().remove(tag);
		} else {
			getTagsDictionary().put(tag, OutilsBase.asString(value));
		}

		Object[] binding = new Object[getTagsDictionary().keySet().size() * 2];

		int index = 0;

		for (String key : getTagsDictionary().keySet()) {
			binding[index++] = key;
			binding[index++] = getTagsDictionary().get(key);
		}

		return binding;
	}
}
