package outils.commun.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import outils.base.OutilsBase;
import outils.commun.load.base.LoadFromFileBase;
import outils.listes.CSVFileData;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.DefaultTestFilename;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.CSVSeparatorsTypes;
import outils.types.FilesCharsetsTypes;

/**
 * Chargement d'un fichier CSV
 * @author Claude Toupin - 2018-06-08
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "LoadCSVFormatFromFile UTF-8.csv", filename = true)
@DefaultParameterTestValue(type = long.class, name = "lineNo", value = "1")
@DefaultTestFilename("LoadCSVFormatFromFile UTF-8.csv")
// @DefaultTestValue(type = FilesCharsetsTypes.class, value = "FilesCharsetsTypes.UTF_8")
// @DefaultTestValue(type = CSVSeparatorsTypes.class, value = "CSVSeparatorsTypes.FRENCH")
public class LoadCSVFormatFromFile extends LoadFromFileBase {
	/** Données du fichier CSV **/
	final private CSVFileData csvFileData;

	/** Type de séparateur **/
	final private CSVSeparatorsTypes separator;

	/** Indicateur de supressions des guillemets **/
	final private boolean escapeQuotes;

	/** Numéro de ligne de l'entête (débute à 1) **/
	final private long lineNo;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	@TestMethodsInstance
	@AutomatedTests(value = { "LoadCSVFormatFromFile ISO-8859-1.csv,LoadCSVFormatFromFile US-ASCII.csv,LoadCSVFormatFromFile UTF-8-BOM.csv,LoadCSVFormatFromFile UTF-16BE.csv,LoadCSVFormatFromFile UTF-16LE.csv", "CSVSeparatorsTypes.FRENCH", "false", "1,2" }, filenames = { 0 }, iterate = true)
	public LoadCSVFormatFromFile(String filename, CSVSeparatorsTypes separator, boolean escapeQuotes, long lineNo) throws IOException {
		super(filename);
		this.csvFileData = new CSVFileData();
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVFormatFromFile(String filename, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator, boolean escapeQuotes, long lineNo) throws IOException {
		super(filename, charsetType);
		this.csvFileData = new CSVFileData();
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVFormatFromFile(File file, CSVSeparatorsTypes separator, boolean escapeQuotes, long lineNo) throws IOException {
		super(file);
		this.csvFileData = new CSVFileData();
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVFormatFromFile(File file, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator, boolean escapeQuotes, long lineNo) throws IOException {
		super(file, charsetType);
		this.csvFileData = new CSVFileData();
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flus de données
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVFormatFromFile(InputStream inputStream, CSVSeparatorsTypes separator, boolean escapeQuotes, long lineNo) throws IOException {
		super(inputStream);
		this.csvFileData = new CSVFileData();
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flus de données
	 * @param charsetType Type de jeu de caractères
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVFormatFromFile(InputStream inputStream, FilesCharsetsTypes charsetType, CSVSeparatorsTypes separator, boolean escapeQuotes, long lineNo) throws IOException {
		super(inputStream, charsetType);
		this.csvFileData = new CSVFileData();
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		this.lineNo = lineNo;
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.load.base.LoadFromFileBase#parseBuffer(java.io.BufferedReader)
	 */
	@Override
	protected void parseBuffer(BufferedReader bufferedReader) throws IOException {
		long no = 1;
		String line;

		while ((line = bufferedReader.readLine()) != null) {
			line = removeBomMarker(line);

			if (no == lineNo) {
				csvFileData.setHeader(OutilsBase.parseCSVRowAsArray(line, separator, escapeQuotes));
			} else {
				csvFileData.getRows().add(OutilsBase.parseCSVRowAsArray(line, separator, escapeQuotes));
			}

			no++;
		}
	}

	/**
	 * Extrait le champ csvFileData
	 * @return un CSVFileData
	 */
	public CSVFileData getCSVFileData() {
		return csvFileData;
	}

}
