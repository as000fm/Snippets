package outils.commun.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import outils.commun.load.base.LoadFromFileBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.DefaultTestFilename;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.CSVSeparatorsTypes;
import outils.types.FilesCharsetsTypes;

/**
 * Charge les entêtes CSV à partir d'un fichier
 * @author Claude Toupin - 2018-06-08
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "LoadCSVFormatFromFile UTF-8.csv", filename = true)
@DefaultParameterTestValue(type = long.class, name = "lineNo", value = "1")
@DefaultTestFilename("LoadCSVFormatFromFile UTF-8.csv")
public class LoadCSVHeaderFromFile extends LoadFromFileBase {
	/** Résultat **/
	private String[] csvHeaders;

	/** Type de séparateur **/
	private CSVSeparatorsTypes separator;

	/** Numéro de ligne de l'entête (débute à 1) **/
	private long lineNo;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	@TestMethodsInstance
	@AutomatedTests(value = { "LoadCSVFormatFromFile ISO-8859-1.csv,LoadCSVFormatFromFile US-ASCII.csv,LoadCSVFormatFromFile UTF-8-BOM.csv,LoadCSVFormatFromFile UTF-16BE.csv,LoadCSVFormatFromFile UTF-16LE.csv", "CSVSeparatorsTypes.FRENCH", "1,2" }, filenames = { 0 }, iterate = true)
	public LoadCSVHeaderFromFile(String filename, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		super(filename);
		this.csvHeaders = null;
		this.separator = separator;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVHeaderFromFile(String filename, CSVSeparatorsTypes separator, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType);
		this.csvHeaders = null;
		this.separator = separator;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVHeaderFromFile(File file, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		super(file);
		this.csvHeaders = null;
		this.separator = separator;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier CSV
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVHeaderFromFile(File file, CSVSeparatorsTypes separator, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType);
		this.csvHeaders = null;
		this.separator = separator;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flus de données
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVHeaderFromFile(InputStream inputStream, CSVSeparatorsTypes separator, long lineNo) throws IOException {
		super(inputStream);
		this.csvHeaders = null;
		this.separator = separator;
		this.lineNo = lineNo;
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flus de données
	 * @param separator Type de séparateur
	 * @param lineNo Numéro de ligne de l'entête (débute à 1)
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public LoadCSVHeaderFromFile(InputStream inputStream, CSVSeparatorsTypes separator, long lineNo, FilesCharsetsTypes charsetType) throws IOException {
		super(inputStream, charsetType);
		this.csvHeaders = null;
		this.separator = separator;
		this.lineNo = lineNo;
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.load.base.LoadFromFileBase#parseBuffer(java.io.BufferedReader)
	 */
	@Override
	protected void parseBuffer(BufferedReader bufferedReader) throws IOException {
		long no = 1;
		String line;

		while ((line = bufferedReader.readLine()) != null) {
			line = removeBomMarker(line);

			if (no == lineNo) {
				csvHeaders = line.split(separator.getSeparator());
				break;
			}

			no++;
		}
	}

	/**
	 * Extrait le champ csvHeaders
	 * @return un String[]
	 */
	public String[] getCSVHeaders() {
		return csvHeaders;
	}

	/**
	 * Modifie le champ csvHeaders
	 * @param csvHeaders La valeur du champ csvHeaders
	 */
	public void setCSVHeaders(String[] csvHeaders) {
		this.csvHeaders = csvHeaders;
	}

}
