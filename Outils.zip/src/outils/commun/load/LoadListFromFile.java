package outils.commun.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import outils.commun.load.base.LoadFromFileBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.DefaultTestFilename;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.FilesCharsetsTypes;

/**
 * Charge une liste de lignes de texte à partir d'un fichier
 * @author Claude Toupin - 2018-06-08
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "LoadFromFile UTF-8.txt", filename = true)
@DefaultTestFilename("LoadFromFile UTF-8.txt")
// @DefaultTestValue(type = FilesCharsetsTypes.class, value = "FilesCharsetsTypes.UTF_8")
public class LoadListFromFile extends LoadFromFileBase {
	/** Liste de lignes de texte **/
	private List<String> list;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur
	 */
	@TestMethodsInstance
	@AutomatedTests(value = { "LoadFromFile ISO-8859-1.txt,LoadFromFile US-ASCII.txt,LoadFromFile UTF-8-BOM.txt,LoadFromFile UTF-16BE.txt,LoadFromFile UTF-16LE.txt" }, filenames = { 0 }, iterate = true)
	public LoadListFromFile(String filename) throws IOException {
		super(filename);
		this.list = new ArrayList<String>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadListFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType);
		this.list = new ArrayList<String>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @throws IOException en cas d'erreur
	 */
	public LoadListFromFile(File file) throws IOException {
		super(file);
		this.list = new ArrayList<String>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadListFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType);
		this.list = new ArrayList<String>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @throws IOException en cas d'erreur
	 */
	public LoadListFromFile(InputStream inputStream) throws IOException {
		super(inputStream);
		this.list = new ArrayList<String>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadListFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		super(inputStream, charsetType);
		this.list = new ArrayList<String>();
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.load.base.LoadFromFileBase#parseBuffer(java.io.BufferedReader)
	 */
	@Override
	protected void parseBuffer(BufferedReader bufferedReader) throws IOException {
		String line;

		while ((line = bufferedReader.readLine()) != null) {
			line = removeBomMarker(line);

			list.add(line);
		}
	}

	/**
	 * Extrait le champ list
	 * @return un List<String>
	 */
	public List<String> getList() {
		return list;
	}

	/**
	 * Modifie le champ list
	 * @param list La valeur du champ list
	 */
	public void setList(List<String> list) {
		this.list = list;
	}

}
