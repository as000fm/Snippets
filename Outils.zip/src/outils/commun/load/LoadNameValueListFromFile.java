package outils.commun.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import outils.commun.load.base.LoadFromFileBase;
import outils.listes.NameValue;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.DefaultTestFilename;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.FilesCharsetsTypes;

/**
 * Charge une liste de lignes NameValue à partir d'un fichier
 * @author Claude Toupin - 2018-06-08
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "LoadFromFile UTF-8.txt", filename = true)
@DefaultTestFilename("LoadFromFile UTF-8.txt")
// @DefaultTestValue(type = FilesCharsetsTypes.class, value = "FilesCharsetsTypes.UTF_8")
public class LoadNameValueListFromFile extends LoadFromFileBase {
	/** Liste de lignes NameValue **/
	private List<NameValue> nameValueList;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur
	 */
	@TestMethodsInstance
	@AutomatedTests(value = { "LoadFromFile ISO-8859-1.txt,LoadFromFile US-ASCII.txt,LoadFromFile UTF-8-BOM.txt,LoadFromFile UTF-16BE.txt,LoadFromFile UTF-16LE.txt" }, filenames = { 0 }, iterate = true)
	public LoadNameValueListFromFile(String filename) throws IOException {
		super(filename);
		this.nameValueList = new ArrayList<NameValue>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadNameValueListFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType);
		this.nameValueList = new ArrayList<NameValue>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @throws IOException en cas d'erreur
	 */
	public LoadNameValueListFromFile(File file) throws IOException {
		super(file);
		this.nameValueList = new ArrayList<NameValue>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadNameValueListFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType);
		this.nameValueList = new ArrayList<NameValue>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @throws IOException en cas d'erreur
	 */
	public LoadNameValueListFromFile(InputStream inputStream) throws IOException {
		super(inputStream);
		this.nameValueList = new ArrayList<NameValue>();
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadNameValueListFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		super(inputStream, charsetType);
		this.nameValueList = new ArrayList<NameValue>();
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.load.base.LoadFromFileBase#parseBuffer(java.io.BufferedReader)
	 */
	@Override
	protected void parseBuffer(BufferedReader bufferedReader) throws IOException {
		String line;

		while ((line = bufferedReader.readLine()) != null) {
			line = removeBomMarker(line);

			nameValueList.add(new NameValue(line));
		}
	}

	/**
	 * Extrait le champ nameValueList
	 * @return un List<nameValueList>
	 */
	public List<NameValue> getNameValueList() {
		return nameValueList;
	}

	/**
	 * Modifie le champ nameValueList
	 * @param nameValueList La valeur du champ nameValueList
	 */
	public void setNameValueList(List<NameValue> nameValueList) {
		this.nameValueList = nameValueList;
	}

}
