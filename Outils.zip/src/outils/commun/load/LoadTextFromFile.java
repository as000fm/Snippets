package outils.commun.load;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import outils.commun.OutilsCommun;
import outils.commun.load.base.LoadFromFileBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.DefaultTestFilename;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.FilesCharsetsTypes;

/**
 * Charge le texte à partir d'un fichier
 * @author Claude Toupin - 2018-06-08
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "LoadFromFile UTF-8.txt", filename = true)
@DefaultTestFilename("LoadFromFile UTF-8.txt")
// @DefaultTestValue(type = FilesCharsetsTypes.class, value = "FilesCharsetsTypes.UTF_8")
public class LoadTextFromFile extends LoadFromFileBase {
	/** Le texte **/
	private String text;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur
	 */
	@TestMethodsInstance
	@AutomatedTests(value = { "LoadFromFile ISO-8859-1.txt,LoadFromFile US-ASCII.txt,LoadFromFile UTF-8-BOM.txt" }, filenames = { 0 }, iterate = true)
	public LoadTextFromFile(String filename) throws IOException {
		super(filename);
		this.text = "";
		process();
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadTextFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType);
		this.text = "";
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @throws IOException en cas d'erreur
	 */
	public LoadTextFromFile(File file) throws IOException {
		super(file);
		this.text = "";
		process();
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadTextFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType);
		this.text = "";
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @throws IOException en cas d'erreur
	 */
	public LoadTextFromFile(InputStream inputStream) throws IOException {
		super(inputStream);
		this.text = "";
		process();
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur
	 */
	public LoadTextFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		super(inputStream, charsetType);
		this.text = "";
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.load.base.LoadFromFileBase#parseBuffer(java.io.BufferedReader)
	 */
	@Override
	protected void parseBuffer(BufferedReader bufferedReader) throws IOException {
		String line;

		while ((line = bufferedReader.readLine()) != null) {
			line = removeBomMarker(line);

			text += line + OutilsCommun.LINE_SEPARATOR;
		}
	}
	
	/**
	 * Extrait le champ text
	 * @return un String
	 */
	public String getText() {
		return text;
	}

	/**
	 * Modifie le champ text
	 * @param resultat La valeur du champ text
	 */
	public void setText(String text) {
		this.text = text;
	}

}
