package outils.commun.load.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;

import outils.base.OutilsBase;
import outils.types.FilesCharsetsTypes;

/**
 * Chargement des données depuis un fichier donné
 * @author Claude Toupin - 2018-06-08
 */
public abstract class LoadFromFileBase {
	/** Flux de données **/
	private InputStream inputStream;

	/** Type de jeu de caractères **/
	private FilesCharsetsTypes charsetType;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	protected LoadFromFileBase(String filename) throws IOException {
		this(filename, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	protected LoadFromFileBase(File file) throws IOException {
		this(file, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	protected LoadFromFileBase(String filename, FilesCharsetsTypes charsetType) throws IOException {
		if (FilesCharsetsTypes.AUTO_DETECTION.equals(charsetType)) {
			this.charsetType = autoDetection(filename);
		} else {
			this.charsetType = charsetType;
		}

		this.inputStream = new FileInputStream(new File(filename));
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	protected LoadFromFileBase(File file, FilesCharsetsTypes charsetType) throws IOException {
		if (FilesCharsetsTypes.AUTO_DETECTION.equals(charsetType)) {
			this.charsetType = autoDetection(file.getAbsolutePath());
		} else {
			this.charsetType = charsetType;
		}

		this.inputStream = new FileInputStream(file);
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected LoadFromFileBase(InputStream inputStream) throws UnsupportedEncodingException {
		this(inputStream, FilesCharsetsTypes.ISO_8859_1);
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected LoadFromFileBase(InputStream inputStream, FilesCharsetsTypes charsetType) throws UnsupportedEncodingException {
		if (FilesCharsetsTypes.AUTO_DETECTION.equals(charsetType)) {
			throw new UnsupportedEncodingException(charsetType.name());
		}

		this.inputStream = inputStream;
		this.charsetType = charsetType;
	}

	/**
	 * Traitement du tampon (buffer)
	 * @param bufferedReader Le tampon donné
	 * @throws IOException en cas d'erreur...
	 */
	protected abstract void parseBuffer(BufferedReader bufferedReader) throws IOException;

	/**
	 * Retire les caractères BOM d'une ligne de données
	 * @param line La ligne de données
	 * @return la ligne de donnés sans caractère BOM
	 */
	protected String removeBomMarker(String line) {
		if (charsetType.isBomMarker()) {
			if (!OutilsBase.isEmpty(line)) {
				new String(removeBomMarker(line.getBytes()));
			}
		}

		return line;
	}

	/**
	 * Retire les caractères BOM d'une ligne de données
	 * @param buf La ligne de données
	 * @return la ligne de donnés sans caractère BOM
	 */
	protected byte[] removeBomMarker(byte[] buf) {
		if (charsetType.isBomMarker()) {
			if (buf != null) {
				boolean found = true;
				int length = charsetType.getBom().length;

				for (int i = 0; i < length; i++) {
					if (i >= buf.length) {
						found = false;
						break;
					} else if (charsetType.getBom()[i] != buf[i]) {
						found = false;
						break;
					}
				}

				if (found) {
					byte[] converted = new byte[buf.length - length];

					for (int i = length; i < buf.length; i++) {
						converted[i - length] = buf[i];
					}

					return converted;
				}
			}
		}

		return buf;
	}

	/**
	 * Détermine l'encodage selon les caractères accentués des diverses méthodes
	 * @param buffer Tampon de charactères
	 * @param length Nombre caractères dans le tampon
	 * @return le type trouvé (null si pas trouvé)
	 */
	protected FilesCharsetsTypes extractFilesCharsetsTypes(byte[] buffer) {
		for (int pos = 0; pos < buffer.length; pos++) {
			int count = buffer.length - pos;

			// UTF-8 - https://en.wikipedia.org/wiki/UTF-8#Encoding

			if (count > 4) {
				// 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
				if (((buffer[pos] & 0xF1) == 0xF0) && ((buffer[pos + 1] & 0xC0) == 0x80) && ((buffer[pos + 2] & 0xC0) == 0x80) && ((buffer[pos + 3] & 0xC0) == 0x80)) {
					return FilesCharsetsTypes.UTF_8;
				}
			}

			if (count > 3) {
				// 1110xxxx 10xxxxxx 10xxxxxx 10xxxxxx
				if (((buffer[pos] & 0xF0) == 0xE0) && ((buffer[pos + 1] & 0xC0) == 0x80) && ((buffer[pos + 2] & 0xC0) == 0x80)) {
					return FilesCharsetsTypes.UTF_8;
				}
			}

			if (count >= 2) {
				// 110xxxxx 10xxxxxx 10xxxxxx 10xxxxxx
				if (((buffer[pos] & 0xE0) == 0xC0) && ((buffer[pos + 1] & 0xC0) == 0x80)) {
					return FilesCharsetsTypes.UTF_8;
				}
			}

			// ISO 8859-1 - https://en.wikipedia.org/wiki/ISO/IEC_8859-1#Code_page_layout

			if ((buffer[pos] >= (byte) 0xC0) && (buffer[pos] <= (byte) 0xFF)) {
				return FilesCharsetsTypes.ISO_8859_1;
			}
		}

		return null;
	}

	/**
	 * Détermine l'encodage selon les caractères accentués des diverses méthodes
	 * @param filename Nom du fichier
	 * @return le type de l'encodage
	 * @throws IOException en cas d'erreur...
	 */
	protected FilesCharsetsTypes autoDetection(String filename) throws IOException {
		File file = new File(filename);

		byte[] content = Files.readAllBytes(file.toPath());

		// Détermine par marqueurs BOM
		FilesCharsetsTypes type = FilesCharsetsTypes.getFilesCharsetsTypes(content);

		if (type != null) {
			return type;
		}

		// Détermine par caractères accentués
		type = extractFilesCharsetsTypes(content);

		if (type != null) {
			return type;
		}

		// Détermine par caractères binaires
		for (int i = 0; i < content.length; i++) {
			if (content[i] > (byte) 0x7F) {
				return FilesCharsetsTypes.ISO_8859_1;
			}
		}

		return FilesCharsetsTypes.US_ASCII;
	}

	/**
	 * Traitement du fichier
	 * @throws IOException en cas d'erreur...
	 */
	protected void process() throws IOException {
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream, charsetType.getCharsetName());

		try {
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

			try {
				parseBuffer(bufferedReader);
			} finally {
				bufferedReader.close();
			}
		} finally {
			inputStreamReader.close();
		}
	}

	/**
	 * Extrait le champ charsetType
	 * @return un FilesCharsetsTypes
	 */
	public FilesCharsetsTypes getCharsetType() {
		return charsetType;
	}
}
