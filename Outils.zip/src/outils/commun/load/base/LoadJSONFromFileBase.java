package outils.commun.load.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import outils.types.FilesCharsetsTypes;

/**
 * Chargement d'un fichier texte contenant un tableau d'objets json ou un simple objet json
 * @author Claude Toupin - 6 sept. 2021
 */
public abstract class LoadJSONFromFileBase extends LoadFromFileBase {
	/** Indicateur d'un élément json faisant parti d'un tableau d'objets json **/
	private boolean jsonArray;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	public LoadJSONFromFileBase(String filename) throws IOException {
		super(filename);
		this.jsonArray = false;
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	public LoadJSONFromFileBase(File file) throws IOException {
		super(file);
		this.jsonArray = false;
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public LoadJSONFromFileBase(String filename, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType);
		this.jsonArray = false;
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public LoadJSONFromFileBase(File file, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType);
		this.jsonArray = false;
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	public LoadJSONFromFileBase(InputStream inputStream) throws UnsupportedEncodingException {
		super(inputStream);
		this.jsonArray = false;
	}

	/**
	 * Constructeur de base
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	public LoadJSONFromFileBase(InputStream inputStream, FilesCharsetsTypes charsetType) throws UnsupportedEncodingException {
		super(inputStream, charsetType);
		this.jsonArray = false;
	}

	/**
	 * Traitement d'un élément json
	 * @param index Index de l'élément json du tableau d'objets json (s'il y a lieu...)
	 * @param element L'élément json à traiter
	 * @return vrai si on doit poursuivre avec le prochain élément
	 */
	abstract protected boolean processJsonElement(int index, JsonElement element);

	/**
	 * Traitement du tampon (buffer)
	 * @param bufferedReader Le tampon donné
	 * @throws IOException en cas d'erreur...
	 */
	@Override
	protected void parseBuffer(BufferedReader bufferedReader) throws IOException {
		this.jsonArray = false;

		boolean array = false;
		boolean quote = false;
		boolean escape = false;

		boolean next = true;

		int escapeU = 0;
		int arrayCount = 0;
		int objectCount = 0;

		int index = 0;

		int c;

		StringBuilder sb = new StringBuilder();

		StringBuilder simpleJson = new StringBuilder();

		while (next && ((c = bufferedReader.read()) != -1)) {
			if (!array && (objectCount == 0)) {
				if (c == '[') {
					array = true;
					simpleJson = null;
					this.jsonArray = true;
				} else if (c == '{') {
					objectCount++;
					simpleJson = null;
					sb.appendCodePoint(c);
				} else {
					if (simpleJson != null) {
						simpleJson.appendCodePoint(c);
					}
				}
			} else {
				if (quote) {
					if (escape) {
						if (escapeU > 0) {
							escapeU--;
						} else {
							escapeU = (c == 'u') ? 4 : 0;
						}

						escape = escapeU > 0;
						sb.appendCodePoint(c);
					} else {
						switch (c) {
							case '"':
								quote = false;
								escape = false;
								escapeU = 0;
								sb.appendCodePoint(c);
								break;
							case '\\':
								escape = true;
								escapeU = 0;
								sb.appendCodePoint(c);
								break;
							default:
								sb.appendCodePoint(c);
								break;
						}
					}
				} else {
					switch (c) {
						case '{':
							objectCount++;
							sb.appendCodePoint(c);
							break;
						case '}':
							objectCount--;
							sb.appendCodePoint(c);

							if (objectCount == 0) {
								next = processJsonElement(index, JsonParser.parseString(sb.toString()));
								sb = new StringBuilder();
								index++;
							}
							break;
						case '[':
							arrayCount++;
							sb.appendCodePoint(c);
							break;
						case ']':
							arrayCount--;

							if (arrayCount == -1) {
								array = false;
							} else {
								sb.appendCodePoint(c);
							}
							break;
						case '"':
							quote = true;
							escape = false;
							escapeU = 0;
							sb.appendCodePoint(c);
							break;
						default:
							if (objectCount > 0) {
								sb.appendCodePoint(c);
							}
							break;
					}
				}
			}
		}

		if (next) {
			if (sb.length() > 0) {
				processJsonElement(index, JsonParser.parseString(sb.toString()));
			} else if (simpleJson != null) {
				processJsonElement(index, JsonParser.parseString(simpleJson.toString()));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.load.base.LoadFromFileBase#process()
	 */
	@Override
	public void process() throws IOException {
		super.process();
	}

	/**
	 * Extrait le champ jsonArray
	 * @return un boolean
	 */
	public boolean isJsonArray() {
		return jsonArray;
	}
}
