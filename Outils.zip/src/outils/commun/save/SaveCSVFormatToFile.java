package outils.commun.save;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.commun.save.base.SaveToFileBase;
import outils.listes.CSVFileData;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.CSVSeparatorsTypes;
import outils.types.FilesCharsetsTypes;

/**
 * Sauvegarde d'un fichier csv
 * @author Claude Toupin - 8 sept. 2021
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "SaveCSVFormatToFile.csv", filename = true)
public class SaveCSVFormatToFile extends SaveToFileBase {
	/** Données du fichier CSV **/
	final private CSVFileData csvFileData;

	/** Type de séparateur **/
	final private CSVSeparatorsTypes separator;

	/** Indicateur de supressions des guillemets **/
	final private boolean escapeQuotes;

	/**
	 * Constructeur de base
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param filename Nom du fichier CSV
	 * @throws IOException en cas d'erreur...
	 */
	@TestMethodsInstance
	@AutomatedTests(value = { "new CSVFileData();new CSVFileData(new String[] {\"1\"}, new java.util.ArrayList<String[]>())", "CSVSeparatorsTypes.FRENCH", "false", "SaveCSVFormatToFile.csv" }, filenames = { 3 }, separator = ';', iterate = true)
	public SaveCSVFormatToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, String filename) throws IOException {
		super(filename, false);
		this.csvFileData = csvFileData;
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		process();
	}

	/**
	 * Constructeur de base
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param filename Nom du fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public SaveCSVFormatToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, String filename, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType, false);
		this.csvFileData = csvFileData;
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		process();
	}

	/**
	 * Constructeur de base
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param file Fichier CSV
	 * @throws IOException en cas d'erreur...
	 */
	public SaveCSVFormatToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, File file) throws IOException {
		super(file, false);
		this.csvFileData = csvFileData;
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		process();
	}

	/**
	 * Constructeur de base
	 * @param csvFileData Données du fichier CSV
	 * @param separator Type de séparateur
	 * @param escapeQuotes Indicateur de supressions des guillemets
	 * @param file Fichier CSV
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public SaveCSVFormatToFile(CSVFileData csvFileData, CSVSeparatorsTypes separator, boolean escapeQuotes, File file, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType, false);
		this.csvFileData = csvFileData;
		this.separator = separator;
		this.escapeQuotes = escapeQuotes;
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.save.base.SaveToFileBase#writeBuffer(java.io.OutputStreamWriter)
	 */
	@Override
	protected void writeBuffer(OutputStreamWriter outputStreamWriter) throws IOException {
		if (csvFileData != null) {
			if (!OutilsBase.isEmpty(csvFileData.getHeader()))
				outputStreamWriter.write(OutilsBase.formatCSVRow(csvFileData.getHeader(), separator, escapeQuotes));
			outputStreamWriter.write(OutilsCommun.LINE_SEPARATOR);

			if (!OutilsBase.isEmpty(csvFileData.getRows())) {
				for (String[] row : csvFileData.getRows()) {
					outputStreamWriter.write(OutilsBase.formatCSVRow(row, separator, escapeQuotes));
					outputStreamWriter.write(OutilsCommun.LINE_SEPARATOR);
				}
			}
		}
	}

	/**
	 * Extrait le champ csvFileData
	 * @return un CSVFileData
	 */
	public CSVFileData getCsvFileData() {
		return csvFileData;
	}

	/**
	 * Extrait le champ separator
	 * @return un CSVSeparatorsTypes
	 */
	public CSVSeparatorsTypes getSeparator() {
		return separator;
	}

	/**
	 * Extrait le champ escapeQuotes
	 * @return un boolean
	 */
	public boolean isEscapeQuotes() {
		return escapeQuotes;
	}

}
