package outils.commun.save;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

import outils.commun.OutilsCommun;
import outils.commun.save.base.SaveToFileBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.FilesCharsetsTypes;

/**
 * Sauvegarde (ou ajout) d'une liste a un fichier
 * @author Claude Toupin - 2018-06-08
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "SaveListToFile.txt", filename = true)
public class SaveListToFile extends SaveToFileBase {
	/** Liste des données **/
	private List<?> list;

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@TestMethodsInstance
	@AutomatedTests(value = { "1,,2,3", "SaveListToFile.txt" }, filenames = { 1 })
	public SaveListToFile(List<?> list, String filename) throws IOException {
		super(filename);
		this.list = list;
		process();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public SaveListToFile(List<?> list, String filename, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType);
		this.list = list;
		process();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveListToFile(List<?> list, String filename, boolean append) throws IOException {
		super(filename, append);
		this.list = list;
		process();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveListToFile(List<?> list, String filename, FilesCharsetsTypes charsetType, boolean append) throws IOException {
		super(filename, charsetType, append);
		this.list = list;
		process();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveListToFile(List<?> list, File file) throws IOException {
		super(file);
		this.list = list;
		process();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public SaveListToFile(List<?> list, File file, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType);
		this.list = list;
		process();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param file Fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveListToFile(List<?> list, File file, boolean append) throws IOException {
		super(file, append);
		this.list = list;
		process();
	}

	/**
	 * Constructeur de base
	 * @param list Liste des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveListToFile(List<?> list, File file, FilesCharsetsTypes charsetType, boolean append) throws IOException {
		super(file, charsetType, append);
		this.list = list;
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.save.base.SaveToFileBase#writeBuffer(java.io.OutputStreamWriter)
	 */
	@Override
	protected void writeBuffer(OutputStreamWriter outputStreamWriter) throws IOException {
		if (list != null) {
			for (Object obj : list) {
				if (obj != null) {
					outputStreamWriter.write(obj.toString());
					outputStreamWriter.write(OutilsCommun.LINE_SEPARATOR);
				}
			}
		}
	}

}
