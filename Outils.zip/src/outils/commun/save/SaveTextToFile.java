package outils.commun.save;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;

import outils.commun.save.base.SaveToFileBase;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.FilesCharsetsTypes;

/**
 * Sauvegarde (ou ajout) d'un texte a un fichier
 * @author Claude Toupin - 2018-06-08
 */
@DefaultParameterTestValue(type = String.class, name = "filename", value = "SaveTextToFile.txt", filename = true)
public class SaveTextToFile extends SaveToFileBase {
	/** Texte des données **/
	private String text;

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @throws IOException en cas d'erreur...
	 */
	@TestMethodsInstance
	public SaveTextToFile(String text, String filename) throws IOException {
		super(filename);
		this.text = text;
		process();
	}

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveTextToFile(String text, String filename, boolean append) throws IOException {
		super(filename, append);
		this.text = text;
		process();
	}

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public SaveTextToFile(String text, String filename, FilesCharsetsTypes charsetType) throws IOException {
		super(filename, charsetType);
		this.text = text;
		process();
	}

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveTextToFile(String text, String filename, FilesCharsetsTypes charsetType, boolean append) throws IOException {
		super(filename, charsetType, append);
		this.text = text;
		process();
	}

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param file Fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveTextToFile(String text, File file) throws IOException {
		super(file);
		this.text = text;
		process();
	}

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param file Fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveTextToFile(String text, File file, boolean append) throws IOException {
		super(file, append);
		this.text = text;
		process();
	}

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws IOException en cas d'erreur...
	 */
	public SaveTextToFile(String text, File file, FilesCharsetsTypes charsetType) throws IOException {
		super(file, charsetType);
		this.text = text;
		process();
	}

	/**
	 * Constructeur de base
	 * @param text Texte des données
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws IOException en cas d'erreur...
	 */
	public SaveTextToFile(String text, File file, FilesCharsetsTypes charsetType, boolean append) throws IOException {
		super(file, charsetType, append);
		this.text = text;
		process();
	}

	/*
	 * (non-Javadoc)
	 * @see outils.commun.save.base.SaveToFileBase#writeBuffer(java.io.OutputStreamWriter)
	 */
	@Override
	protected void writeBuffer(OutputStreamWriter outputStreamWriter) throws IOException {
		if (text != null) {
			outputStreamWriter.write(text);
		}
	}

}
