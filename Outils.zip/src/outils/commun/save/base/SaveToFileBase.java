package outils.commun.save.base;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

import outils.base.OutilsBase;
import outils.types.FilesCharsetsTypes;

/**
 * Sauvegarde (ou ajout) de données dans un fichier
 * @author Claude Toupin - 2018-06-08
 */
public abstract class SaveToFileBase {
	/** Fichier **/
	private File file;

	/** Type de jeu de caractères **/
	private FilesCharsetsTypes charsetType;

	/** Indicateur d'ajout au fichier **/
	private boolean append;

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(String filename) {
		this(new File(filename), FilesCharsetsTypes.AUTO_DETECTION, false);
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(File file) {
		this(file, FilesCharsetsTypes.AUTO_DETECTION, false);
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param append Indicateur d'ajout au fichier
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(String filename, boolean append) {
		this(new File(filename), FilesCharsetsTypes.AUTO_DETECTION, append);
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(File file, boolean append) {
		this(file, FilesCharsetsTypes.AUTO_DETECTION, append);
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(String filename, FilesCharsetsTypes charsetType) {
		this(new File(filename), charsetType, false);
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(File file, FilesCharsetsTypes charsetType) {
		this(file, charsetType, false);
	}

	/**
	 * Constructeur de base
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(String filename, FilesCharsetsTypes charsetType, boolean append) {
		this(new File(filename), charsetType, append);
	}

	/**
	 * Constructeur de base
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @param append Indicateur d'ajout au fichier
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected SaveToFileBase(File file, FilesCharsetsTypes charsetType, boolean append) {
		if (FilesCharsetsTypes.AUTO_DETECTION.equals(charsetType)) {
			charsetType = OutilsBase.areEquals(Charset.defaultCharset().name(), "UTF-8") ? FilesCharsetsTypes.UTF_8 : FilesCharsetsTypes.ISO_8859_1;
		}

		this.file = file;
		this.charsetType = charsetType;
		this.append = append;
	}

	/**
	 * Écriture des données dans la sortie du fichier
	 * @param outputStreamWriter La sortie du fichier
	 * @throws IOException en cas d'erreur...
	 */
	protected abstract void writeBuffer(OutputStreamWriter outputStreamWriter) throws IOException;

	/**
	 * Traitement du fichier
	 * @throws IOException en cas d'erreur...
	 */
	protected void process() throws IOException {
		OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(file, append), charsetType.getCharsetName());

		try {
			if (charsetType.isAddBomMarkerToFile() && !append) {
				// Java fait la conversion magiquement...
				outputStreamWriter.write("\uFEFF");
			}

			writeBuffer(outputStreamWriter);
		} finally {
			outputStreamWriter.close();
		}
	}
}
