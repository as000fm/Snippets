package outils.emails;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.listes.NameValue;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.types.CSVSeparatorsTypes;

/**
 * Classe des méthodes utilitaires de courriels de type final public static
 * @author Claude Toupin - 7 juin 2019
 */
@CoverageTestsCases(OutilsEmails.CoverageTestsCases.class)
public class OutilsEmails {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			List<String> domains = OutilsBase.asList("work.com", "home.org");

			Map<String, List<NameValue>> aliases = new HashMap<String, List<NameValue>>();
			aliases.put("ME", OutilsBase.asList(new NameValue("me@work.com", "myself")));
			aliases.put("fun", OutilsBase.asList(new NameValue("fun@home.org", "fun")));

			OutilsEmails.asEmailsRecipientsList("me", domains, aliases);

			OutilsEmails.asEmailsRecipientsList("mE", domains, aliases);

			OutilsEmails.asEmailsRecipientsList("ME", domains, aliases);

			OutilsEmails.asEmailsRecipientsList("me,FUN", domains, aliases);

			try {
				OutilsEmails.asEmailsRecipientsList("me,ME,mE", domains, aliases);
			} catch (Exception e) {
				// OK
			}
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/**
	 * Extraction de la liste de destinataires pour les courriels
	 * @param text Le texte à analyser
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = { "\"a,,=a\"" }, process = false)
	final public static List<NameValue> asEmailsRecipientsList(String text) throws Exception {
		return asEmailsRecipientsList(text, null, null);
	}

	/**
	 * Extraction de la liste de destinataires pour les courriels
	 * @param text Le texte à analyser
	 * @param domains Liste des domaines de l'adresse de courriel (ex: desjardins.com)
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests(value = { "me@work.com,me@work.com=myself,me@home.lan,123", ",work.com,home.org" }, iterate = true)
	final public static List<NameValue> asEmailsRecipientsList(String text, List<String> domains) throws Exception {
		return asEmailsRecipientsList(text, domains, null);
	}

	/**
	 * Extraction de la liste de destinataires pour les courriels
	 * @param text Le texte à analyser
	 * @param domains Liste des domaines de l'adresse de courriel (ex: desjardins.com)
	 * @param aliases Dictionnaire des alias de destinaires des courriels
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<NameValue> asEmailsRecipientsList(String text, List<String> domains, Map<String, List<NameValue>> aliases) throws Exception {
		List<NameValue> recipients = new ArrayList<NameValue>();

		if (!OutilsBase.isEmpty(text)) {
			text = text.trim();

			List<String> items = OutilsBase.parseCSVRowAsList(text, CSVSeparatorsTypes.ENGLISH, true);

			for (String item : items) {
				NameValue pair = new NameValue(item);

				if (OutilsBase.isEmpty(pair.getName()) && OutilsBase.isEmpty(pair.getValue())) {
					throw new Exception("Le destinataire \"" + item + "\" est invalide. Le format est : \"courriel\" ou \"courriel=nom\".");
				}

				List<NameValue> emails = OutilsBase.asList(pair);

				if (aliases != null) {
					if (aliases.containsKey(pair.getName())) {
						emails = aliases.get(pair.getName());
					} else if (aliases.containsKey(pair.getName().toLowerCase())) {
						emails = aliases.get(pair.getName().toLowerCase());
					} else if (aliases.containsKey(pair.getName().toUpperCase())) {
						emails = aliases.get(pair.getName().toUpperCase());
					}
				}

				for (NameValue email : emails) {
					try {
						new InternetAddress(email.getName()).validate();
					} catch (AddressException e) {
						throw new Exception("L'adresse de courriel \"" + email.getName() + "\" pour le destinataire \"" + email.getValue() + "\" est invalide. Le format est : \"courriel\" ou \"courriel=nom\". L'erreur est: " + e.getLocalizedMessage());
					}

					if (!validateEmailAddressDomain(email.getName(), domains)) {
						throw new Exception("L'adresse de courriel \"" + email.getName() + "\" pour le destinataire \"" + email.getValue() + "\" est invalide. L'adresse de courriel doit être dans un des domaines suivants : " + OutilsCommun.toList(domains, ", "));
					}

					if (OutilsBase.isEmpty(email.getValue())) {
						email.setValue(OutilsBase.getEmailPersonalName(email.getName()));
					}

					if (!recipients.contains(email)) {
						recipients.add(email);
					} else {
						throw new Exception("Doublon de l'adresse de courriel \"" + email.getName() + "\" pour le destinataire \"" + email.getValue() + "\".");
					}
				}
			}
		}

		return recipients;
	}

	/**
	 * Validation du domaine d'une adresse de courriel
	 * @param emailAddress Adresse de courriel à valider
	 * @param domains Liste des domaines de l'adresse de courriel (ex: desjardins.com)
	 * @return vrai si valide
	 */
	final public static boolean validateEmailAddressDomain(String emailAddress, List<String> domains) {
		if (!OutilsBase.isEmpty(emailAddress)) {
			if (domains != null) {
				if (!domains.isEmpty()) {
					boolean valid = false;

					for (String domain : domains) {
						if (emailAddress.toLowerCase().endsWith("@" + domain.toLowerCase())) {
							valid = true;
							break;
						}
					}

					return valid;
				}
			}
		}

		return true;
	}

	/**
	 * Extrait le texte d'une liste de destinataires donnée pour les courriels
	 * @param recipients La liste de destinataires donnée
	 * @return un String
	 */
	final public static String asEmailsRecipientsText(List<NameValue> recipients) {
		if (recipients != null) {
			if (!recipients.isEmpty()) {
				List<String> items = new ArrayList<String>();

				for (NameValue recipient : recipients) {
					if (OutilsBase.isEmpty(recipient.getValue())) {
						items.add(recipient.getName());
					} else {
						items.add(recipient.toString());
					}
				}

				return OutilsBase.formatCSVRow(items, CSVSeparatorsTypes.ENGLISH, true);
			}
		}

		return "";
	}
}
