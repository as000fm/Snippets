package outils.emails;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.ImageHtmlEmail;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.resolver.DataSourceUrlResolver;

import emails.templates.TestHTMLTemplate;
import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.emails.severs.SMTPEmailServer;
import outils.emails.severs.base.EmailServerBase;
import outils.listes.NameValue;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Classe pour l'envoi d'un courriel avec attachements
 * @author Claude Toupin - 2019-02-01
 */
@CoverageTestsCases(SendEmail.CoverageTestsCases.class)
public class SendEmail {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			EmailServerBase emailServer = new SMTPEmailServer();

			SendEmail sendEmail = new SendEmail(emailServer, false, "admin@localhost", "Adminitrateur");
			sendEmail.setSubject("Simple courriel avec attachement");
			sendEmail.setMessage("Ceci est un test !!!");
			sendEmail.addAttachment(OutilsCommun.getFullname(OutilsCommun.getCurrentDirectory(), "tests", SendEmail.class.getName().replace('.', File.separatorChar) + OutilsCommun.JAVA_EXTENSION), SendEmail.class.getSimpleName() + OutilsCommun.JAVA_EXTENSION);
			sendEmail.addRecipientTo("claude.toupin@desjardins.com", "Claude Toupin");
			sendEmail.setDebug(true);

			try {
				sendEmail.send();
			} catch (EmailException e) {
				// OK
			}

			TestHTMLTemplate testHTMLTemplate = new TestHTMLTemplate();

			sendEmail.setHtml(true);
			sendEmail.setSubject("Courriel en html avec attachement");
			sendEmail.setMessage(testHTMLTemplate.produce());
			sendEmail.setDebug(false);

			try {
				sendEmail.send();
			} catch (EmailException e) {
				// OK
			}
			
			sendEmail.getErrorMessage("aaa", new NameValue("claude.toupin@desjadins.com", "Claude Toupin"), null);
			sendEmail.getErrorMessage("aaa", new NameValue("claude.toupin@desjadins.com", "Claude Toupin"), new AddressException("Erreur"));
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/** Serveur de courriels **/
	private EmailServerBase emailServer;

	/** Indicateur de courriel en format html **/
	private boolean html;

	/** Adresse de courriel d'origine (De) **/
	private String originEmailAddress;

	/** Nom d'origine (De) de l'adresse de courriel **/
	private String originUserName;

	/** Sujet du courriel **/
	private String subject;

	/** Contenu du message **/
	private String message;

	/** Liste des paires de destinataires de base (A) sous forme courriel=nom d'usager **/
	final private List<NameValue> recipientsToList;

	/** Liste des paires de destinataires en CC (copie conforme) sous forme courriel=nom d'usager **/
	final private List<NameValue> recipientsCcList;

	/** Liste des paires de destinataires en CCI (copie conforme invisible) sous forme courriel=nom d'usager **/
	final private List<NameValue> recipientsBccList;

	/** Liste des attachements sous forme fichier=nom fichier **/
	final private List<NameValue> attachmentsList;

	/** Indicateur d'utiliser seulement l'adresse de courriel des destinataires **/
	private boolean useRecipientsEmailAddressOnly;

	/** Indicateur de débogage **/
	private boolean debug;

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 */
	@TestMethodsInstance
	public SendEmail(EmailServerBase emailServer, String originEmailAddress, String originUserName) {
		this(emailServer, false, originEmailAddress, originUserName, false);
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param html Indicateur de courriel en format html
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 */
	public SendEmail(EmailServerBase emailServer, boolean html, String originEmailAddress, String originUserName) {
		this(emailServer, html, originEmailAddress, originUserName, false);
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param useRecipientsEmailAddressOnly Indicateur d'utiliser seulement l'adresse de courriel des destinataires
	 */
	public SendEmail(EmailServerBase emailServer, String originEmailAddress, String originUserName, boolean useRecipientsEmailAddressOnly) {
		this(emailServer, false, originEmailAddress, originUserName, useRecipientsEmailAddressOnly);
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param html Indicateur de courriel en format html
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param useRecipientsEmailAddressOnly Indicateur d'utiliser seulement l'adresse de courriel des destinataires
	 */
	public SendEmail(EmailServerBase emailServer, boolean html, String originEmailAddress, String originUserName, boolean useRecipientsEmailAddressOnly) {
		this.emailServer = emailServer;
		this.html = html;
		this.originEmailAddress = originEmailAddress;
		this.originUserName = originUserName;
		this.subject = null;
		this.message = null;
		this.recipientsToList = new ArrayList<NameValue>();
		this.recipientsCcList = new ArrayList<NameValue>();
		this.recipientsBccList = new ArrayList<NameValue>();
		this.attachmentsList = new ArrayList<NameValue>();
		this.useRecipientsEmailAddressOnly = useRecipientsEmailAddressOnly;
		this.debug = false;
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 */
	public SendEmail(EmailServerBase emailServer, String originEmailAddress, String originUserName, String subject) {
		this(emailServer, false, originEmailAddress, originUserName, subject, false);
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param html Indicateur de courriel en format html
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 */
	public SendEmail(EmailServerBase emailServer, boolean html, String originEmailAddress, String originUserName, String subject) {
		this(emailServer, html, originEmailAddress, originUserName, subject, false);
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 * @param useRecipientsEmailAddressOnly Indicateur d'utiliser seulement l'adresse de courriel des destinataires
	 */
	public SendEmail(EmailServerBase emailServer, String originEmailAddress, String originUserName, String subject, boolean useRecipientsEmailAddressOnly) {
		this(emailServer, false, originEmailAddress, originUserName, useRecipientsEmailAddressOnly);
		this.subject = subject;
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param html Indicateur de courriel en format html
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 * @param useRecipientsEmailAddressOnly Indicateur d'utiliser seulement l'adresse de courriel des destinataires
	 */
	public SendEmail(EmailServerBase emailServer, boolean html, String originEmailAddress, String originUserName, String subject, boolean useRecipientsEmailAddressOnly) {
		this(emailServer, html, originEmailAddress, originUserName, useRecipientsEmailAddressOnly);
		this.subject = subject;
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 * @param message Contenu du message
	 */
	public SendEmail(EmailServerBase emailServer, String originEmailAddress, String originUserName, String subject, String message) {
		this(emailServer, false, originEmailAddress, originUserName, subject, message, false);
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param html Indicateur de courriel en format html
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 * @param message Contenu du message
	 */
	public SendEmail(EmailServerBase emailServer, boolean html, String originEmailAddress, String originUserName, String subject, String message) {
		this(emailServer, html, originEmailAddress, originUserName, subject, message, false);
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 * @param message Contenu du message
	 * @param useRecipientsEmailAddressOnly Indicateur d'utiliser seulement l'adresse de courriel des destinataires
	 */
	public SendEmail(EmailServerBase emailServer, String originEmailAddress, String originUserName, String subject, String message, boolean useRecipientsEmailAddressOnly) {
		this(emailServer, false, originEmailAddress, originUserName, subject, useRecipientsEmailAddressOnly);
		this.message = message;
	}

	/**
	 * Constructeur de base
	 * @param emailServer Serveur de courriels
	 * @param html Indicateur de courriel en format html
	 * @param originEmailAddress Adresse de courriel d'origine (De)
	 * @param originUserName Nom d'origine (De) de l'adresse de courriel
	 * @param subject Sujet du courriel
	 * @param message Contenu du message
	 * @param useRecipientsEmailAddressOnly Indicateur d'utiliser seulement l'adresse de courriel des destinataires
	 */
	public SendEmail(EmailServerBase emailServer, boolean html, String originEmailAddress, String originUserName, String subject, String message, boolean useRecipientsEmailAddressOnly) {
		this(emailServer, html, originEmailAddress, originUserName, subject, useRecipientsEmailAddressOnly);
		this.message = message;
	}

	/**
	 * Extrait le courriel à envoyer
	 * @return un Email
	 * @throws EmailException en cas d'erreur...
	 */
	protected Email getEmail() throws EmailException {
		Email email = emailServer.setEmail(html ? new ImageHtmlEmail() : new MultiPartEmail());
		email.setDebug(isDebug());
		email.setCharset("UTF-8");
		email.setSubject(getSubject());
		email.setMsg(getMessage());

		addOriginFrom(email);
		addRecipientTo(email);
		addRecipientCc(email);
		addRecipientBcc(email);

		addAttachments((MultiPartEmail) email);

		if (html) {
			((ImageHtmlEmail) email).setDataSourceResolver(new DataSourceUrlResolver(null));
		}

		return email;
	}

	/**
	 * Validation d'une adresse de courriel
	 * @param address Adresse de courriel à valider
	 * @throws AddressException en cas d'erreur...
	 */
	protected void emailAddressValidation(String address) throws AddressException {
		new InternetAddress(address).validate();
	}

	/**
	 * Extrait le message d'erreur
	 * @param destination La destination (i.e. A CC ou CCI)
	 * @param recipient La paire du destinataire
	 * @param exception L'erreur (i.e. exception)
	 * @return le message d'erreur
	 */
	protected String getErrorMessage(String destination, NameValue recipient, AddressException exception) {
		if (exception == null) {
			return "Pas d'adresse de courriel du destinataire " + destination + " pour la paire \"" + recipient + "\". Le format est : \"courriel\" ou \"courriel=nom\".";
		}

		return "L'adresse de courriel \"" + OutilsBase.asString(recipient.getName()) + "\" pour le destinataire " + destination + " \"" + OutilsBase.asString(recipient.getValue()) + "\" est invalide. Le format est : \"courriel\" ou \"courriel=nom\". L'erreur est: " + exception.getLocalizedMessage();
	}

	/**
	 * Ajout de l'adresse et du nom d'usager d'origine (De) du courriel
	 * @param email Le courriel à renseigner
	 * @throws EmailException en cas d'erreur...
	 */
	protected void addOriginFrom(Email email) throws EmailException {
		if (OutilsBase.isEmpty(originEmailAddress)) {
			throw new EmailException("Pas d'adresse de courriel d'origine (De)");
		}

		try {
			emailAddressValidation(originEmailAddress);
		} catch (AddressException e) {
			throw new EmailException("L'adresse de courriel d'origine (De) est invalide : " + e.getLocalizedMessage());
		}

		if (OutilsBase.isEmpty(originUserName)) {
			email.setFrom(originEmailAddress);
		} else {
			email.setFrom(originEmailAddress, originUserName);
		}
	}

	/**
	 * Ajout des destinataires de base (A) sous forme courriel=nom d'usager
	 * @param email Le courriel à renseigner
	 * @throws EmailException en cas d'erreur...
	 */
	protected void addRecipientTo(Email email) throws EmailException {
		for (NameValue recipient : recipientsToList) {
			String address = recipient.getName();
			String name = useRecipientsEmailAddressOnly ? null : recipient.getValue();

			if (OutilsBase.isEmpty(address)) {
				throw new EmailException(getErrorMessage("de base (A)", recipient, null));
			}

			try {
				emailAddressValidation(address);
			} catch (AddressException e) {
				throw new EmailException(getErrorMessage("de base (A)", recipient, e));
			}

			if (OutilsBase.isEmpty(name)) {
				email.addTo(address);
			} else {
				email.addTo(address, name);
			}
		}
	}

	/**
	 * Ajout des destinataires en CC (copie conforme) sous forme courriel=nom d'usager
	 * @param email Le courriel à renseigner
	 * @throws EmailException en cas d'erreur...
	 */
	protected void addRecipientCc(Email email) throws EmailException {
		for (NameValue recipient : recipientsCcList) {
			String address = recipient.getName();
			String name = useRecipientsEmailAddressOnly ? null : recipient.getValue();

			if (OutilsBase.isEmpty(address)) {
				throw new EmailException(getErrorMessage("en CC (copie conforme)", recipient, null));
			}

			try {
				emailAddressValidation(address);
			} catch (AddressException e) {
				throw new EmailException(getErrorMessage("en CC (copie conforme)", recipient, e));
			}

			if (OutilsBase.isEmpty(name)) {
				email.addCc(address);
			} else {
				email.addCc(address, name);
			}
		}
	}

	/**
	 * Ajout des destinataires en CCI (copie conforme invisible) sous forme courriel=nom d'usager
	 * @param email Le courriel à renseigner
	 * @throws EmailException en cas d'erreur...
	 */
	protected void addRecipientBcc(Email email) throws EmailException {
		for (NameValue recipient : recipientsBccList) {
			String address = recipient.getName();
			String name = useRecipientsEmailAddressOnly ? null : recipient.getValue();

			if (OutilsBase.isEmpty(address)) {
				throw new EmailException(getErrorMessage("en CCI (copie conforme invisible)", recipient, null));
			}

			try {
				emailAddressValidation(address);
			} catch (AddressException e) {
				throw new EmailException(getErrorMessage("en CCI (copie conforme invisible)", recipient, e));
			}

			if (OutilsBase.isEmpty(name)) {
				email.addBcc(address);
			} else {
				email.addBcc(address, name);
			}
		}
	}

	/**
	 * Ajout des attachements
	 * @param email Le courriel à renseigner
	 * @throws EmailException en cas d'erreur...
	 */
	protected void addAttachments(MultiPartEmail email) throws EmailException {
		for (NameValue item : attachmentsList) {
			String filename = item.getName();
			String name = item.getValue();

			File file = new File(filename);

			if (!file.exists()) {
				throw new EmailException("Le fichier \"" + filename + "\" n'existe pas !!!");
			}

			if (OutilsBase.isEmpty(name)) {
				name = file.getName();
			}

			EmailAttachment attachment = new EmailAttachment();
			attachment.setPath(filename);
			attachment.setDisposition(EmailAttachment.ATTACHMENT);
			attachment.setName(name);

			email.attach(attachment);
		}
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires de base (A) sous forme courriel=nom d'usager
	 * @param address Adresse de courriel du destinataire
	 */
	public void addRecipientTo(String address) {
		addRecipientTo(address, "");
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires de base (A) sous forme courriel=nom d'usager
	 * @param address Adresse de courriel du destinataire
	 * @param name Nom de l'usager de l'adresse de courriel du destinataire
	 */
	public void addRecipientTo(String address, String name) {
		this.recipientsToList.add(new NameValue(address, name));
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires de base (A) sous forme d'une paire courriel=nom d'usager
	 * @param recipient Le destinataire sous forme d'une paire courriel=nom d'usager
	 */
	public void addRecipientTo(NameValue recipient) {
		this.recipientsToList.add(recipient);
	}

	/**
	 * Ajout d'une liste de destinataires à la liste des paires de destinataires de base (A) sous forme de paires courriel=nom d'usager
	 * @param recipientsList La liste de destinataires sous forme de paires courriel=nom d'usager
	 */
	public void addRecipientsTo(List<NameValue> recipientsList) {
		this.recipientsToList.addAll(recipientsList);
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires en CC (copie conforme) sous forme courriel=nom d'usager
	 * @param address Adresse de courriel du destinataire
	 */
	public void addRecipientCc(String address) {
		addRecipientCc(address, "");
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires en CC (copie conforme) sous forme courriel=nom d'usager
	 * @param address Adresse de courriel du destinataire
	 * @param name Nom de l'usager de l'adresse de courriel du destinataire
	 */
	public void addRecipientCc(String address, String name) {
		this.recipientsCcList.add(new NameValue(address, name));
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires en CC (copie conforme) sous forme d'une paire courriel=nom d'usager
	 * @param recipient Le destinataire sous forme d'une paire courriel=nom d'usager
	 */
	public void addRecipientCc(NameValue recipient) {
		this.recipientsCcList.add(recipient);
	}

	/**
	 * Ajout d'une liste de destinataires à la liste des paires de destinataires en CC (copie conforme) sous forme de paires courriel=nom d'usager
	 * @param recipientsList La liste de destinataires sous forme de paires courriel=nom d'usager
	 */
	public void addRecipientsCc(List<NameValue> recipientsList) {
		this.recipientsCcList.addAll(recipientsList);
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires en CCI (copie conforme invisible) sous forme courriel=nom d'usager
	 * @param address Adresse de courriel du destinataire
	 */
	public void addRecipientBcc(String address) {
		addRecipientBcc(address, "");
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires en CCI (copie conforme invisible) sous forme courriel=nom d'usager
	 * @param address Adresse de courriel du destinataire
	 * @param name Nom de l'usager de l'adresse de courriel du destinataire
	 */
	public void addRecipientBcc(String address, String name) {
		this.recipientsBccList.add(new NameValue(address, name));
	}

	/**
	 * Ajout d'un destinataire à la liste des paires de destinataires en CCI (copie conforme invisible) sous forme d'une paire courriel=nom d'usager
	 * @param recipient Le destinataire sous forme d'une paire courriel=nom d'usager
	 */
	public void addRecipientBcc(NameValue recipient) {
		this.recipientsBccList.add(recipient);
	}

	/**
	 * Ajout d'une liste de destinataires à la liste des paires de destinataires en CCI (copie conforme invisible) sous forme de paires courriel=nom d'usager
	 * @param recipientsList La liste de destinataires sous forme de paires courriel=nom d'usager
	 */
	public void addRecipientsBcc(List<NameValue> recipientsList) {
		this.recipientsBccList.addAll(recipientsList);
	}

	/**
	 * Ajout d'un attachement à la liste des attachements sous forme fichier=nom fichier
	 * @param filename Le chemin complet du fichier
	 */
	public void addAttachment(String filename) {
		addAttachment(filename, "");
	}

	/**
	 * Ajout d'un attachement à la liste des attachements sous forme fichier=nom fichier
	 * @param filename Le chemin complet du fichier
	 * @param name Le nom du fichier à afficher aux destinataires dans le courriel
	 */
	public void addAttachment(String filename, String name) {
		addAttachment(new NameValue(filename, name));
	}

	/**
	 * Ajout d'un attachement à la liste des attachements sous forme fichier=nom fichier
	 * @param attachment L'attachement sous forme fichier=nom fichier
	 */
	public void addAttachment(NameValue attachment) {
		this.attachmentsList.add(attachment);
	}

	/**
	 * Ajout d'une liste d'attachements à la liste des attachements sous forme fichier=nom fichier
	 * @param attachmentsList Liste des attachements
	 */
	public void addAttachments(List<NameValue> attachmentsList) {
		this.attachmentsList.addAll(attachmentsList);
	}

	/**
	 * Envoi du courriel
	 * @return L'identifiant du courriel envoyé
	 * @throws EmailException en cas d'erreur...
	 */
	public String send() throws EmailException {
		return getEmail().send();
	}

	/**
	 * Extrait le champ emailServer
	 * @return un EmailServer
	 */
	public EmailServerBase getEmailServer() {
		return emailServer;
	}

	/**
	 * Modifie le champ emailServer
	 * @param emailServer La valeur du champ emailServer
	 */
	public void setEmailServer(EmailServerBase emailServer) {
		this.emailServer = emailServer;
	}

	/**
	 * Extrait le champ html
	 * @return un boolean
	 */
	public boolean isHtml() {
		return html;
	}

	/**
	 * Modifie le champ html
	 * @param html La valeur du champ html
	 */
	public void setHtml(boolean html) {
		this.html = html;
	}

	/**
	 * Extrait le champ originEmailAddress
	 * @return un String
	 */
	public String getOriginEmailAddress() {
		return originEmailAddress;
	}

	/**
	 * Modifie le champ originEmailAddress
	 * @param originEmailAddress La valeur du champ originEmailAddress
	 */
	public void setOriginEmailAddress(String originEmailAddress) {
		this.originEmailAddress = originEmailAddress;
	}

	/**
	 * Extrait le champ originUserName
	 * @return un String
	 */
	public String getOriginUserName() {
		return originUserName;
	}

	/**
	 * Modifie le champ originUserName
	 * @param originUserName La valeur du champ originUserName
	 */
	public void setOriginUserName(String originUserName) {
		this.originUserName = originUserName;
	}

	/**
	 * Extrait le champ subject
	 * @return un String
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * Modifie le champ subject
	 * @param subject La valeur du champ subject
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * Extrait le champ message
	 * @return un String
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Modifie le champ message
	 * @param message La valeur du champ message
	 */
	public void setMessage(List<String> message) {
		this.message = OutilsCommun.toList(message, "");
	}

	/**
	 * Modifie le champ message
	 * @param message La valeur du champ message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Extrait le champ recipientsToList
	 * @return un List<NameValue>
	 */
	public List<NameValue> getRecipientsToList() {
		return recipientsToList;
	}

	/**
	 * Extrait le champ recipientsCcList
	 * @return un List<NameValue>
	 */
	public List<NameValue> getRecipientsCcList() {
		return recipientsCcList;
	}

	/**
	 * Extrait le champ recipientsBccList
	 * @return un List<NameValue>
	 */
	public List<NameValue> getRecipientsBccList() {
		return recipientsBccList;
	}

	/**
	 * Extrait le champ attachmentsList
	 * @return un List<NameValue>
	 */
	public List<NameValue> getAttachmentsList() {
		return attachmentsList;
	}

	/**
	 * Extrait le champ useRecipientsEmailAddressOnly
	 * @return un boolean
	 */
	public boolean isUseRecipientsEmailAddressOnly() {
		return useRecipientsEmailAddressOnly;
	}

	/**
	 * Modifie le champ useRecipientsEmailAddressOnly
	 * @param useRecipientsEmailAddressOnly La valeur du champ useRecipientsEmailAddressOnly
	 */
	public void setUseRecipientsEmailAddressOnly(boolean useRecipientsEmailAddressOnly) {
		this.useRecipientsEmailAddressOnly = useRecipientsEmailAddressOnly;
	}

	/**
	 * Extrait le champ debug
	 * @return un boolean
	 */
	public boolean isDebug() {
		return debug;
	}

	/**
	 * Modifie le champ debug
	 * @param debug La valeur du champ debug
	 */
	public void setDebug(boolean debug) {
		this.debug = debug;
	}

}
