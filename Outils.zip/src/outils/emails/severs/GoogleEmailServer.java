package outils.emails.severs;

import outils.emails.severs.base.EmailServerBase;
import outils.emails.severs.types.EmailServersTypes;

/**
 * Clase pour l'envoi d'un courriel via Google
 * Important: Il faut activer l'accès pour les applications moins sécurisées au niveau du compte Google
 * @see https://www.google.com/settings/security/lesssecureapps
 * @author Claude Toupin - 6 sept. 2021
 */
public class GoogleEmailServer extends EmailServerBase {
	/** Serveur de courriels par défaut **/
	final public static String HOSTNAME_DEF = "smtp.gmail.com";

	/**
	 * Constructeur de base
	 * @param userName Nom de l'usager pour l'authentification
	 * @param password Mot de passe de l'usager pour l'authentification
	 */
	public GoogleEmailServer(String userName, String password) {
		// super(EmailServersTypes.SSL, HOSTNAME_DEF, userName, password);
		super(EmailServersTypes.TLS, HOSTNAME_DEF, userName, password);
	}

}
