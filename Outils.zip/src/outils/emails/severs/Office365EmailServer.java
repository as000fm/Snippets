package outils.emails.severs;

import outils.emails.severs.base.EmailServerBase;
import outils.emails.severs.types.EmailServersTypes;

/**
 * Clase pour l'envoi d'un courriel via Office 365
 * @author Claude Toupin - 6 sept. 2021
 */
public class Office365EmailServer extends EmailServerBase {
	/** Serveur de courriels par défaut **/
	final public static String HOSTNAME_DEF = "smtp.office365.com";

	/**
	 * Constructeur de base
	 * @param userName Nom de l'usager pour l'authentification
	 * @param password Mot de passe de l'usager pour l'authentification
	 */
	public Office365EmailServer(String userName, String password) {
		super(EmailServersTypes.TLS, HOSTNAME_DEF, userName, password);
	}

}
