package outils.emails.severs;

import outils.emails.severs.base.EmailServerBase;
import outils.emails.severs.types.EmailServersTypes;

/**
 * Clase pour l'envoi d'un courriel via smtp
 * @author Claude Toupin - 6 sept. 2021
 */
public class SMTPEmailServer extends EmailServerBase {
	/** Serveur de courriels par défaut **/
	final public static String HOSTNAME_DEF = "localhost";

	/**
	 * Constructeur de base
	 */
	public SMTPEmailServer() {
		super(EmailServersTypes.SMTP, HOSTNAME_DEF);
	}

	/**
	 * Constructeur de base
	 * @param hostName Adresse du serveur
	 */
	public SMTPEmailServer(String hostName) {
		super(EmailServersTypes.SMTP, hostName);
	}

	/**
	 * Constructeur de base
	 * @param userName Nom de l'usager pour l'authentification
	 * @param password Mot de passe de l'usager pour l'authentification
	 */
	public SMTPEmailServer(String userName, String password) {
		super(EmailServersTypes.SMTP, HOSTNAME_DEF, userName, password);
	}

	/**
	 * Constructeur de base
	 * @param hostName Adresse du serveur
	 * @param userName Nom de l'usager pour l'authentification
	 * @param password Mot de passe de l'usager pour l'authentification
	 */
	public SMTPEmailServer(String hostName, String userName, String password) {
		super(EmailServersTypes.SMTP, hostName, userName, password);
	}

}
