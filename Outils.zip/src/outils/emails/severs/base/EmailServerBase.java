package outils.emails.severs.base;

import org.apache.commons.mail.Email;

import outils.base.OutilsBase;
import outils.emails.severs.types.EmailServersTypes;
import outils.gson.OutilsGson;

/**
 * Clase pour l'envoi d'un courriel via smtp
 * @author Claude Toupin - 6 sept. 2021
 */
public abstract class EmailServerBase {
	/** Type du serveur de courriels **/
	private EmailServersTypes serverType;

	/** Adresse du serveur **/
	private String hostName;

	/** Port smtp **/
	private int smtpPort;

	/** Nom de l'usager pour l'authentification **/
	private String userName;

	/** Mot de passe de l'usager pour l'authentification **/
	private String password;

	/**
	 * Constructeur de base
	 * @param serverType Type du serveur de courriels
	 * @param hostName Adresse du serveur
	 */
	protected EmailServerBase(EmailServersTypes serverType, String hostName) {
		this(serverType, hostName, serverType.getSmtpPort(), null, null);
	}

	/**
	 * Constructeur de base
	 * @param serverType Type du serveur de courriels
	 * @param hostName Adresse du serveur
	 * @param smtpPort Port smtp
	 */
	protected EmailServerBase(EmailServersTypes serverType, String hostName, int smtpPort) {
		this(serverType, hostName, smtpPort, null, null);
	}

	/**
	 * Constructeur de base
	 * @param serverType Type du serveur de courriels
	 * @param hostName Adresse du serveur
	 * @param userName Nom de l'usager pour l'authentification
	 * @param password Mot de passe de l'usager pour l'authentification
	 */
	protected EmailServerBase(EmailServersTypes serverType, String hostName, String userName, String password) {
		this(serverType, hostName, serverType.getSmtpPort(), userName, password);
	}

	/**
	 * Constructeur de base
	 * @param serverType Type du serveur de courriels
	 * @param hostName Adresse du serveur
	 * @param smtpPort Port smtp
	 * @param userName Nom de l'usager pour l'authentification
	 * @param password Mot de passe de l'usager pour l'authentification
	 */
	protected EmailServerBase(EmailServersTypes serverType, String hostName, int smtpPort, String userName, String password) {
		this.serverType = serverType;
		this.hostName = hostName;
		this.smtpPort = smtpPort;
		this.userName = userName;
		this.password = password;
	}

	/**
	 * Extrait le courriel de base pour le serveur
	 * @param emailClass Classe de courriel à envoyer
	 * @return un Email
	 */
	public Email setEmail(Email email) {
		email.setHostName(hostName);
		email.setSmtpPort(smtpPort);

		if (!OutilsBase.areEmpties(userName, password)) {
			email.setAuthentication(userName, password);
		}

		switch (serverType) {
			case SMTP:
				// Rien
				break;
			case SSL:
				email.setSSLOnConnect(true);
				break;
			case TLS:
				email.setStartTLSEnabled(true);
				break;
			default:
				throw new RuntimeException("Pas de traitement pour " + serverType);
		}

		return email;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return OutilsGson.toJson(this);
	}

	/**
	 * Extrait le champ serverType
	 * @return un EmailServersTypes
	 */
	public EmailServersTypes getServerType() {
		return serverType;
	}

	/**
	 * Modifie le champ serverType
	 * @param serverType La valeur du champ serverType
	 */
	public void setServerType(EmailServersTypes serverType) {
		this.serverType = serverType;
	}

	/**
	 * Extrait le champ hostName
	 * @return un String
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * Modifie le champ hostName
	 * @param hostName La valeur du champ hostName
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**
	 * Extrait le champ smtpPort
	 * @return un int
	 */
	public int getSmtpPort() {
		return smtpPort;
	}

	/**
	 * Modifie le champ smtpPort
	 * @param smtpPort La valeur du champ smtpPort
	 */
	public void setSmtpPort(int smtpPort) {
		this.smtpPort = smtpPort;
	}

	/**
	 * Extrait le champ userName
	 * @return un String
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Modifie le champ userName
	 * @param userName La valeur du champ userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Extrait le champ password
	 * @return un String
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Modifie le champ password
	 * @param password La valeur du champ password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}
