package outils.emails.severs.types;

/**
 * Énumération des types de serveurs de courriels
 * @author Claude Toupin - 6 sept. 2021
 */
public enum EmailServersTypes {
	SMTP(25), //
	SSL(465), //
	TLS(587), //
	;
	
	/** Port smtp **/
	final private int smtpPort;

	/**
	 * Constructeur de base
	 * @param smtpPort Port smtp
	 */
	private EmailServersTypes(int smtpPort) {
		this.smtpPort = smtpPort;
	}

	/**
	 * Extrait le champ smtpPort
	 * @return un int
	 */
	public int getSmtpPort() {
		return smtpPort;
	}
}
