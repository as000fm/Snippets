package outils.groovy;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;
import outils.base.OutilsBase;
import outils.commun.OutilsCommun;

/**
 * Classe de base pour l'exécution de code en langage groovy
 * @author Claude Toupin - 26 déc. 2021
 */
public abstract class ExecuteGroovyCode {
	/** Code source à exécuter **/
	final private List<String> source;

	/** Liaison des données entre java et groovy **/
	final private Binding binding;

	/** Répertoire de base des fichiers groovy à exécuter **/
	final private String baseDir;

	/** Moteur d'exécution du fichier groovy **/
	final private GroovyScriptEngine groovyScriptEngine;

	/**
	 * Constructeur de base
	 */
	protected ExecuteGroovyCode() {
		try {
			this.source = new ArrayList<String>();
			this.binding = new Binding();
			this.baseDir = OutilsCommun.getTempDirectory();
			this.groovyScriptEngine = new GroovyScriptEngine(this.baseDir, this.getClass().getClassLoader());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Extrait la liste des packages requis
	 * @return la liste des packages requis
	 */
	protected abstract List<String> getRequiredPackagesList();

	/**
	 * Exécution du fichier courant de code en langage groovy
	 * @return le résultat de l'exécution (un Object)
	 * @throws Throwable en cas d'erreur...
	 */
	protected Object execute() throws Throwable {
		File file = new File(OutilsCommun.getFullname(baseDir, this.getClass().getSimpleName() + System.currentTimeMillis() + OutilsCommun.GROOVY_EXTENSION));

		try {
			OutilsCommun.saveListToFile(source, file);

			return groovyScriptEngine.run(file.getName(), binding);
		} finally {
			if (file.exists()) {
				file.delete();
			}
		}
	}

	/**
	 * Exécution du fichier courant de code en langage groovy
	 * @param source Le code en langage groovy à exécuter
	 * @return le résultat de l'exécution (un Object)
	 * @throws Throwable en cas d'erreur...
	 */
	protected Object execute(String source) throws Throwable {
		setSource(source);

		return execute();
	}

	/**
	 * Exécution du fichier courant de code en langage groovy
	 * @param source Le code en langage groovy à exécuter
	 * @return le résultat de l'exécution (un Object)
	 * @throws Throwable en cas d'erreur...
	 */
	protected Object execute(List<String> source) throws Throwable {
		setSource(source);

		return execute();
	}

	/**
	 * Extrait le code source
	 * @return le code source
	 */
	protected List<String> getSource() {
		return source;
	}

	/**
	 * Modifie le code source à être exécuter
	 * @param source Le code source à être exécuter
	 */
	protected void setSource(String source) {
		List<String> list = new ArrayList<String>();
		list.add(OutilsBase.asString(source));

		setSource(list);
	}

	/**
	 * Modifie le code source à être exécuter
	 * @param source Le code source à être exécuter
	 */
	protected void setSource(List<String> source) {
		this.source.clear();

		if (source != null) {
			List<String> requiredPackagesList = getRequiredPackagesList();

			if (!OutilsBase.isEmpty(requiredPackagesList)) {
				for (String requiredPackage : getRequiredPackagesList()) {
					if (!this.source.contains(requiredPackage)) {
						this.source.add(requiredPackage);
					}
				}
			}

			this.source.addAll(source);
		}
	}

	/**
	 * Extrait le champ binding
	 * @return un Binding
	 */
	protected Binding getBinding() {
		return binding;
	}
}
