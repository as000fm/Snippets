package outils.gson;

import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.AddImportsForTesting;
import outils.tests.automated.annotations.AutomatedTests;
import outils.types.ParseDatesTypes;

/**
 * Classe des méthodes utilitaires json de type final public static
 * ALERTE: NE PAS MODIFIER MANUELLEMENT CETTE CLASSE !!!
 * @author Projet: Outils, Classe: json.outils.gson.AsOutilsGsonClassGenerator
 */
@SuppressWarnings("deprecation")
@AddImportsForTesting({ com.google.gson.JsonPrimitive.class, com.google.gson.JsonNull.class })
public class AsOutilsGson {
	// ALERTE: NE PAS MODIFIER MANUELLEMENT CETTE CLASSE !!!
	// Utilisez la classe json.outils.gson.AsOutilsGsonClassGenerator du projet Outils

	// AsOutilsGsonClassTemplate

	/**
	 * Conversion d'un texte en date
	 * @param value La valeur à convertir de format yyyy-MM-dd HH:mm:ss
	 * @return un Date (null si vide)
	 */
	final protected static java.util.Date asStringToDate(String value) {
		if (OutilsBase.isEmpty(value)) {
			return null;
		}

		try {
			switch (value.length()) {
				case 16:
					return OutilsCommun.asStringToDate(value + ":00", ParseDatesTypes.YYYY_MM_DD_HH_MM_SS);
				case 19:
					return OutilsCommun.asStringToDate(value, ParseDatesTypes.YYYY_MM_DD_HH_MM_SS);
				default:
					throw new RuntimeException("Pas de conversion pour une date de format \"" + value + "\"");
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Conversion d'un texte en long
	 * @param value La valeur à convertir
	 * @return un Long (null si vide)
	 */
	final protected static Long asStringToLong(String value) {
		if (OutilsBase.isEmpty(value)) {
			return null;
		}

		return new Long(value);
	}

	/**
	 * Vérifie si un objet JSON est vide ou non
	 * @param object L'objet JSON à vérifier
	 * @return vrai si vide
	 */
	@AutomatedTests("new JsonObject()")
	final public static boolean isEmpty(JsonObject object) {
		return (object == null) ? true : false;
	}

	/**
	 * Vérifie si un élélment JSON est vide ou non
	 * @param array Le élélment JSON à vérifier
	 * @return vrai si vide
	 */
	@AutomatedTests(value = { "JsonNull.INSTANCE", "(JsonElement) new JsonObject()" }, process = false)
	final public static boolean isEmpty(JsonElement element) {
		if (element == null) {
			return true;
		} else if (element.isJsonNull()) {
			return true;
		}

		return false;
	}

	/**
	 * Vérifie si un tableau JSON est vide ou non
	 * @param array Le tableau JSON à vérifier
	 * @return vrai si vide
	 */
	@AutomatedTests(value = { "JsonNull.INSTANCE", "new JsonArray()" }, process = false)
	final public static boolean isEmpty(JsonArray array) {
		return (array == null) ? true : false;
	}

	/**
	 * Extrait la valeur texte d'un élélment JSON
	 * @param array Le élélment JSON à extraire
	 * @return un String (null sinon)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(\"A\")" }, process = false)
	final public static String getAsString(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		return element.getAsString();
	}

	/**
	 * Extrait la valeur texte d'un tableau JSON
	 * @param array Le tableau JSON à extraire
	 * @return un String (null sinon)
	 */
	@AutomatedTests("new JsonArray()")
	final public static String getAsString(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		return array.getAsString();
	}

	/**
	 * Extrait un tableau JSON depuis un objet JSON
	 * @param object L'objet JSON à extraire
	 * @return un tableau JSON (null si vide)
	 */
	@AutomatedTests({ "new JsonArray()", "new JsonObject()" })
	final public static JsonArray getAsJsonArray(JsonObject object) {
		if (isEmpty(object)) {
			return null;
		} else if (object.size() != 0) {
			JsonArray jsonArray = new JsonArray();
			jsonArray.add(object);

			return jsonArray;
		}

		return null;
	}

	/**
	 * Extrait un tableau JSON depuis un élélment JSON
	 * @param element L'élélment JSON à extraire
	 * @return un tableau JSON (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonArray()", "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(true)" }, process = false)
	final public static JsonArray getAsJsonArray(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		} else if (element.isJsonArray()) {
			return element.getAsJsonArray();
		} else if (element.isJsonObject()) {
			return getAsJsonArray(element.getAsJsonObject());
		}

		return null;
	}

	/**
	 * Extrait un objet JSON depuis un élélment JSON
	 * @param element L'élélment JSON à extraire
	 * @return un objet JSON (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(true)" }, process = false)
	final public static JsonObject getAsJsonObject(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		} else if (element.isJsonObject()) {
			return element.getAsJsonObject();
		}

		return null;
	}

	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Boolean
	 * @param element Élément JSON
	 * @return un Boolean (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(false)" }, process = false)
	final public static Boolean asBoolean(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsBoolean();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Boolean
	 * @param element Élément JSON
	 * @return un tableau de Boolean (null si vide)
	 */
	final public static Boolean[] asBooleanArray(JsonElement element) {
		return asBooleanArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Boolean
	 * @param array Liste JSON
	 * @return un tableau de Boolean (null si vide)
	 */
	final public static Boolean[] asBooleanArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Boolean[] vector = new Boolean[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asBoolean(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Boolean
	 * @param element Élément JSON
	 * @return un boolean (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(false)" }, process = false)
	final public static boolean asBooleanPrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return false;
		}
		
		return element.getAsBoolean();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Boolean
	 * @param element Élément JSON
	 * @return un tableau de boolean (null si vide)
	 */
	final public static boolean[] asBooleanPrimitiveArray(JsonElement element) {
		return asBooleanPrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Boolean
	 * @param array Liste JSON
	 * @return un tableau de boolean (null si vide)
	 */
	final public static boolean[] asBooleanPrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		boolean[] vector = new boolean[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asBooleanPrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Boolean
	 * @param element Élément JSON
	 * @return une liste de Boolean
	 */
	final public static List<Boolean> asBooleanList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Boolean>();
		}

		return asBooleanList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Boolean
	 * @param array Liste JSON
	 * @return une liste de Boolean
	 */
	final public static List<Boolean> asBooleanList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Boolean>();
		}

		List<Boolean> list = new ArrayList<Boolean>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asBoolean(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Boolean
	 * @param element Élément JSON
	 * @return une liste de tableaux Boolean
	 */
	final public static List<Boolean[]> asBooleanArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Boolean[]>();
		}

		return asBooleanArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Boolean
	 * @param array Liste JSON
	 * @return une liste de tableaux Boolean
	 */
	final public static List<Boolean[]> asBooleanArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Boolean[]>();
		}

		List<Boolean[]> list = new ArrayList<Boolean[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asBooleanArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Boolean
	 * @param element Élément JSON
	 * @return un dictionnaire de Boolean
	 */
	final public static Map<String, Boolean> asBooleanMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Boolean>();
		}

		return asBooleanMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Boolean
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Boolean
	 */
	final public static Map<String, Boolean> asBooleanMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Boolean>();
		}

		Map<String, Boolean> map = new HashMap<String, Boolean>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asBoolean(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Boolean
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Boolean
	 */
	final public static Map<String, Boolean[]> asBooleanArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Boolean[]>();
		}

		return asBooleanArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Boolean
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Boolean
	 */
	final public static Map<String, Boolean[]> asBooleanArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Boolean[]>();
		}

		Map<String, Boolean[]> map = new HashMap<String, Boolean[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asBooleanArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Boolean
	 * @param element Élément JSON
	 * @return un dictionnaire de données Boolean
	 */
	final public static Map<String, List<Boolean>> asBooleanListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Boolean>>();
		}

		return asBooleanListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Boolean
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Boolean
	 */
	final public static Map<String, List<Boolean>> asBooleanListMap(JsonObject jsonObject) {
		Map<String, List<Boolean>> dict = new HashMap<String, List<Boolean>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asBooleanList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Byte
	 * @param element Élément JSON
	 * @return un Byte (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static Byte asByte(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsByte();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Byte
	 * @param element Élément JSON
	 * @return un tableau de Byte (null si vide)
	 */
	final public static Byte[] asByteArray(JsonElement element) {
		return asByteArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Byte
	 * @param array Liste JSON
	 * @return un tableau de Byte (null si vide)
	 */
	final public static Byte[] asByteArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Byte[] vector = new Byte[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asByte(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Byte
	 * @param element Élément JSON
	 * @return un byte (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static byte asBytePrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return ((byte) 0);
		}
		
		return element.getAsByte();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Byte
	 * @param element Élément JSON
	 * @return un tableau de byte (null si vide)
	 */
	final public static byte[] asBytePrimitiveArray(JsonElement element) {
		return asBytePrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Byte
	 * @param array Liste JSON
	 * @return un tableau de byte (null si vide)
	 */
	final public static byte[] asBytePrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		byte[] vector = new byte[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asBytePrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Byte
	 * @param element Élément JSON
	 * @return une liste de Byte
	 */
	final public static List<Byte> asByteList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Byte>();
		}

		return asByteList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Byte
	 * @param array Liste JSON
	 * @return une liste de Byte
	 */
	final public static List<Byte> asByteList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Byte>();
		}

		List<Byte> list = new ArrayList<Byte>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asByte(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Byte
	 * @param element Élément JSON
	 * @return une liste de tableaux Byte
	 */
	final public static List<Byte[]> asByteArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Byte[]>();
		}

		return asByteArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Byte
	 * @param array Liste JSON
	 * @return une liste de tableaux Byte
	 */
	final public static List<Byte[]> asByteArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Byte[]>();
		}

		List<Byte[]> list = new ArrayList<Byte[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asByteArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Byte
	 * @param element Élément JSON
	 * @return un dictionnaire de Byte
	 */
	final public static Map<String, Byte> asByteMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Byte>();
		}

		return asByteMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Byte
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Byte
	 */
	final public static Map<String, Byte> asByteMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Byte>();
		}

		Map<String, Byte> map = new HashMap<String, Byte>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asByte(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Byte
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Byte
	 */
	final public static Map<String, Byte[]> asByteArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Byte[]>();
		}

		return asByteArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Byte
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Byte
	 */
	final public static Map<String, Byte[]> asByteArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Byte[]>();
		}

		Map<String, Byte[]> map = new HashMap<String, Byte[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asByteArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Byte
	 * @param element Élément JSON
	 * @return un dictionnaire de données Byte
	 */
	final public static Map<String, List<Byte>> asByteListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Byte>>();
		}

		return asByteListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Byte
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Byte
	 */
	final public static Map<String, List<Byte>> asByteListMap(JsonObject jsonObject) {
		Map<String, List<Byte>> dict = new HashMap<String, List<Byte>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asByteList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Char
	 * @param element Élément JSON
	 * @return un Character (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(\"A\")" }, process = false)
	final public static Character asChar(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return new Character(element.getAsCharacter());
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Char
	 * @param element Élément JSON
	 * @return un tableau de Character (null si vide)
	 */
	final public static Character[] asCharArray(JsonElement element) {
		return asCharArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Char
	 * @param array Liste JSON
	 * @return un tableau de Character (null si vide)
	 */
	final public static Character[] asCharArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Character[] vector = new Character[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asChar(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Char
	 * @param element Élément JSON
	 * @return un char (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(\"A\")" }, process = false)
	final public static char asCharPrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return ((char) 0);
		}
		
		return (char) element.getAsCharacter();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Char
	 * @param element Élément JSON
	 * @return un tableau de char (null si vide)
	 */
	final public static char[] asCharPrimitiveArray(JsonElement element) {
		return asCharPrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Char
	 * @param array Liste JSON
	 * @return un tableau de char (null si vide)
	 */
	final public static char[] asCharPrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		char[] vector = new char[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asCharPrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Char
	 * @param element Élément JSON
	 * @return une liste de Character
	 */
	final public static List<Character> asCharList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Character>();
		}

		return asCharList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Char
	 * @param array Liste JSON
	 * @return une liste de Character
	 */
	final public static List<Character> asCharList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Character>();
		}

		List<Character> list = new ArrayList<Character>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asChar(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Char
	 * @param element Élément JSON
	 * @return une liste de tableaux Char
	 */
	final public static List<Character[]> asCharArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Character[]>();
		}

		return asCharArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Char
	 * @param array Liste JSON
	 * @return une liste de tableaux Char
	 */
	final public static List<Character[]> asCharArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Character[]>();
		}

		List<Character[]> list = new ArrayList<Character[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asCharArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Char
	 * @param element Élément JSON
	 * @return un dictionnaire de Character
	 */
	final public static Map<String, Character> asCharMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Character>();
		}

		return asCharMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Char
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Character
	 */
	final public static Map<String, Character> asCharMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Character>();
		}

		Map<String, Character> map = new HashMap<String, Character>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asChar(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Char
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Character
	 */
	final public static Map<String, Character[]> asCharArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Character[]>();
		}

		return asCharArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Char
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Character
	 */
	final public static Map<String, Character[]> asCharArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Character[]>();
		}

		Map<String, Character[]> map = new HashMap<String, Character[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asCharArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Char
	 * @param element Élément JSON
	 * @return un dictionnaire de données Character
	 */
	final public static Map<String, List<Character>> asCharListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Character>>();
		}

		return asCharListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Char
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Character
	 */
	final public static Map<String, List<Character>> asCharListMap(JsonObject jsonObject) {
		Map<String, List<Character>> dict = new HashMap<String, List<Character>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asCharList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Double
	 * @param element Élément JSON
	 * @return un Double (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static Double asDouble(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsDouble();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Double
	 * @param element Élément JSON
	 * @return un tableau de Double (null si vide)
	 */
	final public static Double[] asDoubleArray(JsonElement element) {
		return asDoubleArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Double
	 * @param array Liste JSON
	 * @return un tableau de Double (null si vide)
	 */
	final public static Double[] asDoubleArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Double[] vector = new Double[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asDouble(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Double
	 * @param element Élément JSON
	 * @return un double (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static double asDoublePrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return 0;
		}
		
		return element.getAsDouble();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Double
	 * @param element Élément JSON
	 * @return un tableau de double (null si vide)
	 */
	final public static double[] asDoublePrimitiveArray(JsonElement element) {
		return asDoublePrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Double
	 * @param array Liste JSON
	 * @return un tableau de double (null si vide)
	 */
	final public static double[] asDoublePrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		double[] vector = new double[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asDoublePrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Double
	 * @param element Élément JSON
	 * @return une liste de Double
	 */
	final public static List<Double> asDoubleList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Double>();
		}

		return asDoubleList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Double
	 * @param array Liste JSON
	 * @return une liste de Double
	 */
	final public static List<Double> asDoubleList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Double>();
		}

		List<Double> list = new ArrayList<Double>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asDouble(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Double
	 * @param element Élément JSON
	 * @return une liste de tableaux Double
	 */
	final public static List<Double[]> asDoubleArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Double[]>();
		}

		return asDoubleArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Double
	 * @param array Liste JSON
	 * @return une liste de tableaux Double
	 */
	final public static List<Double[]> asDoubleArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Double[]>();
		}

		List<Double[]> list = new ArrayList<Double[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asDoubleArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Double
	 * @param element Élément JSON
	 * @return un dictionnaire de Double
	 */
	final public static Map<String, Double> asDoubleMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Double>();
		}

		return asDoubleMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Double
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Double
	 */
	final public static Map<String, Double> asDoubleMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Double>();
		}

		Map<String, Double> map = new HashMap<String, Double>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asDouble(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Double
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Double
	 */
	final public static Map<String, Double[]> asDoubleArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Double[]>();
		}

		return asDoubleArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Double
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Double
	 */
	final public static Map<String, Double[]> asDoubleArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Double[]>();
		}

		Map<String, Double[]> map = new HashMap<String, Double[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asDoubleArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Double
	 * @param element Élément JSON
	 * @return un dictionnaire de données Double
	 */
	final public static Map<String, List<Double>> asDoubleListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Double>>();
		}

		return asDoubleListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Double
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Double
	 */
	final public static Map<String, List<Double>> asDoubleListMap(JsonObject jsonObject) {
		Map<String, List<Double>> dict = new HashMap<String, List<Double>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asDoubleList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Float
	 * @param element Élément JSON
	 * @return un Float (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static Float asFloat(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsFloat();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Float
	 * @param element Élément JSON
	 * @return un tableau de Float (null si vide)
	 */
	final public static Float[] asFloatArray(JsonElement element) {
		return asFloatArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Float
	 * @param array Liste JSON
	 * @return un tableau de Float (null si vide)
	 */
	final public static Float[] asFloatArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Float[] vector = new Float[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asFloat(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Float
	 * @param element Élément JSON
	 * @return un float (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static float asFloatPrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return 0;
		}
		
		return element.getAsFloat();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Float
	 * @param element Élément JSON
	 * @return un tableau de float (null si vide)
	 */
	final public static float[] asFloatPrimitiveArray(JsonElement element) {
		return asFloatPrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Float
	 * @param array Liste JSON
	 * @return un tableau de float (null si vide)
	 */
	final public static float[] asFloatPrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		float[] vector = new float[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asFloatPrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Float
	 * @param element Élément JSON
	 * @return une liste de Float
	 */
	final public static List<Float> asFloatList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Float>();
		}

		return asFloatList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Float
	 * @param array Liste JSON
	 * @return une liste de Float
	 */
	final public static List<Float> asFloatList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Float>();
		}

		List<Float> list = new ArrayList<Float>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asFloat(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Float
	 * @param element Élément JSON
	 * @return une liste de tableaux Float
	 */
	final public static List<Float[]> asFloatArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Float[]>();
		}

		return asFloatArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Float
	 * @param array Liste JSON
	 * @return une liste de tableaux Float
	 */
	final public static List<Float[]> asFloatArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Float[]>();
		}

		List<Float[]> list = new ArrayList<Float[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asFloatArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Float
	 * @param element Élément JSON
	 * @return un dictionnaire de Float
	 */
	final public static Map<String, Float> asFloatMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Float>();
		}

		return asFloatMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Float
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Float
	 */
	final public static Map<String, Float> asFloatMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Float>();
		}

		Map<String, Float> map = new HashMap<String, Float>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asFloat(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Float
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Float
	 */
	final public static Map<String, Float[]> asFloatArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Float[]>();
		}

		return asFloatArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Float
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Float
	 */
	final public static Map<String, Float[]> asFloatArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Float[]>();
		}

		Map<String, Float[]> map = new HashMap<String, Float[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asFloatArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Float
	 * @param element Élément JSON
	 * @return un dictionnaire de données Float
	 */
	final public static Map<String, List<Float>> asFloatListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Float>>();
		}

		return asFloatListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Float
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Float
	 */
	final public static Map<String, List<Float>> asFloatListMap(JsonObject jsonObject) {
		Map<String, List<Float>> dict = new HashMap<String, List<Float>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asFloatList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Int
	 * @param element Élément JSON
	 * @return un Integer (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static Integer asInt(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsInt();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Int
	 * @param element Élément JSON
	 * @return un tableau de Integer (null si vide)
	 */
	final public static Integer[] asIntArray(JsonElement element) {
		return asIntArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Int
	 * @param array Liste JSON
	 * @return un tableau de Integer (null si vide)
	 */
	final public static Integer[] asIntArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Integer[] vector = new Integer[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asInt(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Int
	 * @param element Élément JSON
	 * @return un int (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static int asIntPrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return 0;
		}
		
		return element.getAsInt();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Int
	 * @param element Élément JSON
	 * @return un tableau de int (null si vide)
	 */
	final public static int[] asIntPrimitiveArray(JsonElement element) {
		return asIntPrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Int
	 * @param array Liste JSON
	 * @return un tableau de int (null si vide)
	 */
	final public static int[] asIntPrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		int[] vector = new int[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asIntPrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Int
	 * @param element Élément JSON
	 * @return une liste de Integer
	 */
	final public static List<Integer> asIntList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Integer>();
		}

		return asIntList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Int
	 * @param array Liste JSON
	 * @return une liste de Integer
	 */
	final public static List<Integer> asIntList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Integer>();
		}

		List<Integer> list = new ArrayList<Integer>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asInt(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Int
	 * @param element Élément JSON
	 * @return une liste de tableaux Int
	 */
	final public static List<Integer[]> asIntArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Integer[]>();
		}

		return asIntArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Int
	 * @param array Liste JSON
	 * @return une liste de tableaux Int
	 */
	final public static List<Integer[]> asIntArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Integer[]>();
		}

		List<Integer[]> list = new ArrayList<Integer[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asIntArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Int
	 * @param element Élément JSON
	 * @return un dictionnaire de Integer
	 */
	final public static Map<String, Integer> asIntMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Integer>();
		}

		return asIntMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Int
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Integer
	 */
	final public static Map<String, Integer> asIntMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Integer>();
		}

		Map<String, Integer> map = new HashMap<String, Integer>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asInt(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Int
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Integer
	 */
	final public static Map<String, Integer[]> asIntArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Integer[]>();
		}

		return asIntArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Int
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Integer
	 */
	final public static Map<String, Integer[]> asIntArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Integer[]>();
		}

		Map<String, Integer[]> map = new HashMap<String, Integer[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asIntArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Int
	 * @param element Élément JSON
	 * @return un dictionnaire de données Integer
	 */
	final public static Map<String, List<Integer>> asIntListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Integer>>();
		}

		return asIntListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Int
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Integer
	 */
	final public static Map<String, List<Integer>> asIntListMap(JsonObject jsonObject) {
		Map<String, List<Integer>> dict = new HashMap<String, List<Integer>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asIntList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Long
	 * @param element Élément JSON
	 * @return un Long (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static Long asLong(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsLong();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Long
	 * @param element Élément JSON
	 * @return un tableau de Long (null si vide)
	 */
	final public static Long[] asLongArray(JsonElement element) {
		return asLongArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Long
	 * @param array Liste JSON
	 * @return un tableau de Long (null si vide)
	 */
	final public static Long[] asLongArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Long[] vector = new Long[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asLong(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Long
	 * @param element Élément JSON
	 * @return un long (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static long asLongPrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return 0;
		}
		
		return element.getAsLong();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Long
	 * @param element Élément JSON
	 * @return un tableau de long (null si vide)
	 */
	final public static long[] asLongPrimitiveArray(JsonElement element) {
		return asLongPrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Long
	 * @param array Liste JSON
	 * @return un tableau de long (null si vide)
	 */
	final public static long[] asLongPrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		long[] vector = new long[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asLongPrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Long
	 * @param element Élément JSON
	 * @return une liste de Long
	 */
	final public static List<Long> asLongList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Long>();
		}

		return asLongList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Long
	 * @param array Liste JSON
	 * @return une liste de Long
	 */
	final public static List<Long> asLongList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Long>();
		}

		List<Long> list = new ArrayList<Long>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asLong(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Long
	 * @param element Élément JSON
	 * @return une liste de tableaux Long
	 */
	final public static List<Long[]> asLongArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Long[]>();
		}

		return asLongArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Long
	 * @param array Liste JSON
	 * @return une liste de tableaux Long
	 */
	final public static List<Long[]> asLongArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Long[]>();
		}

		List<Long[]> list = new ArrayList<Long[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asLongArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Long
	 * @param element Élément JSON
	 * @return un dictionnaire de Long
	 */
	final public static Map<String, Long> asLongMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Long>();
		}

		return asLongMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Long
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Long
	 */
	final public static Map<String, Long> asLongMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Long>();
		}

		Map<String, Long> map = new HashMap<String, Long>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asLong(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Long
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Long
	 */
	final public static Map<String, Long[]> asLongArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Long[]>();
		}

		return asLongArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Long
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Long
	 */
	final public static Map<String, Long[]> asLongArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Long[]>();
		}

		Map<String, Long[]> map = new HashMap<String, Long[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asLongArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Long
	 * @param element Élément JSON
	 * @return un dictionnaire de données Long
	 */
	final public static Map<String, List<Long>> asLongListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Long>>();
		}

		return asLongListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Long
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Long
	 */
	final public static Map<String, List<Long>> asLongListMap(JsonObject jsonObject) {
		Map<String, List<Long>> dict = new HashMap<String, List<Long>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asLongList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Short
	 * @param element Élément JSON
	 * @return un Short (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static Short asShort(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsShort();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Short
	 * @param element Élément JSON
	 * @return un tableau de Short (null si vide)
	 */
	final public static Short[] asShortArray(JsonElement element) {
		return asShortArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Short
	 * @param array Liste JSON
	 * @return un tableau de Short (null si vide)
	 */
	final public static Short[] asShortArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Short[] vector = new Short[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asShort(array.get(i));
		}

		return vector;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Short
	 * @param element Élément JSON
	 * @return un short (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()", "(JsonElement) new JsonPrimitive(0)" }, process = false)
	final public static short asShortPrimitive(JsonElement element) {
		if (isEmpty(element)) {
			return ((short) 0);
		}
		
		return element.getAsShort();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Short
	 * @param element Élément JSON
	 * @return un tableau de short (null si vide)
	 */
	final public static short[] asShortPrimitiveArray(JsonElement element) {
		return asShortPrimitiveArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Short
	 * @param array Liste JSON
	 * @return un tableau de short (null si vide)
	 */
	final public static short[] asShortPrimitiveArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		short[] vector = new short[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asShortPrimitive(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Short
	 * @param element Élément JSON
	 * @return une liste de Short
	 */
	final public static List<Short> asShortList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Short>();
		}

		return asShortList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Short
	 * @param array Liste JSON
	 * @return une liste de Short
	 */
	final public static List<Short> asShortList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Short>();
		}

		List<Short> list = new ArrayList<Short>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asShort(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Short
	 * @param element Élément JSON
	 * @return une liste de tableaux Short
	 */
	final public static List<Short[]> asShortArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Short[]>();
		}

		return asShortArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Short
	 * @param array Liste JSON
	 * @return une liste de tableaux Short
	 */
	final public static List<Short[]> asShortArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Short[]>();
		}

		List<Short[]> list = new ArrayList<Short[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asShortArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Short
	 * @param element Élément JSON
	 * @return un dictionnaire de Short
	 */
	final public static Map<String, Short> asShortMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Short>();
		}

		return asShortMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Short
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Short
	 */
	final public static Map<String, Short> asShortMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Short>();
		}

		Map<String, Short> map = new HashMap<String, Short>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asShort(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Short
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Short
	 */
	final public static Map<String, Short[]> asShortArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Short[]>();
		}

		return asShortArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Short
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Short
	 */
	final public static Map<String, Short[]> asShortArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Short[]>();
		}

		Map<String, Short[]> map = new HashMap<String, Short[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asShortArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Short
	 * @param element Élément JSON
	 * @return un dictionnaire de données Short
	 */
	final public static Map<String, List<Short>> asShortListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Short>>();
		}

		return asShortListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Short
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Short
	 */
	final public static Map<String, List<Short>> asShortListMap(JsonObject jsonObject) {
		Map<String, List<Short>> dict = new HashMap<String, List<Short>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asShortList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON BigDecimal
	 * @param element Élément JSON
	 * @return un BigDecimal (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()" }, process = false)
	final public static BigDecimal asBigDecimal(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsBigDecimal();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON BigDecimal
	 * @param element Élément JSON
	 * @return un tableau de BigDecimal (null si vide)
	 */
	final public static BigDecimal[] asBigDecimalArray(JsonElement element) {
		return asBigDecimalArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON BigDecimal
	 * @param array Liste JSON
	 * @return un tableau de BigDecimal (null si vide)
	 */
	final public static BigDecimal[] asBigDecimalArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		BigDecimal[] vector = new BigDecimal[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asBigDecimal(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON BigDecimal
	 * @param element Élément JSON
	 * @return une liste de BigDecimal
	 */
	final public static List<BigDecimal> asBigDecimalList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<BigDecimal>();
		}

		return asBigDecimalList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON BigDecimal
	 * @param array Liste JSON
	 * @return une liste de BigDecimal
	 */
	final public static List<BigDecimal> asBigDecimalList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<BigDecimal>();
		}

		List<BigDecimal> list = new ArrayList<BigDecimal>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asBigDecimal(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux BigDecimal
	 * @param element Élément JSON
	 * @return une liste de tableaux BigDecimal
	 */
	final public static List<BigDecimal[]> asBigDecimalArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<BigDecimal[]>();
		}

		return asBigDecimalArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux BigDecimal
	 * @param array Liste JSON
	 * @return une liste de tableaux BigDecimal
	 */
	final public static List<BigDecimal[]> asBigDecimalArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<BigDecimal[]>();
		}

		List<BigDecimal[]> list = new ArrayList<BigDecimal[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asBigDecimalArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON BigDecimal
	 * @param element Élément JSON
	 * @return un dictionnaire de BigDecimal
	 */
	final public static Map<String, BigDecimal> asBigDecimalMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, BigDecimal>();
		}

		return asBigDecimalMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON BigDecimal
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de BigDecimal
	 */
	final public static Map<String, BigDecimal> asBigDecimalMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, BigDecimal>();
		}

		Map<String, BigDecimal> map = new HashMap<String, BigDecimal>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asBigDecimal(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux BigDecimal
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux BigDecimal
	 */
	final public static Map<String, BigDecimal[]> asBigDecimalArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, BigDecimal[]>();
		}

		return asBigDecimalArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux BigDecimal
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux BigDecimal
	 */
	final public static Map<String, BigDecimal[]> asBigDecimalArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, BigDecimal[]>();
		}

		Map<String, BigDecimal[]> map = new HashMap<String, BigDecimal[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asBigDecimalArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON BigDecimal
	 * @param element Élément JSON
	 * @return un dictionnaire de données BigDecimal
	 */
	final public static Map<String, List<BigDecimal>> asBigDecimalListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<BigDecimal>>();
		}

		return asBigDecimalListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON BigDecimal
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données BigDecimal
	 */
	final public static Map<String, List<BigDecimal>> asBigDecimalListMap(JsonObject jsonObject) {
		Map<String, List<BigDecimal>> dict = new HashMap<String, List<BigDecimal>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asBigDecimalList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONClassTemplate

	/**
	 * Extrait un élément JSON Date
	 * @param element Élément JSON
	 * @return un java.util.Date (null si vide)
	 */
	final public static java.util.Date asDate(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		return asDate(element.getAsString());
	}

	/**
	 * Conversion en Date
	 * @param value La valeur à convertir en Date
	 * @return un java.util.Date (null si vide)
	 */
	final public static java.util.Date asDate(String value) {
		if (OutilsBase.isEmpty(value)) {
			return null;
		}

		return asStringToDate(value);
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Date
	 * @param element Élément JSON
	 * @return un tableau de java.util.Date (null si vide)
	 */
	final public static java.util.Date[] asDateArray(JsonElement element) {
		return asDateArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Date
	 * @param array Liste JSON
	 * @return un tableau de java.util.Date (null si vide)
	 */
	final public static java.util.Date[] asDateArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		java.util.Date[] vector = new java.util.Date[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asDate(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Date
	 * @param element Élément JSON
	 * @return une liste de java.util.Date
	 */
	final public static List<java.util.Date> asDateList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<java.util.Date>();
		}

		return asDateList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Date
	 * @param array Liste JSON
	 * @return une liste de java.util.Date
	 */
	final public static List<java.util.Date> asDateList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<java.util.Date>();
		}

		List<java.util.Date> list = new ArrayList<java.util.Date>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asDate(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Date
	 * @param element Élément JSON
	 * @return une liste de tableaux Date
	 */
	final public static List<java.util.Date[]> asDateArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<java.util.Date[]>();
		}

		return asDateArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Date
	 * @param array Liste JSON
	 * @return une liste de tableaux Date
	 */
	final public static List<java.util.Date[]> asDateArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<java.util.Date[]>();
		}

		List<java.util.Date[]> list = new ArrayList<java.util.Date[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asDateArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Date
	 * @param element Élément JSON
	 * @return un dictionnaire de java.util.Date
	 */
	final public static Map<String, java.util.Date> asDateMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, java.util.Date>();
		}

		return asDateMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Date
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de java.util.Date
	 */
	final public static Map<String, java.util.Date> asDateMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, java.util.Date>();
		}

		Map<String, java.util.Date> map = new HashMap<String, java.util.Date>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asDate(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Date
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux java.util.Date
	 */
	final public static Map<String, java.util.Date[]> asDateArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, java.util.Date[]>();
		}

		return asDateArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Date
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux java.util.Date
	 */
	final public static Map<String, java.util.Date[]> asDateArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, java.util.Date[]>();
		}

		Map<String, java.util.Date[]> map = new HashMap<String, java.util.Date[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asDateArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Date
	 * @param element Élément JSON
	 * @return un dictionnaire de données java.util.Date
	 */
	final public static Map<String, List<java.util.Date>> asDateListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<java.util.Date>>();
		}

		return asDateListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Date
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données java.util.Date
	 */
	final public static Map<String, List<java.util.Date>> asDateListMap(JsonObject jsonObject) {
		Map<String, List<java.util.Date>> dict = new HashMap<String, List<java.util.Date>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asDateList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONClassTemplate

	/**
	 * Extrait un élément JSON Instant
	 * @param element Élément JSON
	 * @return un Instant (null si vide)
	 */
	final public static Instant asInstant(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		return asInstant(element.getAsString());
	}

	/**
	 * Conversion en Instant
	 * @param value La valeur à convertir en Instant
	 * @return un Instant (null si vide)
	 */
	final public static Instant asInstant(String value) {
		if (OutilsBase.isEmpty(value)) {
			return null;
		}

		return Instant.ofEpochSecond(asStringToLong(value));
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Instant
	 * @param element Élément JSON
	 * @return un tableau de Instant (null si vide)
	 */
	final public static Instant[] asInstantArray(JsonElement element) {
		return asInstantArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Instant
	 * @param array Liste JSON
	 * @return un tableau de Instant (null si vide)
	 */
	final public static Instant[] asInstantArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Instant[] vector = new Instant[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asInstant(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Instant
	 * @param element Élément JSON
	 * @return une liste de Instant
	 */
	final public static List<Instant> asInstantList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Instant>();
		}

		return asInstantList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Instant
	 * @param array Liste JSON
	 * @return une liste de Instant
	 */
	final public static List<Instant> asInstantList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Instant>();
		}

		List<Instant> list = new ArrayList<Instant>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asInstant(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Instant
	 * @param element Élément JSON
	 * @return une liste de tableaux Instant
	 */
	final public static List<Instant[]> asInstantArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Instant[]>();
		}

		return asInstantArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Instant
	 * @param array Liste JSON
	 * @return une liste de tableaux Instant
	 */
	final public static List<Instant[]> asInstantArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Instant[]>();
		}

		List<Instant[]> list = new ArrayList<Instant[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asInstantArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Instant
	 * @param element Élément JSON
	 * @return un dictionnaire de Instant
	 */
	final public static Map<String, Instant> asInstantMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Instant>();
		}

		return asInstantMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Instant
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Instant
	 */
	final public static Map<String, Instant> asInstantMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Instant>();
		}

		Map<String, Instant> map = new HashMap<String, Instant>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asInstant(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Instant
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Instant
	 */
	final public static Map<String, Instant[]> asInstantArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Instant[]>();
		}

		return asInstantArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Instant
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Instant
	 */
	final public static Map<String, Instant[]> asInstantArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Instant[]>();
		}

		Map<String, Instant[]> map = new HashMap<String, Instant[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asInstantArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Instant
	 * @param element Élément JSON
	 * @return un dictionnaire de données Instant
	 */
	final public static Map<String, List<Instant>> asInstantListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Instant>>();
		}

		return asInstantListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Instant
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Instant
	 */
	final public static Map<String, List<Instant>> asInstantListMap(JsonObject jsonObject) {
		Map<String, List<Instant>> dict = new HashMap<String, List<Instant>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asInstantList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON Object
	 * @param element Élément JSON
	 * @return un Object (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()" }, process = false)
	final public static Object asObject(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.toString();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Object
	 * @param element Élément JSON
	 * @return un tableau de Object (null si vide)
	 */
	final public static Object[] asObjectArray(JsonElement element) {
		return asObjectArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Object
	 * @param array Liste JSON
	 * @return un tableau de Object (null si vide)
	 */
	final public static Object[] asObjectArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Object[] vector = new Object[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asObject(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Object
	 * @param element Élément JSON
	 * @return une liste de Object
	 */
	final public static List<Object> asObjectList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Object>();
		}

		return asObjectList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Object
	 * @param array Liste JSON
	 * @return une liste de Object
	 */
	final public static List<Object> asObjectList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Object>();
		}

		List<Object> list = new ArrayList<Object>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asObject(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Object
	 * @param element Élément JSON
	 * @return une liste de tableaux Object
	 */
	final public static List<Object[]> asObjectArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Object[]>();
		}

		return asObjectArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Object
	 * @param array Liste JSON
	 * @return une liste de tableaux Object
	 */
	final public static List<Object[]> asObjectArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Object[]>();
		}

		List<Object[]> list = new ArrayList<Object[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asObjectArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Object
	 * @param element Élément JSON
	 * @return un dictionnaire de Object
	 */
	final public static Map<String, Object> asObjectMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Object>();
		}

		return asObjectMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Object
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Object
	 */
	final public static Map<String, Object> asObjectMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Object>();
		}

		Map<String, Object> map = new HashMap<String, Object>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asObject(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Object
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Object
	 */
	final public static Map<String, Object[]> asObjectArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Object[]>();
		}

		return asObjectArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Object
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Object
	 */
	final public static Map<String, Object[]> asObjectArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Object[]>();
		}

		Map<String, Object[]> map = new HashMap<String, Object[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asObjectArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Object
	 * @param element Élément JSON
	 * @return un dictionnaire de données Object
	 */
	final public static Map<String, List<Object>> asObjectListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Object>>();
		}

		return asObjectListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Object
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Object
	 */
	final public static Map<String, List<Object>> asObjectListMap(JsonObject jsonObject) {
		Map<String, List<Object>> dict = new HashMap<String, List<Object>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asObjectList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONClassTemplate

	/**
	 * Extrait un élément JSON SqlDate
	 * @param element Élément JSON
	 * @return un java.sql.Date (null si vide)
	 */
	final public static java.sql.Date asSqlDate(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		return asSqlDate(element.getAsString());
	}

	/**
	 * Conversion en SqlDate
	 * @param value La valeur à convertir en SqlDate
	 * @return un java.sql.Date (null si vide)
	 */
	final public static java.sql.Date asSqlDate(String value) {
		if (OutilsBase.isEmpty(value)) {
			return null;
		}

		return new java.sql.Date(asStringToDate(value).getTime());
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON SqlDate
	 * @param element Élément JSON
	 * @return un tableau de java.sql.Date (null si vide)
	 */
	final public static java.sql.Date[] asSqlDateArray(JsonElement element) {
		return asSqlDateArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON SqlDate
	 * @param array Liste JSON
	 * @return un tableau de java.sql.Date (null si vide)
	 */
	final public static java.sql.Date[] asSqlDateArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		java.sql.Date[] vector = new java.sql.Date[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asSqlDate(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON SqlDate
	 * @param element Élément JSON
	 * @return une liste de java.sql.Date
	 */
	final public static List<java.sql.Date> asSqlDateList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<java.sql.Date>();
		}

		return asSqlDateList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON SqlDate
	 * @param array Liste JSON
	 * @return une liste de java.sql.Date
	 */
	final public static List<java.sql.Date> asSqlDateList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<java.sql.Date>();
		}

		List<java.sql.Date> list = new ArrayList<java.sql.Date>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asSqlDate(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux SqlDate
	 * @param element Élément JSON
	 * @return une liste de tableaux SqlDate
	 */
	final public static List<java.sql.Date[]> asSqlDateArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<java.sql.Date[]>();
		}

		return asSqlDateArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux SqlDate
	 * @param array Liste JSON
	 * @return une liste de tableaux SqlDate
	 */
	final public static List<java.sql.Date[]> asSqlDateArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<java.sql.Date[]>();
		}

		List<java.sql.Date[]> list = new ArrayList<java.sql.Date[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asSqlDateArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON SqlDate
	 * @param element Élément JSON
	 * @return un dictionnaire de java.sql.Date
	 */
	final public static Map<String, java.sql.Date> asSqlDateMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, java.sql.Date>();
		}

		return asSqlDateMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON SqlDate
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de java.sql.Date
	 */
	final public static Map<String, java.sql.Date> asSqlDateMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, java.sql.Date>();
		}

		Map<String, java.sql.Date> map = new HashMap<String, java.sql.Date>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asSqlDate(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux SqlDate
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux java.sql.Date
	 */
	final public static Map<String, java.sql.Date[]> asSqlDateArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, java.sql.Date[]>();
		}

		return asSqlDateArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux SqlDate
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux java.sql.Date
	 */
	final public static Map<String, java.sql.Date[]> asSqlDateArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, java.sql.Date[]>();
		}

		Map<String, java.sql.Date[]> map = new HashMap<String, java.sql.Date[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asSqlDateArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON SqlDate
	 * @param element Élément JSON
	 * @return un dictionnaire de données java.sql.Date
	 */
	final public static Map<String, List<java.sql.Date>> asSqlDateListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<java.sql.Date>>();
		}

		return asSqlDateListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON SqlDate
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données java.sql.Date
	 */
	final public static Map<String, List<java.sql.Date>> asSqlDateListMap(JsonObject jsonObject) {
		Map<String, List<java.sql.Date>> dict = new HashMap<String, List<java.sql.Date>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asSqlDateList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONBuildInTemplate

	/**
	 * Extrait un élément JSON String
	 * @param element Élément JSON
	 * @return un String (null si vide)
	 */
	@AutomatedTests(value = { "(JsonElement) new JsonObject()" }, process = false)
	final public static String asString(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}
		
		return element.getAsString();
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON String
	 * @param element Élément JSON
	 * @return un tableau de String (null si vide)
	 */
	final public static String[] asStringArray(JsonElement element) {
		return asStringArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON String
	 * @param array Liste JSON
	 * @return un tableau de String (null si vide)
	 */
	final public static String[] asStringArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		String[] vector = new String[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asString(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON String
	 * @param element Élément JSON
	 * @return une liste de String
	 */
	final public static List<String> asStringList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<String>();
		}

		return asStringList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON String
	 * @param array Liste JSON
	 * @return une liste de String
	 */
	final public static List<String> asStringList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<String>();
		}

		List<String> list = new ArrayList<String>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asString(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux String
	 * @param element Élément JSON
	 * @return une liste de tableaux String
	 */
	final public static List<String[]> asStringArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<String[]>();
		}

		return asStringArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux String
	 * @param array Liste JSON
	 * @return une liste de tableaux String
	 */
	final public static List<String[]> asStringArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<String[]>();
		}

		List<String[]> list = new ArrayList<String[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asStringArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON String
	 * @param element Élément JSON
	 * @return un dictionnaire de String
	 */
	final public static Map<String, String> asStringMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, String>();
		}

		return asStringMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON String
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de String
	 */
	final public static Map<String, String> asStringMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, String>();
		}

		Map<String, String> map = new HashMap<String, String>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asString(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux String
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux String
	 */
	final public static Map<String, String[]> asStringArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, String[]>();
		}

		return asStringArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux String
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux String
	 */
	final public static Map<String, String[]> asStringArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, String[]>();
		}

		Map<String, String[]> map = new HashMap<String, String[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asStringArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON String
	 * @param element Élément JSON
	 * @return un dictionnaire de données String
	 */
	final public static Map<String, List<String>> asStringListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<String>>();
		}

		return asStringListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON String
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données String
	 */
	final public static Map<String, List<String>> asStringListMap(JsonObject jsonObject) {
		Map<String, List<String>> dict = new HashMap<String, List<String>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asStringList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONClassTemplate

	/**
	 * Extrait un élément JSON Time
	 * @param element Élément JSON
	 * @return un Time (null si vide)
	 */
	final public static Time asTime(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		return asTime(element.getAsString());
	}

	/**
	 * Conversion en Time
	 * @param value La valeur à convertir en Time
	 * @return un Time (null si vide)
	 */
	final public static Time asTime(String value) {
		if (OutilsBase.isEmpty(value)) {
			return null;
		}

		return new Time(asStringToDate(value).getTime());
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Time
	 * @param element Élément JSON
	 * @return un tableau de Time (null si vide)
	 */
	final public static Time[] asTimeArray(JsonElement element) {
		return asTimeArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Time
	 * @param array Liste JSON
	 * @return un tableau de Time (null si vide)
	 */
	final public static Time[] asTimeArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Time[] vector = new Time[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asTime(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Time
	 * @param element Élément JSON
	 * @return une liste de Time
	 */
	final public static List<Time> asTimeList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Time>();
		}

		return asTimeList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Time
	 * @param array Liste JSON
	 * @return une liste de Time
	 */
	final public static List<Time> asTimeList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Time>();
		}

		List<Time> list = new ArrayList<Time>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asTime(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Time
	 * @param element Élément JSON
	 * @return une liste de tableaux Time
	 */
	final public static List<Time[]> asTimeArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Time[]>();
		}

		return asTimeArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Time
	 * @param array Liste JSON
	 * @return une liste de tableaux Time
	 */
	final public static List<Time[]> asTimeArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Time[]>();
		}

		List<Time[]> list = new ArrayList<Time[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asTimeArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Time
	 * @param element Élément JSON
	 * @return un dictionnaire de Time
	 */
	final public static Map<String, Time> asTimeMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Time>();
		}

		return asTimeMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Time
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Time
	 */
	final public static Map<String, Time> asTimeMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Time>();
		}

		Map<String, Time> map = new HashMap<String, Time>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asTime(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Time
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Time
	 */
	final public static Map<String, Time[]> asTimeArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Time[]>();
		}

		return asTimeArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Time
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Time
	 */
	final public static Map<String, Time[]> asTimeArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Time[]>();
		}

		Map<String, Time[]> map = new HashMap<String, Time[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asTimeArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Time
	 * @param element Élément JSON
	 * @return un dictionnaire de données Time
	 */
	final public static Map<String, List<Time>> asTimeListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Time>>();
		}

		return asTimeListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Time
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Time
	 */
	final public static Map<String, List<Time>> asTimeListMap(JsonObject jsonObject) {
		Map<String, List<Time>> dict = new HashMap<String, List<Time>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asTimeList(entry.getValue()));
			}
		}

		return dict;
	}


	// AsJSONClassTemplate

	/**
	 * Extrait un élément JSON Timestamp
	 * @param element Élément JSON
	 * @return un Timestamp (null si vide)
	 */
	final public static Timestamp asTimestamp(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		return asTimestamp(element.getAsString());
	}

	/**
	 * Conversion en Timestamp
	 * @param value La valeur à convertir en Timestamp
	 * @return un Timestamp (null si vide)
	 */
	final public static Timestamp asTimestamp(String value) {
		if (OutilsBase.isEmpty(value)) {
			return null;
		}

		return new Timestamp(asStringToDate(value).getTime());
	}


	// AsJSONArrayTemplate

	/**
	 * Extrait un tableau d'éléments JSON Timestamp
	 * @param element Élément JSON
	 * @return un tableau de Timestamp (null si vide)
	 */
	final public static Timestamp[] asTimestampArray(JsonElement element) {
		return asTimestampArray(getAsJsonArray(element));
	}

	/**
	 * Extrait un tableau d'éléments JSON Timestamp
	 * @param array Liste JSON
	 * @return un tableau de Timestamp (null si vide)
	 */
	final public static Timestamp[] asTimestampArray(JsonArray array) {
		if (isEmpty(array)) {
			return null;
		}

		Timestamp[] vector = new Timestamp[array.size()];

		for (int i = 0; i < array.size(); i++) {
			vector[i] = asTimestamp(array.get(i));
		}

		return vector;
	}


	// AsJSONListTemplate

	/**
	 * Extrait une liste d'éléments JSON Timestamp
	 * @param element Élément JSON
	 * @return une liste de Timestamp
	 */
	final public static List<Timestamp> asTimestampList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Timestamp>();
		}

		return asTimestampList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON Timestamp
	 * @param array Liste JSON
	 * @return une liste de Timestamp
	 */
	final public static List<Timestamp> asTimestampList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Timestamp>();
		}

		List<Timestamp> list = new ArrayList<Timestamp>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asTimestamp(array.get(i)));
		}

		return list;
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Timestamp
	 * @param element Élément JSON
	 * @return une liste de tableaux Timestamp
	 */
	final public static List<Timestamp[]> asTimestampArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<Timestamp[]>();
		}

		return asTimestampArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON de tableaux Timestamp
	 * @param array Liste JSON
	 * @return une liste de tableaux Timestamp
	 */
	final public static List<Timestamp[]> asTimestampArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<Timestamp[]>();
		}

		List<Timestamp[]> list = new ArrayList<Timestamp[]>();

		for (int i = 0; i < array.size(); i++) {
			list.add(asTimestampArray(array.get(i)));
		}

		return list;
	}
	


	// AsJSONMapTemplate

	/**
	 * Extrait un dictionnaire d'éléments JSON Timestamp
	 * @param element Élément JSON
	 * @return un dictionnaire de Timestamp
	 */
	final public static Map<String, Timestamp> asTimestampMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Timestamp>();
		}

		return asTimestampMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Timestamp
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de Timestamp
	 */
	final public static Map<String, Timestamp> asTimestampMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Timestamp>();
		}

		Map<String, Timestamp> map = new HashMap<String, Timestamp>();

		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asTimestamp(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Timestamp
	 * @param element Élément JSON
	 * @return un dictionnaire de tableaux Timestamp
	 */
	final public static Map<String, Timestamp[]> asTimestampArrayMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, Timestamp[]>();
		}

		return asTimestampArrayMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON de tableaux Timestamp
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de tableaux Timestamp
	 */
	final public static Map<String, Timestamp[]> asTimestampArrayMap(JsonObject object) {
		if (isEmpty(object)) {
			return new HashMap<String, Timestamp[]>();
		}

		Map<String, Timestamp[]> map = new HashMap<String, Timestamp[]>();


		Iterator<Map.Entry<String, JsonElement>> iterator = object.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Map.Entry<String, JsonElement> entry = iterator.next();
			map.put(entry.getKey(), asTimestampArray(entry.getValue()));
		}

		return map;
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Timestamp
	 * @param element Élément JSON
	 * @return un dictionnaire de données Timestamp
	 */
	final public static Map<String, List<Timestamp>> asTimestampListMap(JsonElement element) {
		if (isEmpty(element)) {
			return new HashMap<String, List<Timestamp>>();
		}

		return asTimestampListMap(getAsJsonObject(element));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON Timestamp
	 * @param object Objet JSON du dictionnaire
	 * @return un dictionnaire de données Timestamp
	 */
	final public static Map<String, List<Timestamp>> asTimestampListMap(JsonObject jsonObject) {
		Map<String, List<Timestamp>> dict = new HashMap<String, List<Timestamp>>();

		if (!isEmpty(jsonObject)) {
			Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, JsonElement> entry = iterator.next();
				dict.put(entry.getKey(), asTimestampList(entry.getValue()));
			}
		}

		return dict;
	}

}
