package outils.gson;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import json.types.JSONTypes;
import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.AddImportsForTesting;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.StrictAutomatedTests;
import outils.types.FilesCharsetsTypes;

/**
 * Classe des méthodes utilitaires pour gson de type final public static
 * @author Claude Toupin - 31 oct. 2019
 */
@AddImportsForTesting(classes.outils.POJODataTestClass.class)
public class OutilsGson {
	/**
	 * Modifie le format de la date au format par défaut d'une instance de GsonBuilder donnée
	 * @param gsonBuilder Instance de GsonBuilder à modifier
	 * @return l'instance de GsonBuilder
	 */
	final public static GsonBuilder setDateFormat(GsonBuilder gsonBuilder) {
		return setDateFormat(gsonBuilder, null);
	}

	/**
	 * Modifie le format de la date d'une instance de GsonBuilder donnée
	 * @param gsonBuilder Instance de GsonBuilder à modifier
	 * @param dateFormat Le format de la date (defaut: yyyy-MM-dd HH:mm:ss)
	 * @return l'instance de GsonBuilder
	 */
	final public static GsonBuilder setDateFormat(GsonBuilder gsonBuilder, String dateFormat) {
		if (gsonBuilder != null) {
			gsonBuilder.setDateFormat(OutilsBase.isEmpty(dateFormat) ? "yyyy-MM-dd HH:mm:ss" : dateFormat);
		}

		return gsonBuilder;
	}

	/**
	 * Indique la conversion des caractères en format html
	 * @param gsonBuilder Instance de GsonBuilder à modifier
	 * @return l'instance de GsonBuilder
	 */
	final public static GsonBuilder setHtmlEscaping(GsonBuilder gsonBuilder) {
		return setHtmlEscaping(gsonBuilder, false);
	}

	/**
	 * Indique la conversion des caractères en format html
	 * @param gsonBuilder Instance de GsonBuilder à modifier
	 * @param htmlEscaping Indicateur de conversion des caractères en format html
	 * @return l'instance de GsonBuilder
	 */
	final public static GsonBuilder setHtmlEscaping(GsonBuilder gsonBuilder, boolean htmlEscaping) {
		if (gsonBuilder != null) {
			if (!htmlEscaping) {
				gsonBuilder.disableHtmlEscaping();
			}
		}

		return gsonBuilder;
	}

	/**
	 * Indique le mode d'impression élégante d'une instance de GsonBuilder donnée
	 * @param gsonBuilder Instance de GsonBuilder à modifier
	 * @return l'instance de GsonBuilder
	 */
	final public static GsonBuilder setPrettyPrinting(GsonBuilder gsonBuilder) {
		return setPrettyPrinting(gsonBuilder, true);
	}

	/**
	 * Indique le mode d'impression élégante d'une instance de GsonBuilder donnée
	 * @param gsonBuilder Instance de GsonBuilder à modifier
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return l'instance de GsonBuilder
	 */
	final public static GsonBuilder setPrettyPrinting(GsonBuilder gsonBuilder, boolean prettyPrinting) {
		if (gsonBuilder != null) {
			if (prettyPrinting) {
				gsonBuilder.setPrettyPrinting();
			}
		}

		return gsonBuilder;
	}

	/**
	 * Ajout des adaptateurs des types de classes d'une instance de GsonBuilder donnée
	 * @param gsonBuilder Instance de GsonBuilder à ajouter
	 * @return l'instance de GsonBuilder
	 */
	final public static GsonBuilder registerTypeAdapters(GsonBuilder gsonBuilder) {
		if (gsonBuilder != null) {
			gsonBuilder //
					.registerTypeAdapter(Class.class, new JsonSerializer<Class<?>>() {

						@Override
						public JsonElement serialize(Class<?> src, Type typeOfSrc, JsonSerializationContext context) {
							if (src == null) {
								return JsonNull.INSTANCE;
							}

							return new JsonPrimitive(src.toString());
						}
					}) //
					.registerTypeAdapter(Package.class, new JsonSerializer<Package>() {

						@Override
						public JsonElement serialize(Package src, Type typeOfSrc, JsonSerializationContext context) {
							if (src == null) {
								return JsonNull.INSTANCE;
							}

							return new JsonPrimitive(src.getName());
						}
					}) //
					.registerTypeAdapter(Field.class, new JsonSerializer<Field>() {

						@Override
						public JsonElement serialize(Field src, Type typeOfSrc, JsonSerializationContext context) {
							if (src == null) {
								return JsonNull.INSTANCE;
							}

							return new JsonPrimitive(src.toString());
						}
					}) //
					.registerTypeAdapter(Constructor.class, new JsonSerializer<Constructor<?>>() {

						@Override
						public JsonElement serialize(Constructor<?> src, Type typeOfSrc, JsonSerializationContext context) {
							if (src == null) {
								return JsonNull.INSTANCE;
							}

							return new JsonPrimitive(src.toString());
						}
					}) //
					.registerTypeAdapter(Method.class, new JsonSerializer<Method>() {

						@Override
						public JsonElement serialize(Method src, Type typeOfSrc, JsonSerializationContext context) {
							if (src == null) {
								return JsonNull.INSTANCE;
							}

							return new JsonPrimitive(src.toString());
						}
					}) //
			;
		}

		return gsonBuilder;
	}

	/**
	 * Création d'une instance de GsonBuilder
	 * @return une instance de GsonBuilder
	 */
	final public static GsonBuilder createGsonBuilder() {
		return createGsonBuilder(null, false, false);
	}

	/**
	 * Création d'une instance de GsonBuilder
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return une instance de GsonBuilder
	 */
	final public static GsonBuilder createGsonBuilder(boolean prettyPrinting) {
		return createGsonBuilder(null, false, prettyPrinting);
	}

	/**
	 * Création d'une instance de GsonBuilder
	 * @param dateFormat Le format de la date
	 * @return une instance de GsonBuilder
	 */
	final public static GsonBuilder createGsonBuilder(String dateFormat) {
		return createGsonBuilder(dateFormat, false, false);
	}

	/**
	 * Création d'une instance de GsonBuilder
	 * @param dateFormat Le format de la date
	 * @param htmlEscaping Indicateur de conversion des caractères en format html
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return une instance de GsonBuilder
	 */
	final public static GsonBuilder createGsonBuilder(String dateFormat, boolean htmlEscaping, boolean prettyPrinting) {
		GsonBuilder gsonBuilder = new GsonBuilder();

		setDateFormat(gsonBuilder, dateFormat);
		setHtmlEscaping(gsonBuilder, htmlEscaping);
		setPrettyPrinting(gsonBuilder, prettyPrinting);
		registerTypeAdapters(gsonBuilder);

		return gsonBuilder;
	}

	/**
	 * Création d'une instance de Gson
	 * @return une instance de Gson
	 */
	final public static Gson createGson() {
		return createGsonBuilder().create();
	}

	/**
	 * Création d'une instance de Gson
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return une instance de Gson
	 */
	final public static Gson createGson(boolean prettyPrinting) {
		return createGsonBuilder(prettyPrinting).create();
	}

	/**
	 * Création d'une instance de Gson
	 * @param dateFormat Le format de la date
	 * @return une instance de Gson
	 */
	final public static Gson createGson(String dateFormat) {
		return createGsonBuilder(dateFormat).create();
	}

	/**
	 * Création d'une instance de Gson
	 * @param dateFormat Le format de la date
	 * @param htmlEscaping Indicateur de conversion des caractères en format html
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return une instance de Gson
	 */
	final public static Gson createGson(String dateFormat, boolean htmlEscaping, boolean prettyPrinting) {
		return createGsonBuilder(dateFormat, htmlEscaping, prettyPrinting).create();
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param src L'objet source à convertir
	 * @return la notation json (null si src == null)
	 */
	@AutomatedTests(value = { "POJODataTestClass.class", "POJODataTestClass.class.getPackage()", "POJODataTestClass.class.getField(\"str\")", "POJODataTestClass.class.getConstructor(String.class, int.class, java.util.Date.class, Long.class)", "POJODataTestClass.class.getMethod(\"equals\", Object.class)" }, process = false)
	final public static String toJson(Object src) {
		return toJson(src, null, false, false);
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param src L'objet source à convertir
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return la notation json (null si src == null)
	 */
	final public static String toJson(Object src, boolean prettyPrinting) {
		return toJson(src, null, false, prettyPrinting);
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param src L'objet source à convertir
	 * @param dateFormat Le format de la date
	 * @return la notation json (null si src == null)
	 */
	final public static String toJson(Object src, String dateFormat) {
		return toJson(src, dateFormat, false, false);
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param src L'objet source à convertir
	 * @param dateFormat Le format de la date
	 * @param htmlEscaping Indicateur de conversion des caractères en format html
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return la notation json (null si src == null)
	 */
	final public static String toJson(Object src, String dateFormat, boolean htmlEscaping, boolean prettyPrinting) {
		if (src != null) {
			return createGson(dateFormat, htmlEscaping, prettyPrinting).toJson(src);
		}

		return null;
	}

	/**
	 * Convertit une valeur de type String en format json
	 * @param value Valeur à convertir
	 * @return "value" (null si value == null)
	 */
	final public static String asJson(String value) {
		if (value == null) {
			return null;
		}

		return "\"" + value.replace("\\", "\\\\") + "\"";
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param name Nom du champ
	 * @param src L'objet source à convertir
	 * @return la notation json (null si src == null)
	 */
	final public static String toJson(String name, Object src) {
		if (OutilsBase.isEmpty(name)) {
			return toJson(src);
		}

		return asJson(name) + ":" + toJson(src, null, false, false);
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param name Nom du champ
	 * @param src L'objet source à convertir
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return la notation json (null si src == null)
	 */
	final public static String toJson(String name, Object src, boolean prettyPrinting) {
		if (OutilsBase.isEmpty(name)) {
			return toJson(src, prettyPrinting);
		}

		return asJson(name) + ":" + toJson(src, null, false, prettyPrinting);
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param name Nom du champ
	 * @param src L'objet source à convertir
	 * @param dateFormat Le format de la date
	 * @return la notation json (null si src == null)
	 */
	final public static String toJson(String name, Object src, String dateFormat) {
		if (OutilsBase.isEmpty(name)) {
			return toJson(src, dateFormat);
		}

		return asJson(name) + ":" + toJson(src, dateFormat, false, false);
	}

	/**
	 * Conversion en notation json d'un objet source donné
	 * @param name Nom du champ
	 * @param src L'objet source à convertir
	 * @param dateFormat Le format de la date
	 * @param htmlEscaping Indicateur de conversion des caractères en format html
	 * @param prettyPrinting Indicateur d'impression élégante
	 * @return la notation json (null si src == null)
	 */
	final public static String toJson(String name, Object src, String dateFormat, boolean htmlEscaping, boolean prettyPrinting) {
		if (src != null) {
			if (OutilsBase.isEmpty(name)) {
				return toJson(src, dateFormat, htmlEscaping, prettyPrinting);
			}

			return asJson(name) + ":" + createGson(dateFormat, htmlEscaping, prettyPrinting).toJson(src);
		}

		return null;
	}

	/**
	 * Charge un élément gson à partir d'un fichier
	 * @param filename Nom du fichier
	 * @return l'élément json
	 * @throws IOException en cas d'erreur
	 */
	@StrictAutomatedTests(value = "OutilsGson1.json", filenames = 0)
	final public static JsonElement loadJsonElementsListFromFile(String filename) throws IOException {
		return JsonParser.parseString(OutilsCommun.loadFromFile(filename));
	}

	/**
	 * Charge un élément gson à partir d'un fichier
	 * @param filename Nom du fichier
	 * @param charsetType Type de jeu de caractères
	 * @return la liste des éléments json
	 * @throws IOException en cas d'erreur
	 */
	@StrictAutomatedTests(value = { "OutilsGson1.json", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static JsonElement loadJsonElementsListFromFile(String filename, FilesCharsetsTypes charsetType) throws IOException {
		return JsonParser.parseString(OutilsCommun.loadFromFile(filename, charsetType));
	}

	/**
	 * Charge un élément gson à partir d'un fichier
	 * @param file Fichier
	 * @return la liste des éléments json
	 * @throws IOException en cas d'erreur
	 */
	@StrictAutomatedTests(value = "OutilsGson2.json", filenames = 0)
	final public static JsonElement loadJsonElementsListFromFile(File file) throws IOException {
		return JsonParser.parseString(OutilsCommun.loadFromFile(file));
	}

	/**
	 * Charge un élément gson à partir d'un fichier
	 * @param file Fichier
	 * @param charsetType Type de jeu de caractères
	 * @return la liste des éléments json
	 * @throws IOException en cas d'erreur
	 */
	@StrictAutomatedTests(value = { "OutilsGson2.json", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static JsonElement loadJsonElementsListFromFile(File file, FilesCharsetsTypes charsetType) throws IOException {
		return JsonParser.parseString(OutilsCommun.loadFromFile(file, charsetType));
	}

	/**
	 * Charge un élément gson à partir d'un fichier
	 * @param inputStream Flux de données
	 * @return la liste des éléments json
	 * @throws IOException en cas d'erreur
	 */
	@StrictAutomatedTests(value = "OutilsGson1.json", filenames = 0)
	final public static JsonElement loadJsonElementsListFromFile(InputStream inputStream) throws IOException {
		return JsonParser.parseString(OutilsCommun.loadFromFile(inputStream));
	}

	/**
	 * Charge un élément gson à partir d'un fichier
	 * @param inputStream Flux de données
	 * @param charsetType Type de jeu de caractères
	 * @return la liste des éléments json
	 * @throws IOException en cas d'erreur
	 */
	@StrictAutomatedTests(value = { "OutilsGson1.json", "FilesCharsetsTypes.UTF_8" }, filenames = 0)
	final public static JsonElement loadJsonElementsListFromFile(InputStream inputStream, FilesCharsetsTypes charsetType) throws IOException {
		return JsonParser.parseString(OutilsCommun.loadFromFile(inputStream, charsetType));
	}

	/**
	 * Fusion de 2 objets json
	 * @param source1 L'objet json 1 à fusionner
	 * @param source2 L'objet json 2 à fusionner
	 * @return la fusion des 2 objets json
	 */
	@StrictAutomatedTests(value = { ",new JsonObject()", ",new JsonObject()" }, iterate = true)
	final public static JsonObject mergeJsonObjects(JsonObject source1, JsonObject source2) {
		if (OutilsBase.areNulls(source1, source2)) {
			return null;
		} else if (source1 == null) {
			return source2;
		} else if (source2 == null) {
			return source1;
		}

		JsonObject merge = new JsonObject();

		Map<String, Map.Entry<String, JsonElement>> dict2 = new HashMap<String, Map.Entry<String, JsonElement>>();

		Iterator<Map.Entry<String, JsonElement>> iteratorSource2 = source2.entrySet().iterator();

		while (iteratorSource2.hasNext()) {
			Map.Entry<String, JsonElement> entrySource2 = iteratorSource2.next();
			dict2.put(entrySource2.getKey(), entrySource2);
		}

		Iterator<Map.Entry<String, JsonElement>> iteratorSource1 = source1.entrySet().iterator();

		while (iteratorSource1.hasNext()) {
			Map.Entry<String, JsonElement> entrySource1 = iteratorSource1.next();
			Map.Entry<String, JsonElement> entryDict2 = dict2.get(entrySource1.getKey());

			JsonElement jsonElementSource1 = entrySource1.getValue();

			if (entryDict2 == null) {
				if (jsonElementSource1.isJsonArray()) {
					merge.add(entrySource1.getKey(), mergeJsonArray(jsonElementSource1.getAsJsonArray()));
				} else {
					merge.add(entrySource1.getKey(), jsonElementSource1);
				}
			} else {
				JsonElement jsonElementDict2 = entryDict2.getValue();

				if (jsonElementSource1.isJsonNull() && jsonElementDict2.isJsonNull()) {
					merge.add(entrySource1.getKey(), jsonElementSource1);
				} else if (jsonElementSource1.isJsonPrimitive() && jsonElementDict2.isJsonPrimitive()) {
					merge.add(entrySource1.getKey(), JSONTypes.getPromotedPrimitive(jsonElementSource1.getAsJsonPrimitive(), jsonElementDict2.getAsJsonPrimitive()));
				} else if (jsonElementSource1.isJsonArray() && jsonElementDict2.isJsonArray()) {
					merge.add(entrySource1.getKey(), mergeJsonArrays(jsonElementSource1.getAsJsonArray(), jsonElementDict2.getAsJsonArray()));
				} else if (jsonElementSource1.isJsonObject() && jsonElementDict2.isJsonObject()) {
					merge.add(entrySource1.getKey(), mergeJsonObjects(jsonElementSource1.getAsJsonObject(), jsonElementDict2.getAsJsonObject()));
				} else {
					throw new RuntimeException("Types différents pour \"" + entrySource1.getKey() + "\": " + jsonElementSource1 + " et " + jsonElementDict2);
				}

				dict2.remove(entrySource1.getKey());
			}
		}

		Iterator<String> iteratorDict2 = dict2.keySet().iterator();

		while (iteratorDict2.hasNext()) {
			Map.Entry<String, JsonElement> entryDict2 = dict2.get(iteratorDict2.next());
			merge.add(entryDict2.getKey(), entryDict2.getValue());
		}

		return merge;
	}

	/**
	 * Fusion de 2 listes json
	 * @param source1 La liste json 1 à fusionner
	 * @param source2 La liste json 2 à fusionner
	 * @return la fusion des 2 listes json
	 */
	@SuppressWarnings("deprecation")
	@StrictAutomatedTests(value = { ",new JsonArray()", ",new JsonArray()" }, iterate = true)
	final public static JsonArray mergeJsonArrays(JsonArray source1, JsonArray source2) {
		if (OutilsBase.areNulls(source1, source2)) {
			return null;
		} else if (source1 == null) {
			return mergeJsonArray(source2);
		} else if (source2 == null) {
			return mergeJsonArray(source1);
		}

		source1 = mergeJsonArray(source1);
		source2 = mergeJsonArray(source2);

		if (JSONTypes.isJsonPrimitiveArray(source1) && JSONTypes.isJsonPrimitiveArray(source2)) {
			JsonPrimitive jsonPrimitive = null;

			Iterator<JsonElement> iteratorSource1 = source1.iterator();

			while (iteratorSource1.hasNext()) {
				JsonElement jsonElement1 = iteratorSource1.next();

				if (jsonElement1.isJsonPrimitive()) {
					jsonPrimitive = JSONTypes.getPromotedPrimitive(jsonElement1.getAsJsonPrimitive(), jsonPrimitive);
				}
			}

			Iterator<JsonElement> iteratorSource2 = source2.iterator();

			while (iteratorSource2.hasNext()) {
				JsonElement jsonElement2 = iteratorSource2.next();

				if (jsonElement2.isJsonPrimitive()) {
					jsonPrimitive = JSONTypes.getPromotedPrimitive(jsonElement2.getAsJsonPrimitive(), jsonPrimitive);
				}
			}

			JsonArray array = new JsonArray();

			// Le constructeur JsonNull() est deprecated ???
			array.add((jsonPrimitive == null) ? new JsonNull() : jsonPrimitive);

			return array;
		} else if (JSONTypes.isJsonObjectArray(source1) && JSONTypes.isJsonObjectArray(source2)) {
			if ((source1.size() == 1) && (source2.size() == 1)) {
				JsonArray array = new JsonArray();

				array.add(mergeJsonObjects(source1.get(0).getAsJsonObject(), source2.get(0).getAsJsonObject()));

				return array;
			} else {
				throw new RuntimeException("pas de traitement pour 2 JsonObject de taille " + source1.size() + " et " + source2.size() + " pour: " + source1 + " et " + source1);
			}
		} else if (JSONTypes.isJsonArrayArray(source1) && JSONTypes.isJsonArrayArray(source2)) {
			if ((source1.size() == 1) && (source2.size() == 1)) {
				JsonArray array = new JsonArray();

				array.add(mergeJsonArrays(source1.get(0).getAsJsonArray(), source2.get(0).getAsJsonArray()));

				return array;
			} else {
				throw new RuntimeException("pas de traitement pour 2 JsonArray de taille " + source1.size() + " et " + source2.size() + " pour: " + source1 + " et " + source1);
			}
		}

		throw new RuntimeException("Types différents pour: " + source1 + " et " + source1);
	}

	/**
	 * Fusion des objets d'une liste json
	 * @param source La liste json à à fusionner
	 * @return la fusion de la liste json
	 */
	@StrictAutomatedTests(value = ",new JsonArray()", iterate = true)
	final public static JsonArray mergeJsonArray(JsonArray source) {
		if (source == null) {
			return null;
		}

		JsonNull jsonNull = null;
		JsonPrimitive jsonPrimitive = null;
		JsonArray jsonArray = null;

		List<String> jsonObjectKeysList = new ArrayList<String>();
		Map<String, JsonElement> jsonObjectDict = new HashMap<String, JsonElement>();

		Iterator<JsonElement> iteratorSource = source.iterator();

		while (iteratorSource.hasNext()) {
			JsonElement jsonElement = iteratorSource.next();

			if (jsonElement.isJsonNull()) {
				jsonNull = jsonElement.getAsJsonNull();
			} else if (jsonElement.isJsonPrimitive()) {
				jsonPrimitive = JSONTypes.getPromotedPrimitive(jsonElement.getAsJsonPrimitive(), jsonPrimitive);
			} else if (jsonElement.isJsonObject()) {
				JsonObject jsonObject = jsonElement.getAsJsonObject();

				Iterator<Map.Entry<String, JsonElement>> iteratorObject = jsonObject.entrySet().iterator();

				while (iteratorObject.hasNext()) {
					Map.Entry<String, JsonElement> entryObject = iteratorObject.next();

					if (jsonObjectDict.containsKey(entryObject.getKey())) {
						JsonElement jsonElementDict = jsonObjectDict.get(entryObject.getKey());

						if (entryObject.getValue().isJsonNull() && jsonElementDict.isJsonNull()) {
							// Rien à faire
						} else if (entryObject.getValue().isJsonPrimitive() && jsonElementDict.isJsonPrimitive()) {
							JsonPrimitive jsonPrimitive1 = entryObject.getValue().getAsJsonPrimitive();
							JsonPrimitive jsonPrimitive2 = jsonElementDict.getAsJsonPrimitive();

							jsonObjectDict.put(entryObject.getKey(), JSONTypes.getPromotedPrimitive(jsonPrimitive1, jsonPrimitive2));
						} else if (entryObject.getValue().isJsonObject() && jsonElementDict.isJsonObject()) {
							JsonObject jsonObject1 = entryObject.getValue().getAsJsonObject();
							JsonObject jsonObject2 = jsonElementDict.getAsJsonObject();

							jsonObjectDict.put(entryObject.getKey(), mergeJsonObjects(jsonObject1, jsonObject2));
						} else if (entryObject.getValue().isJsonArray() && jsonElementDict.isJsonArray()) {
							JsonArray jsonArray1 = entryObject.getValue().getAsJsonArray();
							JsonArray jsonArray2 = jsonElementDict.getAsJsonArray();

							jsonObjectDict.put(entryObject.getKey(), mergeJsonArrays(jsonArray1, jsonArray2));
						} else {
							throw new RuntimeException("Types différents pour \"" + entryObject.getKey() + "\": " + entryObject.getValue() + " et " + jsonElementDict);
						}
					} else {
						jsonObjectKeysList.add(entryObject.getKey());
						jsonObjectDict.put(entryObject.getKey(), entryObject.getValue());
					}
				}
			} else if (jsonElement.isJsonArray()) {
				jsonArray = mergeJsonArrays(jsonElement.getAsJsonArray(), jsonArray);
			} else
				throw new RuntimeException("Pas de traitement pour " + jsonElement);
		}

		if (((jsonNull != null) ? 1 : 0) + ((jsonPrimitive != null) ? 1 : 0) + ((jsonArray != null) ? 1 : 0) + (((!jsonObjectKeysList.isEmpty()) ? 1 : 0)) > 1) {
			throw new RuntimeException("Array hybride composé de divers types d'éléments json: " + source);
		}

		JsonArray array = new JsonArray();

		if (jsonNull != null) {
			array.add(jsonNull);
		} else if (jsonPrimitive != null) {
			array.add(jsonPrimitive);
		} else if (jsonArray != null) {
			array.add(jsonArray);
		} else if (!jsonObjectKeysList.isEmpty()) {
			JsonObject object = new JsonObject();

			for (String key : jsonObjectKeysList) {
				object.add(key, jsonObjectDict.get(key));
			}

			array.add(object);
		}

		return array;
	}

}
