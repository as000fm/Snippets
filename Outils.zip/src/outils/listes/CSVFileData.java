package outils.listes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;

/**
 * Classe des données d'un fichier CSV
 * @author Claude Toupin - 1 juin 2021
 */
public class CSVFileData {
	/** Entête des colonnes **/
	private String[] header;

	/** Données des rangées **/
	private List<String[]> rows;

	/**
	 * Constructeur de base
	 */
	public CSVFileData() {
		this(new String[] {}, new ArrayList<String[]>());
	}

	/**
	 * Constructeur de base
	 * @param header Entête des colonnes
	 * @param rows Données des rangées
	 */
	public CSVFileData(String[] header, List<String[]> rows) {
		this.header = header;
		this.rows = rows;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CSVFileData [header=" + Arrays.toString(header) + ", rows=" + rows + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof CSVFileData) {
				CSVFileData csvFileData = (CSVFileData) obj;

				return OutilsBase.areEquals(header, csvFileData.getHeader()) //
						&& OutilsBase.areEquals(rows, csvFileData.getRows()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(header);
		result = prime * result + Objects.hash(rows);
		return result;
	}

	/**
	 * Extrait le champ header
	 * @return un String[]
	 */
	public String[] getHeader() {
		return header;
	}

	/**
	 * Modifie le champ header
	 * @param header La valeur du champ header
	 */
	public void setHeader(String[] header) {
		this.header = header;
	}

	/**
	 * Extrait le champ rows
	 * @return un List<String[]>
	 */
	public List<String[]> getRows() {
		return rows;
	}

	/**
	 * Modifie le champ rows
	 * @param rows La valeur du champ rows
	 */
	public void setRows(List<String[]> rows) {
		this.rows = rows;
	}
}
