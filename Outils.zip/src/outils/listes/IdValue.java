package outils.listes;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;

/**
 * Classe qui contient l'information d'une paire Id-Value.
 * @author Claude Toupin - 13 oct. 2021
 */
@CoverageTestsCases(IdValue.CoverageTestsCases.class)
public class IdValue implements java.io.Serializable {
	private static final long serialVersionUID = -6292099067234231863L;

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 4 févr. 2023
	 */
	public static final class CoverageTestsCases implements ICoverageTestsCases {

		/*
		 * (non-Javadoc)
		 * @see outils.tests.automated.ICoverageTestsCases#doBeforeAll()
		 */
		@Override
		public void doBeforeAll() throws Exception {
			List<IdValue> list = OutilsBase.asList(new IdValue("1=A"), new IdValue("2"), new IdValue(1, "a"), new IdValue(4, "b"));

			list.sort(new IdValue.Compare());
			list.sort(new IdValue.Compare(false));
			list.sort(new IdValue.Compare(false, false));

			new IdValue.Compare().isAscendant();
		}

		/*
		 * (non-Javadoc)
		 * @see outils.tests.automated.ICoverageTestsCases#doAfterAll()
		 */
		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/** Classe pour les tris de liste de NameValue **/
	final public static class Compare implements Comparator<IdValue> {
		/** Indicateur d'ordre ascendant du tri (false -> descendant) **/
		final private boolean ascending;

		/** Indicateur de sensibilité à la casse **/
		final private boolean caseSensitive;

		/**
		 * Constructeur de base
		 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
		 */
		public Compare() {
			this.ascending = true;
			this.caseSensitive = true;
		}

		/**
		 * Constructeur de base
		 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
		 */
		public Compare(boolean ascending) {
			this.ascending = ascending;
			this.caseSensitive = true;
		}

		/**
		 * Constructeur de base
		 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
		 * @param caseSensitive Indicateur de sensibilité à la casse (false -> insensible)
		 */
		public Compare(boolean ascending, boolean caseSensitive) {
			this.ascending = ascending;
			this.caseSensitive = caseSensitive;
		}

		@Override
		public int compare(IdValue item1, IdValue item2) {
			int compare = 0;

			compare = OutilsBase.compare(item1.getId(), item2.getId());

			if (compare == 0) {
				compare = caseSensitive ? OutilsBase.compare(item1.getValue(), item2.getValue()) : OutilsBase.compareIgnoreCase(item1.getValue(), item2.getValue());
			}

			return ascending ? compare : (-1 * compare);
		}

		/**
		 * Extrait le champ ascendant
		 * @return un boolean
		 */
		public boolean isAscendant() {
			return ascending;
		}
	};

	/** La valeur de Id */
	private long id;

	/** La valeur de Value */
	private String value;

	/**
	 * Constructeur par défaut
	 */
	public IdValue() {
		this(0, "");
	}

	/**
	 * Constructeur avec la paire Id-Value
	 * @param id La valeur de Id
	 * @param value La valeur de Value
	 */
	public IdValue(long id, String value) {
		this.id = id;
		this.value = value;
	}

	/**
	 * Constructeur avec la paire Id-Value
	 * @param idValue Les valeurs de Id et de Value séparées par un égale (=)
	 */
	public IdValue(String idValue) {
		if (OutilsBase.isEmpty(idValue)) {
			this.id = 0;
			this.value = "";
		} else {
			int pos = idValue.indexOf("=");

			if (pos != -1) {
				this.id = Long.parseLong(idValue.substring(0, pos));
				this.value = idValue.substring(pos + 1);
			} else {
				this.id = Long.parseLong(idValue);
				this.value = "";
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof IdValue) {
				IdValue nv = (IdValue) obj;

				return (id == nv.getId()) //
						&& OutilsBase.areEquals(value, nv.getValue()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(id, value);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return toString("=");
	}

	/**
	 * Retourne la pair séparé par un séparateur
	 * @param separateur Le séparateur
	 * @return la pair sous forme d'une string
	 */
	public String toString(String separateur) {
		StringBuffer sb = new StringBuffer();
		sb.append(id);
		sb.append(separateur);
		sb.append(value);
		return sb.toString();
	}

	/**
	 * Extrait le champ id
	 * @return un long
	 */
	public long getId() {
		return id;
	}

	/**
	 * Modifie le champ id
	 * @param id La valeur du champ id
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Extrait le champ value
	 * @return un String
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Modifie le champ value
	 * @param value La valeur du champ value
	 */
	public void setValue(String value) {
		this.value = value;
	}

}