package outils.listes;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;

/**
 * Classe qui contient l'information d'une paire Name-Value.
 * 
 * @author Claude Toupin (CGI)
 * @version 1.0
 */
@CoverageTestsCases(NameValue.CoverageTestsCases.class)
public class NameValue implements java.io.Serializable {
	private static final long serialVersionUID = -6292099067234231863L;

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 4 févr. 2023
	 */
	public static final class CoverageTestsCases implements ICoverageTestsCases {

		/*
		 * (non-Javadoc)
		 * @see outils.tests.automated.ICoverageTestsCases#doBeforeAll()
		 */
		@Override
		public void doBeforeAll() throws Exception {
			List<NameValue> list = OutilsBase.asList(new NameValue("A=1"), new NameValue("B"), new NameValue("a", "1"), new NameValue("A", "2"), new NameValue("b", "4"));

			list.sort(new NameValue.Compare());
			list.sort(new NameValue.Compare(false));
			list.sort(new NameValue.Compare(false, false));

			new NameValue.Compare().isAscendant();
		}

		/*
		 * (non-Javadoc)
		 * @see outils.tests.automated.ICoverageTestsCases#doAfterAll()
		 */
		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/** Classe pour les tris de liste de NameValue **/
	final public static class Compare implements Comparator<NameValue> {
		/** Indicateur d'ordre ascendant du tri (false -> descendant) **/
		final private boolean ascending;

		/** Indicateur de sensibilité à la casse **/
		final private boolean caseSensitive;

		/**
		 * Constructeur de base
		 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
		 */
		public Compare() {
			this.ascending = true;
			this.caseSensitive = true;
		}

		/**
		 * Constructeur de base
		 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
		 */
		public Compare(boolean ascending) {
			this.ascending = ascending;
			this.caseSensitive = true;
		}

		/**
		 * Constructeur de base
		 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
		 * @param caseSensitive Indicateur de sensibilité à la casse (false -> insensible)
		 */
		public Compare(boolean ascending, boolean caseSensitive) {
			this.ascending = ascending;
			this.caseSensitive = caseSensitive;
		}

		@Override
		public int compare(NameValue item1, NameValue item2) {
			int compare = caseSensitive ? OutilsBase.compare(item1.getName(), item2.getName()) : OutilsBase.compareIgnoreCase(item1.getName(), item2.getName());

			if (compare == 0) {
				compare = caseSensitive ? OutilsBase.compare(item1.getValue(), item2.getValue()) : OutilsBase.compareIgnoreCase(item1.getValue(), item2.getValue());
			}

			return ascending ? compare : (-1 * compare);
		}

		/**
		 * Extrait le champ ascendant
		 * @return un boolean
		 */
		public boolean isAscendant() {
			return ascending;
		}
	};

	/** La valeur de Name */
	private String name;

	/** La valeur de Value */
	private String value;

	/**
	 * Constructeur par défaut
	 */
	public NameValue() {
		this("", "");
	}

	/**
	 * Constructeur avec la paire Name-Value
	 * @param name La valeur de Name
	 * @param value La valeur de Value
	 */
	public NameValue(String name, String value) {
		this.name = name;
		this.value = value;
	}

	/**
	 * Constructeur avec la paire Name-Value
	 * @param nameValue Les valeurs de Name et de Value séparées par un égale (=)
	 */
	public NameValue(String nameValue) {
		if (OutilsBase.isEmpty(nameValue)) {
			this.name = "";
			this.value = "";
		} else {
			int pos = nameValue.indexOf("=");

			if (pos != -1) {
				this.name = nameValue.substring(0, pos);
				this.value = nameValue.substring(pos + 1);
			} else {
				this.name = nameValue;
				this.value = "";
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof NameValue) {
				NameValue nv = (NameValue) obj;

				return OutilsBase.areEquals(name, nv.getName()) && OutilsBase.areEquals(value, nv.getValue());
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(name, value);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return toString("=");
	}

	/**
	 * Retourne la pair séparé par un séparateur
	 * @param separateur Le séparateur
	 * @return la pair sous forme d'une string
	 */
	public String toString(String separateur) {
		StringBuffer sb = new StringBuffer(name);
		sb.append(separateur);
		sb.append(value);
		return sb.toString();
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Modifie le champ name
	 * @param name La valeur du champ name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Extrait le champ value
	 * @return un String
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Modifie le champ value
	 * @param value La valeur du champ value
	 */
	public void setValue(String value) {
		this.value = value;
	}

}