package outils.listes;

import java.io.Serializable;
import java.util.Objects;

import outils.base.OutilsBase;

/**
 * Classe d'une donnée d'un String avec sa donnée Object
 * @author Claude Toupin - Apr 12, 2007
 */
public class StringData implements Serializable {
	private static final long serialVersionUID = -7823603378325041745L;

	/** La string */
	private String string;

	/** La donnée */
	private Object data;

	/**
	 * Constructeur de base
	 */

	public StringData() {
		this(null, null);
	}

	/**
	 * Constructeur avec juste le string
	 * @param string Le string
	 */

	public StringData(String string) {
		this(string, null);
	}

	/**
	 * Constructeur avec toutes les valeurs
	 * @param string Le string
	 * @param data La donnée
	 */

	public StringData(String string, Object data) {
		this.string = string;
		this.data = data;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof StringData) {
				StringData sd = (StringData) obj;

				return OutilsBase.areEquals(string, sd.getString()) && OutilsBase.areEquals(data, sd.getData());
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(data, string);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return toString("=");
	}

	/**
	 * Retourne la pair séparé par un séparateur
	 * @param separateur Le séparateur
	 * @return la pair sous forme d'une string
	 */
	public String toString(String separateur) {
		StringBuffer sb = new StringBuffer(string);
		sb.append(separateur);
		sb.append(data);
		return sb.toString();
	}

	/**
	 * Extrait le champ string
	 * @return un String
	 */
	public String getString() {
		return string;
	}

	/**
	 * Modifie le champ string
	 * @param string La valeur du champ string
	 */
	public void setString(String string) {
		this.string = string;
	}

	/**
	 * Extrait le champ data
	 * @return un Object
	 */
	public Object getData() {
		return data;
	}

	/**
	 * Modifie le champ data
	 * @param data La valeur du champ data
	 */
	public void setData(Object data) {
		this.data = data;
	}
}
