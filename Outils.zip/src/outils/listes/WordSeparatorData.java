package outils.listes;

import java.io.Serializable;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.StrictAutomatedTests;
import outils.tests.automated.annotations.TestMethodsInstance;
import outils.types.WordSeparatorsTypes;

/**
 * Classe d'une donnée d'un mot et de son type de séparateur
 * @author Claude Toupin - 2019-01-22
 */
public class WordSeparatorData implements Serializable {
	private static final long serialVersionUID = 7683971858494293027L;

	/** Type du mot **/
	final private WordSeparatorsTypes type;

	/** Texte du mot **/
	final private String text;

	/**
	 * Constructeur de base
	 * @param type Type du mot
	 */
	public WordSeparatorData(WordSeparatorsTypes type) {
		this(type, null);
	}

	/**
	 * Constructeur de base
	 * @param text Texte du mot
	 */
	public WordSeparatorData(String text) {
		this(WordSeparatorsTypes.WORD, text);
	}

	/**
	 * Constructeur de base
	 * @param type Type du mot
	 * @param text Texte du mot
	 */
	@TestMethodsInstance
	@StrictAutomatedTests({ "null", "null" })
	@StrictAutomatedTests({ "null", "Automated Test Value" })
	@StrictAutomatedTests({ "WordSeparatorsTypes.WORD", "null" })
	@StrictAutomatedTests({ "WordSeparatorsTypes.WORD", "Automated Test Value" })
	@StrictAutomatedTests({ "WordSeparatorsTypes.SPACE", "null" })
	@StrictAutomatedTests({ "WordSeparatorsTypes.SPACE", "Automated Test Value" })
	public WordSeparatorData(WordSeparatorsTypes type, String text) {
		if (type == null) {
			type = (text == null) ? WordSeparatorsTypes.SPACE : WordSeparatorsTypes.WORD; // Par défaut
		} 
		if (type.isWord()) {
			if (text == null) {
				throw new RuntimeException("Un mot doit avoir un texte !!!");
			}

			this.type = type;
			this.text = text;
		} else {
			if (text != null) {
				throw new RuntimeException("Un séparateur ne doit pas avoir un texte !!!");
			}

			this.type = type;
			this.text = OutilsBase.asString(type.getSeparator());
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	@AutomatedTests("new outils.listes.WordSeparatorData(WordSeparatorsTypes.WORD, \"SPACE\")")
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof WordSeparatorData) {
				WordSeparatorData wsd = (WordSeparatorData) obj;

				return OutilsBase.areEquals(type, wsd.getType()) //
						&& OutilsBase.areEquals(text, wsd.getText()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(text, type);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return toString("=");
	}

	/**
	 * Retourne la pair séparé par un séparateur
	 * @param separateur Le séparateur
	 * @return la pair sous forme d'une string
	 */
	public String toString(String separateur) {
		StringBuffer sb = new StringBuffer(type.name());
		sb.append(separateur);
		sb.append(text);
		return sb.toString();
	}

	/**
	 * Extrait le champ type
	 * @return un WordSeparatorsTypes
	 */
	public WordSeparatorsTypes getType() {
		return type;
	}

	/**
	 * Extrait le champ text
	 * @return un String
	 */
	public String getText() {
		return text;
	}

}
