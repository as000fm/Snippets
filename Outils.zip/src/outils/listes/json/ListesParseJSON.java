package outils.listes.json;

import java.lang.reflect.Type;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

import static outils.gson.AsOutilsGson.*;

import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import outils.listes.CSVFileData;
import outils.listes.IdValue;
import outils.listes.NameValue;
import outils.listes.StringData;
import outils.listes.WordSeparatorData;
import outils.types.WordSeparatorsTypes;

/**
 * Classe utilitaire pour convertir des données JSON en classes java
 * ALERTE: NE PAS MODIFIER MANUELLEMENT CETTE CLASSE !!!
 * @author Projet: Outils, Classe: json.OutilsJSONGenerator
 */
public class ListesParseJSON {
	// ALERTE: NE PAS MODIFIER MANUELLEMENT CETTE CLASSE !!!
	// Utilisez la classe json.OutilsJSONGenerator du projet Outils

	// ParseJSONTemplate

	// ParseJSONAsClassDataTemplate

	/** Désérialisation des données json d'un CSVFileData **/
	final private static GsonBuilder CSV_FILE_DATA_GSON_BUILDER = new GsonBuilder().registerTypeAdapter(CSVFileData.class, new JsonDeserializer<CSVFileData>() {

		@Override
		public CSVFileData deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
			return asCSVFileData(json);
		}
	});

	/**
	 * Extrait un CSVFileData depuis un élément json
	 * @param element Élément JSON du CSVFileData
	 * @return un CSVFileData (null si element == null)
	 */
	final public static CSVFileData asCSVFileData(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		if (element.isJsonPrimitive()) {
			throw new NoSuchElementException("Pas de primitive json pour outils.listes.CSVFileData");
		}

		return asCSVFileData(element.getAsJsonObject());
	}

	/**
	 * Extrait un CSVFileData depuis le texte json
	 * @param object Objet json du CSVFileData
	 * @return un CSVFileData (null si object == null)
	 */
	final public static CSVFileData asCSVFileData(JsonObject object) {
		if (isEmpty(object)) {
			return null;
		}

		// Traitement de header
		List<String> headerToArray = new ArrayList<>();

		JsonArray headerJsonArray = getAsJsonArray(object.get("header"));

		if (!isEmpty(headerJsonArray)) {
			Iterator<JsonElement> iterator1 = headerJsonArray.iterator();

			while (iterator1.hasNext()) {
				String item2 = asString(iterator1.next());
				headerToArray.add(item2);
			}
		}

		String[] header = headerToArray.toArray(new String[headerToArray.size()]);

		// Traitement de rows
		List<String[]> rows = asStringArrayList(object.get("rows"));

		CSVFileData csvFileData = new CSVFileData(header, rows);


		return csvFileData;
	}

	/**
	 * Extrait un CSVFileData depuis le texte json
	 * @param json Le texte json du CSVFileData
	 * @return un CSVFileData (null si json == null)
	 */
	final public static CSVFileData asCSVFileData(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new CSVFileData();
		}

		return CSV_FILE_DATA_GSON_BUILDER.create().fromJson(json, CSVFileData.class);
	}

	// ParseJSONAsArraysListsMapsTemplate

	/**
	 * Extrait une liste d'éléments JSON CSVFileData
	 * @param element Élément JSON
	 * @return une liste de CSVFileData
	 */
	final public static List<CSVFileData> asCSVFileDataList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<CSVFileData>();
		}

		return asCSVFileDataList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON CSVFileData
	 * @param array Liste JSON
	 * @return une liste de CSVFileData
	 */
	final public static List<CSVFileData> asCSVFileDataList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<CSVFileData>();
		}

		List<CSVFileData> list = new ArrayList<CSVFileData>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asCSVFileData(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste CSVFileData depuis le texte json
	 * @param json Le texte json
	 * @return une liste de CSVFileData (null si json == null)
	 */
	final public static List<CSVFileData> asCSVFileDataList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<CSVFileData>();
		}

		return CSV_FILE_DATA_GSON_BUILDER.create().fromJson(json, new TypeToken<List<CSVFileData>>() {}.getType());
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON CSVFileData
	 * @param element Élément JSON
	 * @return un dictionnaire CSVFileData
	 */
	final public static Map<String, CSVFileData> asCSVFileDataMap(JsonElement element) {
		Map<String, CSVFileData> dict = new HashMap<String, CSVFileData>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asCSVFileData(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire CSVFileData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire CSVFileData (null si json == null)
	 */
	final public static Map<String, CSVFileData> asCSVFileDataMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, CSVFileData>();
		}

		return asCSVFileDataMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un tableau d'éléments JSON CSVFileData
	 * @param element Élément JSON
	 * @return un tableau de CSVFileData
	 */
	final public static CSVFileData[] asCSVFileDataArray(JsonElement element) {
		if (isEmpty(element)) {
			return new CSVFileData[0];
		}
		
		List<CSVFileData> list = asCSVFileDataList(element);
		
		return list.toArray(new CSVFileData[list.size()]);
	}

	/**
	 * Extrait un tableau d'éléments JSON CSVFileData
	 * @param array Liste JSON
	 * @return un tableau de CSVFileData
	 */
	final public static CSVFileData[] asCSVFileDataArray(JsonArray array) {
		if (isEmpty(array)) {
			return new CSVFileData[0];
		}
		
		List<CSVFileData> list = asCSVFileDataList(array);
		
		return list.toArray(new CSVFileData[list.size()]);
	}

	/**
	 * Extrait uun tableau CSVFileData depuis le texte json
	 * @param element Élément JSON
	 * @return un tableau de CSVFileData
	 */
	final public static CSVFileData[] asCSVFileDataArray(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new CSVFileData[0];
		}
		
		List<CSVFileData> list = asCSVFileDataList(json);
		
		return list.toArray(new CSVFileData[list.size()]);
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON CSVFileData
	 * @param element Élément JSON
	 * @return une liste de tableaux de CSVFileData
	 */
	final public static List<CSVFileData[]> asCSVFileDataArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<CSVFileData[]>();
		}

		return asCSVFileDataArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON CSVFileData
	 * @param array Liste JSON
	 * @return une liste de tableaux de CSVFileData
	 */
	final public static List<CSVFileData[]> asCSVFileDataArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<CSVFileData[]>();
		}

		List<CSVFileData[]> list = new ArrayList<CSVFileData[]>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asCSVFileDataArray(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste de tableaux CSVFileData depuis le texte json
	 * @param json Le texte json
	 * @return une liste de tableaux de CSVFileData (null si json == null)
	 */
	final public static List<CSVFileData[]> asCSVFileDataArrayList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<CSVFileData[]>();
		}
		
		return asCSVFileDataArrayList(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON CSVFileData
	 * @param element Élément JSON
	 * @return un dictionnaire de données CSVFileData
	 */
	final public static Map<String, CSVFileData[]> asCSVFileDataArrayMap(JsonElement element) {
		Map<String, CSVFileData[]> dict = new HashMap<String, CSVFileData[]>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asCSVFileDataArray(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données CSVFileData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données CSVFileData (null si json == null)
	 */
	final public static Map<String, CSVFileData[]> asCSVFileDataArrayMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, CSVFileData[]>();
		}

		return asCSVFileDataArrayMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON CSVFileData
	 * @param element Élément JSON
	 * @return un dictionnaire de données CSVFileData
	 */
	final public static Map<String, List<CSVFileData>> asCSVFileDataListMap(JsonElement element) {
		Map<String, List<CSVFileData>> dict = new HashMap<String, List<CSVFileData>>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asCSVFileDataList(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données CSVFileData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données CSVFileData (null si json == null)
	 */
	final public static Map<String, List<CSVFileData>> asCSVFileDataListMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, List<CSVFileData>>();
		}

		return asCSVFileDataListMap(JsonParser.parseString(json));
	}

	// ParseJSONAsClassDataTemplate

	/** Désérialisation des données json d'un IdValue **/
	final private static GsonBuilder ID_VALUE_GSON_BUILDER = new GsonBuilder().registerTypeAdapter(IdValue.class, new JsonDeserializer<IdValue>() {

		@Override
		public IdValue deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
			return asIdValue(json);
		}
	});

	/**
	 * Extrait un IdValue depuis un élément json
	 * @param element Élément JSON du IdValue
	 * @return un IdValue (null si element == null)
	 */
	final public static IdValue asIdValue(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		if (element.isJsonPrimitive()) {
			throw new NoSuchElementException("Pas de primitive json pour outils.listes.IdValue");
		}

		return asIdValue(element.getAsJsonObject());
	}

	/**
	 * Extrait un IdValue depuis le texte json
	 * @param object Objet json du IdValue
	 * @return un IdValue (null si object == null)
	 */
	final public static IdValue asIdValue(JsonObject object) {
		if (isEmpty(object)) {
			return null;
		}

		// Traitement de id
		long id = asLongPrimitive(object.get("id"));

		// Traitement de value
		String value = asString(object.get("value"));

		IdValue idValue = new IdValue(id, value);


		return idValue;
	}

	/**
	 * Extrait un IdValue depuis le texte json
	 * @param json Le texte json du IdValue
	 * @return un IdValue (null si json == null)
	 */
	final public static IdValue asIdValue(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new IdValue();
		}

		return ID_VALUE_GSON_BUILDER.create().fromJson(json, IdValue.class);
	}

	// ParseJSONAsArraysListsMapsTemplate

	/**
	 * Extrait une liste d'éléments JSON IdValue
	 * @param element Élément JSON
	 * @return une liste de IdValue
	 */
	final public static List<IdValue> asIdValueList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<IdValue>();
		}

		return asIdValueList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON IdValue
	 * @param array Liste JSON
	 * @return une liste de IdValue
	 */
	final public static List<IdValue> asIdValueList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<IdValue>();
		}

		List<IdValue> list = new ArrayList<IdValue>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asIdValue(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste IdValue depuis le texte json
	 * @param json Le texte json
	 * @return une liste de IdValue (null si json == null)
	 */
	final public static List<IdValue> asIdValueList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<IdValue>();
		}

		return ID_VALUE_GSON_BUILDER.create().fromJson(json, new TypeToken<List<IdValue>>() {}.getType());
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON IdValue
	 * @param element Élément JSON
	 * @return un dictionnaire IdValue
	 */
	final public static Map<String, IdValue> asIdValueMap(JsonElement element) {
		Map<String, IdValue> dict = new HashMap<String, IdValue>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asIdValue(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire IdValue depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire IdValue (null si json == null)
	 */
	final public static Map<String, IdValue> asIdValueMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, IdValue>();
		}

		return asIdValueMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un tableau d'éléments JSON IdValue
	 * @param element Élément JSON
	 * @return un tableau de IdValue
	 */
	final public static IdValue[] asIdValueArray(JsonElement element) {
		if (isEmpty(element)) {
			return new IdValue[0];
		}
		
		List<IdValue> list = asIdValueList(element);
		
		return list.toArray(new IdValue[list.size()]);
	}

	/**
	 * Extrait un tableau d'éléments JSON IdValue
	 * @param array Liste JSON
	 * @return un tableau de IdValue
	 */
	final public static IdValue[] asIdValueArray(JsonArray array) {
		if (isEmpty(array)) {
			return new IdValue[0];
		}
		
		List<IdValue> list = asIdValueList(array);
		
		return list.toArray(new IdValue[list.size()]);
	}

	/**
	 * Extrait uun tableau IdValue depuis le texte json
	 * @param element Élément JSON
	 * @return un tableau de IdValue
	 */
	final public static IdValue[] asIdValueArray(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new IdValue[0];
		}
		
		List<IdValue> list = asIdValueList(json);
		
		return list.toArray(new IdValue[list.size()]);
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON IdValue
	 * @param element Élément JSON
	 * @return une liste de tableaux de IdValue
	 */
	final public static List<IdValue[]> asIdValueArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<IdValue[]>();
		}

		return asIdValueArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON IdValue
	 * @param array Liste JSON
	 * @return une liste de tableaux de IdValue
	 */
	final public static List<IdValue[]> asIdValueArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<IdValue[]>();
		}

		List<IdValue[]> list = new ArrayList<IdValue[]>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asIdValueArray(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste de tableaux IdValue depuis le texte json
	 * @param json Le texte json
	 * @return une liste de tableaux de IdValue (null si json == null)
	 */
	final public static List<IdValue[]> asIdValueArrayList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<IdValue[]>();
		}
		
		return asIdValueArrayList(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON IdValue
	 * @param element Élément JSON
	 * @return un dictionnaire de données IdValue
	 */
	final public static Map<String, IdValue[]> asIdValueArrayMap(JsonElement element) {
		Map<String, IdValue[]> dict = new HashMap<String, IdValue[]>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asIdValueArray(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données IdValue depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données IdValue (null si json == null)
	 */
	final public static Map<String, IdValue[]> asIdValueArrayMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, IdValue[]>();
		}

		return asIdValueArrayMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON IdValue
	 * @param element Élément JSON
	 * @return un dictionnaire de données IdValue
	 */
	final public static Map<String, List<IdValue>> asIdValueListMap(JsonElement element) {
		Map<String, List<IdValue>> dict = new HashMap<String, List<IdValue>>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asIdValueList(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données IdValue depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données IdValue (null si json == null)
	 */
	final public static Map<String, List<IdValue>> asIdValueListMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, List<IdValue>>();
		}

		return asIdValueListMap(JsonParser.parseString(json));
	}

	// ParseJSONAsClassDataTemplate

	/** Désérialisation des données json d'un NameValue **/
	final private static GsonBuilder NAME_VALUE_GSON_BUILDER = new GsonBuilder().registerTypeAdapter(NameValue.class, new JsonDeserializer<NameValue>() {

		@Override
		public NameValue deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
			return asNameValue(json);
		}
	});

	/**
	 * Extrait un NameValue depuis un élément json
	 * @param element Élément JSON du NameValue
	 * @return un NameValue (null si element == null)
	 */
	final public static NameValue asNameValue(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		if (element.isJsonPrimitive()) {
			throw new NoSuchElementException("Pas de primitive json pour outils.listes.NameValue");
		}

		return asNameValue(element.getAsJsonObject());
	}

	/**
	 * Extrait un NameValue depuis le texte json
	 * @param object Objet json du NameValue
	 * @return un NameValue (null si object == null)
	 */
	final public static NameValue asNameValue(JsonObject object) {
		if (isEmpty(object)) {
			return null;
		}

		// Traitement de name
		String name = asString(object.get("name"));

		// Traitement de value
		String value = asString(object.get("value"));

		NameValue nameValue = new NameValue(name, value);


		return nameValue;
	}

	/**
	 * Extrait un NameValue depuis le texte json
	 * @param json Le texte json du NameValue
	 * @return un NameValue (null si json == null)
	 */
	final public static NameValue asNameValue(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new NameValue();
		}

		return NAME_VALUE_GSON_BUILDER.create().fromJson(json, NameValue.class);
	}

	// ParseJSONAsArraysListsMapsTemplate

	/**
	 * Extrait une liste d'éléments JSON NameValue
	 * @param element Élément JSON
	 * @return une liste de NameValue
	 */
	final public static List<NameValue> asNameValueList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<NameValue>();
		}

		return asNameValueList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON NameValue
	 * @param array Liste JSON
	 * @return une liste de NameValue
	 */
	final public static List<NameValue> asNameValueList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<NameValue>();
		}

		List<NameValue> list = new ArrayList<NameValue>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asNameValue(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste NameValue depuis le texte json
	 * @param json Le texte json
	 * @return une liste de NameValue (null si json == null)
	 */
	final public static List<NameValue> asNameValueList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<NameValue>();
		}

		return NAME_VALUE_GSON_BUILDER.create().fromJson(json, new TypeToken<List<NameValue>>() {}.getType());
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON NameValue
	 * @param element Élément JSON
	 * @return un dictionnaire NameValue
	 */
	final public static Map<String, NameValue> asNameValueMap(JsonElement element) {
		Map<String, NameValue> dict = new HashMap<String, NameValue>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asNameValue(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire NameValue depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire NameValue (null si json == null)
	 */
	final public static Map<String, NameValue> asNameValueMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, NameValue>();
		}

		return asNameValueMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un tableau d'éléments JSON NameValue
	 * @param element Élément JSON
	 * @return un tableau de NameValue
	 */
	final public static NameValue[] asNameValueArray(JsonElement element) {
		if (isEmpty(element)) {
			return new NameValue[0];
		}
		
		List<NameValue> list = asNameValueList(element);
		
		return list.toArray(new NameValue[list.size()]);
	}

	/**
	 * Extrait un tableau d'éléments JSON NameValue
	 * @param array Liste JSON
	 * @return un tableau de NameValue
	 */
	final public static NameValue[] asNameValueArray(JsonArray array) {
		if (isEmpty(array)) {
			return new NameValue[0];
		}
		
		List<NameValue> list = asNameValueList(array);
		
		return list.toArray(new NameValue[list.size()]);
	}

	/**
	 * Extrait uun tableau NameValue depuis le texte json
	 * @param element Élément JSON
	 * @return un tableau de NameValue
	 */
	final public static NameValue[] asNameValueArray(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new NameValue[0];
		}
		
		List<NameValue> list = asNameValueList(json);
		
		return list.toArray(new NameValue[list.size()]);
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON NameValue
	 * @param element Élément JSON
	 * @return une liste de tableaux de NameValue
	 */
	final public static List<NameValue[]> asNameValueArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<NameValue[]>();
		}

		return asNameValueArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON NameValue
	 * @param array Liste JSON
	 * @return une liste de tableaux de NameValue
	 */
	final public static List<NameValue[]> asNameValueArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<NameValue[]>();
		}

		List<NameValue[]> list = new ArrayList<NameValue[]>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asNameValueArray(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste de tableaux NameValue depuis le texte json
	 * @param json Le texte json
	 * @return une liste de tableaux de NameValue (null si json == null)
	 */
	final public static List<NameValue[]> asNameValueArrayList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<NameValue[]>();
		}
		
		return asNameValueArrayList(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON NameValue
	 * @param element Élément JSON
	 * @return un dictionnaire de données NameValue
	 */
	final public static Map<String, NameValue[]> asNameValueArrayMap(JsonElement element) {
		Map<String, NameValue[]> dict = new HashMap<String, NameValue[]>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asNameValueArray(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données NameValue depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données NameValue (null si json == null)
	 */
	final public static Map<String, NameValue[]> asNameValueArrayMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, NameValue[]>();
		}

		return asNameValueArrayMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON NameValue
	 * @param element Élément JSON
	 * @return un dictionnaire de données NameValue
	 */
	final public static Map<String, List<NameValue>> asNameValueListMap(JsonElement element) {
		Map<String, List<NameValue>> dict = new HashMap<String, List<NameValue>>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asNameValueList(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données NameValue depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données NameValue (null si json == null)
	 */
	final public static Map<String, List<NameValue>> asNameValueListMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, List<NameValue>>();
		}

		return asNameValueListMap(JsonParser.parseString(json));
	}

	// ParseJSONAsClassDataTemplate

	/** Désérialisation des données json d'un StringData **/
	final private static GsonBuilder STRING_DATA_GSON_BUILDER = new GsonBuilder().registerTypeAdapter(StringData.class, new JsonDeserializer<StringData>() {

		@Override
		public StringData deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
			return asStringData(json);
		}
	});

	/**
	 * Extrait un StringData depuis un élément json
	 * @param element Élément JSON du StringData
	 * @return un StringData (null si element == null)
	 */
	final public static StringData asStringData(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		if (element.isJsonPrimitive()) {
			throw new NoSuchElementException("Pas de primitive json pour outils.listes.StringData");
		}

		return asStringData(element.getAsJsonObject());
	}

	/**
	 * Extrait un StringData depuis le texte json
	 * @param object Objet json du StringData
	 * @return un StringData (null si object == null)
	 */
	final public static StringData asStringData(JsonObject object) {
		if (isEmpty(object)) {
			return null;
		}

		// Traitement de string
		String string = asString(object.get("string"));

		// Traitement de data
		Object data = asObject(object.get("data"));

		StringData stringData = new StringData(string, data);


		return stringData;
	}

	/**
	 * Extrait un StringData depuis le texte json
	 * @param json Le texte json du StringData
	 * @return un StringData (null si json == null)
	 */
	final public static StringData asStringData(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new StringData();
		}

		return STRING_DATA_GSON_BUILDER.create().fromJson(json, StringData.class);
	}

	// ParseJSONAsArraysListsMapsTemplate

	/**
	 * Extrait une liste d'éléments JSON StringData
	 * @param element Élément JSON
	 * @return une liste de StringData
	 */
	final public static List<StringData> asStringDataList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<StringData>();
		}

		return asStringDataList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON StringData
	 * @param array Liste JSON
	 * @return une liste de StringData
	 */
	final public static List<StringData> asStringDataList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<StringData>();
		}

		List<StringData> list = new ArrayList<StringData>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asStringData(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste StringData depuis le texte json
	 * @param json Le texte json
	 * @return une liste de StringData (null si json == null)
	 */
	final public static List<StringData> asStringDataList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<StringData>();
		}

		return STRING_DATA_GSON_BUILDER.create().fromJson(json, new TypeToken<List<StringData>>() {}.getType());
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON StringData
	 * @param element Élément JSON
	 * @return un dictionnaire StringData
	 */
	final public static Map<String, StringData> asStringDataMap(JsonElement element) {
		Map<String, StringData> dict = new HashMap<String, StringData>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asStringData(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire StringData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire StringData (null si json == null)
	 */
	final public static Map<String, StringData> asStringDataMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, StringData>();
		}

		return asStringDataMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un tableau d'éléments JSON StringData
	 * @param element Élément JSON
	 * @return un tableau de StringData
	 */
	final public static StringData[] asStringDataArray(JsonElement element) {
		if (isEmpty(element)) {
			return new StringData[0];
		}
		
		List<StringData> list = asStringDataList(element);
		
		return list.toArray(new StringData[list.size()]);
	}

	/**
	 * Extrait un tableau d'éléments JSON StringData
	 * @param array Liste JSON
	 * @return un tableau de StringData
	 */
	final public static StringData[] asStringDataArray(JsonArray array) {
		if (isEmpty(array)) {
			return new StringData[0];
		}
		
		List<StringData> list = asStringDataList(array);
		
		return list.toArray(new StringData[list.size()]);
	}

	/**
	 * Extrait uun tableau StringData depuis le texte json
	 * @param element Élément JSON
	 * @return un tableau de StringData
	 */
	final public static StringData[] asStringDataArray(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new StringData[0];
		}
		
		List<StringData> list = asStringDataList(json);
		
		return list.toArray(new StringData[list.size()]);
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON StringData
	 * @param element Élément JSON
	 * @return une liste de tableaux de StringData
	 */
	final public static List<StringData[]> asStringDataArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<StringData[]>();
		}

		return asStringDataArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON StringData
	 * @param array Liste JSON
	 * @return une liste de tableaux de StringData
	 */
	final public static List<StringData[]> asStringDataArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<StringData[]>();
		}

		List<StringData[]> list = new ArrayList<StringData[]>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asStringDataArray(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste de tableaux StringData depuis le texte json
	 * @param json Le texte json
	 * @return une liste de tableaux de StringData (null si json == null)
	 */
	final public static List<StringData[]> asStringDataArrayList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<StringData[]>();
		}
		
		return asStringDataArrayList(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON StringData
	 * @param element Élément JSON
	 * @return un dictionnaire de données StringData
	 */
	final public static Map<String, StringData[]> asStringDataArrayMap(JsonElement element) {
		Map<String, StringData[]> dict = new HashMap<String, StringData[]>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asStringDataArray(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données StringData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données StringData (null si json == null)
	 */
	final public static Map<String, StringData[]> asStringDataArrayMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, StringData[]>();
		}

		return asStringDataArrayMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON StringData
	 * @param element Élément JSON
	 * @return un dictionnaire de données StringData
	 */
	final public static Map<String, List<StringData>> asStringDataListMap(JsonElement element) {
		Map<String, List<StringData>> dict = new HashMap<String, List<StringData>>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asStringDataList(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données StringData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données StringData (null si json == null)
	 */
	final public static Map<String, List<StringData>> asStringDataListMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, List<StringData>>();
		}

		return asStringDataListMap(JsonParser.parseString(json));
	}

	// ParseJSONAsClassDataTemplate

	/** Désérialisation des données json d'un WordSeparatorData **/
	final private static GsonBuilder WORD_SEPARATOR_DATA_GSON_BUILDER = new GsonBuilder().registerTypeAdapter(WordSeparatorData.class, new JsonDeserializer<WordSeparatorData>() {

		@Override
		public WordSeparatorData deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
			return asWordSeparatorData(json);
		}
	});

	/**
	 * Extrait un WordSeparatorData depuis un élément json
	 * @param element Élément JSON du WordSeparatorData
	 * @return un WordSeparatorData (null si element == null)
	 */
	final public static WordSeparatorData asWordSeparatorData(JsonElement element) {
		if (isEmpty(element)) {
			return null;
		}

		if (element.isJsonPrimitive()) {
			throw new NoSuchElementException("Pas de primitive json pour outils.listes.WordSeparatorData");
		}

		return asWordSeparatorData(element.getAsJsonObject());
	}

	/**
	 * Extrait un WordSeparatorData depuis le texte json
	 * @param object Objet json du WordSeparatorData
	 * @return un WordSeparatorData (null si object == null)
	 */
	final public static WordSeparatorData asWordSeparatorData(JsonObject object) {
		if (isEmpty(object)) {
			return null;
		}

		// Traitement de type
		WordSeparatorsTypes type = WordSeparatorsTypes.valueOf(getAsString(object.get("type")));

		// Traitement de text
		String text = asString(object.get("text"));

		WordSeparatorData wordSeparatorData = new WordSeparatorData(type, text);


		return wordSeparatorData;
	}

	/**
	 * Extrait un WordSeparatorData depuis le texte json
	 * @param json Le texte json du WordSeparatorData
	 * @return un WordSeparatorData (null si json == null)
	 */
	final public static WordSeparatorData asWordSeparatorData(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new WordSeparatorData(null, null);
		}

		return WORD_SEPARATOR_DATA_GSON_BUILDER.create().fromJson(json, WordSeparatorData.class);
	}

	// ParseJSONAsArraysListsMapsTemplate

	/**
	 * Extrait une liste d'éléments JSON WordSeparatorData
	 * @param element Élément JSON
	 * @return une liste de WordSeparatorData
	 */
	final public static List<WordSeparatorData> asWordSeparatorDataList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<WordSeparatorData>();
		}

		return asWordSeparatorDataList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments JSON WordSeparatorData
	 * @param array Liste JSON
	 * @return une liste de WordSeparatorData
	 */
	final public static List<WordSeparatorData> asWordSeparatorDataList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<WordSeparatorData>();
		}

		List<WordSeparatorData> list = new ArrayList<WordSeparatorData>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asWordSeparatorData(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste WordSeparatorData depuis le texte json
	 * @param json Le texte json
	 * @return une liste de WordSeparatorData (null si json == null)
	 */
	final public static List<WordSeparatorData> asWordSeparatorDataList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<WordSeparatorData>();
		}

		return WORD_SEPARATOR_DATA_GSON_BUILDER.create().fromJson(json, new TypeToken<List<WordSeparatorData>>() {}.getType());
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON WordSeparatorData
	 * @param element Élément JSON
	 * @return un dictionnaire WordSeparatorData
	 */
	final public static Map<String, WordSeparatorData> asWordSeparatorDataMap(JsonElement element) {
		Map<String, WordSeparatorData> dict = new HashMap<String, WordSeparatorData>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asWordSeparatorData(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire WordSeparatorData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire WordSeparatorData (null si json == null)
	 */
	final public static Map<String, WordSeparatorData> asWordSeparatorDataMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, WordSeparatorData>();
		}

		return asWordSeparatorDataMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un tableau d'éléments JSON WordSeparatorData
	 * @param element Élément JSON
	 * @return un tableau de WordSeparatorData
	 */
	final public static WordSeparatorData[] asWordSeparatorDataArray(JsonElement element) {
		if (isEmpty(element)) {
			return new WordSeparatorData[0];
		}
		
		List<WordSeparatorData> list = asWordSeparatorDataList(element);
		
		return list.toArray(new WordSeparatorData[list.size()]);
	}

	/**
	 * Extrait un tableau d'éléments JSON WordSeparatorData
	 * @param array Liste JSON
	 * @return un tableau de WordSeparatorData
	 */
	final public static WordSeparatorData[] asWordSeparatorDataArray(JsonArray array) {
		if (isEmpty(array)) {
			return new WordSeparatorData[0];
		}
		
		List<WordSeparatorData> list = asWordSeparatorDataList(array);
		
		return list.toArray(new WordSeparatorData[list.size()]);
	}

	/**
	 * Extrait uun tableau WordSeparatorData depuis le texte json
	 * @param element Élément JSON
	 * @return un tableau de WordSeparatorData
	 */
	final public static WordSeparatorData[] asWordSeparatorDataArray(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new WordSeparatorData[0];
		}
		
		List<WordSeparatorData> list = asWordSeparatorDataList(json);
		
		return list.toArray(new WordSeparatorData[list.size()]);
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON WordSeparatorData
	 * @param element Élément JSON
	 * @return une liste de tableaux de WordSeparatorData
	 */
	final public static List<WordSeparatorData[]> asWordSeparatorDataArrayList(JsonElement element) {
		if (isEmpty(element)) {
			return new ArrayList<WordSeparatorData[]>();
		}

		return asWordSeparatorDataArrayList(getAsJsonArray(element));
	}

	/**
	 * Extrait une liste d'éléments de tableaux JSON WordSeparatorData
	 * @param array Liste JSON
	 * @return une liste de tableaux de WordSeparatorData
	 */
	final public static List<WordSeparatorData[]> asWordSeparatorDataArrayList(JsonArray array) {
		if (isEmpty(array)) {
			return new ArrayList<WordSeparatorData[]>();
		}

		List<WordSeparatorData[]> list = new ArrayList<WordSeparatorData[]>();

		Iterator<JsonElement> iterator = array.iterator();

		while(iterator.hasNext()) {
			list.add(asWordSeparatorDataArray(iterator.next()));
		}

		return list;
	}

	/**
	 * Extrait une liste de tableaux WordSeparatorData depuis le texte json
	 * @param json Le texte json
	 * @return une liste de tableaux de WordSeparatorData (null si json == null)
	 */
	final public static List<WordSeparatorData[]> asWordSeparatorDataArrayList(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new ArrayList<WordSeparatorData[]>();
		}
		
		return asWordSeparatorDataArrayList(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON WordSeparatorData
	 * @param element Élément JSON
	 * @return un dictionnaire de données WordSeparatorData
	 */
	final public static Map<String, WordSeparatorData[]> asWordSeparatorDataArrayMap(JsonElement element) {
		Map<String, WordSeparatorData[]> dict = new HashMap<String, WordSeparatorData[]>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asWordSeparatorDataArray(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données WordSeparatorData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données WordSeparatorData (null si json == null)
	 */
	final public static Map<String, WordSeparatorData[]> asWordSeparatorDataArrayMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, WordSeparatorData[]>();
		}

		return asWordSeparatorDataArrayMap(JsonParser.parseString(json));
	}

	/**
	 * Extrait un dictionnaire d'éléments JSON WordSeparatorData
	 * @param element Élément JSON
	 * @return un dictionnaire de données WordSeparatorData
	 */
	final public static Map<String, List<WordSeparatorData>> asWordSeparatorDataListMap(JsonElement element) {
		Map<String, List<WordSeparatorData>> dict = new HashMap<String, List<WordSeparatorData>>();

		if (!isEmpty(element)) {
			JsonObject jsonObject = getAsJsonObject(element);

			if (!isEmpty(jsonObject)) {
				Iterator<Map.Entry<String, JsonElement>> iterator = jsonObject.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry<String, JsonElement> entry = iterator.next();
					dict.put(entry.getKey(), asWordSeparatorDataList(entry.getValue()));
				}
			}
		}

		return dict;
	}

	/**
	 * Extrait un dictionnaire de données WordSeparatorData depuis le texte json
	 * @param json Le texte json
	 * @return un dictionnaire de données WordSeparatorData (null si json == null)
	 */
	final public static Map<String, List<WordSeparatorData>> asWordSeparatorDataListMap(String json) {
		if (json == null) {
			return null;
		} else if (json.isEmpty()) {
			return new HashMap<String, List<WordSeparatorData>>();
		}

		return asWordSeparatorDataListMap(JsonParser.parseString(json));
	}

}
