package outils.patterns;

import java.util.Objects;

import outils.base.OutilsBase;

/**
 * Classe des données d'un patron composé de caractères ! (négation), ? et * (wildcards)
 * @author Claude Toupin - 7 mars 2019
 */
public class PatternData {
	/** Le patron composé de caractères ! (négation), ? et * (wildcards) **/
	private String pattern;

	/** L'expression régulière d'inclusion (i.e. correspond à) **/
	private String regex;

	/** Indicateur d'exclusion (i.e. ne corresponds pas à) **/
	private boolean negative;

	/** Indicateur d'insensible à la casse **/
	private boolean caseInsensitive;

	/**
	 * Constructeur de base
	 */
	public PatternData() {
		this.pattern = null;
		this.regex = null;
		this.negative = false;
		this.caseInsensitive = false;
	}

	/**
	 * Constructeur de base
	 * @param pattern Le patron composé de caractères ! (négation), ? et * (wildcards)
	 */
	public PatternData(String pattern) {
		this(pattern, false);
	}

	/**
	 * Constructeur de base
	 * @param pattern Le patron composé de caractères ! (négation), ? et * (wildcards)
	 * @param caseInsensitive Indicateur d'insensible à la casse
	 */
	public PatternData(String pattern, boolean caseInsensitive) {
		this.caseInsensitive = caseInsensitive;

		setPattern(pattern);
	}

	/**
	 * Indique si une valeur contient un patron ou non
	 * @param value La valeur à vérifier
	 * @return vrai si contient un patron
	 */
	final public static boolean hasPattern(String value) {
		if (!OutilsBase.isEmpty(value)) {
			return (value.startsWith("!") || value.contains("?") || value.contains("*"));
		}

		return false;
	}

	/**
	 * Extrait le champ pattern
	 * @return un String
	 */
	public String getPattern() {
		return pattern;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[pattern:" + pattern + ", regex:" + regex + ", negative:" + negative + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof PatternData) {
				PatternData patternlanData = (PatternData) obj;

				return OutilsBase.areEquals(pattern, patternlanData.getPattern()) //
						&& OutilsBase.areEquals(regex, patternlanData.getRegex()) //
						&& (negative == patternlanData.isNegative()) //
						&& (caseInsensitive == patternlanData.isCaseInsensitive()) //
						;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(caseInsensitive, negative, pattern, regex);
	}

	/**
	 * Détermine si une valeur correspond au patron courant
	 * @param value La valeur à déterminer
	 * @return vrai si correspond
	 */
	public boolean isMatching(String value) {
		if ((value == null) || (pattern == null)) {
			return caseInsensitive ? OutilsBase.areEqualsIgnoreCase(value, pattern) : OutilsBase.areEquals(value, pattern);
		}

		String compare = caseInsensitive ? value.toUpperCase() : value;

		return negative ? !compare.matches(regex) : compare.matches(regex);
	}

	/**
	 * Détermine si une valeur ne correspond pas au patron courant
	 * @param value La valeur à déterminer
	 * @return vrai si correspond
	 */
	public boolean isNotMatching(String value) {
		return !isMatching(value);
	}

	/**
	 * Modifie le champ pattern
	 * @param pattern La valeur du champ pattern
	 */
	public void setPattern(String pattern) {
		this.pattern = pattern; // Conserve une copie du patron original
		this.regex = null;
		this.negative = false;

		if (!OutilsBase.isEmpty(pattern)) {
			if (pattern.startsWith("!")) {
				pattern = pattern.substring(1);
				this.negative = true;
			}

			String compare = caseInsensitive ? pattern.toUpperCase() : pattern;

			this.regex = compare.replace("\\", "\\\\").replace(".", "\\.").replace("*", ".*").replace("?", ".?");
		}
	}

	/**
	 * Extrait le champ regex
	 * @return un String
	 */
	public String getRegex() {
		return regex;
	}

	/**
	 * Extrait le champ negative
	 * @return un boolean
	 */
	public boolean isNegative() {
		return negative;
	}

	/**
	 * Extrait le champ caseInsensitive
	 * @return un boolean
	 */
	public boolean isCaseInsensitive() {
		return caseInsensitive;
	}

	/**
	 * Modifie le champ caseInsensitive
	 * @param caseInsensitive La valeur du champ caseInsensitive
	 */
	public void setCaseInsensitive(boolean caseInsensitive) {
		this.caseInsensitive = caseInsensitive;

		setPattern(this.pattern);
	}
}
