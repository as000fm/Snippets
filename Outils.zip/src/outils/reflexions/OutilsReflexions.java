package outils.reflexions;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.reflexions.data.ConstructorInfoData;
import outils.reflexions.data.FieldInfoData;
import outils.reflexions.data.MethodInfoData;
import outils.reflexions.data.ParameterInfoData;
import outils.reflexions.data.TypeInfoData;
import outils.reflexions.data.filters.ModifiersFilter;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Classes des utilitaires de réflexion java
 * @author Claude Toupin - 2 juill. 2021
 */
public class OutilsReflexions {
	/**
	 * Extrait la liste des valeurs d'une classe d'énumération
	 * @param classData La classe à extraire les valeurs d'une énumération
	 * @return la liste des valeurs d'une énumération
	 * @throws Exception en cas d'erreur...
	 */
	@AutomatedTests({ "outils.types.CSVSeparatorsTypes.class", "outils.reflexions.OutilsReflexions.class" })
	final public static List<Enum<?>> getEnumClassValuesList(Class<?> classData) throws Exception {
		if (classData == null) {
			throw new Exception("Pas de classe de spécifiée");
		}

		if (classData.isEnum()) {
			return OutilsBase.asList((Enum<?>[]) classData.getEnumConstants());
		}

		return new ArrayList<Enum<?>>();
	}

	/**
	 * Extrait la liste des champs d'une classe
	 * @param classData La classe à extraire les champs
	 * @return la liste des champs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<FieldInfoData> getClassFieldsList(Class<?> classData) throws Exception {
		return getClassFieldsList(classData, null, true);
	}

	/**
	 * Extrait la liste des champs d'une classe
	 * @param classData La classe à extraire les champs
	 * @param filter Filtre sur les champs
	 * @return la liste des champs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<FieldInfoData> getClassFieldsList(Class<?> classData, ModifiersFilter filter) throws Exception {
		return getClassFieldsList(classData, filter, true);
	}

	/**
	 * Extrait la liste des champs d'une classe
	 * @param classData La classe à extraire les champs
	 * @param parent Indicateur d'extraction des champs de la classe parent
	 * @return la liste des champs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<FieldInfoData> getClassFieldsList(Class<?> classData, boolean parent) throws Exception {
		return getClassFieldsList(classData, null, parent);
	}

	/**
	 * Extrait la liste des champs d'une classe
	 * @param classData La classe à extraire les champs
	 * @param filter Filtre sur les champs
	 * @param parent Indicateur d'extraction des champs de la classe parent
	 * @return la liste des champs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<FieldInfoData> getClassFieldsList(Class<?> classData, ModifiersFilter filter, boolean parent) throws Exception {
		if (classData == null) {
			throw new Exception("Pas de classe de spécifiée");
		}

		List<FieldInfoData> fieldsList = new ArrayList<FieldInfoData>();

		if (!Object.class.equals(classData)) {
			for (Field field : classData.getDeclaredFields()) {
				if (field.isSynthetic()) {
					continue;
				}

				boolean accept = true;

				if (filter != null) {
					accept = filter.accept(field.getModifiers());
				}

				if (accept) {
					fieldsList.add(new FieldInfoData(field));
				}
			}

			if (parent) {
				fieldsList.addAll(getClassFieldsList(classData.getSuperclass(), filter, parent));
			}
		}

		return fieldsList;
	}

	/**
	 * Extrait la liste des méthodes d'une classe
	 * @param classData La classe à extraire les méthodes
	 * @return la liste des méthodes
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<MethodInfoData> getClassMethodsList(Class<?> classData) throws Exception {
		return getClassMethodsList(classData, null, true, new ArrayList<String>());
	}

	/**
	 * Extrait la liste des méthodes d'une classe
	 * @param classData La classe à extraire les méthodes
	 * @param filter Filtre sur les méthodes
	 * @return la liste des méthodes
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<MethodInfoData> getClassMethodsList(Class<?> classData, ModifiersFilter filter) throws Exception {
		return getClassMethodsList(classData, filter, true, new ArrayList<String>());
	}

	/**
	 * Extrait la liste des méthodes d'une classe
	 * @param classData La classe à extraire les méthodes
	 * @param parent Indicateur d'extraction des méthodes de la classe parent
	 * @return la liste des méthodes
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<MethodInfoData> getClassMethodsList(Class<?> classData, boolean parent) throws Exception {
		return getClassMethodsList(classData, null, parent, new ArrayList<String>());
	}

	/**
	 * Extrait la liste des méthodes d'une classe
	 * @param classData La classe à extraire les méthodes
	 * @param filter Filtre sur les méthodes
	 * @param parent Indicateur d'extraction des méthodes de la classe parent
	 * @return la liste des méthodes
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<MethodInfoData> getClassMethodsList(Class<?> classData, ModifiersFilter filter, boolean parent) throws Exception {
		return getClassMethodsList(classData, filter, parent, new ArrayList<String>());
	}

	/**
	 * Extrait la liste des méthodes d'une classe
	 * @param classData La classe à extraire les méthodes
	 * @param filter Filtre sur les méthodes
	 * @param parent Indicateur d'extraction des méthodes de la classe parent
	 * @param signaturesList Liste des signatures des méthodes déjà extraites
	 * @return la liste des méthodes
	 * @throws Exception en cas d'erreur...
	 */
	final protected static List<MethodInfoData> getClassMethodsList(Class<?> classData, ModifiersFilter filter, boolean parent, List<String> signaturesList) throws Exception {
		if (classData == null) {
			throw new Exception("Pas de classe de spécifiée");
		}

		List<MethodInfoData> methodsList = new ArrayList<MethodInfoData>();

		if (!Object.class.equals(classData)) {
			for (Method method : classData.getDeclaredMethods()) {
				if (method.isSynthetic()) {
					continue;
				}

				boolean accept = true;

				if (filter != null) {
					accept = filter.accept(method.getModifiers());
				}

				if (accept) {
					MethodInfoData methodInfoData = new MethodInfoData(method);

					String signature = methodInfoData.getSignature(false);

					if (!signaturesList.contains(signature)) {
						signaturesList.add(signature);
						methodsList.add(methodInfoData);
					}
				}
			}

			if (parent) {
				methodsList.addAll(getClassMethodsList(classData.getSuperclass(), filter, parent, signaturesList));
			}
		}

		return methodsList;
	}

	/**
	 * Extrait la liste des constructeurs d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @return la liste des constructeurs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<ConstructorInfoData> getClassConstructorsList(Class<?> classData) throws Exception {
		return getClassConstructorsList(classData, null, true);
	}

	/**
	 * Extrait la liste des constructeurs d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @param filter Filtre sur les constructeurs
	 * @return la liste des constructeurs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<ConstructorInfoData> getClassConstructorsList(Class<?> classData, ModifiersFilter filter) throws Exception {
		return getClassConstructorsList(classData, filter, true);
	}

	/**
	 * Extrait la liste des constructeurs d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @param parent Indicateur d'extraction des constructeurs de la classe parent
	 * @return la liste des constructeurs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<ConstructorInfoData> getClassConstructorsList(Class<?> classData, boolean parent) throws Exception {
		return getClassConstructorsList(classData, null, parent);
	}

	/**
	 * Extrait la liste des constructeurs d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @param filter Filtre sur les constructeurs
	 * @param parent Indicateur d'extraction des constructeurs de la classe parent
	 * @return la liste des constructeurs
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<ConstructorInfoData> getClassConstructorsList(Class<?> classData, ModifiersFilter filter, boolean parent) throws Exception {
		if (classData == null) {
			throw new Exception("Pas de classe de spécifiée");
		}

		List<ConstructorInfoData> constructorsList = new ArrayList<ConstructorInfoData>();

		if (!Object.class.equals(classData)) {
			for (Constructor<?> constructor : classData.getDeclaredConstructors()) {
				if (constructor.isSynthetic()) {
					continue;
				}

				boolean accept = true;

				if (filter != null) {
					accept = filter.accept(constructor.getModifiers());
				}

				if (accept) {
					constructorsList.add(new ConstructorInfoData(constructor));
				}
			}

			if (parent) {
				constructorsList.addAll(getClassConstructorsList(classData.getSuperclass(), filter, parent));
			}
		}

		return constructorsList;
	}

	/**
	 * Extrait la liste des interfaces d'une classe
	 * @param classData La classe à extraire les interfaces
	 * @return la liste des interfaces
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<TypeInfoData> getClassInterfacesList(Class<?> classData) throws Exception {
		return getClassInterfacesList(classData, null);
	}

	/**
	 * Extrait la liste des interfaces d'une classe
	 * @param classData La classe à extraire les interfaces
	 * @param filter Filtre sur les interfaces
	 * @return la liste des interfaces
	 * @throws Exception en cas d'erreur...
	 */
	final public static List<TypeInfoData> getClassInterfacesList(Class<?> classData, ModifiersFilter filter) throws Exception {
		if (classData == null) {
			throw new Exception("Pas de classe de spécifiée");
		}

		List<TypeInfoData> interfacesList = new ArrayList<TypeInfoData>();

		for (Class<?> classe : classData.getInterfaces()) {
			if (classe.isSynthetic()) {
				continue;
			}

			boolean accept = true;

			if (filter != null) {
				accept = filter.accept(classe.getModifiers());
			}

			if (accept) {
				interfacesList.add(new TypeInfoData(classe));
			}
		}

		return interfacesList;
	}

	/**
	 * Extrait le constructeur vide d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @return le constructeur vide d'une classe (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findEmptyConstructor(Class<?> classData) throws Exception {
		return findEmptyConstructor(getClassConstructorsList(classData, false));
	}

	/**
	 * Extrait le constructeur vide d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @param parent Indicateur d'extraction des constructeurs de la classe parent
	 * @return le constructeur vide d'une classe (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findEmptyConstructor(Class<?> classData, boolean parent) throws Exception {
		return findEmptyConstructor(getClassConstructorsList(classData, parent));
	}

	/**
	 * Extrait le constructeur vide d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @param filter Filtre sur les constructeurs
	 * @return le constructeur vide d'une classe (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findEmptyConstructor(Class<?> classData, ModifiersFilter filter) throws Exception {
		return findEmptyConstructor(getClassConstructorsList(classData, filter, false));
	}

	/**
	 * Extrait le constructeur vide d'une classe
	 * @param classData La classe à extraire les constructeurs
	 * @param filter Filtre sur les constructeurs
	 * @param parent Indicateur d'extraction des constructeurs de la classe parent
	 * @return le constructeur vide d'une classe (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findEmptyConstructor(Class<?> classData, ModifiersFilter filter, boolean parent) throws Exception {
		return findEmptyConstructor(getClassConstructorsList(classData, filter, parent));
	}

	/**
	 * Extrait le constructeur vide d'une classe
	 * @param constructorsList Liste des constructeurs d'une classe
	 * @return le constructeur vide d'une classe (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findEmptyConstructor(List<ConstructorInfoData> constructorsList) throws Exception {
		if (!OutilsBase.isEmpty(constructorsList)) {
			for (ConstructorInfoData constructorInfoData : constructorsList) {
				if (constructorInfoData.getParametersList().isEmpty()) {
					return constructorInfoData;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des champs d'une classe
	 * @param constructorsList Liste des constructeurs d'une classe
	 * @param fieldsList Liste des champs d'une classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(List<ConstructorInfoData> constructorsList, FieldInfoData... fieldsList) throws Exception {
		return findSignatureConstructor(constructorsList, false, fieldsList);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des champs d'une classe
	 * @param constructorsList Liste des constructeurs d'une classe
	 * @param finalFieldsExcluded Indicateur de champs finaux (final) sont exclus
	 * @param fieldsList Liste des champs d'une classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(List<ConstructorInfoData> constructorsList, boolean finalFieldsExcluded, FieldInfoData... fieldsList) throws Exception {
		if (OutilsBase.isEmpty(fieldsList)) {
			return findEmptyConstructor(constructorsList);
		}

		return findSignatureConstructor(constructorsList, OutilsBase.asList(fieldsList), finalFieldsExcluded);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des champs d'une classe
	 * @param constructorsList Liste des constructeurs d'une classe
	 * @param fieldsList Liste des champs d'une classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(List<ConstructorInfoData> constructorsList, List<FieldInfoData> fieldsList) throws Exception {
		return findSignatureConstructor(constructorsList, fieldsList, false);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des champs d'une classe
	 * @param constructorsList Liste des constructeurs d'une classe
	 * @param fieldsList Liste des champs d'une classe
	 * @param finalFieldsExcluded Indicateur de champs finaux (final) sont exclus
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(List<ConstructorInfoData> constructorsList, List<FieldInfoData> fieldsList, boolean finalFieldsExcluded) throws Exception {
		List<FieldInfoData> list = fieldsList;

		if (finalFieldsExcluded) {
			list = new ArrayList<FieldInfoData>();

			for (FieldInfoData fieldInfoData : fieldsList) {
				if (!Modifier.isFinal(fieldInfoData.getField().getModifiers())) {
					list.add(fieldInfoData);
				}
			}
		}

		if (OutilsBase.isEmpty(list)) {
			return findEmptyConstructor(constructorsList);
		}

		for (ConstructorInfoData constructorInfoData : constructorsList) {
			if (constructorInfoData.getParametersList().size() == list.size()) {
				Map<String, FieldInfoData> fieldsDict = new HashMap<String, FieldInfoData>();

				for (FieldInfoData fieldInfoData : list) {
					fieldsDict.put(fieldInfoData.getParam(), fieldInfoData);
				}

				for (ParameterInfoData parameterInfoData : constructorInfoData.getParametersList()) {
					if (fieldsDict.containsKey(parameterInfoData.getParam())) {
						fieldsDict.remove(parameterInfoData.getParam());
					}
				}

				if (fieldsDict.isEmpty()) {
					return constructorInfoData;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des paramètres comme champs de la classe donnée
	 * @param classData La classe à extraire les constructeurs
	 * @param skipExtraParameters Indicateur de ne pas tenir compte des paramètres qui ne sont pas des champs de la classe
	 * @param parametersList Liste des paramètres comme champs de la classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(Class<?> classData, ParameterInfoData... parametersList) throws Exception {
		return findSignatureConstructor(classData, false, parametersList);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des paramètres comme champs de la classe donnée
	 * @param classData La classe à extraire les constructeurs
	 * @param finalFieldsExcluded Indicateur de champs finaux (final) sont exclus
	 * @param parametersList Liste des paramètres comme champs de la classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(Class<?> classData, boolean finalFieldsExcluded, ParameterInfoData... parametersList) throws Exception {
		if (OutilsBase.isEmpty(parametersList)) {
			return findEmptyConstructor(classData);
		}

		return findSignatureConstructor(classData, OutilsBase.asList(parametersList), finalFieldsExcluded);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des paramètres comme champs de la classe donnée
	 * @param classData La classe à extraire les constructeurs
	 * @param finalFieldsExcluded Indicateur de champs finaux (final) sont exclus
	 * @param skipExtraParameters Indicateur de ne pas tenir compte des paramètres qui ne sont pas des champs de la classe
	 * @param parametersList Liste des paramètres comme champs de la classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(Class<?> classData, boolean finalFieldsExcluded, boolean skipExtraParameters, ParameterInfoData... parametersList) throws Exception {
		if (OutilsBase.isEmpty(parametersList)) {
			return findEmptyConstructor(classData);
		}

		return findSignatureConstructor(classData, OutilsBase.asList(parametersList), finalFieldsExcluded, skipExtraParameters);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des paramètres comme champs de la classe donnée
	 * @param classData La classe à extraire les constructeurs
	 * @param parametersList Liste des paramètres comme champs de la classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(Class<?> classData, List<ParameterInfoData> parametersList) throws Exception {
		return findSignatureConstructor(classData, parametersList, false, false);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des paramètres comme champs de la classe donnée
	 * @param classData La classe à extraire les constructeurs
	 * @param parametersList Liste des paramètres comme champs de la classe
	 * @param finalFieldsExcluded Indicateur de champs finaux (final) sont exclus
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(Class<?> classData, List<ParameterInfoData> parametersList, boolean finalFieldsExcluded) throws Exception {
		return findSignatureConstructor(classData, parametersList, finalFieldsExcluded, false);
	}

	/**
	 * Extrait le constructeur d'une classe ayant la signature de la liste des paramètres comme champs de la classe donnée
	 * @param classData La classe à extraire les constructeurs
	 * @param parametersList Liste des paramètres comme champs de la classe
	 * @param finalFieldsExcluded Indicateur de champs finaux (final) sont exclus
	 * @param skipExtraParameters Indicateur de ne pas tenir compte des paramètres qui ne sont pas des champs de la classe
	 * @return le constructeur avec la signature (null si aucun)
	 * @throws Exception en cas d'erreur...
	 */
	final public static ConstructorInfoData findSignatureConstructor(Class<?> classData, List<ParameterInfoData> parametersList, boolean finalFieldsExcluded, boolean skipExtraParameters) throws Exception {
		if (OutilsBase.isEmpty(parametersList)) {
			return findEmptyConstructor(classData);
		}

		Map<String, ParameterInfoData> parametersDict = new HashMap<String, ParameterInfoData>();

		for (ParameterInfoData parameterInfoData : parametersList) {
			parametersDict.put(parameterInfoData.getName(), parameterInfoData);
		}

		if (finalFieldsExcluded) {
			List<FieldInfoData> finalFieldsList = getClassFieldsList(classData, new ModifiersFilter() {

				@Override
				public boolean accept(int modifiers) {
					return Modifier.isFinal(modifiers);
				}
			}, false);

			List<MethodInfoData> methodsList = getClassMethodsList(classData, new ModifiersFilter() {

				@Override
				public boolean accept(int modifiers) {
					return Modifier.isPublic(modifiers) && !Modifier.isStatic(modifiers);
				}
			}, false);

			for (FieldInfoData fieldInfoData : finalFieldsList) {
				String key = fieldInfoData.getName();

				if (!fieldInfoData.isListType() && !fieldInfoData.isMapType()) {
					throw new Exception("Pas de traitement pour le champ final " + key + " de la classe " + classData.getName());
				}

				if (parametersDict.containsKey(key)) {
					String getterName = "get" + OutilsBase.doCapitalize(key);

					for (MethodInfoData methodInfoData : methodsList) {
						if (OutilsBase.areEquals(getterName, methodInfoData.getName())) {
							parametersDict.remove(key);
							break;
						}
					}
				} else {
					throw new Exception("Pas de paramètre " + key + " pour le champ final " + key + " de la classe " + classData.getName());
				}
			}
		}

		List<FieldInfoData> fieldsList = getClassFieldsList(classData, new ModifiersFilter() {

			@Override
			public boolean accept(int modifiers) {
				return finalFieldsExcluded ? !Modifier.isFinal(modifiers) : true;
			}
		}, false);

		for (FieldInfoData fieldInfoData : fieldsList) {
			String key = fieldInfoData.getName();

			if (parametersDict.containsKey(key)) {
				parametersDict.remove(key);
			} else {
				throw new Exception("Pas de paramètre " + key + " pour le champ " + key + " de la classe " + classData.getName());
			}
		}

		if (!skipExtraParameters) {
			if (!parametersDict.isEmpty()) {
				List<String> namesList = new ArrayList<String>();

				for (String key : parametersDict.keySet()) {
					namesList.add(key);
				}

				throw new Exception("Pas de champ de trouver dans la classe " + classData.getName() + " pour " + OutilsBase.plural(parametersDict.size(), "le", "paramètre", "suivant") + ": " + OutilsCommun.toList(namesList, ", "));
			}
		}

		List<ConstructorInfoData> constructorsList = getClassConstructorsList(classData, new ModifiersFilter() {

			@Override
			public boolean accept(int modifiers) {
				return Modifier.isPublic(modifiers);
			}
		}, false);

		return findSignatureConstructor(constructorsList, fieldsList);
	}

	/**
	 * Extrait la méthode de conversion d'une énumération afin de convertir un String en un membre de l'énumération
	 * @param classData La classe de l'énumération
	 * @return la méthode de conversion (valueOf par défaut)
	 * @throws Exception en cas d'erreur...
	 */
	final public static Method findEnumConverterMedthod(Class<?> classData) throws Exception {
		if (classData == null) {
			throw new Exception("Pas de classe de spécifiée");
		}

		if (!classData.isEnum()) {
			throw new Exception("La classe \"" + classData.getName() + "\" doit être une énumération");
		}

		Method converterMethod = null;
		Method valueOfMethod = null;

		for (Method method : classData.getMethods()) {
			if (classData.equals(method.getDeclaringClass())) {
				if (Modifier.isStatic(method.getModifiers())) {
					if (OutilsBase.areEquals(classData.getTypeName(), method.getGenericReturnType().getTypeName())) {
						if (method.getParameters().length == 1) {
							Parameter parameter = method.getParameters()[0];

							if (OutilsBase.areEquals(parameter.getParameterizedType().getTypeName(), String.class.getTypeName())) {
								if (OutilsBase.areEquals(method.getName(), "valueOf")) {
									valueOfMethod = method;
								} else if (converterMethod != null) {
									throw new Exception("Doublon des méthodes de conversion d'une énumération afin de convertir un String en un membre de l'énumération pour " + classData.getName());
								} else {
									converterMethod = method;
								}
							}
						}
					}
				}
			}
		}

		return (converterMethod != null) ? converterMethod : valueOfMethod;
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de champs donnée
	 * @param fieldsList La liste de champs à trier
	 */
	final public static void sortFieldsList(List<FieldInfoData> fieldsList) {
		sortFieldsList(fieldsList, null);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de champs donnée
	 * @param fieldsList La liste de champs à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortFieldsList(List<FieldInfoData> fieldsList, boolean ascending) {
		sortFieldsList(fieldsList, null, ascending);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de champs donnée
	 * @param fieldsList La liste de champs à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortFieldsList(List<FieldInfoData> fieldsList, boolean ascending, boolean caseSensitive) {
		sortFieldsList(fieldsList, null, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de champs donnée
	 * @param fieldsList La liste de champs à trier
	 * @param filter Filtre sur les champs
	 */
	final public static void sortFieldsList(List<FieldInfoData> fieldsList, ModifiersFilter filter) {
		sortFieldsList(fieldsList, filter, true, true);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de champs donnée
	 * @param fieldsList La liste de champs à trier
	 * @param filter Filtre sur les champs
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortFieldsList(List<FieldInfoData> fieldsList, ModifiersFilter filter, boolean ascending) {
		sortFieldsList(fieldsList, filter, ascending, true);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de champs donnée
	 * @param fieldsList La liste de champs à trier
	 * @param filter Filtre sur les champs
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortFieldsList(List<FieldInfoData> fieldsList, ModifiersFilter filter, boolean ascending, boolean caseSensitive) {
		if (!OutilsBase.isEmpty(fieldsList)) {
			fieldsList.sort(new Comparator<FieldInfoData>() {

				@Override
				public int compare(FieldInfoData field1, FieldInfoData field2) {
					int compare = 0;

					if (filter != null) {
						compare = OutilsBase.compare(filter.accept(field1.getField().getModifiers()), filter.accept(field2.getField().getModifiers()));
					}

					if (compare == 0) {
						compare = caseSensitive ? OutilsBase.compare(field1.getName(), field2.getName()) : OutilsBase.compareIgnoreCase(field1.getName(), field2.getName());
					}

					return ascending ? compare : (-1 * compare);
				}
			});
		}
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 */
	final public static void sortMethodsListByName(List<MethodInfoData> methodsList) {
		sortMethodsList(methodsList, null, null, false);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsListByName(List<MethodInfoData> methodsList, boolean ascending) {
		sortMethodsList(methodsList, null, null, false, ascending);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortMethodsListByName(List<MethodInfoData> methodsList, boolean ascending, boolean caseSensitive) {
		sortMethodsList(methodsList, null, null, false, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 */
	final public static void sortMethodsListByName(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, false);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsListByName(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter, boolean ascending) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, false, ascending);
	}

	/**
	 * Effectue le tri en ordre alphabétique d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortMethodsListByName(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter, boolean ascending, boolean caseSensitive) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, false, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 */
	final public static void sortMethodsListBySignature(List<MethodInfoData> methodsList) {
		sortMethodsList(methodsList, null, null, true);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsListBySignature(List<MethodInfoData> methodsList, boolean ascending) {
		sortMethodsList(methodsList, null, null, true, ascending);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortMethodsListBySignature(List<MethodInfoData> methodsList, boolean ascending, boolean caseSensitive) {
		sortMethodsList(methodsList, null, null, true, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 */
	final public static void sortMethodsListBySignature(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, true);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsListBySignature(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter, boolean ascending) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, true, ascending);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortMethodsListBySignature(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter, boolean ascending, boolean caseSensitive) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, true, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param bySignature Indicateur de tri des méthodes par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsList(List<MethodInfoData> methodsList, boolean bySignature) {
		sortMethodsList(methodsList, null, null, bySignature, true, true);
	}

	/**
	 * Effectue le tri d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param bySignature Indicateur de tri des méthodes par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsList(List<MethodInfoData> methodsList, boolean bySignature, boolean ascending) {
		sortMethodsList(methodsList, null, null, bySignature, ascending, true);
	}

	/**
	 * Effectue le tri d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param bySignature Indicateur de tri des méthodes par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortMethodsList(List<MethodInfoData> methodsList, boolean bySignature, boolean ascending, boolean caseSensitive) {
		sortMethodsList(methodsList, null, null, bySignature, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 * @param bySignature Indicateur de tri des méthodes par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsList(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter, boolean bySignature) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, bySignature, true, true);
	}

	/**
	 * Effectue le tri d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 * @param bySignature Indicateur de tri des méthodes par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortMethodsList(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter, boolean bySignature, boolean ascending) {
		sortMethodsList(methodsList, modifiersFilter, methodsFilter, bySignature, ascending, true);
	}

	/**
	 * Effectue le tri d'une liste de méthodes donnée
	 * @param methodsList La liste de méthodes à trier
	 * @param modifiersFilter Filtre sur les méthodes
	 * @param methodsFilter Filtre sur les méthodes par MethodInfoData
	 * @param bySignature Indicateur de tri des méthodes par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortMethodsList(List<MethodInfoData> methodsList, ModifiersFilter modifiersFilter, Comparator<MethodInfoData> methodsFilter, boolean bySignature, boolean ascending, boolean caseSensitive) {
		if (!OutilsBase.isEmpty(methodsList)) {
			if (bySignature) {
				methodsList.sort(new Comparator<MethodInfoData>() {

					@Override
					public int compare(MethodInfoData method1, MethodInfoData method2) {
						int compare = 0;

						if (modifiersFilter != null) {
							compare = OutilsBase.compare(modifiersFilter.accept(method1.getMethod().getModifiers()), modifiersFilter.accept(method2.getMethod().getModifiers()));
						}

						if ((compare == 0) && (methodsFilter != null)) {
							compare = methodsFilter.compare(method1, method2);
						}

						if (compare == 0) {
							compare = OutilsBase.compare(method1.getParametersList().size(), method2.getParametersList().size());
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(method1.getParametersList(), method2.getParametersList()) : OutilsBase.compareIgnoreCase(method1.getParametersList(), method2.getParametersList());
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(method1.getName(), method2.getName()) : OutilsBase.compareIgnoreCase(method1.getName(), method2.getName());
						}

						return ascending ? compare : (-1 * compare);
					}
				});
			} else {
				methodsList.sort(new Comparator<MethodInfoData>() {

					@Override
					public int compare(MethodInfoData method1, MethodInfoData method2) {
						int compare = 0;

						if (modifiersFilter != null) {
							compare = OutilsBase.compare(modifiersFilter.accept(method1.getMethod().getModifiers()), modifiersFilter.accept(method2.getMethod().getModifiers()));
						}

						if ((compare == 0) && (methodsFilter != null)) {
							compare = methodsFilter.compare(method1, method2);
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(method1.getName(), method2.getName()) : OutilsBase.compareIgnoreCase(method1.getName(), method2.getName());
						}

						if (compare == 0) {
							compare = OutilsBase.compare(method1.getParametersList().size(), method2.getParametersList().size());
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(method1.getParametersList(), method2.getParametersList()) : OutilsBase.compareIgnoreCase(method1.getParametersList(), method2.getParametersList());
						}

						return ascending ? compare : (-1 * compare);
					}
				});
			}
		}
	}

	/**
	 * Effectue le tri en order alphabétique d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 */
	final public static void sortConstructorsListByName(List<ConstructorInfoData> constructorsList) {
		sortConstructorsList(constructorsList, null, null, false);
	}

	/**
	 * Effectue le tri en order alphabétique d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortConstructorsListByName(List<ConstructorInfoData> constructorsList, boolean ascending) {
		sortConstructorsList(constructorsList, null, null, false, ascending);
	}

	/**
	 * Effectue le tri en order alphabétique d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortConstructorsListByName(List<ConstructorInfoData> constructorsList, boolean ascending, boolean caseSensitive) {
		sortConstructorsList(constructorsList, null, null, false, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri en order alphabétique d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 */
	final public static void sortConstructorsListByName(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, false);
	}

	/**
	 * Effectue le tri en order alphabétique d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortConstructorsListByName(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter, boolean ascending) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, false, ascending);
	}

	/**
	 * Effectue le tri en order alphabétique d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortConstructorsListByName(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter, boolean ascending, boolean caseSensitive) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, false, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 */
	final public static void sortConstructorsListBySignature(List<ConstructorInfoData> constructorsList) {
		sortConstructorsList(constructorsList, null, null, true);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortConstructorsListBySignature(List<ConstructorInfoData> constructorsList, boolean ascending) {
		sortConstructorsList(constructorsList, null, null, true, ascending);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortConstructorsListBySignature(List<ConstructorInfoData> constructorsList, boolean ascending, boolean caseSensitive) {
		sortConstructorsList(constructorsList, null, null, true, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 */
	final public static void sortConstructorsListBySignature(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, true);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortConstructorsListBySignature(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter, boolean ascending) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, true, ascending);
	}

	/**
	 * Effectue le tri en ordre de signature d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortConstructorsListBySignature(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter, boolean ascending, boolean caseSensitive) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, true, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param bySignature Indicateur de tri des constructeurs par signature en premier (false -> par nom en premier)
	 */
	final public static void sortConstructorsList(List<ConstructorInfoData> constructorsList, boolean bySignature) {
		sortConstructorsList(constructorsList, null, null, bySignature, true, true);
	}

	/**
	 * Effectue le tri d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param bySignature Indicateur de tri des constructeurs par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortConstructorsList(List<ConstructorInfoData> constructorsList, boolean bySignature, boolean ascending) {
		sortConstructorsList(constructorsList, null, null, bySignature, ascending, true);
	}

	/**
	 * Effectue le tri d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param bySignature Indicateur de tri des constructeurs par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortConstructorsList(List<ConstructorInfoData> constructorsList, boolean bySignature, boolean ascending, boolean caseSensitive) {
		sortConstructorsList(constructorsList, null, null, bySignature, ascending, caseSensitive);
	}

	/**
	 * Effectue le tri d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 * @param bySignature Indicateur de tri des constructeurs par signature en premier (false -> par nom en premier)
	 */
	final public static void sortConstructorsList(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter, boolean bySignature) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, bySignature, true, true);
	}

	/**
	 * Effectue le tri d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 * @param bySignature Indicateur de tri des constructeurs par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 */
	final public static void sortConstructorsList(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter, boolean bySignature, boolean ascending) {
		sortConstructorsList(constructorsList, modifiersFilter, constructorsFilter, bySignature, ascending, true);
	}

	/**
	 * Effectue le tri d'une liste de constructeurs donnée
	 * @param constructorsList La liste de constructeurs à trier
	 * @param modifiersFilter Filtre sur les constructeurs par Modifiers
	 * @param constructorsFilter Filtre sur les constructeurs par ConstructorInfoData
	 * @param bySignature Indicateur de tri des constructeurs par signature en premier (false -> par nom en premier)
	 * @param ascending Indicateur d'ordre ascendant du tri (false -> descendant)
	 * @param caseSensitive Indicateur de sensibilité à la casse
	 */
	final public static void sortConstructorsList(List<ConstructorInfoData> constructorsList, ModifiersFilter modifiersFilter, Comparator<ConstructorInfoData> constructorsFilter, boolean bySignature, boolean ascending, boolean caseSensitive) {
		if (!OutilsBase.isEmpty(constructorsList)) {
			if (bySignature) {
				constructorsList.sort(new Comparator<ConstructorInfoData>() {

					@Override
					public int compare(ConstructorInfoData constructor1, ConstructorInfoData constructor2) {
						int compare = 0;

						if (modifiersFilter != null) {
							compare = OutilsBase.compare(modifiersFilter.accept(constructor1.getConstructor().getModifiers()), modifiersFilter.accept(constructor2.getConstructor().getModifiers()));
						}

						if ((compare == 0) && (constructorsFilter != null)) {
							compare = constructorsFilter.compare(constructor1, constructor2);
						}

						if (compare == 0) {
							compare = OutilsBase.compare(constructor1.getParametersList().size(), constructor2.getParametersList().size());
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(constructor1.getParametersList(), constructor2.getParametersList()) : OutilsBase.compareIgnoreCase(constructor1.getParametersList(), constructor2.getParametersList());
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(constructor1.getName(), constructor2.getName()) : OutilsBase.compareIgnoreCase(constructor1.getName(), constructor2.getName());
						}

						return ascending ? compare : (-1 * compare);
					}
				});
			} else {
				constructorsList.sort(new Comparator<ConstructorInfoData>() {

					@Override
					public int compare(ConstructorInfoData constructor1, ConstructorInfoData constructor2) {
						int compare = 0;

						if (modifiersFilter != null) {
							compare = OutilsBase.compare(modifiersFilter.accept(constructor1.getConstructor().getModifiers()), modifiersFilter.accept(constructor2.getConstructor().getModifiers()));
						}

						if ((compare == 0) && (constructorsFilter != null)) {
							compare = constructorsFilter.compare(constructor1, constructor2);
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(constructor1.getName(), constructor2.getName()) : OutilsBase.compareIgnoreCase(constructor1.getName(), constructor2.getName());
						}

						if (compare == 0) {
							compare = OutilsBase.compare(constructor1.getParametersList().size(), constructor2.getParametersList().size());
						}

						if (compare == 0) {
							compare = caseSensitive ? OutilsBase.compare(constructor1.getParametersList(), constructor2.getParametersList()) : OutilsBase.compareIgnoreCase(constructor1.getParametersList(), constructor2.getParametersList());
						}

						return ascending ? compare : (-1 * compare);
					}
				});
			}
		}
	}
}
