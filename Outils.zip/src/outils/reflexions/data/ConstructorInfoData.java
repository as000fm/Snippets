package outils.reflexions.data;

import java.lang.reflect.Constructor;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Classe des données d'un construteur d'une classe
 * @author Claude Toupin - 2 juill. 2021
 */
public class ConstructorInfoData extends TypeInfoData {
	/** Données du constructeur **/
	final private Constructor<?> constructor;

	/** Liste des paramètres du constructeur **/
	final private List<ParameterInfoData> parametersList;

	/** Liste des exceptions du constructeur **/
	final private List<TypeInfoData> exceptionsList;

	/**
	 * Constructeur de base
	 * @param constructor Données d'un constructeur d'une classe
	 */
	@StrictAutomatedTests("outils.reflexions.data.ConstructorInfoData.class.getConstructors()[0]")
	@StrictAutomatedTests("classes.reflexions.data.ConstructorInfoDataTestClass.class.getConstructors()[0]")
	public ConstructorInfoData(Constructor<?> constructor) {
		super(constructor.getDeclaringClass());

		this.constructor = constructor;
		this.parametersList = new ArrayList<ParameterInfoData>();

		for (Parameter parameter : constructor.getParameters()) {
			this.parametersList.add(new ParameterInfoData(parameter));
		}

		this.exceptionsList = new ArrayList<TypeInfoData>();

		for (Class<?> exceptionType : constructor.getExceptionTypes()) {
			this.exceptionsList.add(new TypeInfoData(exceptionType));
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ConstructorInfoData [" + getSignature() + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof ConstructorInfoData) {
				ConstructorInfoData constructorInfoData = (ConstructorInfoData) obj;

				return OutilsBase.areEquals(getSignature(false), constructorInfoData.getSignature(false));
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getSignature());
	}

	/**
	 * Indicateur de la présence d'annotations
	 * @return vrai si présence d'annotations
	 */
	public boolean hasAnnotation() {
		return !OutilsBase.isEmpty(constructor.getAnnotations());
	}

	/**
	 * Extrait la signature
	 * @return la signature
	 */
	public String getSignature() {
		return getSignature(true);
	}

	/**
	 * Extrait la signature
	 * @param simpleType Indicateur de type simple
	 * @return la signature
	 */
	public String getSignature(boolean simpleType) {
		return getName(simpleType) + "(" + getSignatureAssignments(simpleType) + ")";
	}

	/**
	 * Extrait la liste des noms des assignations
	 * @return la liste des noms des assignations
	 */
	public String getSignatureAssignments() {
		List<String> params = new ArrayList<String>();

		for (ParameterInfoData parameter : parametersList) {
			params.add(parameter.getName());
		}

		return OutilsCommun.toList(params, ", ");
	}

	/**
	 * Extrait la liste des types des assignations
	 * @param simpleType Indicateur de type simple
	 * @return la liste des types des assignations
	 */
	public String getSignatureAssignments(boolean simpleType) {
		List<String> params = new ArrayList<String>();

		for (ParameterInfoData parameter : parametersList) {
			params.add(parameter.getParam(simpleType));
		}

		return OutilsCommun.toList(params, ", ");
	}

	/**
	 * Extrait la liste des valeurs par défaut des assignations
	 * @return la liste des valeurs par défaut des assignations
	 */
	public String getSignatureAssignmentsValues() {
		List<String> params = new ArrayList<String>();

		for (ParameterInfoData parameter : parametersList) {
			params.add(parameter.getDefaultValue());
		}

		return OutilsCommun.toList(params, ", ");
	}

	/**
	 * Extrait le paramètre pour un type de données
	 * @param typeInfoData Le type de données à extraire le paramètre
	 * @return le paramètre trouvé (null sinon)
	 */
	@AutomatedTests("new TypeInfoData(java.lang.String.class)")
	@AutomatedTests("new TypeInfoData(java.lang.Integer.class)")
	public ParameterInfoData findParameter(TypeInfoData typeInfoData) {
		
		if (typeInfoData != null) {
			for (ParameterInfoData paramerter : parametersList) {
				if (OutilsBase.areEquals(paramerter, typeInfoData)) {
					return paramerter;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait l'index du paramètre pour un type de données
	 * @param typeInfoData Le type de données à extraire le paramètre
	 * @return l'index du paramètre trouvé (-1 sinon)
	 */
	@AutomatedTests("new TypeInfoData(java.lang.String.class)")
	@AutomatedTests("new TypeInfoData(java.lang.Integer.class)")
	public int findParameterIndex(TypeInfoData typeInfoData) {
		if (typeInfoData != null) {
			ParameterInfoData paramerter = findParameter(typeInfoData);

			if (paramerter != null) {
				return parametersList.indexOf(paramerter);
			}
		}

		return -1;
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return getName(true);
	}

	/**
	 * Extrait le champ name
	 * @param simpleType Indicateur de type simple
	 * @return un String
	 */
	public String getName(boolean simpleType) {
		return getTypeName(simpleType);
	}

	/**
	 * Extrait le champ constructor
	 * @return un Constructor<?>
	 */
	public Constructor<?> getConstructor() {
		return constructor;
	}

	/**
	 * Extrait le champ parametersList
	 * @return un List<ParameterInfoData>
	 */
	public List<ParameterInfoData> getParametersList() {
		return parametersList;
	}

	/**
	 * Extrait le champ exceptionsList
	 * @return un List<TypeInfoData>
	 */
	public List<TypeInfoData> getExceptionsList() {
		return exceptionsList;
	}

}
