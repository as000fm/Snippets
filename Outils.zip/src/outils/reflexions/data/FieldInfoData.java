package outils.reflexions.data;

import java.lang.reflect.Field;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Classe des données d'un champ d'une classe
 * @author Claude Toupin - 2 juill. 2021
 */
public class FieldInfoData extends TypeInfoData {
	/** Données du champ **/
	final private Field field;

	/**
	 * Constructeur de base
	 * @param field Données d'un champ d'une classe
	 */
	@StrictAutomatedTests("classes.reflexions.data.FieldInfoDataTestClass.class.getField(\"field\")")
	@StrictAutomatedTests("classes.reflexions.data.FieldInfoDataTestClass.class.getField(\"json\")")
	public FieldInfoData(Field field) {
		super(field.getGenericType());
		
		this.field = field;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FieldInfoData [" + getParam() + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof FieldInfoData) {
				FieldInfoData fieldInfoData = (FieldInfoData) obj;

				return OutilsBase.areEquals(getParam(false), fieldInfoData.getParam(false));
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getParam());
	}

	/**
	 * Indicateur de la présence d'annotations
	 * @return vrai si présence d'annotations
	 */
	public boolean hasAnnotation() {
		return !OutilsBase.isEmpty(field.getAnnotations());
	}

	/**
	 * Extrait le paramètre pour le champ
	 * @return le paramètre pour le champ
	 */
	public String getParam() {
		return getParam(true);
	}

	/**
	 * Extrait le paramètre pour le champ
	 * @param simpleType Indicateur de type simple
	 * @return le paramètre pour le champ
	 */
	public String getParam(boolean simpleType) {
		return getTypeName(simpleType) + " " + getName();
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return field.getName();
	}

	/**
	 * Extrait le champ field
	 * @return un Field
	 */
	public Field getField() {
		return field;
	}

}
