package outils.reflexions.data;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Classe des données d'une méthode d'une classe
 * @author Claude Toupin - 2 juill. 2021
 */
public class MethodInfoData extends TypeInfoData {
	/** Données de la méthode **/
	final private Method method;

	/** Liste des paramètres de la méthode **/
	final private List<ParameterInfoData> parametersList;

	/** Liste des exceptions de la méthode **/
	final private List<TypeInfoData> exceptionsList;

	/**
	 * Constructeur de base
	 * @param method Données d'une méthode d'une classe
	 */
	@StrictAutomatedTests("classes.reflexions.data.MethodInfoDataTestClass.class.getMethods()[0]")
	@StrictAutomatedTests("outils.reflexions.data.MethodInfoData.class.getMethod(\"equals\", Object.class)")
	public MethodInfoData(Method method) {
		super(method.getGenericReturnType());

		this.method = method;
		this.parametersList = new ArrayList<ParameterInfoData>();

		for (Parameter parameter : method.getParameters()) {
			this.parametersList.add(new ParameterInfoData(parameter));
		}

		this.exceptionsList = new ArrayList<TypeInfoData>();

		for (Class<?> exceptionType : method.getExceptionTypes()) {
			this.exceptionsList.add(new TypeInfoData(exceptionType));
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MethodInfoData [" + getSignature() + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof MethodInfoData) {
				MethodInfoData methodInfoData = (MethodInfoData) obj;

				return OutilsBase.areEquals(getSignature(false), methodInfoData.getSignature(false));
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getSignature());
	}

	/**
	 * Indicateur de la présence d'annotations
	 * @return vrai si présence d'annotations
	 */
	public boolean hasAnnotation() {
		return !OutilsBase.isEmpty(method.getAnnotations());
	}

	/**
	 * Extrait la signature
	 * @return la signature
	 */
	public String getSignature() {
		return getSignature(true);
	}

	/**
	 * Extrait la signature
	 * @param simpleType Indicateur de type simple
	 * @return la signature
	 */
	public String getSignature(boolean simpleType) {
		List<String> params = new ArrayList<String>();

		for (ParameterInfoData parameter : parametersList) {
			params.add(parameter.getParam(simpleType));
		}

		return getTypeName(simpleType) + " " + getName() + "(" + OutilsCommun.toList(params, ", ") + ")";
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return method.getName();
	}

	/**
	 * Extrait le champ method
	 * @return un Method
	 */
	public Method getMethod() {
		return method;
	}

	/**
	 * Extrait le champ parametersList
	 * @return un List<ParameterInfoData>
	 */
	public List<ParameterInfoData> getParametersList() {
		return parametersList;
	}

	/**
	 * Extrait le champ exceptionsList
	 * @return un List<TypeInfoData>
	 */
	public List<TypeInfoData> getExceptionsList() {
		return exceptionsList;
	}

}
