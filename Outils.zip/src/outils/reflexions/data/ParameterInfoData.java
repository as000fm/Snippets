package outils.reflexions.data;

import java.lang.reflect.Parameter;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Classe des données d'un paramètre d'une méthode
 * @author Claude Toupin - 28 juin 2021
 */
public class ParameterInfoData extends TypeInfoData {
	/** Données du paramètre **/
	final private Parameter parameter;

	/**
	 * Constructeur de base
	 * @param typename Nom du type de la classe
	 * @param name Nom du paramètre
	 */
	@StrictAutomatedTests("outils.reflexions.data.ParameterInfoData.class.getMethod(\"equals\", Object.class).getParameters()[0]")
	@StrictAutomatedTests("classes.reflexions.data.ParameterInfoDataTestClass.class.getMethods()[0].getParameters()[0]")
	public ParameterInfoData(Parameter parameter) {
		super(parameter.getParameterizedType());

		this.parameter = parameter;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ParameterInfoData [" + getParam() + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof ParameterInfoData) {
				ParameterInfoData parameterInfoData = (ParameterInfoData) obj;

				return OutilsBase.areEquals(getParam(false), parameterInfoData.getParam(false));
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getParam());
	}

	/**
	 * Indicateur de la présence d'annotations
	 * @return vrai si présence d'annotations
	 */
	public boolean hasAnnotation() {
		return !OutilsBase.isEmpty(parameter.getAnnotations());
	}

	/**
	 * Extrait le paramètre
	 * @return le paramètre
	 */
	public String getParam() {
		return getParam(true);
	}

	/**
	 * Extrait le paramètre
	 * @param simpleType Indicateur de type simple
	 * @return le paramètre
	 */
	public String getParam(boolean simpleType) {
 		return getTypeName(simpleType) + " " + getName();
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return parameter.getName();
	}

	/**
	 * Extrait le champ parameter
	 * @return un Parameter
	 */
	public Parameter getParameter() {
		return parameter;
	}
}
