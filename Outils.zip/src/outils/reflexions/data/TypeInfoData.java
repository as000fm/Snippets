package outils.reflexions.data;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.tests.automated.annotations.AutomatedTests;
import outils.tests.automated.annotations.NotForTestMethodsInstance;
import outils.tests.automated.annotations.StrictAutomatedTests;

/**
 * Classe des données d'un type de classe
 * @author Claude Toupin - 28 juin 2021
 */
public class TypeInfoData {
	/** Données de la classe **/
	private Class<?> classData;

	/** Données de la classe sans tableau **/
	private Class<?> classSimpleData;

	/** Package de la classe **/
	private String packageName;

	/** Nom de la classe **/
	private String className;

	/** Nom de la classe sans package **/
	private String classSimpleName;

	/** Valeur par défaut de la classe **/
	private String defaultValue;

	/** Valeur par défaut de la classe sans tableau **/
	private String defaultSimpleValue;

	/** Indicateur de type base (ex: int, double, char, etc.) **/
	private boolean primitive;

	/** Type de la classe de la primitive **/
	private Class<?> primitiveType;

	/** Classe de la primitive **/
	private Class<?> primitiveAsClass;

	/** Indicateur de type simple **/
	private boolean simpleType;

	/** Indicateur de type simple avec importation requise **/
	private boolean simpleTypeImportRequired;

	/** Liste des importations requises **/
	private List<Class<?>> importRequiredList;

	/** Indicateur de type java java.lang.Class **/
	private boolean classType;

	/** Indicateur de type java java.lang.Object **/
	private boolean objectType;

	/** Indicateur de type java java.lang.String **/
	private boolean stringType;

	/** Indicateur de type java java.io.Serializable **/
	private boolean serializableType;

	/** Indicateur de liste **/
	private boolean listType;

	/** Indicateur de dictionnaire **/
	private boolean mapType;

	/** Indicateur d'énumération **/
	private boolean enumType;

	/** Indicateur de la classe d'énumération **/
	private boolean enumClassType;

	/** Indicateur de tableau **/
	private boolean arrayType;

	/** Nombre de dimensions du tableau **/
	private int arrayDimensions;

	/** Indicateur de type générique **/
	private boolean genericType;

	/** Valeur du type générique (i.e. la valeur de TypeVariable ou WildcardType) **/
	private String genericTypeValue;

	/** Indicateur de type spécifique **/
	private boolean specificType;

	/** Liste des types **/
	private TypeInfoData[] typesList;

	/** Nom du convertisseur de OutilsGson à utiliser **/
	private String jsonParserName;

	/**
	 * Constructeur de base
	 */
	protected TypeInfoData() {
		this.classData = null;
		this.classSimpleData = null;
		this.packageName = null;
		this.className = null;
		this.classSimpleName = null;
		this.defaultValue = "null";
		this.defaultSimpleValue = "null";
		this.primitive = false;
		this.primitiveType = null;
		this.primitiveAsClass = null;
		this.simpleType = false;
		this.simpleTypeImportRequired = false;
		this.importRequiredList = null;
		this.classType = false;
		this.objectType = false;
		this.stringType = false;
		this.serializableType = false;
		this.listType = false;
		this.mapType = false;
		this.enumType = false;
		this.enumClassType = false;
		this.arrayType = false;
		this.arrayDimensions = 0;
		this.genericType = false;
		this.genericTypeValue = null;
		this.specificType = false;
		this.typesList = new TypeInfoData[0];
		this.jsonParserName = null;
	}

	/**
	 * Constructeur de base
	 * @param typeInfoData Classe des données d'un type de classe
	 */
	@StrictAutomatedTests("new TypeInfoData(java.lang.String.class)")
	@StrictAutomatedTests("new TypeInfoData(classes.reflexions.data.TypeInfoDataTestClass.class)")
	public TypeInfoData(TypeInfoData typeInfoData) {
		this.classData = typeInfoData.classData;
		this.classSimpleData = typeInfoData.classSimpleData;
		this.packageName = typeInfoData.packageName;
		this.className = typeInfoData.className;
		this.classSimpleName = typeInfoData.classSimpleName;
		this.defaultValue = typeInfoData.defaultValue;
		this.defaultSimpleValue = typeInfoData.defaultSimpleValue;
		this.primitive = typeInfoData.primitive;
		this.primitiveType = typeInfoData.primitiveType;
		this.primitiveAsClass = typeInfoData.primitiveAsClass;
		this.simpleType = typeInfoData.simpleType;
		this.simpleTypeImportRequired = typeInfoData.simpleTypeImportRequired;
		this.importRequiredList = typeInfoData.importRequiredList;
		this.classType = typeInfoData.classType;
		this.objectType = typeInfoData.objectType;
		this.stringType = typeInfoData.stringType;
		this.serializableType = typeInfoData.serializableType;
		this.listType = typeInfoData.listType;
		this.mapType = typeInfoData.mapType;
		this.enumType = typeInfoData.enumType;
		this.enumClassType = typeInfoData.enumClassType;
		this.arrayType = typeInfoData.arrayType;
		this.arrayDimensions = typeInfoData.arrayDimensions;
		this.genericType = typeInfoData.genericType;
		this.genericTypeValue = typeInfoData.genericTypeValue;
		this.specificType = typeInfoData.specificType;
		this.jsonParserName = typeInfoData.jsonParserName;

		if (!OutilsBase.isEmpty(typeInfoData.typesList)) {
			this.typesList = new TypeInfoData[typeInfoData.typesList.length];

			for (int i = 0; i < typeInfoData.typesList.length; i++) {
				this.typesList[i] = typeInfoData.typesList[i];
			}
		} else {
			this.typesList = new TypeInfoData[0];
		}
	}

	/**
	 * Constructeur de base
	 * @param name Nom de la classe
	 */
	@AutomatedTests(value = "boolean,byte,char,double,float,int,long,short,void", iterate = true)
	@AutomatedTests(value = "boolean[].class.getName(),byte[].class.getName(),char[].class.getName(),double[].class.getName(),float[].class.getName(),int[].class.getName(),long[].class.getName(),short[].class.getName()", iterate = true, process = false)
	@AutomatedTests(value = "java.lang.Boolean,java.lang.Byte,java.lang.Character,java.lang.Double,java.lang.Float,java.lang.Integer,java.lang.Long,java.lang.Short", iterate = true)
	@AutomatedTests(value = "java.math.BigDecimal,java.util.Date,java.sql.Date,java.lang.Enum,java.time.Instant,java.lang.String,java.sql.Time,java.sql.Timestamp,java.lang.Void", iterate = true)
	@AutomatedTests(value = "Boolean[].class.getName(),Byte[].class.getName(),Character[].class.getName(),Double[].class.getName(),Float[].class.getName(),Integer[].class.getName(),Long[].class.getName(),Short[].class.getName(),java.math.BigDecimal[].class.getName()", iterate = true, process = false)
	@AutomatedTests(value = "classes.reflexions.data.TypeInfoDataTestClass.class.getName(),classes.reflexions.data.TypeInfoDataTestClass.InnerClass.class.getName()", iterate = true, process = false)
	@AutomatedTests(value = "java.util.List.class.getName(),java.util.Map.class.getName()", iterate = true, process = false)
	@AutomatedTests(value = "new java.util.ArrayList<java.lang.String>().getClass().getName();new java.util.HashMap<java.lang.String, java.lang.String>().getClass().getName()", separator = ';', iterate = true, process = false)
	@NotForTestMethodsInstance
	public TypeInfoData(String name) {
		this();
		
		if (OutilsBase.isEmpty(name)) {
			throw new RuntimeException("Pas de nom de classe de spécifié");
		}

		switch (name) {
			case "boolean":
				extractClass(boolean.class);
				break;
			case "byte":
				extractClass(byte.class);
				break;
			case "char":
				extractClass(char.class);
				break;
			case "double":
				extractClass(double.class);
				break;
			case "float":
				extractClass(float.class);
				break;
			case "int":
				extractClass(int.class);
				break;
			case "long":
				extractClass(long.class);
				break;
			case "short":
				extractClass(short.class);
				break;
			case "void":
				extractClass(void.class);
				break;
			default:
				try {
					extractClass(Class.forName(name));
				} catch (ClassNotFoundException e) {
					throw new RuntimeException(e);
				}
				break;
		}
	}

	/**
	 * Constructeur de base
	 * @param data Les données de la classe
	 */
	@StrictAutomatedTests({ "(Class<?>) null", "outils.reflexions.data.TypeInfoData.class" })
	public TypeInfoData(Class<?> data) {
		this();

		if (data == null) {
			throw new RuntimeException("Pas de classe de spécifiée");
		}

		extractClass(data);
	}

	/**
	 * Constructeur de base
	 * @param type Type de la classe
	 */
	@StrictAutomatedTests("outils.reflexions.data.TypeInfoData.class.getGenericSuperclass()")
	@NotForTestMethodsInstance
	public TypeInfoData(Type type) {
		this();
		
		extractType(type);
	}

	/**
	 * Extraction des données pour une classe donnée
	 * @param data La classe à extraire
	 */
	protected void extractClass(Class<?> data) {
		processClass(data);

		processType(data);

		processJsonParserName();
	}

	/**
	 * Extraction des données pour un type de classe donné
	 * @param type Le type de la classe à extraire
	 */
	protected void extractType(Type type) {
		processType(type);

		processJsonParserName();
	}

	/**
	 * Traitement d'une classe
	 * @param data Les données de la classe à traiter
	 */
	protected void processClass(Class<?> data) {
		classData = data;
		className = classData.getTypeName().replace("[]", "");
		primitive = classData.isPrimitive();
		enumType = classData.isEnum();
		arrayType = classData.isArray();

		int pos = className.lastIndexOf('.');
		int posInnerClass = className.lastIndexOf('$');

		className = className.replace('$', '.');
		packageName = (pos != -1) ? className.substring(0, pos) : null;
		classSimpleName = (posInnerClass != -1) ? className.substring(posInnerClass + 1) : ((pos != -1) ? className.substring(pos + 1) : className);

		if (arrayType) {
			Class<?> clz = classData;

			while (clz.isArray()) {
				arrayDimensions++;
				clz = clz.getComponentType();
			}
		}

		switch (className) {
			case "boolean":
				primitive = true;
				primitiveType = boolean.class;
				primitiveAsClass = Boolean.class;
				defaultSimpleValue = "false";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Boolean":
				primitiveAsClass = classData;
				defaultSimpleValue = "Boolean.FALSE";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "byte":
				primitive = true;
				primitiveType = byte.class;
				primitiveAsClass = Byte.class;
				defaultSimpleValue = "(" + classSimpleName + ") 0";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Byte":
				primitiveAsClass = classData;
				defaultSimpleValue = "new " + classSimpleName + "((" + byte.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "char":
				primitive = true;
				primitiveType = char.class;
				primitiveAsClass = Character.class;
				defaultSimpleValue = "(" + classSimpleName + ") 0";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Character":
				primitiveAsClass = classData;
				defaultSimpleValue = "new " + classSimpleName + "((" + char.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "double":
				primitive = true;
				primitiveType = double.class;
				primitiveAsClass = Double.class;
				defaultSimpleValue = "(" + classSimpleName + ") 0";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Double":
				primitiveAsClass = classData;
				defaultSimpleValue = "new " + classSimpleName + "((" + double.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Enum":
				enumClassType = true;
				break;
			case "float":
				primitive = true;
				primitiveType = float.class;
				primitiveAsClass = Float.class;
				defaultSimpleValue = "(" + classSimpleName + ") 0";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Float":
				primitiveAsClass = classData;
				defaultSimpleValue = "new " + classSimpleName + "((" + float.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "int":
				primitive = true;
				primitiveType = int.class;
				primitiveAsClass = Integer.class;
				defaultSimpleValue = "(" + classSimpleName + ") 0";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Integer":
				primitiveAsClass = classData;
				defaultSimpleValue = "new " + classSimpleName + "((" + int.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "long":
				primitive = true;
				primitiveType = long.class;
				primitiveAsClass = Long.class;
				defaultSimpleValue = "(" + classSimpleName + ") 0";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Long":
				primitiveAsClass = classData;
				defaultSimpleValue = classSimpleName + ".valueOf((" + long.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "short":
				primitive = true;
				primitiveType = short.class;
				primitiveAsClass = Short.class;
				defaultSimpleValue = "(" + classSimpleName + ") 0";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "java.lang.Short":
				primitiveAsClass = classData;
				defaultSimpleValue = "new " + classSimpleName + "((" + short.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
			case "void":
				primitive = false;
				primitiveType = void.class;
				primitiveAsClass = Void.class;
				defaultSimpleValue = "";
				defaultValue = "";
				break;
			case "java.lang.Void":
				primitiveAsClass = classData;
				defaultSimpleValue = "";
				defaultValue = "";
				break;
			case "java.math.BigDecimal":
				primitiveAsClass = classData;
				defaultSimpleValue = "new " + classSimpleName + "((" + int.class.getSimpleName() + ") 0)";
				defaultValue = arrayType ? ("new " + classSimpleName + getArrayDimensionsAsString(true)) : defaultSimpleValue;
				break;
		}

		simpleType = primitive || (!genericType && className.startsWith("java.lang."));

		if (arrayType) {
			if (primitive) {
				classSimpleData = primitiveType;
			} else {
				try {
					classSimpleData = Class.forName(className);
				} catch (ClassNotFoundException e) {
					throw new RuntimeException(e);
				}
			}
		} else {
			classSimpleData = classData;
		}

		simpleTypeImportRequired = java.math.BigDecimal.class.equals(classSimpleData) //
				|| java.util.Date.class.equals(classSimpleData) //
				|| java.sql.Date.class.equals(classSimpleData) //
				|| java.time.Instant.class.equals(classSimpleData) //
				|| java.sql.Time.class.equals(classSimpleData) //
				|| java.sql.Timestamp.class.equals(classSimpleData) //
		;

		classType = Class.class.equals(classSimpleData);
		objectType = Object.class.equals(classSimpleData);
		stringType = String.class.equals(classSimpleData);
		serializableType = Serializable.class.equals(classSimpleData);
		listType = List.class.equals(classSimpleData);
		mapType = Map.class.equals(classSimpleData);
	}

	/**
	 * Traitement d'un type de classe
	 * @param data Les données de la classe à traiter
	 */
	protected void processType(Class<?> data) {
		if (data instanceof GenericDeclaration) {
			GenericDeclaration genericDeclaration = (GenericDeclaration) data;

			TypeVariable<?>[] typeVariables = genericDeclaration.getTypeParameters();

			if (!OutilsBase.isEmpty(typeVariables)) {
				genericType = true;
				genericTypeValue = null;
				typesList = new TypeInfoData[typeVariables.length];

				for (int i = 0; i < typeVariables.length; i++) {
					typesList[i] = new TypeInfoData(typeVariables[i]);
				}
			}
		}
	}

	/**
	 * Traitement d'un type
	 * @param type Les données du type à traiter
	 */
	protected void processType(Type type) {
		if (type instanceof GenericArrayType) {
			GenericArrayType genericArrayType = (GenericArrayType) type;

			processType(genericArrayType.getGenericComponentType());

			arrayType = true;
			arrayDimensions++;
		} else if (type instanceof ParameterizedType) {
			ParameterizedType parameterizedType = (ParameterizedType) type;

			processType(parameterizedType.getRawType());

			Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();

			if (!OutilsBase.isEmpty(actualTypeArguments)) {
				typesList = new TypeInfoData[actualTypeArguments.length];

				genericType = false;
				specificType = false;

				for (int i = 0; i < actualTypeArguments.length; i++) {
					Type item = actualTypeArguments[i];

					if ((item instanceof TypeVariable) || (item instanceof WildcardType)) {
						genericType = true;
					} else {
						specificType = true;
					}

					typesList[i] = new TypeInfoData(item);
				}
			}
		} else if (type instanceof TypeVariable) {
			processClass(Object.class);

			genericType = true;
			genericTypeValue = ((TypeVariable<?>) type).getName();
		} else if (type instanceof WildcardType) {
			processClass(Object.class);

			genericType = true;
			genericTypeValue = "?";
		} else if (type instanceof Class<?>) {
			extractClass((Class<?>) type);
		} else {
			throw new RuntimeException("Pas de traitement pour " + type);
		}
	}

	/**
	 * Traitement du nom du convertisseur de OutilsGson à utiliser
	 */
	protected void processJsonParserName() {
		Class<?> parserClass = null;
		String parserSimpleName = null;

		if (!arrayType || (arrayType && (arrayDimensions <= 1))) {
			if (listType) {
				if (!genericType && (typesList.length == 1)) {
					parserClass = typesList[0].classData;
					parserSimpleName = typesList[0].classSimpleName;
				}
			} else if (mapType) {
				if (!genericType && (typesList.length == 2)) {
					parserClass = typesList[1].classData; // Map Value Type
					parserSimpleName = typesList[1].classSimpleName;
				}
			} else {
				parserClass = classData;
				parserSimpleName = classSimpleName;
			}
		}

		String parserName = null;

		if (parserClass != null) {
			String parserType = "";
			String parserTypeName = OutilsBase.doCapitalize(parserSimpleName);

			if (primitive) {
				parserType = "Primitive" + (arrayType ? "Array" : "");
			} else if (listType) {
				if (parserClass.isArray()) {
					parserType = "Array";
				}

				parserType += "List";
			} else if (mapType) {
				if (parserClass.isArray()) {
					parserType = "Array";
				}

				parserType += "Map";
			} else if (arrayType) {
				parserType = "Array";
			}

			switch (parserTypeName) {
				case "BigDecimal":
				case "Boolean":
				case "Byte":
				case "Char":
				case "Double":
				case "Float":
				case "Int":
				case "Long":
				case "Object":
				case "Short":
				case "String":
				case "Timestamp":
					parserName = "as" + parserTypeName + parserType;
					break;
				case "Character":
					parserName = "asChar" + parserType;
					break;
				case "Integer":
					parserName = "asInt" + parserType;
					break;
				case "Date":
					if (java.util.Date.class.equals(parserClass)) {
						parserName = "asDate" + parserType;
					} else if (java.sql.Date.class.equals(parserClass)) {
						parserName = "asSqlDate" + parserType;
					} else {
						parserName = null;
					}
					break;
				default:
					parserName = null;
					break;
			}
		}

		jsonParserName = parserName;
	}

	/**
	 * Normalisation d'un type source selon le type courant
	 * @param sourceType Le type source à normaliser
	 * @return le type source normalisé
	 */
	protected TypeInfoData asCurrentType(TypeInfoData sourceType) {
		return asTargetType(sourceType, this);
	}

	/**
	 * Normalisation du type courant selon un type cible donné
	 * @param targetType Le type cible donné
	 * @return le type source normalisé
	 */
	protected TypeInfoData asTargetType(TypeInfoData targetType) {
		return asTargetType(this, targetType);
	}

	/**
	 * Normalisation d'un type source selon un type cible donné
	 * @param sourceType Le type source à normaliser
	 * @param targetType Le type cible donné
	 * @return le type source normalisé
	 */
	protected TypeInfoData asTargetType(TypeInfoData sourceType, TypeInfoData targetType) {
		TypeInfoData typeInfoData = sourceType;

		if (sourceType.arrayDimensions != targetType.arrayDimensions) {
			typeInfoData = new TypeInfoData(sourceType);
			typeInfoData.arrayType = targetType.arrayType;
			typeInfoData.arrayDimensions = targetType.arrayDimensions;
		}

		return typeInfoData;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TypeInfoData [" + getTypeName(true) + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof TypeInfoData) {
				TypeInfoData typeInfoData = (TypeInfoData) obj;

				return OutilsBase.areEquals(classData, typeInfoData.classData);
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(classData);
	}

	/**
	 * Extrait la classe des données du type de classe
	 * @return la classe des données du type de classe
	 */
	public Class<?> getClassData() {
		return getClassData(true);
	}

	/**
	 * Extrait la classe des données du type de classe
	 * @param simpleClass Indicateur de classe simple de base
	 * @return la classe des données du type de classe
	 */
	public Class<?> getClassData(boolean simpleClass) {
		return simpleClass ? classSimpleData : classData;
	}

	/**
	 * Extrait le champ packageName
	 * @return un String
	 */
	public String getPackageName() {
		return packageName;
	}

	/**
	 * Extrait le nom de la classe des données du type de classe
	 * @return le nom de la classe des données du type de classe
	 */
	public String getClassName() {
		return getClassName(true);
	}

	/**
	 * Extrait le nom de la classe des données du type de classe
	 * @param simpleClass Indicateur de classe simple de base
	 * @return le nom de la classe des données du type de classe
	 */
	public String getClassName(boolean simpleClass) {
		return simpleClass ? classSimpleName : className;
	}

	/**
	 * Convertion d'un type de classe generique en type de classe spécifique
	 * @param defaultGenericType Type générique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le type de classe spécifique convertit
	 */
	public TypeInfoData asSpecificTypeInfoData(TypeInfoData defaultGenericType) {
		return asSpecificTypeInfoData(null, defaultGenericType);
	}

	/**
	 * Convertion d'un type de classe generique en type de classe spécifique
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @return le type de classe spécifique convertit
	 */
	public TypeInfoData asSpecificTypeInfoData(Map<String, TypeInfoData> genericTypesDict) {
		return asSpecificTypeInfoData(genericTypesDict, null);
	}

	/**
	 * Convertion d'un type de classe generique en type de classe spécifique
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @param defaultGenericType Type générique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le type de classe spécifique convertit
	 */
	public TypeInfoData asSpecificTypeInfoData(Map<String, TypeInfoData> genericTypesDict, TypeInfoData defaultGenericType) {
		TypeInfoData specificTypeInfoData;

		if (objectType && genericType && !OutilsBase.isEmpty(genericTypeValue)) {
			if ((genericTypesDict != null) ? genericTypesDict.containsKey(genericTypeValue) : false) {
				specificTypeInfoData = asCurrentType(genericTypesDict.get(genericTypeValue)).asSpecificTypeInfoData(genericTypesDict, defaultGenericType);
			} else if (defaultGenericType != null) {
				specificTypeInfoData = asCurrentType(defaultGenericType).asSpecificTypeInfoData(genericTypesDict, defaultGenericType);
			} else {
				specificTypeInfoData = asCurrentType(new TypeInfoData(Object.class));
			}
		} else {
			specificTypeInfoData = new TypeInfoData(this);
		}

		if (specificTypeInfoData.isGenericType() || specificTypeInfoData.isSpecificType()) {
			for (int i = 0; i < specificTypeInfoData.getTypesList().length; i++) {
				TypeInfoData type = specificTypeInfoData.getTypesList()[i];

				if (type.isGenericType()) {
					if (!OutilsBase.isEmpty(type.getGenericTypeValue())) {
						if ((genericTypesDict != null) ? genericTypesDict.containsKey(type.getGenericTypeValue()) : false) {
							specificTypeInfoData.getTypesList()[i] = asTargetType(genericTypesDict.get(type.getGenericTypeValue()), type).asSpecificTypeInfoData(genericTypesDict, defaultGenericType);
						} else if (defaultGenericType != null) {
							specificTypeInfoData.getTypesList()[i] = asTargetType(defaultGenericType, type).asSpecificTypeInfoData(genericTypesDict, defaultGenericType);
						} else {
							specificTypeInfoData.getTypesList()[i] = asTargetType(new TypeInfoData(Object.class), type);
						}
					} else {
						specificTypeInfoData.getTypesList()[i] = type.asSpecificTypeInfoData(genericTypesDict, defaultGenericType);
					}
				} else {
					specificTypeInfoData.getTypesList()[i] = new TypeInfoData(type);
				}

				specificTypeInfoData.specificType = true;
			}
		}

		specificTypeInfoData.genericType = false;
		specificTypeInfoData.genericTypeValue = null;

		return specificTypeInfoData;
	}

	/**
	 * Extrait le nom du type
	 * @return le nom du type
	 */
	public String getTypeName() {
		return getTypeName(false, false, false, null, null);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType) {
		return getTypeName(simpleType, false, false, null, null);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType) {
		return getTypeName(simpleType, plainType, false, null, null);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @param typeless Indicateur d'extraction du type sans type générique ou spécifique
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType, boolean typeless) {
		return getTypeName(simpleType, plainType, typeless, null, null);
	}

	/**
	 * Extrait le nom du type
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @return le nom du type
	 */
	public String getTypeName(Map<String, TypeInfoData> genericTypesDict) {
		return getTypeName(false, false, false, genericTypesDict, null);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, Map<String, TypeInfoData> genericTypesDict) {
		return getTypeName(simpleType, false, false, genericTypesDict, null);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType, Map<String, TypeInfoData> genericTypesDict) {
		return getTypeName(simpleType, plainType, false, genericTypesDict, null);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @param typeless Indicateur d'extraction du type sans type générique ou spécifique
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType, boolean typeless, Map<String, TypeInfoData> genericTypesDict) {
		return getTypeName(simpleType, plainType, typeless, genericTypesDict, null);
	}

	/**
	 * Extrait le nom du type
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(TypeInfoData defaultGenericType) {
		return getTypeName(false, false, false, null, defaultGenericType);
	}

	/**
	 * Extrait le nom du type
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(Map<String, TypeInfoData> genericTypesDict, TypeInfoData defaultGenericType) {
		return getTypeName(false, false, false, genericTypesDict, defaultGenericType);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, TypeInfoData defaultGenericType) {
		return getTypeName(simpleType, false, false, null, defaultGenericType);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, Map<String, TypeInfoData> genericTypesDict, TypeInfoData defaultGenericType) {
		return getTypeName(simpleType, false, false, genericTypesDict, defaultGenericType);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType, TypeInfoData defaultGenericType) {
		return getTypeName(simpleType, plainType, false, null, defaultGenericType);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @param typeless Indicateur d'extraction du type sans type générique ou spécifique
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType, boolean typeless, TypeInfoData defaultGenericType) {
		return getTypeName(simpleType, plainType, typeless, null, defaultGenericType);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType, Map<String, TypeInfoData> genericTypesDict, TypeInfoData defaultGenericType) {
		return getTypeName(simpleType, plainType, false, genericTypesDict, defaultGenericType);
	}

	/**
	 * Extrait le nom du type
	 * @param simpleType Indicateur de type simple
	 * @param plainType Indicateur d'extraction du type sans tableau
	 * @param typeless Indicateur d'extraction du type sans type générique ou spécifique
	 * @param genericTypesDict Dictionnaire des types des noms génériques de types
	 * @param defaultGenericType Type génétique par défaut pour les valeurs non présentes dans le dictionnaire
	 * @return le nom du type
	 */
	public String getTypeName(boolean simpleType, boolean plainType, boolean typeless, Map<String, TypeInfoData> genericTypesDict, TypeInfoData defaultGenericType) {
		String typeName;

		if (objectType && genericType && !OutilsBase.isEmpty(genericTypeValue)) {
			if ((genericTypesDict != null) ? genericTypesDict.containsKey(genericTypeValue) : false) {
				typeName = genericTypesDict.get(genericTypeValue).getTypeName(simpleType, plainType, typeless, genericTypesDict, defaultGenericType);
			} else if (defaultGenericType != null) {
				typeName = defaultGenericType.getTypeName(simpleType, plainType, typeless, genericTypesDict, defaultGenericType);
			} else {
				typeName = genericTypeValue;
			}
		} else {
			typeName = simpleType ? classSimpleName : className;

			if (genericType || specificType) {
				List<String> list = new ArrayList<String>();

				for (TypeInfoData type : typesList) {
					if (type.isGenericType()) {
						if (!OutilsBase.isEmpty(type.getGenericTypeValue())) {
							String item;

							if ((genericTypesDict != null) ? genericTypesDict.containsKey(type.getGenericTypeValue()) : false) {
								item = genericTypesDict.get(type.getGenericTypeValue()).getTypeName(simpleType, plainType, typeless, genericTypesDict, defaultGenericType);
							} else if (defaultGenericType != null) {
								item = defaultGenericType.getTypeName(simpleType, plainType, typeless, genericTypesDict, defaultGenericType);
							} else {
								item = type.getGenericTypeValue();
							}

							list.add(item + type.getArrayDimensionsAsString());
						} else {
							list.add(type.getTypeName(simpleType, plainType, typeless, genericTypesDict, defaultGenericType));
						}
					} else {
						list.add(type.getTypeName(simpleType, false, false, genericTypesDict, defaultGenericType));
					}
				}

				if (!typeless) {
					typeName += "<" + OutilsCommun.toList(list, ", ") + ">";
				}
			}
		}

		if (!plainType && arrayType) {
			typeName += getArrayDimensionsAsString();
		}

		return typeName;
	}

	/**
	 * Indique s'il y a des importations requises ou non
	 * @return vrai s'il y a des importations requises
	 */
	public boolean isImportRequired() {
		return !getImportRequiredList().isEmpty();
	}

	/**
	 * Extrait la liste des classes requises pour importation
	 * @return la liste des classes requises pour importation
	 */
	public List<Class<?>> getImportRequiredList() {
		if (importRequiredList == null) {
			importRequiredList = new ArrayList<Class<?>>();

			if (simpleType && simpleTypeImportRequired) {
				importRequiredList.add(classSimpleData);
			} else if (!simpleType && !OutilsBase.areEquals("java.lang", packageName)) {
				importRequiredList.add(classSimpleData);
			}

			if (listType && !importRequiredList.contains(List.class)) {
				importRequiredList.add(List.class);
			}

			if (mapType && !importRequiredList.contains(Map.class)) {
				importRequiredList.add(Map.class);
			}

			if (!OutilsBase.isEmpty(typesList)) {
				for (TypeInfoData type : typesList) {
					if (type.isImportRequired()) {
						for (Class<?> item : type.getImportRequiredList()) {
							if (!importRequiredList.contains(item)) {
								importRequiredList.add(item);
							}
						}
					}
				}
			}

			importRequiredList.sort(new Comparator<Class<?>>() {

				@Override
				public int compare(Class<?> o1, Class<?> o2) {
					return OutilsBase.compareIgnoreCase(o1, o2);
				}
			});
		}

		return importRequiredList;
	}

	/**
	 * Extrait la liste des noms des classes requises pour importation
	 * @return la liste des noms des classes requises pour importation
	 */
	public List<String> getImportRequiredAsStringList() {
		List<String> list = new ArrayList<String>();

		for (Class<?> item : getImportRequiredList()) {
			list.add(item.getTypeName());
		}

		return list;
	}

	/**
	 * Indicateur d'utilisation du convertisseur de OutilsGson
	 * @return vrai si un convertisseur existe
	 */
	public boolean hasJsonParserName() {
		return jsonParserName != null;
	}

	/**
	 * Indique si le type est void ou non
	 * @return vrai si le type est void
	 */
	public boolean isVoid() {
		return void.class.equals(classData);
	}

	/**
	 * Indique si c'est une interface ou non
	 * @return vrai si c'est une interface
	 */
	public boolean isInterfaceType() {
		return classData.isInterface();
	}

	/**
	 * Indique si c'est compatible avec une instance donnée
	 * @param object L'instance à vérifier
	 * @return vrai si c'est compatible
	 */
	public boolean isInstance(Object object) {
		return classData.isInstance(object);
	}

	/**
	 * Indique si c'est compatible avec une classe donnée
	 * @param data La classe à vérifier
	 * @return vrai si c'est compatible
	 */
	public boolean isAssignableFrom(Class<?> data) {
		if (data != null) {
			return classData.isAssignableFrom(data);
		}

		return false;
	}

	/**
	 * Indique si c'est compatible pour un type de classe donné
	 * @param typeInfoData Le type de classe à vérifier
	 * @return vrai si c'est compatible
	 */
	public boolean isAssignableFrom(TypeInfoData typeInfoData) {
		if (typeInfoData != null) {
			return classData.isAssignableFrom(typeInfoData.classData);
		}

		return false;
	}

	/**
	 * Extrait le champ defaultValue
	 * @return un String
	 */
	public String getDefaultValue() {
		return defaultValue;
	}

	/**
	 * Extrait le champ defaultSimpleValue
	 * @return un String
	 */
	public String getDefaultSimpleValue() {
		return defaultSimpleValue;
	}

	/**
	 * Extrait le champ primitive
	 * @return un boolean
	 */
	public boolean isPrimitive() {
		return primitive;
	}

	/**
	 * Modifie le champ primitiveType
	 * @param primitiveType La valeur du champ primitiveType
	 */
	public void setPrimitiveType(Class<?> primitiveType) {
		this.primitiveType = primitiveType;
	}

	/**
	 * Extrait le champ primitiveType
	 * @return un Class<?>
	 */
	public Class<?> getPrimitiveType() {
		return primitiveType;
	}

	/**
	 * Indique si le type a une classe de primitive ou non
	 * @return vrai si le type a une classe de primitive
	 */
	public boolean hasPrimitiveAsClass() {
		return primitiveAsClass != null;
	}

	/**
	 * Extrait le champ primitiveAsClass
	 * @return un Class<?>
	 */
	public Class<?> getPrimitiveAsClass() {
		return primitiveAsClass;
	}

	/**
	 * Extrait le champ simpleType
	 * @return un boolean
	 */
	public boolean isSimpleType() {
		return simpleType || simpleTypeImportRequired || enumType;
	}

	/**
	 * Extrait le champ simpleTypeImportRequired
	 * @return un boolean
	 */
	public boolean isSimpleTypeImportRequired() {
		return simpleTypeImportRequired;
	}

	/**
	 * Extrait le champ classType
	 * @return un boolean
	 */
	public boolean isClassType() {
		return classType;
	}

	/**
	 * Extrait le champ objectType
	 * @return un boolean
	 */
	public boolean isObjectType() {
		return objectType;
	}

	/**
	 * Extrait le champ stringType
	 * @return un boolean
	 */
	public boolean isStringType() {
		return stringType;
	}

	/**
	 * Extrait le champ serializableType
	 * @return un boolean
	 */
	public boolean isSerializableType() {
		return serializableType;
	}

	/**
	 * Extrait le champ listType
	 * @return un boolean
	 */
	public boolean isListType() {
		return listType;
	}

	/**
	 * Extrait le champ listTypeGeneric
	 * @return un boolean
	 */
	public boolean isListTypeGeneric() {
		return genericType;
	}

	/**
	 * Extrait le type de la liste
	 * @return le type de la liste (null sinon)
	 */
	public TypeInfoData getListType() {
		if (listType && (typesList.length == 1)) {
			return typesList[0];
		}

		return null;
	}

	/**
	 * Modifie le champ typesList
	 * @param typesList La valeur du champ typesList
	 */
	public void setTypesList(TypeInfoData... typesList) {
		if (typesList == null) {
			this.typesList = new TypeInfoData[0];
		} else {
			this.typesList = typesList;
		}
	}

	/**
	 * Extrait le champ mapType
	 * @return un boolean
	 */
	public boolean isMapType() {
		return mapType;
	}

	/**
	 * Extrait le champ mapTypeGeneric
	 * @return un boolean
	 */
	public boolean isMapTypeGeneric() {
		return genericType;
	}

	/**
	 * Extrait le type des clés du dictionnaire
	 * @return le type des clés du dictionnaire (null sinon)
	 */
	public TypeInfoData getMapKeysType() {
		if (mapType && (typesList.length == 2)) {
			return typesList[0];
		}

		return null;
	}

	/**
	 * Extrait le type des valeurs du dictionnaire
	 * @return le type des valeurs du dictionnaire (null sinon)
	 */
	public TypeInfoData getMapValuesType() {
		if (mapType && (typesList.length == 2)) {
			return typesList[1];
		}

		return null;
	}

	/**
	 * Extrait le champ enumType
	 * @return un boolean
	 */
	public boolean isEnumType() {
		return enumType;
	}

	/**
	 * Extrait le champ enumClassType
	 * @return un boolean
	 */
	public boolean isEnumClassType() {
		return enumClassType;
	}

	/**
	 * Extrait la liste des valeurs d'une énumération
	 * @return la liste des valeurs d'une énumération
	 * @throws Exception en cas d'erreur...
	 */
	public List<Enum<?>> getEnumValuesList() throws Exception {
		if (enumType) {
			return OutilsBase.asList((Enum<?>[]) classData.getEnumConstants());
		}

		return new ArrayList<Enum<?>>();
	}

	/**
	 * Extrait le champ arrayType
	 * @return un boolean
	 */
	public boolean isArrayType() {
		return arrayType;
	}

	/**
	 * Extrait le champ arrayDimensions
	 * @return un int
	 */
	public int getArrayDimensions() {
		return arrayDimensions;
	}

	/**
	 * Extrait le champ arrayDimensions sous forme de texte
	 * @return un String
	 */
	public String getArrayDimensionsAsString() {
		return getArrayDimensionsAsString(false);
	}

	/**
	 * Extrait le champ arrayDimensions sous forme de texte
	 * @param empty Indicateur de dimension à zéro
	 * @return un String
	 */
	public String getArrayDimensionsAsString(boolean empty) {
		String result = "";

		if (arrayType) {
			for (int i = 0; i < arrayDimensions; i++) {
				result += empty ? "[0]" : "[]";
			}
		}

		return result;
	}

	/**
	 * Extrait le champ genericType
	 * @return un boolean
	 */
	public boolean isGenericType() {
		return genericType;
	}

	/**
	 * Extrait le champ genericTypeValue
	 * @return un String
	 */
	public String getGenericTypeValue() {
		return genericTypeValue;
	}

	/**
	 * Extrait le champ specificType
	 * @return un boolean
	 */
	public boolean isSpecificType() {
		return specificType;
	}

	/**
	 * Extrait le champ typesList
	 * @return un TypeInfoData[]
	 */
	public TypeInfoData[] getTypesList() {
		return typesList;
	}

	/**
	 * Extrait le champ jsonParserName
	 * @return un String
	 */
	public String getJsonParserName() {
		return jsonParserName;
	}
}
