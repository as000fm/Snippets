package outils.reflexions.data.filters;

import java.lang.reflect.Modifier;

import outils.tests.automated.annotations.AddImportsForTesting;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Filtre sur les modificateurs d'un constructeur d'une classe pour JSON
 * @author Claude Toupin - 2 juill. 2021
 */
@AddImportsForTesting(java.lang.reflect.Modifier.class)
public class JSONConstructorModifiersFilter implements ModifiersFilter {

	/*
	 * (non-Javadoc)
	 * @see outils.reflexions.data.ModifiersFilter#accept(int)
	 */
	@Override
	@AutomatedTests({ "Modifier.PUBLIC", "Modifier.STATIC" })
	public boolean accept(int modifiers) {
		if (!Modifier.isPublic(modifiers) || Modifier.isStatic(modifiers)) {
			return false;
		}

		return true;
	}

}
