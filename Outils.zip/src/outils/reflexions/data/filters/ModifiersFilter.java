package outils.reflexions.data.filters;

/**
 * Filtre sur les modificateurs
 * @author Claude Toupin - 2 juill. 2021
 */
@FunctionalInterface
public interface ModifiersFilter {

	/**
	 * Test d'acception des modificateurs
	 * @param modifiers Valeur des modificateurs à tester
	 * @return vrai si accepté
	 */
	boolean accept(int modifiers);
}
