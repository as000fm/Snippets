package outils.registry;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import outils.base.OutilsBase;
import outils.commun.OutilsCommun;
import outils.listes.NameValue;
import outils.registry.types.WindowsRegistryHivesTypes;
import outils.tests.automated.ICoverageTestsCases;
import outils.tests.automated.annotations.CoverageTestsCases;
import outils.tests.automated.annotations.DefaultParameterTestValue;
import outils.tests.automated.annotations.TestExecutionOrder;

/**
 * Classe d'accès à la base de registre de Windows
 * @author Claude Toupin - 13 août 2019
 */
@DefaultParameterTestValue(type = WindowsRegistryHivesTypes.class, name = "hive", value = "WindowsRegistryHivesTypes.HKEY_CURRENT_USER", strict = false)
@DefaultParameterTestValue(type = String.class, name = "keyName", value = "TestUnit\\KeyName", strict = false)
@DefaultParameterTestValue(type = String.class, name = "fullName", value = "HKCU\\TestUnit\\FullName", strict = false)
@CoverageTestsCases(WindowsRegistry.CoverageTestsCases.class)
public class WindowsRegistry {

	/**
	 * Classe des cas de tests supplémentaires à être exécutés pour les tests de couverture
	 * @author Claude Toupin - 29 janv. 2023
	 */
	final public static class CoverageTestsCases implements ICoverageTestsCases {

		@Override
		public void doBeforeAll() throws Exception {
			WindowsRegistry.byteArrayToString(null);
			WindowsRegistry.byteArrayToString(new byte[0]);

			try {
				WindowsRegistry.checkResult(ERROR_CODE, WindowsRegistryHivesTypes.HKEY_CURRENT_USER, "TestUnit\\KeyName");
			} catch (BackingStoreException e) {
				// OK
			}

			try {
				WindowsRegistry.checkResult(ERROR_FILE_NOT_FOUND, WindowsRegistryHivesTypes.HKEY_CURRENT_USER, "TestUnit\\KeyName");
			} catch (BackingStoreException e) {
				// OK
			}

			try {
				WindowsRegistry.checkResult(ERROR_ACCESS_DENIED, WindowsRegistryHivesTypes.HKEY_CURRENT_USER, "TestUnit\\KeyName");
			} catch (BackingStoreException e) {
				// OK
			}

			WindowsRegistry.getHiveData(WindowsRegistryHivesTypes.HKEY_LOCAL_MACHINE.getName());

			try {
				WindowsRegistry.getHiveData("Test");
			} catch (IllegalArgumentException e) {
				// OK
			}
		}

		@Override
		public void doAfterAll() throws Exception {
			// Aucun
		}

	}

	/**
	 * Données de la branche principale (hive) et du nom de la clé
	 * @author Claude Toupin - 13 août 2019
	 */
	protected static class HiveData {
		/** Branche principale (hive) **/
		final private WindowsRegistryHivesTypes hive;

		/** Nom de la clé **/
		final private String keyName;

		/**
		 * Constructeur de base
		 * @param hive Branche principale (hive)
		 * @param keyName Nom de la clé
		 */
		public HiveData(WindowsRegistryHivesTypes hive, String keyName) {
			this.hive = hive;
			this.keyName = keyName;
		}

		/**
		 * Extrait le champ hive
		 * @return un WindowsRegistryHivesTypes
		 */
		public WindowsRegistryHivesTypes getHive() {
			return hive;
		}

		/**
		 * Extrait le champ keyName
		 * @return un String
		 */
		public String getKeyName() {
			return keyName;
		}
	}

	/** Méthode d'ouverture d'une clé **/
	final private static Method windowsRegOpenKey;

	/** Méthode de fermeture d'une clé **/
	final private static Method windowsRegCloseKey;

	/** Méthode de recherche d'une clé **/
	final private static Method windowsRegQueryValueEx;

	/** Méthode d'énumération de valeurs **/
	final private static Method windowsRegEnumValue;

	/** Méthode d'information d'une clé **/
	final private static Method windowsRegQueryInfoKey1;

	/** Méthode d'énumération de clés **/
	final private static Method windowsRegEnumKeyEx;

	/** Méthode de création d'une clé **/
	final private static Method windowsRegCreateKeyEx;

	/** Méthode de modification d'une valeur **/
	final private static Method windowsRegSetValueEx;

	/** Méthode de supression d'une clé **/
	final private static Method windowsRegDeleteKey;

	/** Méthode de supression d'une valeur **/
	final private static Method windowsRegDeleteValue;

	/** Masque de sécurité Windows de lecture **/
	final private static int KEY_READ = 0x20019;

	/** Masque de sécurité Windows d'accès complet **/
	final private static int KEY_ALL_ACCESS = 0xf003f;

	/** Index de gestion du retour d'appel d'une fonction native **/
	final private static int NATIVE_HANDLE = 0;

	/** Index de gestion du retour d'appel d'une fonction native **/
	final private static int ERROR_CODE = 1;

	/** Code d'erreur Windows: Succès **/
	final private static int ERROR_SUCCESS = 0;

	/** Code d'erreur Windows: Fichier non trouvé **/
	final private static int ERROR_FILE_NOT_FOUND = 2;

	/** Code d'erreur Windows: Accès refusé **/
	final private static int ERROR_ACCESS_DENIED = 5;

	static {
		if (!OutilsCommun.isWindows()) {
			throw new RuntimeException("La classe " + WindowsRegistry.class.getName() + " doit être exécutée sous Windows seulement !!!");
		}

		Class<? extends Preferences> userClass = Preferences.userRoot().getClass();

		try {
			windowsRegOpenKey = userClass.getDeclaredMethod("WindowsRegOpenKey", int.class, byte[].class, int.class);
			windowsRegOpenKey.setAccessible(true);

			windowsRegCloseKey = userClass.getDeclaredMethod("WindowsRegCloseKey", int.class);
			windowsRegCloseKey.setAccessible(true);

			windowsRegQueryValueEx = userClass.getDeclaredMethod("WindowsRegQueryValueEx", int.class, byte[].class);
			windowsRegQueryValueEx.setAccessible(true);

			windowsRegEnumValue = userClass.getDeclaredMethod("WindowsRegEnumValue", new Class[] { int.class, int.class, int.class });
			windowsRegEnumValue.setAccessible(true);

			windowsRegQueryInfoKey1 = userClass.getDeclaredMethod("WindowsRegQueryInfoKey1", new Class[] { int.class });
			windowsRegQueryInfoKey1.setAccessible(true);

			windowsRegEnumKeyEx = userClass.getDeclaredMethod("WindowsRegEnumKeyEx", new Class[] { int.class, int.class, int.class });
			windowsRegEnumKeyEx.setAccessible(true);

			windowsRegCreateKeyEx = userClass.getDeclaredMethod("WindowsRegCreateKeyEx", new Class[] { int.class, byte[].class });
			windowsRegCreateKeyEx.setAccessible(true);

			windowsRegSetValueEx = userClass.getDeclaredMethod("WindowsRegSetValueEx", new Class[] { int.class, byte[].class, byte[].class });
			windowsRegSetValueEx.setAccessible(true);

			windowsRegDeleteValue = userClass.getDeclaredMethod("WindowsRegDeleteValue", new Class[] { int.class, byte[].class });
			windowsRegDeleteValue.setAccessible(true);

			windowsRegDeleteKey = userClass.getDeclaredMethod("WindowsRegDeleteKey", new Class[] { int.class, byte[].class });
			windowsRegDeleteKey.setAccessible(true);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Conversion d'un texte en tableau terminé par un zéro (i.e. null-terminated)
	 * @param value Le texte à convertir
	 * @return le tableau terminé par un zéro
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected static byte[] stringToByteArray(String value) throws UnsupportedEncodingException {
		byte[] buf = value.getBytes("ISO-8859-1");

		byte[] result = new byte[buf.length + 1];

		for (int i = 0; i < buf.length; i++) {
			result[i] = buf[i];
		}

		result[buf.length] = 0;

		return result;
	}

	/**
	 * Conversion d'un tableau terminé par un zéro (i.e. null-terminated) en texte
	 * @param array Le tableau terminé par un zéro à convertir
	 * @return le texte
	 * @throws UnsupportedEncodingException en cas d'erreur...
	 */
	protected static String byteArrayToString(byte[] array) throws UnsupportedEncodingException {
		if (array == null) {
			return null;
		} else if (array.length <= 1) {
			return "";
		}

		byte[] buf = new byte[array.length - 1];

		for (int i = 0; i < buf.length; i++) {
			buf[i] = array[i];
		}

		return new String(buf, "ISO-8859-1");
	}

	/**
	 * Vérification du résultat d'une commande à la base de registre de Windows
	 * @param result Le résultat d'une commande à la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @return le résultat d'une commande à la base de registre de Windows
	 * @throws BackingStoreException en cas d'erreur...
	 */
	protected static int checkResult(int result, WindowsRegistryHivesTypes hive, String keyName) throws BackingStoreException {
		if (result != ERROR_SUCCESS) {
			if (result == ERROR_FILE_NOT_FOUND) {
				throw new BackingStoreException("Clé de registre introuvable: " + hive.getShortName() + "\\" + keyName);
			} else if (result == ERROR_ACCESS_DENIED) {
				throw new BackingStoreException("Accès refusé à la clé: " + hive.getShortName() + "\\" + keyName);
			} else {
				throw new BackingStoreException("Code d'erreur " + result + " lors de l'ouverture de la clé: " + hive.getShortName() + "\\" + keyName);
			}
		}

		return result;
	}

	/**
	 * Vérification du résultat d'une commande à la base de registre de Windows
	 * @param result Le résultat d'une commande à la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @return le résultat d'une commande à la base de registre de Windows
	 * @throws BackingStoreException en cas d'erreur...
	 */
	protected static int[] checkResult(int[] result, WindowsRegistryHivesTypes hive, String keyName) throws BackingStoreException {
		checkResult(result[ERROR_CODE], hive, keyName);

		return result;
	}

	/**
	 * Extrait la branche principale (hive) depuis un nom de clé donné
	 * @param name Nom de la clé à extraire la branche principale (hive)
	 * @return la branche principale (hive)
	 */
	protected static HiveData getHiveData(String name) {
		if (OutilsBase.isEmpty(name)) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		WindowsRegistryHivesTypes hive = null;

		int pos = name.indexOf("\\");

		if (pos != -1) {
			hive = WindowsRegistryHivesTypes.getWindowsRegistryHiveType(name.substring(0, pos));
			name = name.substring(pos + 1).trim();
		} else {
			hive = WindowsRegistryHivesTypes.getWindowsRegistryHiveType(name);
			name = "";
		}

		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		return new HiveData(hive, name);
	}

	/**
	 * Lecture d'une valeur d'une clé de la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @param valueName Le nom de la valeur
	 * @return La valeur extraite
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static String getValue(WindowsRegistryHivesTypes hive, String keyName, String valueName) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (keyName == null) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		if (OutilsBase.isEmpty(valueName)) {
			throw new IllegalArgumentException("Pas de nom de valeur de spécifé");
		}

		try {
			int[] result = checkResult((int[]) windowsRegOpenKey.invoke(hive.getRoot(), hive.getId(), stringToByteArray(keyName), KEY_READ), hive, keyName);

			int hKey = result[NATIVE_HANDLE];

			byte[] array = (byte[]) windowsRegQueryValueEx.invoke(hive.getRoot(), hKey, stringToByteArray(valueName));

			windowsRegCloseKey.invoke(hive.getRoot(), hKey);

			return byteArrayToString(array);
		} catch (InvocationTargetException e) {
			throw new BackingStoreException(e.getCause());
		} catch (Throwable t) {
			throw new BackingStoreException(t);
		}
	}

	/**
	 * Lecture d'une valeur d'une clé de la base de registre de Windows
	 * @param fullName Le chemin complet de la clé
	 * @param valueName Le nom de la valeur
	 * @return La valeur extraite
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static String getValue(String fullName, String valueName) throws BackingStoreException {
		if (OutilsBase.isEmpty(valueName)) {
			throw new IllegalArgumentException("Pas de nom de valeur de spécifé");
		}

		HiveData hiveData = getHiveData(fullName);

		return getValue(hiveData.getHive(), hiveData.getKeyName(), valueName);
	}

	/**
	 * Écriture d'une valeur d'une clé de la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @param valueName Le nom de la valeur
	 * @param value La valeur à écrire
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(-1)
	final public static void setValue(WindowsRegistryHivesTypes hive, String keyName, String valueName, String value) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (keyName == null) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		if (OutilsBase.isEmpty(valueName)) {
			throw new IllegalArgumentException("Pas de nom de valeur de spécifé");
		}

		if (value == null) {
			throw new IllegalArgumentException("Pas de valeur de spécifé");
		}

		try {
			int[] result = checkResult((int[]) windowsRegOpenKey.invoke(hive.getRoot(), hive.getId(), stringToByteArray(keyName), KEY_ALL_ACCESS), hive, keyName);

			int hKey = result[NATIVE_HANDLE];

			windowsRegSetValueEx.invoke(hive.getRoot(), hKey, stringToByteArray(valueName), stringToByteArray(value));

			windowsRegCloseKey.invoke(hive.getRoot(), hKey);
		} catch (InvocationTargetException e) {
			throw new BackingStoreException(e.getCause());
		} catch (Throwable t) {
			throw new BackingStoreException(t);
		}
	}

	/**
	 * Écriture d'une valeur d'une clé de la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @param valueName Le nom de la valeur
	 * @param value La valeur à écrire
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(-1)
	final public static void setValue(String fullName, String valueName, String value) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		setValue(hiveData.getHive(), hiveData.getKeyName(), valueName, value);
	}

	/**
	 * Extraction du dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @return le dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static Map<String, String> getValuesDict(WindowsRegistryHivesTypes hive, String keyName) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (keyName == null) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		HashMap<String, String> dict = new HashMap<String, String>();

		try {
			int[] result = checkResult((int[]) windowsRegOpenKey.invoke(hive.getRoot(), hive.getId(), stringToByteArray(keyName), KEY_READ), hive, keyName);

			int hKey = result[NATIVE_HANDLE];

			int[] info = (int[]) windowsRegQueryInfoKey1.invoke(hive.getRoot(), hKey);

			int count = info[2];

			int maxlen = info[4];

			for (int index = 0; index < count; index++) {
				String valueName = byteArrayToString((byte[]) windowsRegEnumValue.invoke(hive.getRoot(), hKey, index, maxlen + 1));

				String value = getValue(hive, keyName, valueName);

				dict.put(valueName, value);
			}

			windowsRegCloseKey.invoke(hive.getRoot(), hKey);
		} catch (InvocationTargetException e) {
			throw new BackingStoreException(e.getCause());
		} catch (Throwable t) {
			throw new BackingStoreException(t);
		}

		return dict;
	}

	/**
	 * Extraction du dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @return le dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static Map<String, String> getValuesDict(String fullName) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		return getValuesDict(hiveData.getHive(), hiveData.getKeyName());
	}

	/**
	 * Écriture du dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @param dict Le dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(-1)
	final public static void setValuesDict(WindowsRegistryHivesTypes hive, String keyName, Map<String, String> dict) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (keyName == null) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		if (dict == null) {
			throw new IllegalArgumentException("Pas de dictionnaire de spécifé");
		}

		for (String key : dict.keySet()) {
			setValue(hive, keyName, key, dict.get(key));
		}
	}

	/**
	 * Écriture du dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @param dict Le dictionnaire des valeurs d'une clé de la base de registre de Windows
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(-1)
	final public static void setValuesDict(String fullName, Map<String, String> dict) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		setValuesDict(hiveData.getHive(), hiveData.getKeyName(), dict);
	}

	/**
	 * Extraction de la liste des valeurs d'une clé de la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<NameValue> getValuesList(WindowsRegistryHivesTypes hive, String keyName) throws BackingStoreException {
		Map<String, String> dict = getValuesDict(hive, keyName);

		List<NameValue> list = new ArrayList<NameValue>();

		for (String key : dict.keySet()) {
			list.add(new NameValue(key, dict.get(key)));
		}

		if (list.size() > 1) {
			list.sort(new NameValue.Compare());
		}

		return list;
	}

	/**
	 * Extraction de la liste des valeurs d'une clé de la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<NameValue> getValuesList(String fullName) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		return getValuesList(hiveData.getHive(), hiveData.getKeyName());
	}

	/**
	 * Écriture de la liste des valeurs d'une clé de la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(-1)
	final public static void setValuesList(WindowsRegistryHivesTypes hive, String keyName, List<NameValue> list) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (keyName == null) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		if (list == null) {
			throw new IllegalArgumentException("Pas de liste de spécifé");
		}

		for (NameValue item : list) {
			setValue(hive, keyName, item.getName(), item.getValue());
		}
	}

	/**
	 * Écriture de la liste des valeurs d'une clé de la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(-1)
	final public static void setValuesList(String fullName, List<NameValue> list) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		setValuesList(hiveData.getHive(), hiveData.getKeyName(), list);
	}

	/**
	 * Création d'une clé dans la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @param valueName Le nom de la valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(1)
	final public static void deleteValue(WindowsRegistryHivesTypes hive, String keyName, String valueName) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (OutilsBase.isEmpty(keyName)) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		if (OutilsBase.isEmpty(valueName)) {
			throw new IllegalArgumentException("Pas de nom de valeur de spécifé");
		}

		try {
			int[] result = checkResult((int[]) windowsRegOpenKey.invoke(hive.getRoot(), hive.getId(), stringToByteArray(keyName), KEY_ALL_ACCESS), hive, keyName);

			int hKey = result[NATIVE_HANDLE];

			checkResult((int) windowsRegDeleteValue.invoke(hive.getRoot(), hKey, stringToByteArray(valueName)), hive, keyName);

			windowsRegCloseKey.invoke(hive.getRoot(), hKey);
		} catch (InvocationTargetException e) {
			throw new BackingStoreException(e.getCause());
		} catch (Throwable t) {
			throw new BackingStoreException(t);
		}
	}

	/**
	 * Création d'une clé dans la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @param valueName Le nom de la valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(1)
	final public static void deleteValue(String fullName, String valueName) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		deleteValue(hiveData.getHive(), hiveData.getKeyName(), valueName);
	}

	/**
	 * Extraction de la liste des clés la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @param addKeyPath Indicateur d'ajout du chemin de la clé aux clés extraites
	 * @param addHiveToKeyPath Indicateur d'ajout de la branche principale (hive) aux clés extraites
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<String> getKeysList(WindowsRegistryHivesTypes hive, String keyName, boolean addKeyPath, boolean addHiveToKeyPath) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (keyName == null) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		List<String> list = new ArrayList<String>();

		try {
			int[] result = checkResult((int[]) windowsRegOpenKey.invoke(hive.getRoot(), hive.getId(), stringToByteArray(keyName), KEY_READ), hive, keyName);

			int hKey = result[NATIVE_HANDLE];

			int[] info = (int[]) windowsRegQueryInfoKey1.invoke(hive.getRoot(), hKey);

			int count = info[0];

			int maxlen = info[3];

			for (int index = 0; index < count; index++) {
				String key = byteArrayToString((byte[]) windowsRegEnumKeyEx.invoke(hive.getRoot(), hKey, index, maxlen + 1));

				if (addKeyPath) {
					if (!OutilsBase.isEmpty(keyName)) {
						key = keyName + "\\" + key;
					}

					if (addHiveToKeyPath) {
						key = hive.getName() + "\\" + key;
					}
				}

				list.add(key);
			}

			windowsRegCloseKey.invoke(hive.getRoot(), hKey);
		} catch (InvocationTargetException e) {
			throw new BackingStoreException(e.getCause());
		} catch (Throwable t) {
			throw new BackingStoreException(t);
		}

		if (list.size() > 1) {
			Collections.sort(list);
		}

		return list;
	}

	/**
	 * Extraction de la liste des clés la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @param addKeyPath Indicateur d'ajout du chemin de la clé aux clés extraites
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<String> getKeysList(WindowsRegistryHivesTypes hive, String keyName, boolean addKeyPath) throws BackingStoreException {
		return getKeysList(hive, keyName, addKeyPath, false);
	}

	/**
	 * Extraction de la liste des clés la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<String> getKeysList(WindowsRegistryHivesTypes hive, String keyName) throws BackingStoreException {
		return getKeysList(hive, keyName, false, false);
	}

	/**
	 * Extraction de la liste des clés la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<String> getKeysList(String fullName, boolean addKeyPath, boolean addHiveToKeyPath) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		return getKeysList(hiveData.getHive(), hiveData.getKeyName(), addKeyPath, addHiveToKeyPath);
	}

	/**
	 * Extraction de la liste des clés la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<String> getKeysList(String fullName, boolean addKeyPath) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		return getKeysList(hiveData.getHive(), hiveData.getKeyName(), addKeyPath, addKeyPath);
	}

	/**
	 * Extraction de la liste des clés la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @return la liste des valeurs sous forme nom=valeur
	 * @throws BackingStoreException en cas d'erreur...
	 */
	final public static List<String> getKeysList(String fullName) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		return getKeysList(hiveData.getHive(), hiveData.getKeyName(), false, false);
	}

	/**
	 * Création d'une clé dans la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(first = true)
	final public static void createKey(WindowsRegistryHivesTypes hive, String keyName) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (OutilsBase.isEmpty(keyName)) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		try {
			int[] result = checkResult((int[]) windowsRegCreateKeyEx.invoke(hive.getRoot(), hive.getId(), stringToByteArray(keyName)), hive, keyName);

			int hKey = result[NATIVE_HANDLE];

			windowsRegCloseKey.invoke(hive.getRoot(), hKey);
		} catch (InvocationTargetException e) {
			throw new BackingStoreException(e.getCause());
		} catch (Throwable t) {
			throw new BackingStoreException(t);
		}
	}

	/**
	 * Création d'une clé dans la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(first = true)
	final public static void createKey(String fullName) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		createKey(hiveData.getHive(), hiveData.getKeyName());
	}

	/**
	 * Création d'une clé dans la base de registre de Windows
	 * @param hive La branche principale (hive)
	 * @param keyName Le chemin de la clé
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(last = true)
	final public static void deleteKey(WindowsRegistryHivesTypes hive, String keyName) throws BackingStoreException {
		if (hive == null) {
			throw new IllegalArgumentException("Pas de type de branche principale (hive) de spécifé");
		}

		if (OutilsBase.isEmpty(keyName)) {
			throw new IllegalArgumentException("Pas de nom de clé de spécifé");
		}

		try {
			checkResult((int) windowsRegDeleteKey.invoke(hive.getRoot(), hive.getId(), stringToByteArray(keyName)), hive, keyName);
		} catch (InvocationTargetException e) {
			throw new BackingStoreException(e.getCause());
		} catch (Throwable t) {
			throw new BackingStoreException(t);
		}
	}

	/**
	 * Création d'une clé dans la base de registre de Windows
	 * @param fullName Le chemin de la clé
	 * @throws BackingStoreException en cas d'erreur...
	 */
	@TestExecutionOrder(last = true)
	final public static void deleteKey(String fullName) throws BackingStoreException {
		HiveData hiveData = getHiveData(fullName);

		deleteKey(hiveData.getHive(), hiveData.getKeyName());
	}
}
