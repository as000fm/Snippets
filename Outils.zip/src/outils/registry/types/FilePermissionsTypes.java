package outils.registry.types;

import java.nio.file.attribute.PosixFilePermission;
import java.util.EnumSet;
import java.util.Set;

import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types de permissions de fichiers
 * @author Claude Toupin - 27 juin 2019
 */
public enum FilePermissionsTypes {
	OWNER_READ(PosixFilePermission.OWNER_READ, 0x400), //
	OWNER_WRITE(PosixFilePermission.OWNER_WRITE, 0x200), //
	OWNER_EXECUTE(PosixFilePermission.OWNER_EXECUTE, 0x100), //
	GROUP_READ(PosixFilePermission.GROUP_READ, 0x40), //
	GROUP_WRITE(PosixFilePermission.GROUP_WRITE, 0x20), //
	GROUP_EXECUTE(PosixFilePermission.GROUP_EXECUTE, 0x10), //
	OTHERS_READ(PosixFilePermission.OTHERS_READ, 0x4), //
	OTHERS_WRITE(PosixFilePermission.OTHERS_WRITE, 0x2), //
	OTHERS_EXECUTE(PosixFilePermission.OTHERS_EXECUTE, 0x1), //
	;

	/** Permission de fichier posix **/
	final private PosixFilePermission posixFilePermission;

	/** Position unix **/
	final private int position;

	/**
	 * Constructeur de base
	 * @param posixFilePermission Permission de fichier posix
	 * @param position Position unix
	 */
	private FilePermissionsTypes(PosixFilePermission posixFilePermission, int position) {
		this.posixFilePermission = posixFilePermission;
		this.position = position;
	}

	/**
	 * Extrait la liste des permissions posix pour un masque de permissions en hexadécimale (ex: 0x640)
	 * @param permissions Le masque de permissions en hexadécimale
	 * @return la liste des permissions posix
	 */
	@AutomatedTests({ "-1", "0x640" })
	final public static Set<PosixFilePermission> getPosixFilePermissions(int permissions) {
		if (permissions < 0) {
			throw new RuntimeException("La valeur des permissions doit être 0 ou positve (i.e. >= 0)");
		}

		Set<PosixFilePermission> result = EnumSet.noneOf(PosixFilePermission.class);

		for (FilePermissionsTypes type : FilePermissionsTypes.values()) {
			if ((permissions & type.getPosition()) != 0) {
				result.add(type.getPosixFilePermission());
			}
		}

		return result;
	}

	/**
	 * Extrait le masque de permissions en hexadécimale depuis une liste des permissions posix
	 * @param permissions Liste des permissions posix
	 * @return le masque de permissions en hexadécimale
	 */
	@AutomatedTests(value = "java.util.EnumSet.of(PosixFilePermission.OWNER_READ)", process = false)
	final public static int getPermissions(Set<PosixFilePermission> permissions) {
		int value = 0;

		if (permissions != null) {
			for (FilePermissionsTypes type : FilePermissionsTypes.values()) {
				if (permissions.contains(type.getPosixFilePermission())) {
					value |= type.getPosition();
				}
			}
		}

		return value;
	}

	/**
	 * Indique si permission de lecture
	 * @param permissions Le masque de permissions en hexadécimale
	 * @return vrai si permission de lecture
	 */
	final public static boolean isReadable(int permissions) {
		return isReadable(getPosixFilePermissions(permissions));
	}

	/**
	 * Indique si permission de lecture
	 * @param permissions Liste des permissions posix
	 * @return vrai si permission de lecture
	 */
	@AutomatedTests(value = {"java.util.EnumSet.of(PosixFilePermission.OWNER_READ)", "java.util.EnumSet.of(PosixFilePermission.GROUP_READ)", "java.util.EnumSet.of(PosixFilePermission.OTHERS_READ)"}, process = false)
	final public static boolean isReadable(Set<PosixFilePermission> permissions) {
		if (permissions != null) {
			return permissions.contains(PosixFilePermission.OWNER_READ) || permissions.contains(PosixFilePermission.GROUP_READ) || permissions.contains(PosixFilePermission.OTHERS_READ);
		}

		return false;
	}

	final public static boolean isReadableByOwnerOnly(int permissions) {
		return isReadableByOwnerOnly(getPosixFilePermissions(permissions));
	}

	/**
	 * Indique si permission de lecture par le propriétaire seulement
	 * @param permissions Liste des permissions posix
	 * @return vrai si permission de lecture par le propriétaire seulement
	 */
	@AutomatedTests(value = {"java.util.EnumSet.of(PosixFilePermission.OWNER_READ)", "java.util.EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.GROUP_READ)", "java.util.EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OTHERS_READ)"}, process = false)
	final public static boolean isReadableByOwnerOnly(Set<PosixFilePermission> permissions) {
		if (permissions != null) {
			return permissions.contains(PosixFilePermission.OWNER_READ) && !(permissions.contains(PosixFilePermission.GROUP_READ) || permissions.contains(PosixFilePermission.OTHERS_READ));
		}

		return false;
	}

	/**
	 * Indique si permission d'écriture
	 * @param permissions Le masque de permissions en hexadécimale
	 * @return vrai si permission d'écriture
	 */
	final public static boolean isWritable(int permissions) {
		return isWritable(getPosixFilePermissions(permissions));
	}

	/**
	 * Indique si permission d'écriture
	 * @param permissions Liste des permissions posix
	 * @return vrai si permission d'écriture
	 */
	@AutomatedTests(value = {"java.util.EnumSet.of(PosixFilePermission.OWNER_WRITE)", "java.util.EnumSet.of(PosixFilePermission.GROUP_WRITE)", "java.util.EnumSet.of(PosixFilePermission.OTHERS_WRITE)"}, process = false)
	final public static boolean isWritable(Set<PosixFilePermission> permissions) {
		if (permissions != null) {
			return permissions.contains(PosixFilePermission.OWNER_WRITE) || permissions.contains(PosixFilePermission.GROUP_WRITE) || permissions.contains(PosixFilePermission.OTHERS_WRITE);
		}

		return false;
	}

	final public static boolean isWritableByOwnerOnly(int permissions) {
		return isWritableByOwnerOnly(getPosixFilePermissions(permissions));
	}

	/**
	 * Indique si permission d'écriture par le propriétaire seulement
	 * @param permissions Liste des permissions posix
	 * @return vrai si permission d'écriture par le propriétaire seulement
	 */
	@AutomatedTests(value = {"java.util.EnumSet.of(PosixFilePermission.OWNER_WRITE)", "java.util.EnumSet.of(PosixFilePermission.OWNER_WRITE, PosixFilePermission.GROUP_WRITE)", "java.util.EnumSet.of(PosixFilePermission.OWNER_WRITE, PosixFilePermission.OTHERS_WRITE)"}, process = false)
	final public static boolean isWritableByOwnerOnly(Set<PosixFilePermission> permissions) {
		if (permissions != null) {
			return permissions.contains(PosixFilePermission.OWNER_WRITE) && !(permissions.contains(PosixFilePermission.GROUP_WRITE) || permissions.contains(PosixFilePermission.OTHERS_WRITE));
		}

		return false;
	}

	/**
	 * Indique si permission d'exécution
	 * @param permissions Le masque de permissions en hexadécimale
	 * @return vrai si permission d'exécution
	 */
	final public static boolean isExecutable(int permissions) {
		return isExecutable(getPosixFilePermissions(permissions));
	}

	/**
	 * Indique si permission d'exécution
	 * @param permissions Liste des permissions posix
	 * @return vrai si permission d'exécution
	 */
	@AutomatedTests(value = {"java.util.EnumSet.of(PosixFilePermission.OWNER_EXECUTE)", "java.util.EnumSet.of(PosixFilePermission.GROUP_EXECUTE)", "java.util.EnumSet.of(PosixFilePermission.OTHERS_EXECUTE)"}, process = false)
	final public static boolean isExecutable(Set<PosixFilePermission> permissions) {
		if (permissions != null) {
			return permissions.contains(PosixFilePermission.OWNER_EXECUTE) || permissions.contains(PosixFilePermission.GROUP_EXECUTE) || permissions.contains(PosixFilePermission.OTHERS_EXECUTE);
		}

		return false;
	}

	final public static boolean isExecutableByOwnerOnly(int permissions) {
		return isExecutableByOwnerOnly(getPosixFilePermissions(permissions));
	}

	/**
	 * Indique si permission d'exécution par le propriétaire seulement
	 * @param permissions Liste des permissions posix
	 * @return vrai si permission d'exécution par le propriétaire seulement
	 */
	@AutomatedTests(value = {"java.util.EnumSet.of(PosixFilePermission.OWNER_EXECUTE)", "java.util.EnumSet.of(PosixFilePermission.OWNER_EXECUTE, PosixFilePermission.GROUP_EXECUTE)", "java.util.EnumSet.of(PosixFilePermission.OWNER_EXECUTE, PosixFilePermission.OTHERS_EXECUTE)"}, process = false)
	final public static boolean isExecutableByOwnerOnly(Set<PosixFilePermission> permissions) {
		if (permissions != null) {
			return permissions.contains(PosixFilePermission.OWNER_EXECUTE) && !(permissions.contains(PosixFilePermission.GROUP_EXECUTE) || permissions.contains(PosixFilePermission.OTHERS_EXECUTE));
		}

		return false;
	}

	/**
	 * Extrait le champ posixFilePermission
	 * @return un PosixFilePermission
	 */
	public PosixFilePermission getPosixFilePermission() {
		return posixFilePermission;
	}

	/**
	 * Extrait le champ position
	 * @return un int
	 */
	public int getPosition() {
		return position;
	}
}
