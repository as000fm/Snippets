package outils.registry.types;

import java.util.prefs.Preferences;

import outils.base.OutilsBase;

/**
 * Énumération des types des branches principales (hives) de la base de registre de Windows
 * @author Claude Toupin - 13 août 2019
 */
public enum WindowsRegistryHivesTypes {
	HKEY_CLASSES_ROOT("HKCR", "HKEY_CLASSES_ROOT", 0x80000000), //
	HKEY_CURRENT_USER("HKCU", "HKEY_CURRENT_USER", 0x80000001, Preferences.userRoot()), // Avertissement? -> Il faut créer la clé: HKEY_LOCAL_MACHINE\Software\JavaSoft\Prefs
	HKEY_LOCAL_MACHINE("HKLM", "HKEY_LOCAL_MACHINE", 0x80000002), //
	HKEY_USERS("HKU", "HKEY_USERS", 0x80000003), //
	HKEY_CURRENT_CONFIG("HKCC", "HKEY_CURRENT_CONFIG", 0x80000005), //
	;
	
	/** Nom court de la branche principale (hive) **/
	final private String shortName;
	
	/** Nom complet de la branche principale (hive) **/
	final private String name;
	
	/** Identifiant de la branche principale (hive) **/
	final private int id;
	
	/** Indicateur de préférences usager ou système **/
	final private Preferences root;

	/**
	 * Constructeur de base
	 * @param shortName Nom court de la branche principale (hive)
	 * @param name Nom complet de la branche principale (hive)
	 * @param id Identifiant de la branche principale (hive)
	 */
	private WindowsRegistryHivesTypes(String shortName, String name, int id) {
		this(shortName, name, id, Preferences.systemRoot());
	}

	/**
	 * Constructeur de base
	 * @param shortName Nom court de la branche principale (hive)
	 * @param name Nom complet de la branche principale (hive)
	 * @param id Identifiant de la branche principale (hive)
	 * @param root Indicateur de préférences usager ou système
	 */
	private WindowsRegistryHivesTypes(String shortName, String name, int id, Preferences root) {
		this.shortName = shortName;
		this.name = name;
		this.id = id;
		this.root = root;
	}
	
	/**
	 * Extrait le type de branche principale (hive) pour une clé donnée
	 * @param key La clé à extraire 
	 * @return le type de branche principale (null si pas trouvé)
	 */
	final public static WindowsRegistryHivesTypes getWindowsRegistryHiveType(String key) {
		if (!OutilsBase.isEmpty(key)) {
			String value = key.toUpperCase();
			
			for(WindowsRegistryHivesTypes type: WindowsRegistryHivesTypes.values()) {
				if (value.startsWith(type.getShortName()) || value.startsWith(type.getName())) {
					return type;
				}
			}
		}
		
		return null;
	}

	/**
	 * Extrait le champ shortName
	 * @return un String
	 */
	public String getShortName() {
		return shortName;
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Extrait le champ id
	 * @return un int
	 */
	public int getId() {
		return id;
	}

	/**
	 * Extrait le champ root
	 * @return un Preferences
	 */
	public Preferences getRoot() {
		return root;
	}
}
