package outils.tests.automated;

import java.util.List;

import outils.tests.automated.data.AutomatedTestsCaseData;

/**
 * Interface des valeurs des cas de tests pour les tests automatisés générés par programmation (similaire à @AutomatedTests et @StrictAutomatedTests)
 * @author Claude Toupin - 2 janv. 2022
 */
public interface IAutomatedTestsCases {
	/**
	 * Extrait les valeurs des cas de tests pour la signature d'un constructeur donné
	 * @param testClass Classe des cas de tests à extraire les valeurs de tests
	 * @param constructorSignature La signature du constructeur des cas de tests à extraire les valeurs de tests
	 * @return la liste des valeurs des cas de tests pour la signature du constructeur (null si aucun test requis)
	 */
	List<AutomatedTestsCaseData> getConstructorValues(Class<?> testClass, String constructorSignature);

	/**
	 * Extrait les valeurs des cas de tests pour la signature d'une méthode donnée
	 * @param testClass Classe des cas de tests à extraire les valeurs de tests
	 * @param constructorSignature La signature de la méthode des cas de tests à extraire les valeurs de tests
	 * @return la liste des valeurs des cas de tests pour la signature de la méthode (null si aucun test requis)
	 */
	List<AutomatedTestsCaseData> getMethodValues(Class<?> testClass, String methodSignature);
}
