package outils.tests.automated;

/**
 * Interface des cas de tests supplémentaires à être exécutés pour les tests de couverture
 * @author Claude Toupin - 29 janv. 2023
 */
public interface ICoverageTestsCases {

	/**
	 * Effectue les cas de tests en premier
	 * @throws Exception en cas d'erreur...
	 */
	void doBeforeAll() throws Exception;

	/**
	 * Effectue les cas de tests en dernier
	 * @throws Exception en cas d'erreur...
	 */
	void doAfterAll() throws Exception;
}
