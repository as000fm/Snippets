package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation pour spécifier des classes supplémentaires à importer pour effectuer les tests
 * @author Claude Toupin - 5 janv. 2022
 */
@Documented
@Retention(RUNTIME)
@Target({ TYPE })
@Repeatable(AddImportsForTesting.List.class)
public @interface AddImportsForTesting {
	Class<?>[] value();

	@Documented
	@Retention(RUNTIME)
	@Target({ TYPE })
	@interface List {
		AddImportsForTesting[] value();
	}
}
