package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import outils.tests.automated.data.AutomatedTestsCaseData;

/**
 * Annotation des valeurs pour les tests automatisés
 * @author Claude Toupin - 25 déc. 2021
 */
@Documented
@Retention(RUNTIME)
@Target({ METHOD, CONSTRUCTOR })
@Repeatable(AutomatedTests.List.class)
public @interface AutomatedTests {
	String[] value();

	int[] filenames() default {};

	boolean process() default true;

	boolean iterate() default false;

	char separator() default AutomatedTestsCaseData.SEPARATOR_CHAR_DEFAULT;

	@Documented
	@Retention(RUNTIME)
	@Target({ METHOD, CONSTRUCTOR })
	@interface List {
		AutomatedTests[] value();
	}
}
