package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation pour indiquer que les tests doivent être effectués pour la couverture du code seulement (i.e. pas de test assert d'effectué)
 * @author Claude Toupin - 25 déc. 2021
 */
@Documented
@Retention(RUNTIME)
@Target({ METHOD, CONSTRUCTOR, TYPE })
public @interface CoverageOnly {

}
