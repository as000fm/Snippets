package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation des cas de tests à être exécutés pour les tests automatisés
 * @author Claude Toupin - 29 janv. 2023
 */
@Documented
@Retention(RUNTIME)
@Target(TYPE)
@Repeatable(CoverageTestsCases.List.class)
public @interface CoverageTestsCases {
	// Note: la classe doit implémenter l'interface outils.tests.automated.ICoverageTestsCases
	Class<?>[] value();

	@Documented
	@Retention(RUNTIME)
	@Target(TYPE)
	@interface List {
		CoverageTestsCases[] value();
	}
}
