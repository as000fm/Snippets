package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import outils.tests.automated.data.AutomatedTestsCaseData;

/**
 * Annotation pour spécifier la valeur par défaut à utiliser pour un paramètre d'un type de classe donné
 * @author Claude Toupin - 5 janv. 2022
 */
@Documented
@Retention(RUNTIME)
@Target({ TYPE })
@Repeatable(DefaultParameterTestValue.List.class)
public @interface DefaultParameterTestValue {
	Class<?> type();

	String typename() default "";

	String name();

	String value();

	boolean filename() default false;

	boolean process() default true;

	char separator() default AutomatedTestsCaseData.SEPARATOR_CHAR_DEFAULT;

	boolean strict() default true;

	@Documented
	@Retention(RUNTIME)
	@Target({ TYPE })
	@interface List {
		DefaultParameterTestValue[] value();
	}
}
