package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation pour spécifier le nom de fichier par défaut à utiliser pour les paramètres de type File, Path et InputStream
 * @author Claude Toupin - 5 janv. 2022
 */
@Documented
@Retention(RUNTIME)
@Target({ TYPE })
public @interface DefaultTestFilename {
	String value();

	boolean process() default true;
}
