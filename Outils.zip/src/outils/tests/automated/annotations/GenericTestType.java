package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation des types des noms génériques de types (ex: T[] -> String[]) pour les tests automatisés
 * @author Claude Toupin - 9 janv. 2022
 */
@Documented
@Retention(RUNTIME)
@Target({ TYPE })
@Repeatable(GenericTestType.List.class)
public @interface GenericTestType {
	String name();

	Class<?> type();

	@Documented
	@Retention(RUNTIME)
	@Target({ TYPE })
	@interface List {
		GenericTestType[] value();
	}
}
