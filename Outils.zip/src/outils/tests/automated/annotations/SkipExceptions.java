package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation de la liste des exceptions à ignorer dans les tests automatisés
 * @author Claude Toupin - 16 janv. 2022
 */
@Documented
@Retention(RUNTIME)
@Target({ TYPE, METHOD, CONSTRUCTOR })
@Repeatable(SkipExceptions.List.class)
public @interface SkipExceptions {
	Class<?> value();

	@Documented
	@Retention(RUNTIME)
	@Target({ TYPE, METHOD, CONSTRUCTOR })
	@interface List {
		SkipExceptions[] value();
	}
}
