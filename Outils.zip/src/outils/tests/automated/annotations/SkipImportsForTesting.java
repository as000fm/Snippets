package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation pour spécifier des classes à ne pas importer pour effectuer les tests
 * @author Claude Toupin - 5 janv. 2022
 */
@Documented
@Retention(RUNTIME)
@Target({ TYPE })
@Repeatable(SkipImportsForTesting.List.class)
public @interface SkipImportsForTesting {
	Class<?>[] value();

	@Documented
	@Retention(RUNTIME)
	@Target({ TYPE })
	@interface List {
		SkipImportsForTesting[] value();
	}
}
