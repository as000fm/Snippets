package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation pour indiquer que les tests automatisés doivent être faits avec les valeurs spécifiées par programmation seulement
 * @author Claude Toupin - 25 déc. 2021
 */
@Documented
@Retention(RUNTIME)
@Target({ METHOD, CONSTRUCTOR })
@Repeatable(StrictAutomatedTestsCases.List.class)
public @interface StrictAutomatedTestsCases {
	//Note: la classe doit implémenter l'interface outils.tests.automated.IAutomatedTestsCases
	Class<?> value();

	String name() default "";

	@Documented
	@Retention(RUNTIME)
	@Target({ METHOD, CONSTRUCTOR })
	@interface List {
		StrictAutomatedTestsCases[] value();
	}
}
