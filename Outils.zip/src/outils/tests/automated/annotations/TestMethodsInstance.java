package outils.tests.automated.annotations;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation pour indiquer d'utiliser ce construteur pour les tests automatisés des méthodes
 * @author Claude Toupin - 25 déc. 2021
 */
@Documented
@Retention(RUNTIME)
@Target({ CONSTRUCTOR })
public @interface TestMethodsInstance {

}
