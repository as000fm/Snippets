package outils.tests.automated.data;

import java.util.Arrays;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.TestMethodsInstance;

/**
 * Données des valeurs des cas de tests pour les tests automatisés générés par programmation
 * @author Claude Toupin - 7 janv. 2022
 */
public class AutomatedTestsCaseData {
	/** Séparateur des items d'un test **/
	final public static char SEPARATOR_CHAR_DEFAULT = ',';
	
	/** Tableau des positions des traitements de noms de fichiers **/
	private int[] filenames;

	/** Indicateur de traitement des données **/
	private boolean process;

	/** Indicateur d'itération des données **/
	private boolean iterate;

	/** Type du separateur des valeurs des cas de tests **/
	private char separator;

	/** Liste des valeurs des cas de tests **/
	private String[] values;

	/**
	 * Constructeur de base
	 */
	public AutomatedTestsCaseData() {
		this((int[]) null, true, false, ',', (String[]) null);
	}

	/**
	 * Constructeur de base
	 * @param values Liste des valeurs des cas de tests
	 */
	@TestMethodsInstance
	public AutomatedTestsCaseData(String... values) {
		this(null, true, false, ',', values);
	}

	/**
	 * Constructeur de base
	 * @param iterate Indicateur d'itération des données
	 * @param values Liste des valeurs des cas de tests
	 */
	public AutomatedTestsCaseData(boolean iterate, String... values) {
		this(null, true, iterate, ',', values);
	}

	/**
	 * Constructeur de base
	 * @param separator Type du separateur des valeurs des cas de tests
	 * @param values Liste des valeurs des cas de tests
	 */
	public AutomatedTestsCaseData(char separator, String... values) {
		this(null, true, false, separator, values);
	}

	/**
	 * Constructeur de base
	 * @param filenames Tableau des positions des traitements de noms de fichiers
	 * @param values Liste des valeurs des cas de tests
	 */
	public AutomatedTestsCaseData(int[] filenames, String... values) {
		this(filenames, true, false, ',', values);
	}

	/**
	 * Constructeur de base
	 * @param filenames Tableau des positions des traitements de noms de fichiers
	 * @param separator Type du separateur des valeurs des cas de tests
	 * @param values Liste des valeurs des cas de tests
	 */
	public AutomatedTestsCaseData(int[] filenames, char separator, String... values) {
		this(filenames, true, false, separator, values);
	}

	/**
	 * Constructeur de base
	 * @param filenames Tableau des positions des traitements de noms de fichiers
	 * @param process Indicateur de traitement des données
	 * @param iterate Indicateur d'itération des données
	 * @param values Liste des valeurs des cas de tests
	 */
	public AutomatedTestsCaseData(int[] filenames, boolean process, boolean iterate, String... values) {
		this(filenames, process, iterate, ',', values);
	}

	/**
	 * Constructeur de base
	 * @param filenames Tableau des positions des traitements de noms de fichiers
	 * @param process Indicateur de traitement des données
	 * @param iterate Indicateur d'itération des données
	 * @param separator Type du separateur des valeurs des cas de tests
	 * @param values Liste des valeurs des cas de tests
	 */
	public AutomatedTestsCaseData(int[] filenames, boolean process, boolean iterate, char separator, String... values) {
		this.filenames = filenames;
		this.process = process;
		this.iterate = iterate;
		this.separator = separator;
		this.values = values;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AutomatedTestsCaseData [filenames=" + Arrays.toString(filenames) + ", process=" + process + ", iterate=" + iterate + ", separator=" + separator + ", values=" + Arrays.toString(values) + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof AutomatedTestsCaseData) {
				AutomatedTestsCaseData automatedTestsCaseData = (AutomatedTestsCaseData) obj;

				return OutilsBase.areEquals(filenames, automatedTestsCaseData.getFilenames()) //
						&& (process == automatedTestsCaseData.isProcess()) //
						&& (iterate == automatedTestsCaseData.isIterate()) //
						&& OutilsBase.areEquals(separator, automatedTestsCaseData.getSeparator()) //
						&& OutilsBase.areEquals(values, automatedTestsCaseData.getValues()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(filenames);
		result = prime * result + Arrays.hashCode(values);
		result = prime * result + Objects.hash(iterate, process, separator);
		return result;
	}

	/**
	 * Extrait le champ filenames
	 * @return un int[]
	 */
	public int[] getFilenames() {
		return filenames;
	}

	/**
	 * Modifie le champ filenames
	 * @param filenames La valeur du champ filenames
	 */
	public void setFilenames(int[] filenames) {
		this.filenames = filenames;
	}

	/**
	 * Extrait le champ process
	 * @return un boolean
	 */
	public boolean isProcess() {
		return process;
	}

	/**
	 * Modifie le champ process
	 * @param process La valeur du champ process
	 */
	public void setProcess(boolean process) {
		this.process = process;
	}

	/**
	 * Extrait le champ iterate
	 * @return un boolean
	 */
	public boolean isIterate() {
		return iterate;
	}

	/**
	 * Modifie le champ iterate
	 * @param iterate La valeur du champ iterate
	 */
	public void setIterate(boolean iterate) {
		this.iterate = iterate;
	}

	/**
	 * Extrait le champ separator
	 * @return un char
	 */
	public char getSeparator() {
		return separator;
	}

	/**
	 * Modifie le champ separator
	 * @param separator La valeur du champ separator
	 */
	public void setSeparator(char separator) {
		this.separator = separator;
	}

	/**
	 * Extrait le champ values
	 * @return un String[]
	 */
	public String[] getValues() {
		return values;
	}

	/**
	 * Modifie le champ values
	 * @param values La valeur du champ values
	 */
	public void setValues(String[] values) {
		this.values = values;
	}
}
