package outils.types;

/**
 * Énumération des types de séparateurs dans un fichier CSV
 * @author Claude Toupin - 2018-06-07
 */
public enum CSVSeparatorsTypes {
	ENGLISH(","), //
	FRENCH(";"), //
	TAB("\t"), //
	SPACE(" "), //
	;
	
	/** Séparateur **/
	final private String separator;
	
	/** Séparateur en caractère **/
	final private char separatorChar;

	/**
	 * Constructeur de base
	 * @param separator Séparateur
	 */
	private CSVSeparatorsTypes(String separator) {
		this.separator = separator;
		this.separatorChar = separator.charAt(0);
	}

	/**
	 * Extrait le champ separator
	 * @return un String
	 */
	public String getSeparator() {
		return separator;
	}

	/**
	 * Extrait le champ separatorChar
	 * @return un char
	 */
	public char getSeparatorChar() {
		return separatorChar;
	}
	
}
