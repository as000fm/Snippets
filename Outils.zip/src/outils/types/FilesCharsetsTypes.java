package outils.types;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types de jeux de caractères pour les fichiers
 * @author Claude Toupin - 10 juin 2019
 */
public enum FilesCharsetsTypes {
	AUTO_DETECTION(null), //
	US_ASCII("US-ASCII"), //
	ISO_8859_1("ISO-8859-1"), //
	UTF_8("UTF-8"), //
	UTF_8_BOM("UTF-8", new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF }, true), // Java fait la conversion à EFBBBF dans le fichier produit
	UTF_16BE("UTF-16BE", new byte[] { (byte) 0xFE, (byte) 0xFF }), //
	UTF_16LE("UTF-16LE", new byte[] { (byte) 0xFF, (byte) 0xFE }), //
	EUC_JP("EUC_JP"), //
	;

	/** Nom de l'encodage de caractères **/
	final private String charsetName;

	/** Caractères d'un marqueur BOM au début du fichier **/
	final private byte[] bom;

	/** Indicateur d'ajout d'un marqueur BOM au début du fichier **/
	final private boolean bomMarker;

	/** Indicateur d'ajout marqueur BOM au début du fichier **/
	final private boolean addBomMarkerToFile;

	/**
	 * Constructeur de base
	 * @param charsetName Nom de l'encodage de caractères
	 */
	private FilesCharsetsTypes(String charsetName) {
		this(charsetName, null);
	}

	/**
	 * Constructeur de base
	 * @param charsetName Nom de l'encodage de caractères
	 * @param bom Caractères d'un marqueur BOM au début du fichier
	 */
	private FilesCharsetsTypes(String charsetName, byte[] bom) {
		this(charsetName, bom, false);
	}

	/**
	 * Constructeur de base
	 * @param charsetName Nom de l'encodage de caractères
	 * @param bom Caractères d'un marqueur BOM au début du fichier
	 */
	private FilesCharsetsTypes(String charsetName, byte[] bom, boolean addBomMarkerToFile) {
		this.charsetName = charsetName;
		this.bom = bom;
		this.bomMarker = (bom != null);
		this.addBomMarkerToFile = addBomMarkerToFile;
	}

	/**
	 * Extrait le type de jeux de caractères pour les fichiers pour une valeur donnée
	 * @param value La valeur à extraire
	 * @return le type (null si pas trouvé)
	 */
	final public static FilesCharsetsTypes getFilesCharsetsTypes(String value) {
		if (!OutilsBase.isEmpty(value)) {
			for (FilesCharsetsTypes type : FilesCharsetsTypes.values()) {
				if (type.getCharsetName() != null) {
					if (type.getCharsetName().equalsIgnoreCase(value)) {
						return type;
					}
				}

				if (type.name().equalsIgnoreCase(value)) {
					return type;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le type de jeux de caractères pour les fichiers pour un tampon donné de caractères BOM
	 * @param buffer Le tampon des caractères BOM
	 * @return le type (null si pas trouvé)
	 */
	@AutomatedTests("new byte[] { (byte) 0xFF, (byte) 0xFE }")
	final public static FilesCharsetsTypes getFilesCharsetsTypes(byte[] buffer) {
		if (!OutilsBase.isEmpty(buffer)) {
			for (FilesCharsetsTypes type : FilesCharsetsTypes.values()) {
				if (type.isBomMarker()) {
					if (buffer.length >= type.getBom().length) {
						boolean found = true;

						byte[] bom = type.getBom();

						for (int i = 0; i < bom.length; i++) {
							if (bom[i] != buffer[i]) {
								found = false;
								break;
							}
						}

						if (found) {
							return type;
						}
					}
				}
			}
		}

		return null;

	}

	/**
	 * Extrait le champ charsetName
	 * @return un String
	 */
	public String getCharsetName() {
		return charsetName;
	}

	/**
	 * Extrait le champ bom
	 * @return un byte[]
	 */
	public byte[] getBom() {
		return bom;
	}

	/**
	 * Extrait le champ bomMarker
	 * @return un boolean
	 */
	public boolean isBomMarker() {
		return bomMarker;
	}

	/**
	 * Extrait le champ addBomMarkerToFile
	 * @return un boolean
	 */
	public boolean isAddBomMarkerToFile() {
		return addBomMarkerToFile;
	}

}
