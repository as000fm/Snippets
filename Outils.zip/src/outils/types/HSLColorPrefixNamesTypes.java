package outils.types;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types des noms de préfixes de couleurs HSL-79 selon la saturation et luminosité (lightness)
 * @author Claude Toupin - 29 déc. 2022
 * @link https://chilliant.com/colournames.html
 */
public enum HSLColorPrefixNamesTypes {
	// Attention: l'ordre de la liste a de l'importance !!!
	NONE("", 12, 88, 28), // Couleurs BLACK (luminosité < 12%), WHITE (luminosité > 88%) et GRAY (Saturation < 28%)
	DULL("Dull", 51), // Saturation < 51%
	DEEP("Deep", 12, 24), // Luminosité entre 12% et 24% exclusivement
	DARK("Dark", 24, 44), // Luminosité entre 24% et 44% exclusivement
	// NO_PREFIX("", 44, 56), // Luminosité entre 44% et 56% exclusivement. Idem à NONE dans le traitement
	LIGHT("Light", 56, 76), // Luminosité entre 56% et 76% exclusivement
	PALE("Pale", 76, 88), // Luminosité entre 76% et 88% exclusivement
	;

	/** Nom du préfixe **/
	final private String prefix;

	/** Début du pourcentage de la luminosité du nom de préfixe **/
	final private float lightnessStartsAt;

	/** Fin du pourcentage de la luminosité du nom de préfixe **/
	final private float lightnessEndsAt;

	/** Valeur du pourcentage de la saturation du nom de préfixe **/
	final private float saturation;

	/**
	 * Constructeur de base
	 * @param prefix Nom du préfixe
	 * @param lightnessStartsAt Début du pourcentage de la luminosité du nom de préfixe
	 * @param lightnessEndsAt Fin du pourcentage de la luminosité du nom de préfixe
	 */
	private HSLColorPrefixNamesTypes(String prefix, float lightnessStartsAt, float lightnessEndsAt) {
		this(prefix, lightnessStartsAt, lightnessEndsAt, 51);
	}

	/**
	 * Constructeur de base
	 * @param prefix Nom du préfixe
	 * @param saturation Valeur du pourcentage de la saturation du nom de préfixe
	 */
	private HSLColorPrefixNamesTypes(String prefix, float saturation) {
		this(prefix, -1, -1, saturation);
	}

	/**
	 * Constructeur de base
	 * @param prefix Nom du préfixe
	 * @param lightnessStartsAt Début du pourcentage de la luminosité du nom de préfixe
	 * @param lightnessEndsAt Fin du pourcentage de la luminosité du nom de préfixe
	 * @param saturation Valeur du pourcentage de la saturation du nom de préfixe
	 */
	private HSLColorPrefixNamesTypes(String prefix, float lightnessStartsAt, float lightnessEndsAt, float saturation) {
		this.prefix = prefix;
		this.lightnessStartsAt = lightnessStartsAt;
		this.lightnessEndsAt = lightnessEndsAt;
		this.saturation = saturation;
	}

	/**
	 * Extrait le type du nom de préfixe de la couleur HSL-79 pour une saturation et luminosité (lightness) données
	 * @param saturation La valeur de la saturation en pourcentage
	 * @param lightness La valeur de la luminosité en pourcentage
	 * @return le type du nom de préfixe de la couleur HSL-79 (NONE par défaut)
	 */
	@AutomatedTests(value = { "20,30,60,100", "20,50,75,100" }, iterate = true)
	public static HSLColorPrefixNamesTypes getHSLColorPrefixNamesTypes(float saturation, float lightness) {
		for (HSLColorPrefixNamesTypes type : HSLColorPrefixNamesTypes.values()) {
			switch (type) {
				case NONE:
					if ((lightness < type.getLightnessStartsAt()) || (lightness > type.getLightnessEndsAt())) {
						return type;
					}
					break;
				case DULL:
					if ((saturation >= NONE.getSaturation()) && (saturation < type.getSaturation())) {
						return type;
					}
				default:
					if ((lightness >= type.getLightnessStartsAt()) && (lightness < type.getLightnessEndsAt())) {
						return type;
					}
					break;
			}
		}

		return NONE;
	}

	/**
	 * Extrait le type du nom de préfixe de la couleur HSL-79 pour une valeur donnée
	 * @param value La valeur à extraire
	 * @return le type (null si pas trouvé)
	 */
	public static HSLColorPrefixNamesTypes getHSLColorPrefixNamesTypes(String value) {
		if (!OutilsBase.isEmpty(value)) {
			for (HSLColorPrefixNamesTypes type : HSLColorPrefixNamesTypes.values()) {
				if (type.name().equalsIgnoreCase(value)) {
					return type;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le nom complet capitalisé de la couleur HSL-79
	 * @param group Nom du groupe de couleur
	 * @return le nom complet capitalisé de la couleur HSL-79
	 */
	public String getColorName(HSLFullColorGroupNamesTypes group) {
		return getColorName(group, true);
	}

	/**
	 * Extrait le nom complet de la couleur HSL-79
	 * @param group Nom du groupe de couleur
	 * @param capitalise Indicateur de capitalisation du nom complet de la couleur HSL-79
	 * @return le nom complet de la couleur HSL-79 (mull si pas de donnée)
	 */
	public String getColorName(HSLFullColorGroupNamesTypes group, boolean capitalise) {
		if (group != null) {
			String color = group.getColorGroupName(capitalise);
			String lightness = capitalise ? OutilsBase.doCapitalize(prefix) : prefix;

			switch (this) {
				case NONE:
					return color;
				default:
					switch (group) {
						case BLACK:
						case WHITE:
							return color;
						default:
							return lightness + " " + color;
					}
			}
		}

		return null;
	}

	/**
	 * Extrait le champ prefix
	 * @return un String
	 */
	public String getPrefix() {
		return prefix;
	}

	/**
	 * Extrait le champ lightnessStartsAt
	 * @return un float
	 */
	public float getLightnessStartsAt() {
		return lightnessStartsAt;
	}

	/**
	 * Extrait le champ lightnessEndsAt
	 * @return un float
	 */
	public float getLightnessEndsAt() {
		return lightnessEndsAt;
	}

	/**
	 * Extrait le champ saturation
	 * @return un float
	 */
	public float getSaturation() {
		return saturation;
	}
}
