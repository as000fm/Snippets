package outils.types;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types des noms de groupes de couleurs HSL-79 selon la teinte (hue), la saturation et la luminosité (lightness)
 * @author Claude Toupin - 29 déc. 2022
 * @link https://chilliant.com/colournames.html
 */
public enum HSLFullColorGroupNamesTypes {
	// Attention: l'ordre de la liste a de l'importance !!!
	BLACK(-1, -1, -1, 25), // Luminosité < 25%
	WHITE(-1, -1, -1, 75), // Luminosité > 75%
	GRAY(-1, -1, 20, -1), // Saturation < 20% et luminosité entre 25% et 75%
	// Saturation >= 20% et luminosité entre 25% et 75%
	RED(345, 15), // Teinte >= 345° ou teinte < 15°°
	ORANGE(15, 45), // Teinte entre 15° et 45° exclusivement
	YELLOW(45, 75), // Teinte entre 45° et 75° exclusivement
	CHARTREUSE(75, 105), // Teinte entre 75° et 105° exclusivement (vert-jaune)
	GREEN(105, 135), // Teinte entre 105° et 135° exclusivement
	SPRING(135, 165), // Teinte entre 135° et 165° exclusivement
	CYAN(165, 195), // Teinte entre 165° et 195° exclusivement
	AZURE(195, 225), // Teinte entre 195° et 225° exclusivement
	BLUE(225, 255), // Teinte entre 225° et 255° exclusivement
	PURPLE(255, 285), // Teinte entre 255° et 285° exclusivement
	MAGENTA(285, 315), // Teinte entre 285° et 315° exclusivement
	PINK(315, 345), // Teinte entre 315° et 345° exclusivement
	;

	/** Début de l'angle de la teinte de la couleur **/
	final private float hueStartsAt;

	/** Fin de l'angle de la teinte de la couleur **/
	final private float hueEndsAt;

	/** Valeur du pourcentage de la saturation de la couleur **/
	final private float saturation;

	/** Valeur du pourcentage de la luminosité de la couleur **/
	final private float lightness;

	/**
	 * Constructeur de base
	 * @param hueStartsAt Début de l'angle de la teinte de la couleur
	 * @param hueEndsAt Fin de l'angle de la teinte de la couleur
	 */
	private HSLFullColorGroupNamesTypes(float hueStartsAt, float hueEndsAt) {
		this(hueStartsAt, hueEndsAt, -1, -1);
	}

	/**
	 * Constructeur de base
	 * @param hueStartsAt Début de l'angle de la teinte de la couleur
	 * @param hueEndsAt Fin de l'angle de la teinte de la couleur
	 * @param saturation Valeur du pourcentage de la saturation de la couleur
	 * @param lightness Valeur du pourcentage de la luminosité de la couleur
	 */
	private HSLFullColorGroupNamesTypes(float hueStartsAt, float hueEndsAt, float saturation, float lightness) {
		this.hueStartsAt = hueStartsAt;
		this.hueEndsAt = hueEndsAt;
		this.saturation = saturation;
		this.lightness = lightness;
	}

	/**
	 * Extrait le type du nom de groupe de couleurs HSL-79 pour une teinte (hue), saturation et luminosité (lightness) données
	 * @param hue La valeur de l'angle de la teinte entre 0 et 359
	 * @param saturation La valeur de la saturation en pourcentage
	 * @param lightness La valeur de la luminosité en pourcentage
	 * @return le type du nom de groupe de couleurs HSL-79
	 */
	@AutomatedTests(value = { "10,100,350", "15,50", "20,50,80" }, iterate = true)
	public static HSLFullColorGroupNamesTypes getHSLColorGroupNamesTypes(float hue, float saturation, float lightness) {
		for (HSLFullColorGroupNamesTypes type : HSLFullColorGroupNamesTypes.values()) {
			switch (type) {
				case BLACK:
					if (lightness < type.getLightness()) {
						return type;
					}
					break;
				case WHITE:
					if (lightness > type.getLightness()) {
						return type;
					}
					break;
				case GRAY:
					if (saturation < type.getSaturation()) {
						return type;
					}
					break;
				case RED:
					if ((hue >= type.getHueStartsAt()) || (hue < type.getHueEndsAt())) {
						return type;
					}
					break;
				default:
					if ((hue >= type.getHueStartsAt()) && (hue < type.getHueEndsAt())) {
						return type;
					}
					break;
			}
		}

		// Devrait jamais se produire...
		return null;
	}

	/**
	 * Extrait le type du nom de groupe de couleurs HSL-79 pour une valeur donnée
	 * @param value La valeur à extraire
	 * @return le type (null si pas trouvé)
	 */
	public static HSLFullColorGroupNamesTypes getHSLColorGroupNamesTypes(String value) {
		if (!OutilsBase.isEmpty(value)) {
			for (HSLFullColorGroupNamesTypes type : HSLFullColorGroupNamesTypes.values()) {
				if (type.name().equalsIgnoreCase(value)) {
					return type;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le nom du groupe capitalisé de couleurs HSL-79
	 * @return le nom du groupe capitalisé de couleurs HSL-79
	 */
	public String getColorGroupName() {
		return getColorGroupName(true);
	}

	/**
	 * Extrait le nom du groupe de couleurs HSL-79
	 * @param capitalise Indicateur de capitalisation du nom du groupe de couleurs HSL-79
	 * @return le nom du groupe de couleurs HSL-79
	 */
	public String getColorGroupName(boolean capitalise) {
		return capitalise ? OutilsBase.doCapitalize(name().toLowerCase()) : name().toLowerCase();
	}

	/**
	 * Extrait le champ hueStartsAt
	 * @return un float
	 */
	public float getHueStartsAt() {
		return hueStartsAt;
	}

	/**
	 * Extrait le champ hueEndsAt
	 * @return un float
	 */
	public float getHueEndsAt() {
		return hueEndsAt;
	}

	/**
	 * Extrait le champ saturation
	 * @return un float
	 */
	public float getSaturation() {
		return saturation;
	}

	/**
	 * Extrait le champ lightness
	 * @return un float
	 */
	public float getLightness() {
		return lightness;
	}
}
