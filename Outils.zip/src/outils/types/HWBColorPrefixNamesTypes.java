package outils.types;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types des noms de préfixes de couleurs HWB-91 selon la blancheur (whiteness) et la noirceur (blackness)
 * @author Claude Toupin - 29 déc. 2022
 * @link https://chilliant.com/colournames.html
 */
public enum HWBColorPrefixNamesTypes {
	// Attention: l'ordre de la liste a de l'importance !!!
	DEEP("Deep", 0f, 8f, 62.5f, 87.5f), // Point milleu de la noirceur: 75%
	DARK("Dark", 0f, 8f, 24f, 62.5f), // Point milleu de la noirceur: 50%
	LIGHT("Light", 24f, 62.5f, 0f, 8f), // Point milleu de la blancheur: 50%
	PALE("Pale", 62.5f, 87.5f, 0f, 8f), // Point milleu de la blancheur: 75%
	VIVID("Vivid", 0f, 8f, 0f, 8f), // Point de base de la blancheur: 0% et de la noirceur: 0%
	DULL("Dull", 16.7f, 50f, 16.7f, 50f), // Point de milleu de la blancheur: 33% et de la noirceur: 33%
	NONE("", -1f, -1f, -1f, -1f), // Par défaut, inclus WHITE (100%, 0%), BLACK (0%, 100%) et GRAY (50%, 50%)
	;

	/** Nom du préfixe **/
	final private String prefix;

	/** Début du pourcentage de la blancheur du nom de préfixe **/
	final private float whitenessStartsAt;

	/** Fin du pourcentage de la blancheur du nom de préfixe **/
	final private float whitenessEndsAt;

	/** Début du pourcentage de la noirceur du nom de préfixe **/
	final private float blacknessStartsAt;

	/** Fin du pourcentage de la noirceur du nom de préfixe **/
	final private float blacknessEndsAt;

	/**
	 * Constructeur de base
	 * @param prefix Nom du préfixe
	 * @param whitenessStartsAt Début du pourcentage de la blancheur du nom de préfixe
	 * @param whitenessEndsAt Fin du pourcentage de la blancheur du nom de préfixe
	 * @param blacknessStartsAt Début du pourcentage de la noirceur du nom de préfixe
	 * @param blacknessEndsAt Fin du pourcentage de la noirceur du nom de préfixe
	 */
	private HWBColorPrefixNamesTypes(String prefix, float whitenessStartsAt, float whitenessEndsAt, float blacknessStartsAt, float blacknessEndsAt) {
		this.prefix = prefix;
		this.whitenessStartsAt = whitenessStartsAt;
		this.whitenessEndsAt = whitenessEndsAt;
		this.blacknessStartsAt = blacknessStartsAt;
		this.blacknessEndsAt = blacknessEndsAt;
	}

	/**
	 * Extrait le type du nom de préfixe de la couleur HWB-91 pour une blancheur (whiteness) et noirceur (blackness) données
	 * @param whiteness La valeur de la blancheur en pourcentage
	 * @param blackness La valeur de la noirceur en pourcentage
	 * @return le type du nom de préfixe de la couleur HWB-91 (NONE par défaut)
	 */
	@AutomatedTests(value = { "5,50,75", "5,50,75" }, iterate = true)
	public static HWBColorPrefixNamesTypes getHWBColorPrefixNamesTypes(float whiteness, float blackness) {
		for (HWBColorPrefixNamesTypes type : HWBColorPrefixNamesTypes.values()) {
			switch (type) {
				case NONE:
					break;
				default:
					if ((whiteness >= type.getWhitenessStartsAt()) && (whiteness < type.getWhitenessEndsAt()) && (blackness >= type.getBlacknessStartsAt()) && (blackness < type.getBlacknessEndsAt())) {
						return type;
					}
					break;
			}
		}

		return NONE;
	}

	/**
	 * Extrait le type du nom de préfixe de la couleur HWB-91 pour une valeur donnée
	 * @param value La valeur à extraire
	 * @return le type (null si pas trouvé)
	 */
	public static HWBColorPrefixNamesTypes getHWBColorPrefixNamesTypes(String value) {
		if (!OutilsBase.isEmpty(value)) {
			for (HWBColorPrefixNamesTypes type : HWBColorPrefixNamesTypes.values()) {
				if (type.name().equalsIgnoreCase(value)) {
					return type;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le nom complet capitalisé de la couleur HWB-91
	 * @param group Nom du groupe de couleur
	 * @return le nom complet capitalisé de la couleur HWB-91
	 */
	public String getColorName(HWBHalfColorGroupNamesTypes group) {
		return getColorName(group, true);
	}

	/**
	 * Extrait le nom complet de la couleur HWB-91
	 * @param group Nom du groupe de couleur
	 * @param capitalise Indicateur de capitalisation du nom complet de la couleur HWB-91
	 * @return le nom complet de la couleur HWB-91 (mull si pas de donnée)
	 */
	public String getColorName(HWBHalfColorGroupNamesTypes group, boolean capitalise) {
		if (group != null) {
			String color = group.getColorGroupName(capitalise);
			String lightness = capitalise ? OutilsBase.doCapitalize(prefix) : prefix;

			switch (this) {
				case NONE:
					return color;
				default:
					switch (group) {
						case BLACK:
						case WHITE:
							return color;
						default:
							return lightness + " " + color;
					}
			}
		}

		return null;
	}

	/**
	 * Extrait le champ prefix
	 * @return un String
	 */
	public String getPrefix() {
		return prefix;
	}

	/**
	 * Extrait le champ whitenessStartsAt
	 * @return un float
	 */
	public float getWhitenessStartsAt() {
		return whitenessStartsAt;
	}

	/**
	 * Extrait le champ whitenessEndsAt
	 * @return un float
	 */
	public float getWhitenessEndsAt() {
		return whitenessEndsAt;
	}

	/**
	 * Extrait le champ blacknessStartsAt
	 * @return un float
	 */
	public float getBlacknessStartsAt() {
		return blacknessStartsAt;
	}

	/**
	 * Extrait le champ blacknessEndsAt
	 * @return un float
	 */
	public float getBlacknessEndsAt() {
		return blacknessEndsAt;
	}
}
