package outils.types;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types des noms de groupes de couleurs HWB-91 selon la teinte (hue), la blancheur (whiteness) et la noirceur (blackness)
 * @author Claude Toupin - 29 déc. 2022
 * @link https://chilliant.com/colournames.html
 */
public enum HWBFullColorGroupNamesTypes {
	// Attention: l'ordre de la liste a de l'importance !!!
	BLACK(-1, -1, 28, 71), // Blancheur < 28% et noirceur > 71%
	WHITE(-1, -1, 86, 13), // Blancheur > 86% et noirceur < 13%
	GRAY(-1, -1, 95), // Grisaille: blancheur + noirceur > 95%
	RED(345, 15), // Teinte >= 345° ou teinte < 15°
	ORANGE(15, 45), // Teinte entre 15° et 45° exclusivement
	YELLOW(45, 75), // Teinte entre 45° et 75° exclusivement
	CHARTREUSE(75, 105), // Teinte entre 75° et 105° exclusivement (vert-jaune)
	GREEN(105, 135), // Teinte entre 105° et 135° exclusivement
	SPRING(135, 165), // Teinte entre 135° et 165° exclusivement
	CYAN(165, 195), // Teinte entre 165° et 195° exclusivement
	AZURE(195, 225), // Teinte entre 195° et 225° exclusivement
	BLUE(225, 255), // Teinte entre 225° et 255° exclusivement
	PURPLE(255, 285), // Teinte entre 255° et 285° exclusivement
	MAGENTA(285, 315), // Teinte entre 285° et 315° exclusivement
	PINK(315, 345), // Teinte entre 315° et 345° exclusivement
	;

	/** Début de l'angle de la teinte de la couleur **/
	final private float hueStartsAt;

	/** Fin de l'angle de la teinte de la couleur **/
	final private float hueEndsAt;

	/** Valeur du pourcentage de la blancheur de la couleur **/
	final private float whiteness;

	/** Valeur du pourcentage de la noirceur de la couleur **/
	final private float blackness;

	/**
	 * Constructeur de base
	 * @param hueStartsAt Début de l'angle de la teinte de la couleur
	 * @param hueEndsAt Fin de l'angle de la teinte de la couleur
	 */
	private HWBFullColorGroupNamesTypes(float hueStartsAt, float hueEndsAt) {
		this(hueStartsAt, hueEndsAt, -1, -1);
	}

	/**
	 * Constructeur de base
	 * @param hueStartsAt Début de l'angle de la teinte de la couleur
	 * @param hueEndsAt Fin de l'angle de la teinte de la couleur
	 * @param grayness Valeur du pourcentage de la grisaille de la couleur
	 */
	private HWBFullColorGroupNamesTypes(float hueStartsAt, float hueEndsAt, float grayness) {
		this(hueStartsAt, hueEndsAt, grayness, grayness);
	}

	/**
	 * Constructeur de base
	 * @param hueStartsAt Début de l'angle de la teinte de la couleur
	 * @param hueEndsAt Fin de l'angle de la teinte de la couleur
	 * @param whiteness Valeur du pourcentage de la blancheur de la couleur
	 * @param blackness Valeur du pourcentage de la noirceur de la couleur
	 */
	private HWBFullColorGroupNamesTypes(float hueStartsAt, float hueEndsAt, float whiteness, float blackness) {
		this.hueStartsAt = hueStartsAt;
		this.hueEndsAt = hueEndsAt;
		this.whiteness = whiteness;
		this.blackness = blackness;
	}

	/**
	 * Extrait le type du nom de groupe de couleurs HWB-91 pour une teinte (hue), saturation et luminosité (lightness) données
	 * @param hue La valeur de l'angle de la teinte entre 0 et 359
	 * @param whiteness La valeur de la blancheur en pourcentage
	 * @param blackness La valeur de la noirceur en pourcentage
	 * @return le type du nom de groupe de couleurs HWB-91
	 */
	@AutomatedTests(value = { "10,100,350", "20,50,90", "10,50,75" }, iterate = true)
	public static HWBFullColorGroupNamesTypes getHWBColorGroupNamesTypes(float hue, float whiteness, float blackness) {
		for (HWBFullColorGroupNamesTypes type : HWBFullColorGroupNamesTypes.values()) {
			switch (type) {
				case BLACK:
					if ((whiteness < type.getWhiteness()) && (blackness > type.getBlackness())) {
						return type;
					}
					break;
				case WHITE:
					if ((whiteness > type.getWhiteness()) && (blackness < type.getBlackness())) {
						return type;
					}
					break;
				case GRAY:
					if ((whiteness + blackness) > type.getWhiteness()) {
						return type;
					}
					break;
				case RED:
					if ((hue >= type.getHueStartsAt()) || (hue < type.getHueEndsAt())) {
						return type;
					}
					break;
				default:
					if ((hue >= type.getHueStartsAt()) && (hue < type.getHueEndsAt())) {
						return type;
					}
					break;
			}
		}

		// Devrait jamais se produire...
		return null;
	}

	/**
	 * Extrait le type du nom de groupe de couleurs HWB-91 pour une valeur donnée
	 * @param value La valeur à extraire
	 * @return le type (null si pas trouvé)
	 */
	public static HWBFullColorGroupNamesTypes getHWBColorGroupNamesTypes(String value) {
		if (!OutilsBase.isEmpty(value)) {
			for (HWBFullColorGroupNamesTypes type : HWBFullColorGroupNamesTypes.values()) {
				if (type.name().equalsIgnoreCase(value)) {
					return type;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le nom du groupe capitalisé de couleurs HWB-91
	 * @return le nom du groupe capitalisé de couleurs HWB-91
	 */
	public String getColorGroupName() {
		return getColorGroupName(true);
	}

	/**
	 * Extrait le nom du groupe de couleurs HWB-91
	 * @param capitalise Indicateur de capitalisation du nom du groupe de couleurs HWB-91
	 * @return le nom du groupe de couleurs HWB-91
	 */
	public String getColorGroupName(boolean capitalise) {
		return capitalise ? OutilsBase.doCapitalize(name().toLowerCase()) : name().toLowerCase();
	}

	/**
	 * Extrait le champ hueStartsAt
	 * @return un float
	 */
	public float getHueStartsAt() {
		return hueStartsAt;
	}

	/**
	 * Extrait le champ hueEndsAt
	 * @return un float
	 */
	public float getHueEndsAt() {
		return hueEndsAt;
	}

	/**
	 * Extrait le champ whiteness
	 * @return un float
	 */
	public float getWhiteness() {
		return whiteness;
	}

	/**
	 * Extrait le champ blackness
	 * @return un float
	 */
	public float getBlackness() {
		return blackness;
	}
}
