package outils.types;

import outils.base.OutilsBase;

/**
 * Énumération des algorithmes disponibles pour java.security.MessageDigest
 * @author Claude Toupin - 17 déc. 2021
 */
public enum MessageDigestAlgorithmsTypes {
	MD5("MD5"), //
	SHA_1("SHA-1"), //
	SHA_256("SHA-256"), //
	;

	/** Nom de l'algorithme **/
	final private String algorithm;

	/**
	 * Constructeur de base
	 * @param algorithm Nom de l'algorithme
	 */
	private MessageDigestAlgorithmsTypes(String algorithm) {
		this.algorithm = algorithm;
	}

	/**
	 * Extrait le type d'algorithme pour une valeur donnée
	 * @param value La valeur à extraire
	 * @return le type (null si pas trouvé)
	 */
	final public static MessageDigestAlgorithmsTypes getMessageDigestAlgorithmsTypes(String value) {
		if (!OutilsBase.isEmpty(value)) {
			for (MessageDigestAlgorithmsTypes type : MessageDigestAlgorithmsTypes.values()) {
				if (type.name().equalsIgnoreCase(value) || type.getAlgorithm().equalsIgnoreCase(value)) {
					return type;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le champ algorithm
	 * @return un String
	 */
	public String getAlgorithm() {
		return algorithm;
	}
}
