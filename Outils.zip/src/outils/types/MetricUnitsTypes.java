package outils.types;

import outils.base.OutilsBase;
import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des unités métriques (i.e. Exa, Péta, Téra, Giga, Méga, Kilo)
 * @author Claude Toupin - 2012-01-21
 */
public enum MetricUnitsTypes {
	EXA(1000000000000000000l, 1152921504606846976l, "E"), // Exa
	PETA(1000000000000000l, 1125899906842624l, "P"), // Péta
	TERA(1000000000000l, 1099511627776l, "T"), // Téra
	GIGA(1000000000l, 1073741824l, "G"), // Giga
	MEGA(1000000l, 1048576l, "M"), // Méga
	KILO(1000l, 1024l, "K"); // Kilo

	/** Valeur de référence en base 10 **/
	final private long reference;

	/** Valeur de référence en base 2 (octets) **/
	final private long unit;

	/** Préfixe de l'unité métrique (i.e. E, P, T, G, M, K) **/
	final private String prefix;

	/**
	 * Constructeur de base
	 * @param reference Valeur de référence en base 10
	 * @param unit Valeur de référence en base 2 (octets)
	 * @param prefix Préfixe de l'unité métrique (i.e. E, P, T, G, M, K)
	 */
	private MetricUnitsTypes(long reference, long unit, String prefix) {
		this.reference = reference;
		this.unit = unit;
		this.prefix = prefix;
	}

	/**
	 * Extrait l'unité métrique d'une valeur donné
	 * @param value La valeur
	 * @return un MetricUnits (null si pas d'unité préfixée i.e. value < 1000)
	 */
	@AutomatedTests({ "-1L", "1048576L" })
	public static MetricUnitsTypes getUnit(long value) {
		for (MetricUnitsTypes unit : values()) {
			if (value >= unit.getReference()) {
				return unit;
			}
		}

		return null;
	}

	/**
	 * Extrait l'unité métrique d'une valeur donné
	 * @param value La valeur
	 * @return un MetricUnits (null si pas d'unité préfixée i.e. value en octets)
	 */
	public static MetricUnitsTypes getUnit(String value) {
		if (!OutilsBase.isEmpty(value)) {
			String prefix = OutilsBase.asString(value.toUpperCase().charAt(0));

			for (MetricUnitsTypes unit : values()) {
				if (unit.getPrefix().equals(prefix)) {
					return unit;
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le champ reference
	 * @return un long
	 */
	public long getReference() {
		return reference;
	}

	/**
	 * Extrait le champ unit
	 * @return un long
	 */
	public long getUnit() {
		return unit;
	}

	/**
	 * Extrait le champ prefix
	 * @return un String
	 */
	public String getPrefix() {
		return prefix;
	}
}