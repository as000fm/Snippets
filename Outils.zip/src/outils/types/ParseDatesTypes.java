package outils.types;

/**
 * Énumération des types de date à convertir en date
 * @author Claude Toupin - 13 févr. 2019
 */
public enum ParseDatesTypes {
	YYYY, //
	YYYY_MM, //
	YYYY_MM_DD, //
	YYYY_MM_DD_HH_MM, //
	YYYY_MM_DD_HH_MM_FRENCH, //
	YYYY_MM_DD_HH_MM_SS, //
	YYYY_MM_DD_HH_MM_SS_SSS, //
	HH_MM, //
	HH_MM_FRENCH, //
	HH_MM_SS, //
	HH_MM_SS_SSS, //
	MM_SS, //
	;
	
	/** Longueur **/
	final private int length;

	/**
	 * Constructeur de base
	 */
	private ParseDatesTypes() {
		this.length = this.name().length();
	}

	/**
	 * Extrait le champ length
	 * @return un int
	 */
	public int getLength() {
		return length;
	} 
}
