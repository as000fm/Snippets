package outils.types;

/**
 * Énumération des types de méthodes des requêtes HTTP (voir FetchURL)
 * @author Claude Toupin - 2018-07-27
 */
public enum RequestMethodsTypes {
	DELETE, GET, POST, PUT;
}
