package outils.types;

import outils.tests.automated.annotations.AutomatedTests;

/**
 * Énumération des types de séparateurs de mots ou d'un mot
 * @author Claude Toupin - 2019-01-22
 */
public enum WordSeparatorsTypes {
	WORD(), //
	TAB('\t'), //
	BACKSPACE('\b'), //
	NEWLINE('\n'), //
	CARRIAGE_RETURN('\r'), //
	FORMFEED('\f'), //
	SINGLE_QUOTE('\''), //
	DOUBLE_QUOTE('\"'), //
	BACKSLASH('\\'), //
	SPACE(' '), //
	DASH('-'), //
	UNDERSCORE('_'), //
	PERIOD('.'), //
	COMMA(','), //
	SEMICOLON(';'), //
	EXCLAMATION_MARK('!'), //
	QUESTION_MARK('?'), //
	AMPERSON('&'), //
	LEFT_PARENTHESE('('), //
	RIGHT_PARENTHESE(')'), //
	LEFT_BRACKET('['), //
	RIGHT_BRACKET(']'), //
	LEFT_BRACE('{'), //
	RIGHT_BRACE('}'), //
	;

	/** Indicateur de mot **/
	final private boolean word;

	/** Caractère du séparateur **/
	final private char separator;

	/**
	 * Constructeur de base
	 * @param word Indicateur de mot
	 */
	private WordSeparatorsTypes() {
		this.word = true;
		this.separator = '\0';
	}

	/**
	 * Constructeur de base
	 * @param separator Caractère du séparateur
	 */
	private WordSeparatorsTypes(char separator) {
		this.word = false;
		this.separator = separator;
	}

	/**
	 * Extrait le type de séparateur
	 * @param separator Le séparateur à extraire
	 * @return le type de séparateur
	 */
	@AutomatedTests({ "(char) 8211", "(char) 65279", "\t", "a" })
	final public static WordSeparatorsTypes getWordSeparatorsTypes(char separator) {
		switch ((int) separator) {
			case 8211:
				return WordSeparatorsTypes.DASH;
			case 65279:
				return WordSeparatorsTypes.SPACE;
			default:
				for (WordSeparatorsTypes type : WordSeparatorsTypes.values()) {
					if (type.getSeparator() == separator) {
						return type;
					}
				}
		}

		throw new RuntimeException("Pas de type pour le caractère \'" + separator + "\' " + ((int) separator) + " !!!");
	}

	/**
	 * Extrait le champ word
	 * @return un boolean
	 */
	public boolean isWord() {
		return word;
	}

	/**
	 * Extrait le champ separator (!word)
	 * @return un boolean
	 */
	public boolean isSeparator() {
		return !word;
	}

	/**
	 * Extrait le champ separator
	 * @return un char
	 */
	public char getSeparator() {
		return separator;
	}
}
