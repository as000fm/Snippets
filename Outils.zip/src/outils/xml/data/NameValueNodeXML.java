package outils.xml.data;

import java.util.Objects;

import outils.base.OutilsBase;

/**
 * Classe des données d'une paire nom-valeur-noeud XML associé
 * @author Claude Toupin - 2018-12-04
 */
public class NameValueNodeXML implements java.io.Serializable {
	/** Champ serialVersionUID **/
	private static final long serialVersionUID = -3058372397788159023L;

	/** La valeur de Name */
	private String name;

	/** La valeur de Value */
	private String value;

	/** La valeur nodeXML **/
	private NodeXML nodeXML;

	/**
	 * Constructeur par défaut
	 */
	public NameValueNodeXML() {
		this("", "", null);
	}

	/**
	 * Constructeur avec la paire Name-Value
	 * @param name La valeur de Name
	 * @param value La valeur de Value
	 * @param nodeXML La valeur nodeXML
	 */
	public NameValueNodeXML(String name, String value, NodeXML nodeXML) {
		this.name = name;
		this.value = value;
		this.nodeXML = nodeXML;
	}

	/**
	 * Constructeur avec la paire Name-Value
	 * @param nameValue Les valeurs de Name et de Value séparées par un égale (=)
	 * @param nodeXML La valeur nodeXML
	 */
	public NameValueNodeXML(String nameValue, NodeXML nodeXML) {
		if (OutilsBase.isEmpty(nameValue)) {
			this.name = "";
			this.value = "";
		} else {
			int pos = nameValue.indexOf("=");

			if (pos != -1) {
				this.name = nameValue.substring(0, pos);
				this.value = nameValue.substring(pos + 1);
			} else {
				this.name = nameValue;
				this.value = "";
			}
		}

		this.nodeXML = nodeXML;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return toString("=");
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof NameValueNodeXML) {
				NameValueNodeXML nvn = (NameValueNodeXML) obj;

				return OutilsBase.areEquals(name, nvn.getName()) //
						&& OutilsBase.areEquals(value, nvn.getValue()) //
						&& OutilsBase.areEquals(nodeXML, nvn.getNodeXML()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(name, nodeXML, value);
	}

	/**
	 * Retourne la pair séparé par un séparateur
	 * @param separateur Le séparateur
	 * @return la pair sous forme d'une string
	 */
	public String toString(String separateur) {
		StringBuffer sb = new StringBuffer(name);
		sb.append(separateur);
		sb.append(value);
		sb.append(" : ");
		sb.append((nodeXML != null) ? nodeXML.toString() : "null");
		return sb.toString();
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Modifie le champ name
	 * @param name La valeur du champ name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Extrait le champ value
	 * @return un String
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Modifie le champ value
	 * @param value La valeur du champ value
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Extrait le champ nodeXML
	 * @return un NodeXML
	 */
	public NodeXML getNodeXML() {
		return nodeXML;
	}

	/**
	 * Modifie le champ nodeXML
	 * @param nodeXML La valeur du champ nodeXML
	 */
	public void setNodeXML(NodeXML nodeXML) {
		this.nodeXML = nodeXML;
	}

}