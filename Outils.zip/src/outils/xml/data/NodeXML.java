package outils.xml.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.listes.NameValue;
import outils.xml.search.ICriteriaSearchNodesXML;

/**
 * Données d'un noeudXML
 * @author Claude Toupin - 2018-07-20
 */
public class NodeXML {
	final public static String SEPARATOR = "/";

	/** Parent de ce noeud **/
	final private NodeXML parent;

	/** Liste des enfants **/
	final private List<NodeXML> childrenList;

	/** Liste des attributs sous forme de paires nom=valeur **/
	final private List<NameValue> attributesList;

	/** Nom du noeud **/
	final private String name;

	/** Texte du noeud **/
	private String text;

	/** Indicateur de noeud en commentaire **/
	private boolean comment;

	/**
	 * Extrait la clé pour une liste de valeurs
	 * @param values Liste des valeurs
	 * @return la clé
	 */
	public static String getNodeKey(String... values) {
		return getSeparatorNodeKey(SEPARATOR, values);
	}

	/**
	 * Extrait la clé pour une liste de valeurs
	 * @param separator Separateur entre les noms des noeuds
	 * @param values Liste des valeurs
	 * @return la clé
	 */
	public static String getSeparatorNodeKey(String separator, String... values) {
		StringBuffer sb = new StringBuffer();

		if (values != null) {
			sb.append(separator);

			for (String value : values) {
				sb.append(separator);
				sb.append(value);
			}
		}

		return sb.toString();
	}

	/**
	 * Constructeur de base
	 * @param parent Parent de ce noeud
	 * @param name Nom du noeud
	 */
	public NodeXML(NodeXML parent, String name) {
		this(parent, name, null, false);
	}

	/**
	 * Constructeur de base
	 * @param parent Parent de ce noeud
	 * @param name Nom du noeud
	 * @param text Texte du noeud
	 * @param comment Indicateur de noeud en commentaire
	 */
	public NodeXML(NodeXML parent, String name, String text) {
		this(parent, name, text, false);
	}

	/**
	 * Constructeur de base
	 * @param parent Parent de ce noeud
	 * @param name Nom du noeud
	 * @param text Texte du noeud
	 * @param comment Indicateur de noeud en commentaire
	 */
	public NodeXML(NodeXML parent, String name, String text, boolean comment) {
		this.parent = parent;
		this.childrenList = new ArrayList<NodeXML>();
		this.attributesList = new ArrayList<NameValue>();
		this.name = name;
		this.text = text;
		this.comment = comment;

		if (this.parent != null) {
			this.parent.getChildrenList().add(this);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String openBrace = comment ? "<!-- " : "<";
		String closeBrace = comment ? " -->" : ">";

		boolean singleTag = OutilsBase.isEmpty(text) && childrenList.isEmpty();

		String tag = openBrace + name;

		for (NameValue attribute : attributesList) {
			if (attribute.getValue() == null) {
				tag += " " + attribute.getName();
			} else {
				tag += " " + attribute.getName() + "=" + ("\"" + attribute.getValue() + "\"");
			}
		}

		if (singleTag) {
			tag += (comment ? "" : "/") + closeBrace;
		} else {
			tag += ">" + OutilsBase.asString(text);

			for (NodeXML child : childrenList) {
				tag += child.toString();
			}

			tag += "</" + name + closeBrace;
		}

		return tag;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof NodeXML) {
				NodeXML node = (NodeXML) obj;

				return OutilsBase.areEquals(name, node.getName()) //
						&& OutilsBase.areEquals(text, node.getText()) //
						// && OutilsBase.areEquals(parent, node.getParent()) //
						&& OutilsBase.areEquals(childrenList, node.getChildrenList()) //
						&& OutilsBase.areEquals(attributesList, node.getAttributesList()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(attributesList, childrenList, comment, name, parent, text);
	}

	/**
	 * Effectue le formattage du xml avec indentation et sur plusieurs lignes
	 * @param indentation Chaine de l'indentation
	 * @param level Niveau courant de l'indentation
	 * @param expand Indicateur d'expansion des balises xml (i.e. pas de balise simple style <allo/>)
	 * @return les lignes xml formattées
	 */
	protected List<String> toPrettyPrint(String indentation, String level, boolean expand) {
		List<String> lines = new ArrayList<String>();

		String openBrace = comment ? "<!-- " : "<";
		String closeBrace = comment ? " -->" : ">";

		boolean singleTag = !expand && OutilsBase.isEmpty(text) && childrenList.isEmpty();

		String tag = level + openBrace + name;

		for (NameValue attribute : attributesList) {
			if (attribute.getValue() == null) {
				tag += " " + attribute.getName();
			} else {
				tag += " " + attribute.getName() + "=" + ("\"" + attribute.getValue() + "\"");
			}
		}

		if (singleTag) {
			tag += (comment ? "" : "/") + closeBrace;

			lines.add(tag);
		} else {
			tag += ">" + OutilsBase.asString(text);

			if (childrenList.isEmpty()) {
				tag += "</" + name + closeBrace;

				lines.add(tag);
			} else {
				lines.add(tag);

				for (NodeXML child : childrenList) {
					lines.addAll(child.toPrettyPrint(indentation, level + indentation, expand));
				}

				lines.add(level + "</" + name + closeBrace);
			}
		}

		return lines;
	}

	/**
	 * Effectue le formattage du xml avec indentation et sur plusieurs lignes
	 * @param indentation Chaine de l'indentation
	 * @return les lignes xml formattées
	 */
	public List<String> toPrettyPrint(String indentation) {
		return toPrettyPrint(indentation, false);
	}

	/**
	 * Effectue le formattage du xml avec indentation et sur plusieurs lignes
	 * @param indentation Chaine de l'indentation
	 * @param expand Indicateur d'expansion des balises xml (i.e. pas de balise simple style <allo/>)
	 * @return les lignes xml formattées
	 */
	public List<String> toPrettyPrint(String indentation, boolean expand) {
		return toPrettyPrint(indentation, "", expand);
	}

	/**
	 * Ajout au dictionnaire d'un noeudXML pour clé donnée
	 * @param dictionary Dictionnaire des noeuds
	 * @param key La clé donnée
	 * @param node Le noeudXML à ajouter
	 */
	protected void addToDictionary(Map<String, List<NodeXML>> dictionary, String key, NodeXML node) {
		List<NodeXML> list;

		if (dictionary.containsKey(key)) {
			list = dictionary.get(key);
		} else {
			list = new ArrayList<NodeXML>();
			dictionary.put(key, list);
		}

		list.add(node);
	}

	/**
	 * Extrait le dictionnaire des noeuds d'une arboresence
	 * @param separator Separateur entre les noms des noeuds
	 * @param list Le contenu des noeuds sous forme de liste
	 * @return le dictionnaire courant
	 */
	protected Map<String, List<NodeXML>> asDictionary(String separator, List<NameValueNodeXML> list) {
		Map<String, List<NodeXML>> dictionary = new HashMap<String, List<NodeXML>>();

		if (list != null) {
			for (NameValueNodeXML node : list) {
				addToDictionary(dictionary, node.getName(), node.getNodeXML());

				if (node.getValue() != null) {
					addToDictionary(dictionary, node.getName() + separator + node.getValue(), node.getNodeXML());
				}
			}
		}

		return dictionary;
	}

	/**
	 * Extrait le dictionnaire des noeuds
	 * @return le dictionnaire des noeuds ayant comme clé noeud + separateur + noeud + separateur + noeud + separateur ...
	 */
	public Map<String, List<NodeXML>> asDictionary() {
		return asDictionary(SEPARATOR);
	}

	/**
	 * Extrait le dictionnaire des noeuds
	 * @param separator Separateur entre les noms des noeuds
	 * @return le dictionnaire des noeuds ayant comme clé noeud + separateur + noeud + separateur + noeud + separateur ...
	 */
	public Map<String, List<NodeXML>> asDictionary(String separator) {
		return asDictionary(separator, asNameValueNodeXMLList(separator));
	}

	/**
	 * Extrait le contenu des noeuds sous forme de liste
	 * @param parent Le parent courant
	 * @param key La clé courante
	 * @param separator Le séparateur à utiliser
	 * @return une liste de paires clé=valeur
	 */
	protected List<NameValue> asNameValueList(NodeXML parent, String key, String separator) {
		List<NameValue> list = new ArrayList<NameValue>();

		if (parent != null) {
			String candidate = key + separator + parent.getName();

			list.add(new NameValue(candidate, parent.getText()));

			for (NameValue item : parent.getAttributesList()) {
				list.add(new NameValue(candidate + separator + item.getName(), item.getValue()));
			}

			for (NodeXML node : parent.getChildrenList()) {
				list.addAll(asNameValueList(node, candidate, separator));
			}
		}

		return list;
	}

	/**
	 * Extrait le contenu des noeuds sous forme de liste
	 * @return une liste de paires clé=valeur
	 */
	public List<NameValue> asNameValueList() {
		return asNameValueList(SEPARATOR);
	}

	/**
	 * Extrait le contenu des noeuds sous forme de liste
	 * @param separator Separateur entre les noms des noeuds
	 * @return une liste de paires clé=valeur
	 */
	public List<NameValue> asNameValueList(String separator) {
		return asNameValueList(this, OutilsBase.asString(separator), OutilsBase.asString(separator));
	}

	/**
	 * Extrait le contenu des noeuds sous forme de liste
	 * @param parent Le parent courant
	 * @param key La clé courante
	 * @param separator Le séparateur à utiliser
	 * @return une liste de paires clé=valeur : <xml>
	 */
	protected List<NameValueNodeXML> asNameValueNodeXMLList(NodeXML parent, String key, String separator) {
		List<NameValueNodeXML> list = new ArrayList<NameValueNodeXML>();

		if (parent != null) {
			String candidate = key + separator + parent.getName();

			list.add(new NameValueNodeXML(candidate, parent.getText(), parent));

			for (NameValue item : parent.getAttributesList()) {
				list.add(new NameValueNodeXML(candidate + separator + item.getName(), item.getValue(), parent));
			}

			for (NodeXML node : parent.getChildrenList()) {
				list.addAll(asNameValueNodeXMLList(node, candidate, separator));
			}
		}

		return list;
	}

	/**
	 * Extrait le contenu des noeuds sous forme de liste
	 * @return une liste de paires clé=valeur : <xml>
	 */
	public List<NameValueNodeXML> asNameValueNodeXMLList() {
		return asNameValueNodeXMLList(SEPARATOR);
	}

	/**
	 * Extrait le contenu des noeuds sous forme de liste
	 * @param separator Separateur entre les noms des noeuds
	 * @return une liste de paires clé=valeur : <xml>
	 */
	public List<NameValueNodeXML> asNameValueNodeXMLList(String separator) {
		return asNameValueNodeXMLList(this, OutilsBase.asString(separator), OutilsBase.asString(separator));
	}

	/**
	 * Effectue la recherche pour une liste de critères données
	 * @param criterias Liste des critères à rechercher
	 * @return une liste de NodeXML trouvés
	 */
	public List<NodeXML> search(ICriteriaSearchNodesXML... criterias) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		if (criterias != null) {
			List<NodeXML> search = new ArrayList<NodeXML>();
			search.add(this);

			for (ICriteriaSearchNodesXML criteria : criterias) {
				result.clear();

				for (NodeXML item : search) {
					result.addAll(criteria.searchNodesXML(item));
				}

				if (result.isEmpty()) {
					break;
				}

				search.clear();
				search.addAll(result);
			}
		}

		return result;
	}

	/**
	 * Extrait le chemin de la racine
	 * @param separator Separateur entre les noms des noeuds
	 * @return un String noeud + separateur + noeud + separateur + noeud + separateur ...
	 */
	protected String doPath(String separator) {
		String path = (parent != null) ? parent.doPath(separator) : "";

		if (!path.isEmpty()) {
			path += OutilsBase.asString(separator);
		}

		return path + name;
	}

	/**
	 * Extrait le chemin de la racine
	 * @return un String noeud\noeud\noeud\...
	 */
	public String getPath() {
		return getPath(SEPARATOR);
	}

	/**
	 * Extrait le chemin de la racine
	 * @param separator Separateur entre les noms des noeuds
	 * @return un String separateur + separateur + noeud + separateur + noeud + separateur + noeud + separateur ...
	 */
	public String getPath(String separator) {
		String path = (parent != null) ? parent.doPath(separator) : "";

		if (!path.isEmpty()) {
			path += OutilsBase.asString(separator);
		}

		return OutilsBase.asString(separator) + OutilsBase.asString(separator) + path + name;
	}

	/**
	 * Extrait la valeur pour un attribut donné
	 * @param name Nom de l'attribut
	 * @return la valeur (null si pas trouvé...)
	 */
	public String getAttribute(String name) {
		if (name != null) {
			for (NameValue attribute : attributesList) {
				if (attribute.getName().equals(name)) {
					return attribute.getValue();
				}
			}
		}

		return null;
	}

	/**
	 * Extrait le champ parent
	 * @return un NodeXML
	 */
	public NodeXML getParent() {
		return parent;
	}

	/**
	 * Extrait le champ childrenList
	 * @return un List<NodeXML>
	 */
	public List<NodeXML> getChildrenList() {
		return childrenList;
	}

	/**
	 * Extrait le champ attributesList
	 * @return un List<NameValue>
	 */
	public List<NameValue> getAttributesList() {
		return attributesList;
	}

	/**
	 * Extrait le champ name
	 * @return un String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Extrait le champ text
	 * @return un String
	 */
	public String getText() {
		return text;
	}

	/**
	 * Modifie le champ text
	 * @param text La valeur du champ text
	 * @return un NodeXML
	 */
	public NodeXML setText(String text) {
		this.text = text;
		return this;
	}

	/**
	 * Extrait le champ comment
	 * @return un boolean
	 */
	public boolean isComment() {
		return comment;
	}

	/**
	 * Modifie le champ comment
	 * @param comment La valeur du champ comment
	 * @return un NodeXML
	 */
	public NodeXML setComment(boolean comment) {
		this.comment = comment;
		return this;
	}
}
