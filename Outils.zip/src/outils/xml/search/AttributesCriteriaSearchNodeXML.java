package outils.xml.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.listes.NameValue;
import outils.patterns.PatternData;
import outils.xml.data.NodeXML;
import outils.xml.search.types.CriteriasSearchNodesXMLTypes;

/**
 * Recherche de noeuds par une liste de noms ou de nom-valeur d'attributs
 * @author Claude Toupin - 2018-12-06
 */
public class AttributesCriteriaSearchNodeXML implements ICriteriaSearchNodesXML {
	/** Indicateur de sensible à la case **/
	private boolean caseSensitive;

	/** Liste des noms des attributs **/
	private String[] attributesNamesList;

	/** Liste des attributs **/
	private NameValue[] attributesList;

	/**
	 * Constructeur de base
	 * @param attributesNamesList Liste des noms des attributs
	 * @param textNode Valeur du texte du noeud
	 * @param nodesNamesHierarchy Hiérarchie des noms des noeuds XML à trouver
	 */
	public AttributesCriteriaSearchNodeXML(String... attributesNamesList) {
		this(true, attributesNamesList);
	}

	/**
	 * Constructeur de base
	 * @param attributesList Liste des noms-valeurs des attributs
	 * @param textNode Valeur du texte du noeud
	 * @param nodesNamesHierarchy Hiérarchie des noms des noeuds XML à trouver
	 */
	public AttributesCriteriaSearchNodeXML(NameValue... attributesList) {
		this(true, attributesList);
	}

	/**
	 * Constructeur de base
	 * @param caseSensitive Indicateur de sensible à la case
	 * @param attributesNamesList Liste des noms des attributs
	 * @param textNode Valeur du texte du noeud
	 * @param nodesNamesHierarchy Hiérarchie des noms des noeuds XML à trouver
	 */
	public AttributesCriteriaSearchNodeXML(boolean caseSensitive, String... attributesNamesList) {
		this.caseSensitive = caseSensitive;
		this.attributesNamesList = attributesNamesList;
		this.attributesList = null;
	}

	/**
	 * Constructeur de base
	 * @param caseSensitive Indicateur de sensible à la case
	 * @param attributesList Liste des noms-valeurs des attributs
	 * @param textNode Valeur du texte du noeud
	 * @param nodesNamesHierarchy Hiérarchie des noms des noeuds XML à trouver
	 */
	public AttributesCriteriaSearchNodeXML(boolean caseSensitive, NameValue... attributesList) {
		this.caseSensitive = caseSensitive;
		this.attributesNamesList = null;
		this.attributesList = attributesList;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.CriteriaSearchNodesXMLBase#getCriteriaSearchNodesXMLType()
	 */
	@Override
	public CriteriasSearchNodesXMLTypes getCriteriaSearchNodesXMLType() {
		return CriteriasSearchNodesXMLTypes.ATTRIBUTES;
	}

	/**
	 * Recherche la liste des noms des attributs
	 * @param parent Le parent courant
	 * @return une liste de noeuds XML trouvés
	 */
	protected List<NodeXML> doSearchByAttributesNamesList(NodeXML parent) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		for (String item : attributesNamesList) {
			boolean found = false;

			PatternData patternData = new PatternData(caseSensitive ? item : item.toLowerCase());

			for (NameValue attribut : parent.getAttributesList()) {
				if (patternData.isMatching(caseSensitive ? attribut.getName() : attribut.getName().toLowerCase())) {
					found = true;
					break;
				}
			}

			if (!found) {
				return result;
			}
		}

		result.add(parent);

		return result;
	}

	/**
	 * Recherche la liste des attributs
	 * @param parent Le parent courant
	 * @return une liste de noeuds XML trouvés
	 */
	protected List<NodeXML> doSearchByAttributesList(NodeXML parent) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		for (NameValue item : attributesList) {
			boolean found = false;

			PatternData patternNameData = new PatternData(caseSensitive ? item.getName() : item.getName().toLowerCase());
			PatternData patternValueData = new PatternData(caseSensitive ? item.getValue() : item.getValue().toLowerCase());

			for (NameValue attribut : parent.getAttributesList()) {
				String name = caseSensitive ? attribut.getName() : attribut.getName().toLowerCase();
				String value = caseSensitive ? attribut.getValue() : attribut.getValue().toLowerCase();

				if (patternNameData.isMatching(name) && patternValueData.isMatching(value)) {
					found = true;
					break;
				}
			}

			if (!found) {
				return result;
			}
		}

		result.add(parent);

		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AttributesCriteriaSearchNodeXML [caseSensitive=" + caseSensitive + ", attributesNamesList=" + Arrays.toString(attributesNamesList) + ", attributesList=" + Arrays.toString(attributesList) + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof AttributesCriteriaSearchNodeXML) {
				AttributesCriteriaSearchNodeXML attributesCriteriaSearchNodeXML = (AttributesCriteriaSearchNodeXML) obj;

				return (caseSensitive == attributesCriteriaSearchNodeXML.isCaseSensitive()) //
						&& OutilsBase.areEquals(attributesNamesList, attributesCriteriaSearchNodeXML.getAttributesNamesList()) //
						&& OutilsBase.areEquals(attributesList, attributesCriteriaSearchNodeXML.getAttributesList()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(attributesList);
		result = prime * result + Arrays.hashCode(attributesNamesList);
		result = prime * result + Objects.hash(caseSensitive);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.CriteriaSearchNodesXMLBase#searchNodesXML(outils.xml.NodeXML)
	 */
	@Override
	public List<NodeXML> searchNodesXML(NodeXML parent) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		if (parent != null) {
			if (attributesNamesList != null) {
				result.addAll(doSearchByAttributesNamesList(parent));
			} else if (attributesList != null) {
				result.addAll(doSearchByAttributesList(parent));
			}
		}

		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.ICriteriaSearchNodesXML#searchNodesXML(java.util.List)
	 */
	@Override
	public List<NodeXML> searchNodesXML(List<NodeXML> parentsList) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		if (parentsList != null) {
			for (NodeXML parent : parentsList) {
				result.addAll(searchNodesXML(parent));
			}
		}

		return result;
	}

	/**
	 * Extrait le champ caseSensitive
	 * @return un boolean
	 */
	public boolean isCaseSensitive() {
		return caseSensitive;
	}

	/**
	 * Modifie le champ caseSensitive
	 * @param caseSensitive La valeur du champ caseSensitive
	 */
	public void setCaseSensitive(boolean caseSensitive) {
		this.caseSensitive = caseSensitive;
	}

	/**
	 * Extrait le champ attributesNamesList
	 * @return un String[]
	 */
	public String[] getAttributesNamesList() {
		return attributesNamesList;
	}

	/**
	 * Modifie le champ attributesNamesList
	 * @param attributesNamesList La valeur du champ attributesNamesList
	 */
	public void setAttributesNamesList(String[] attributesNamesList) {
		this.attributesNamesList = attributesNamesList;
		this.attributesList = null;
	}

	/**
	 * Extrait le champ attributesList
	 * @return un NameValue[]
	 */
	public NameValue[] getAttributesList() {
		return attributesList;
	}

	/**
	 * Modifie le champ attributesList
	 * @param attributesList La valeur du champ attributesList
	 */
	public void setAttributesList(NameValue[] attributesList) {
		this.attributesNamesList = null;
		this.attributesList = attributesList;
	}
}
