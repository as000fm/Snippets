package outils.xml.search;

import java.util.List;

import outils.xml.data.NodeXML;
import outils.xml.search.types.CriteriasSearchNodesXMLTypes;

/**
 * Interface des critères de recherche de noeuds XML
 * @author Claude Toupin - 2018-12-06
 */
public interface ICriteriaSearchNodesXML {
	/**
	 * Extrait le type de critère de recherche de noeuds XML
	 * @return un CriteriasSearchNodesXMLTypes
	 */
	CriteriasSearchNodesXMLTypes getCriteriaSearchNodesXMLType();

	/**
	 * Effectue la recherche sur un parent donné
	 * @param parent Le parent courant
	 * @return une liste de noeuds XML trouvés
	 */
	List<NodeXML> searchNodesXML(NodeXML parent);

	/**
	 * Effectue la recherche sur une liste de parents donné
	 * @param parentsList La liste de parents courant
	 * @return une liste de noeuds XML trouvés
	 */
	List<NodeXML> searchNodesXML(List<NodeXML> parentsList);
}
