package outils.xml.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.patterns.PatternData;
import outils.xml.data.NodeXML;
import outils.xml.search.types.CriteriasSearchNodesXMLTypes;

/**
 * Recherche par noms de noeuds
 * @author Claude Toupin - 2018-12-06
 */
public class NodesCriteriaSearchNodeXML implements ICriteriaSearchNodesXML {
	/** Indicateur de sensible à la case **/
	private boolean caseSensitive;

	/** Hiérarchie des noms des noeuds XML à trouver **/
	private String[] nodesNamesHierarchy;

	/**
	 * Constructeur de base
	 * @param nodesNamesHierarchy Hiérarchie des noms des noeuds XML à trouver
	 */
	public NodesCriteriaSearchNodeXML(String... nodesNamesHierarchy) {
		this(true, nodesNamesHierarchy);
	}

	/**
	 * Constructeur de base
	 * @param caseSensitive Indicateur de sensible à la case
	 * @param nodesNamesHierarchy Hiérarchie des noms des noeuds XML à trouver
	 */
	public NodesCriteriaSearchNodeXML(boolean caseSensitive, String... nodesNamesHierarchy) {
		this.caseSensitive = caseSensitive;
		this.nodesNamesHierarchy = nodesNamesHierarchy;
	}

	/**
	 * Effectue la recherche sur un parent donné
	 * @param parent Le parent courant
	 * @param patternData Le patron du nom de noeud à trouver
	 * @return un NodeXML (null si pas trouvé)
	 */
	protected NodeXML doSearchNodeXML(NodeXML parent, PatternData patternData) {
		NodeXML searchResult = null;

		if (parent != null) {
			if (patternData.isMatching(caseSensitive ? parent.getName() : parent.getName().toLowerCase())) {
				searchResult = parent;
			}
		}

		return searchResult;
	}

	/**
	 * Effectue la recherche sur une liste de parents donné
	 * @param parents La liste des parents courant
	 * @param patternData Le patron du nom de noeud à trouver
	 * @return une liste de noeuds XML trouvés
	 */
	protected List<NodeXML> doSearchNodeXML(List<NodeXML> parents, PatternData patternData) {
		List<NodeXML> searchResult = new ArrayList<NodeXML>();

		if (parents != null) {
			for (NodeXML parent : parents) {
				if (doSearchNodeXML(parent, patternData) != null) {
					searchResult.add(parent);
				}
			}
		}

		return searchResult;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NodesCriteriaSearchNodeXML [caseSensitive=" + caseSensitive + ", nodesNamesHierarchy=" + Arrays.toString(nodesNamesHierarchy) + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof NodesCriteriaSearchNodeXML) {
				NodesCriteriaSearchNodeXML nodesCriteriaSearchNodeXML = (NodesCriteriaSearchNodeXML) obj;

				return (caseSensitive == nodesCriteriaSearchNodeXML.isCaseSensitive()) //
						&& OutilsBase.areEquals(nodesNamesHierarchy, nodesCriteriaSearchNodeXML.getNodesNamesHierarchy()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(nodesNamesHierarchy);
		result = prime * result + Objects.hash(caseSensitive);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.ICriteriaSearchNodesXML#getCriteriaSearchNodesXMLType()
	 */
	@Override
	public CriteriasSearchNodesXMLTypes getCriteriaSearchNodesXMLType() {
		return CriteriasSearchNodesXMLTypes.NODE;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.ICriteriaSearchNodesXML#searchNodesXML(outils.xml.NodeXML)
	 */
	@Override
	public List<NodeXML> searchNodesXML(NodeXML parent) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		if ((parent != null) && (nodesNamesHierarchy != null)) {
			List<NodeXML> search = new ArrayList<NodeXML>();
			search.add(parent);

			for (String nodeName : nodesNamesHierarchy) {
				PatternData patternData = new PatternData(caseSensitive ? nodeName : nodeName.toLowerCase());

				result.clear();

				result.addAll(doSearchNodeXML(search, patternData));

				if (result.isEmpty()) {
					break;
				}

				search.clear();

				for (NodeXML node : result) {
					search.addAll(node.getChildrenList());
				}

				if (search.isEmpty()) {
					break;
				}
			}
		}

		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.ICriteriaSearchNodesXML#searchNodesXML(java.util.List)
	 */
	@Override
	public List<NodeXML> searchNodesXML(List<NodeXML> parentsList) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		if (parentsList != null) {
			for (NodeXML parent : parentsList) {
				result.addAll(searchNodesXML(parent));
			}
		}

		return result;
	}

	/**
	 * Extrait le champ caseSensitive
	 * @return un boolean
	 */
	public boolean isCaseSensitive() {
		return caseSensitive;
	}

	/**
	 * Modifie le champ caseSensitive
	 * @param caseSensitive La valeur du champ caseSensitive
	 */
	public void setCaseSensitive(boolean caseSensitive) {
		this.caseSensitive = caseSensitive;
	}

	/**
	 * Extrait le champ nodesNamesHierarchy
	 * @return un String[]
	 */
	public String[] getNodesNamesHierarchy() {
		return nodesNamesHierarchy;
	}

	/**
	 * Modifie le champ nodesNamesHierarchy
	 * @param nodesNamesHierarchy La valeur du champ nodesNamesHierarchy
	 */
	public void setNodesNamesHierarchy(String[] nodesNamesHierarchy) {
		this.nodesNamesHierarchy = nodesNamesHierarchy;
	}
}
