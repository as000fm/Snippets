package outils.xml.search;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import outils.base.OutilsBase;
import outils.patterns.PatternData;
import outils.xml.data.NodeXML;
import outils.xml.search.types.CriteriasSearchNodesXMLTypes;

/**
 * Recherche de noeuds par valeur de texte
 * @author Claude Toupin - 2018-12-06
 */
public class TextsCriteriaSearchNodeXML implements ICriteriaSearchNodesXML {
	/** Indicateur de sensible à la case **/
	private boolean caseSensitive;

	/** Valeur du texte du noeud **/
	private String textNode;

	/**
	 * Constructeur de base
	 * @param textNode Valeur du texte du noeud
	 */
	public TextsCriteriaSearchNodeXML(String textNode) {
		this(true, textNode);
	}

	/**
	 * Constructeur de base
	 * @param caseSensitive Indicateur de sensible à la case
	 * @param textNode Valeur du texte du noeud
	 */
	public TextsCriteriaSearchNodeXML(boolean caseSensitive, String textNode) {
		this.caseSensitive = caseSensitive;
		this.textNode = textNode;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TextsCriteriaSearchNodeXML [caseSensitive=" + caseSensitive + ", textNode=" + textNode + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (obj instanceof TextsCriteriaSearchNodeXML) {
				TextsCriteriaSearchNodeXML textsCriteriaSearchNodeXML = (TextsCriteriaSearchNodeXML) obj;

				return (caseSensitive == textsCriteriaSearchNodeXML.isCaseSensitive()) //
						&& OutilsBase.areEquals(textNode, textsCriteriaSearchNodeXML.getTextNode()) //
				;
			}
		}

		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(caseSensitive, textNode);
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.ICriteriaSearchNodesXML#getCriteriaSearchNodesXMLType()
	 */
	@Override
	public CriteriasSearchNodesXMLTypes getCriteriaSearchNodesXMLType() {
		return CriteriasSearchNodesXMLTypes.TEXT;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.ICriteriaSearchNodesXML#searchNodesXML(outils.xml.NodeXML)
	 */
	@Override
	public List<NodeXML> searchNodesXML(NodeXML parent) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		if (parent != null) {
			if (textNode == null) {
				if (parent.getText() == null) {
					result.add(parent);
				}
			} else {
				PatternData patternData = new PatternData(caseSensitive ? textNode : textNode.toLowerCase());

				if (patternData.isMatching(caseSensitive ? parent.getText() : OutilsBase.asString(parent.getText()).toLowerCase())) {
					result.add(parent);
				}
			}
		}

		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see outils.xml.search.ICriteriaSearchNodesXML#searchNodesXML(java.util.List)
	 */
	@Override
	public List<NodeXML> searchNodesXML(List<NodeXML> parentsList) {
		List<NodeXML> result = new ArrayList<NodeXML>();

		if (parentsList != null) {
			for (NodeXML parent : parentsList) {
				result.addAll(searchNodesXML(parent));
			}
		}

		return result;
	}

	/**
	 * Extrait le champ caseSensitive
	 * @return un boolean
	 */
	public boolean isCaseSensitive() {
		return caseSensitive;
	}

	/**
	 * Modifie le champ caseSensitive
	 * @param caseSensitive La valeur du champ caseSensitive
	 */
	public void setCaseSensitive(boolean caseSensitive) {
		this.caseSensitive = caseSensitive;
	}

	/**
	 * Extrait le champ textNode
	 * @return un String
	 */
	public String getTextNode() {
		return textNode;
	}

	/**
	 * Modifie le champ textNode
	 * @param textNode La valeur du champ textNode
	 */
	public void setTextNode(String textNode) {
		this.textNode = textNode;
	}

}
