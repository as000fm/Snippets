package outils.xml.search.types;

/**
 * Énumération des types de critères de recherche de noeuds XML
 * @author Claude Toupin - 2018-12-06
 */
public enum CriteriasSearchNodesXMLTypes {
	NODE, TEXT, ATTRIBUTES;
}
