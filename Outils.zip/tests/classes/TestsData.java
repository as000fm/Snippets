package classes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import outils.base.OutilsBase;
import outils.gson.OutilsGson;

/**
 * Génération des données des cas de tests
 */
public class TestsData<T> {
	/** Donnée des tests **/
	final private T data;

	/**
	 * Constructeur de base
	 * @param data Donnée des tests
	 */
	public TestsData(T data) {
		this.data = data;
	}

	/**
	 * Extrait la donnée sous forme de liste
	 * @param items Nombre d'items dans la liste
	 * @return un List
	 */
	protected List<T> getList(int items) {
		List<T> list = new ArrayList<>();

		for (int i = 0; i < items; i++) {
			list.add(data);
		}

		return list;
	}

	/**
	 * Extrait la donnée sous forme d'un tableau
	 * @param items Nombre d'items dans la liste
	 * @return un List
	 */
	protected Object[] getArray(int items) {
		Object[] array = new Object[items];

		for (int i = 0; i < items; i++) {
			array[i] = data;
		}

		return array;
	}

	/**
	 * Extrait la donnée sous forme json
	 * @return un String
	 */
	public String asJSON() {
		return OutilsGson.toJson(data);
	}

	/**
	 * Extrait la donnée sous forme d'une liste json
	 * @param items Nombre d'items dans la liste
	 * @return un String
	 */
	public String asJSONList(int items) {
		if (items < 0) {
			return "";
		}

		return OutilsGson.toJson(getList(items));
	}

	/**
	 * Extrait la donnée sous forme d'un dictionnaire json
	 * @param items Nombre d'items dans le dictionnaire
	 * @return un String
	 */
	public String asJSONMap(int items) {
		if (items < 0) {
			return "";
		}

		Map<String, T> map = new HashMap<>();

		for (int i = 0; i < items; i++) {
			map.put(OutilsBase.asString(i), data);
		}

		return OutilsGson.toJson(map);
	}

	/**
	 * Extrait la donnée sous forme d'un tableau json
	 * @param items Nombre d'items dans le tableau
	 * @return un String
	 */
	public String asJSONArray(int items) {
		if (items < 0) {
			return "";
		}

		return OutilsGson.toJson(getArray(items));
	}

	/**
	 * Extrait la donnée sous forme d'une liste de tableaux json
	 * @param items Nombre d'items dans la liste de tableaux
	 * @return un String
	 */
	public String asJSONArrayList(int items) {
		if (items < 0) {
			return "";
		}

		List<Object[]> list = new ArrayList<>();

		for (int i = 0; i < items; i++) {
			list.add(getArray(i + 1));
		}

		return OutilsGson.toJson(list);
	}

	/**
	 * Extrait la donnée sous forme d'un dictionnaire de tableaux json
	 * @param items Nombre d'items dans le dictionnaire de tableaux
	 * @return un String
	 */
	public String asJSONArrayMap(int items) {
		if (items < 0) {
			return "";
		}

		Map<String, Object[]> map = new HashMap<>();

		for (int i = 0; i < items; i++) {
			map.put(OutilsBase.asString(i), getArray(i + 1));
		}

		return OutilsGson.toJson(map);
	}

	/**
	 * Extrait la donnée sous forme d'un dictionnaire de listes json
	 * @param items Nombre d'items dans le dictionnaire de listes
	 * @return un String
	 */
	public String asJSONListMap(int items) {
		if (items < 0) {
			return "";
		}

		Map<String, List<T>> map = new HashMap<>();

		for (int i = 0; i < items; i++) {
			map.put(OutilsBase.asString(i), getList(i + 1));
		}

		return OutilsGson.toJson(map);
	}
	
	/**
	 * Extrait la donnée sous forme d'une liste json
	 * @param items Nombre d'items dans la liste
	 * @return un JsonArray
	 */
	public JsonArray getJsonArray(int items) {
		 JsonElement element = JsonParser.parseString(asJSONArray(items));
		 
		 if (element.isJsonArray()) {
			 return element.getAsJsonArray();
		 }
		 
		 return new JsonArray();
	}
}