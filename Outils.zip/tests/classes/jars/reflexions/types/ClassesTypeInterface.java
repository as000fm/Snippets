package classes.jars.reflexions.types;

/**
 * Interface de test
 * @author Claude Toupin - 4 févr. 2023
 */
public interface ClassesTypeInterface {

}
