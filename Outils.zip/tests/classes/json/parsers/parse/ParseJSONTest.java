package classes.json.parsers.parse;

import java.util.List;
import java.util.Map;

import outils.gson.annotations.JSON;
import outils.gson.annotations.NO_JSON;

/**
 * Classe de test pour ParseJSONGenerator
 * @author Claude Toupin - 11 févr. 2023
 */
public class ParseJSONTest {

	@JSON(name = "authenticationResultCode")
	private String authenticationResultCode;

	@NO_JSON
	private int value;

	private List<Integer[]> list;

	private int array[];

	private Map<String, Integer> map;

	public ParseJSONTest(String authenticationResultCode, List<Integer[]> list, int[] array, Map<String, Integer> map) {
		this.authenticationResultCode = authenticationResultCode;
		this.value = 0;
		this.list = list;
		this.array = array;
		this.map = map;
	}

	public String getAuthenticationResultCode() {
		return authenticationResultCode;
	}

	public void setAuthenticationResultCode(String authenticationResultCode) {
		this.authenticationResultCode = authenticationResultCode;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public List<Integer[]> getList() {
		return list;
	}

	public void setList(List<Integer[]> list) {
		this.list = list;
	}

	public int[] getArray() {
		return array;
	}

	public void setArray(int[] array) {
		this.array = array;
	}

	public Map<String, Integer> getMap() {
		return map;
	}

	public void setMap(Map<String, Integer> map) {
		this.map = map;
	}

}
