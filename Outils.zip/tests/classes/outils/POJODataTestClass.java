package classes.outils;

import java.util.Date;
import java.util.Objects;

/**
 * Classe de test de base (POJO)
 * @author Claude Toupin - 27 janv. 2023
 */
public class POJODataTestClass {
	/** Champ str **/
	private String str;

	/** Champ number **/
	private int number;

	/** Champ date **/
	private Date date;

	/** Champ big **/
	private Long big;

	/**
	 * Constructeur de base
	 */
	public POJODataTestClass() {
		this("Test", 10, new Date(1583025602029L), null);
	}

	/**
	 * Constructeur de base
	 * @param str Champ str
	 * @param number Champ number
	 * @param date Champ date
	 */
	public POJODataTestClass(String str, int number, Date date, Long big) {
		this.str = str;
		this.number = number;
		this.date = date;
		this.big = big;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "POJODataTestClass [str=" + str + ", number=" + number + ", date=" + date + ", big=" + big + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(big, date, number, str);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		POJODataTestClass other = (POJODataTestClass) obj;
		return Objects.equals(big, other.big) && Objects.equals(date, other.date) && number == other.number && Objects.equals(str, other.str);
	}

	/**
	 * Extrait le champ str
	 * @return un String
	 */
	public String getStr() {
		return str;
	}

	/**
	 * Modifie le champ str
	 * @param str La valeur du champ str
	 */
	public void setStr(String str) {
		this.str = str;
	}

	/**
	 * Extrait le champ number
	 * @return un int
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * Modifie le champ number
	 * @param number La valeur du champ number
	 */
	public void setNumber(int number) {
		this.number = number;
	}

	/**
	 * Extrait le champ date
	 * @return un Date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Modifie le champ date
	 * @param date La valeur du champ date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Extrait le champ big
	 * @return un Long
	 */
	public Long getBig() {
		return big;
	}

	/**
	 * Modifie le champ big
	 * @param big La valeur du champ big
	 */
	public void setBig(Long big) {
		this.big = big;
	}

}
