package classes.reflexions;

public class OutilsReflexionsTestClass {
	private int test;

	private String value;

	public OutilsReflexionsTestClass() {
		this(0, null);
	}

	public OutilsReflexionsTestClass(int test, String value) {
		this.test = test;
		this.value = value;
	}

	public int getTest() {
		return test;
	}

	public void setTest(int test) {
		this.test = test;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
