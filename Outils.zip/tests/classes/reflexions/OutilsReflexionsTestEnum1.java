package classes.reflexions;

public enum OutilsReflexionsTestEnum1 {
	A,B;
	
}
