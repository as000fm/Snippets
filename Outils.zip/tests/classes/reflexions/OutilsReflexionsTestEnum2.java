package classes.reflexions;

public enum OutilsReflexionsTestEnum2 {
	A,B;
	
	public static OutilsReflexionsTestEnum2 getOutilsReflexionsEnum(String value) {
		return null;
	}
}
