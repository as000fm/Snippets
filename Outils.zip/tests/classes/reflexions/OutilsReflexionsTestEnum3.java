package classes.reflexions;

public enum OutilsReflexionsTestEnum3 {
	A,B;
	
	public static OutilsReflexionsTestEnum3 getOutilsReflexionsEnum1(String value) {
		return null;
	}
	
	public static OutilsReflexionsTestEnum3 getOutilsReflexionsEnum2(String value) {
		return null;
	}
}
