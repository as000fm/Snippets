package classes.reflexions;

public interface OutilsReflexionsTestInterface {

}
