package classes.reflexions.data;

/**
 * Classe de test pour ConstructorInfoData
 * @author Claude Toupin - 3 févr. 2023
 */
public class ConstructorInfoDataTestClass {

	public ConstructorInfoDataTestClass(String param) throws Exception {
		//
	}
}
