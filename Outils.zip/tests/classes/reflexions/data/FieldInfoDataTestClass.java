package classes.reflexions.data;

import outils.gson.annotations.NO_JSON;

/**
 * Classe de test pour FieldInfoData
 * @author Claude Toupin - 1 févr. 2023
 */
public class FieldInfoDataTestClass {
	public String field;
	
	@NO_JSON
	public String json;
}
