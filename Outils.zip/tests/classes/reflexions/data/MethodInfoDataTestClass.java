package classes.reflexions.data;

import outils.tests.automated.annotations.SkipTesting;

/**
 * Classe de test pour MethodInfoData
 * @author Claude Toupin - 3 févr. 2023
 */
public class MethodInfoDataTestClass {

	public MethodInfoDataTestClass() throws Exception {
		
	}

	@SkipTesting
	public int test() throws Exception {
		return 0;
	}
}
