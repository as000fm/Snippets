package classes.reflexions.data;

import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import outils.tests.automated.annotations.SkipTesting;

/**
 * Classe de test pour ParameterInfoData
 * @author Claude Toupin - 3 févr. 2023
 */
public class ParameterInfoDataTestClass {

	@Documented
	@Retention(RUNTIME)
	@Target(PARAMETER)
	public @interface TestParm {

	}

	public ParameterInfoDataTestClass() throws Exception {
		
	}

	@SkipTesting
	public int test(@TestParm int test) throws Exception {
		return test;
	}
}
