package classes.reflexions.data;

import java.util.List;

/**
 * Classe de test pour TypeInfoData
 * @author Claude Toupin - 4 févr. 2023
 */
public class TypeInfoDataTestClass<E> {
	public E value;
	
	public E[] array;
	
	public List<?> list;
	
	public List<E> values;

	public static class InnerClass {

	}
}
