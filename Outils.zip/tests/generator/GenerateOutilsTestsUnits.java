package generator;

import outils.commun.OutilsCommun;
import tests.automated.AutomatedTestsUnitsGenerator;

/**
 * Générateur des tests unitaires du projet Outils
 * @author Claude Toupin - 29 déc. 2021
 */
public class GenerateOutilsTestsUnits {
	/** Répertoire courant **/
	final public static String BASE_DIR = OutilsCommun.getCurrentDirectory();

	/**
	 * Générateur des tests automatisés du projet Outils
	 * @param args Arguments
	 * @throws Exception en cas d'erreur...
	 */
	public static void main(String[] args) throws Exception {
		boolean autoUpdate = (args.length > 0);
		boolean debug = (args.length > 1);

		AutomatedTestsUnitsGenerator generator = new AutomatedTestsUnitsGenerator( //
				OutilsCommun.getCurrentEclipseProject(), // Nom du project
				GenerateOutilsTestsUnits.class, // Classe du générateur des tests automatisés
				OutilsCommun.getFullname(BASE_DIR, "tests"), // Répertoire de sortie
				"junit", // Package de sortie
				autoUpdate, // Indicateur de mise à jour automatique des fichiers de tests du répertoire de sortie produits si le fichier source a été modifié
				debug // Indicateur de mode de débogage des tests en groovy (i.e. 1 test à la fois)
		);

		generator.generateProjectTestsUnits( //
				OutilsCommun.getFullname(BASE_DIR, "src"), //
				OutilsCommun.getFullname(BASE_DIR, "generators") //
		);
	}

}
